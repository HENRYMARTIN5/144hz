package me.zero.alpine.event;

public interface EventPriority {
  public static final int HIGHEST = 200;
  
  public static final int HIGH = 100;
  
  public static final int MEDIUM = 0;
  
  public static final int LOW = -100;
  
  public static final int LOWEST = -200;
  
  public static final int DEFAULT = 0;
}


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\Alpine-1.9.jar!\me\zero\alpine\event\EventPriority.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */