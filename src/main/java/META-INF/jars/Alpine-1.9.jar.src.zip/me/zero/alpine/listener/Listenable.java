package me.zero.alpine.listener;

public interface Listenable {}


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\Alpine-1.9.jar!\me\zero\alpine\listener\Listenable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */