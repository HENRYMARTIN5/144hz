package me.zero.alpine.event.type;

public interface ICancellable {
  void cancel();
  
  boolean isCancelled();
}


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\Alpine-1.9.jar!\me\zero\alpine\event\type\ICancellable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */