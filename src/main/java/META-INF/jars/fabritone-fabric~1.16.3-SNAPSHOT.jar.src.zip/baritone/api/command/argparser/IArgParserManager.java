package baritone.api.command.argparser;

import baritone.api.command.argument.ICommandArgument;
import baritone.api.command.exception.CommandInvalidTypeException;
import baritone.api.command.registry.Registry;

public interface IArgParserManager {
  <T> IArgParser.Stateless<T> getParserStateless(Class<T> paramClass);
  
  <T, S> IArgParser.Stated<T, S> getParserStated(Class<T> paramClass, Class<S> paramClass1);
  
  <T> T parseStateless(Class<T> paramClass, ICommandArgument paramICommandArgument) throws CommandInvalidTypeException;
  
  <T, S> T parseStated(Class<T> paramClass, Class<S> paramClass1, ICommandArgument paramICommandArgument, S paramS) throws CommandInvalidTypeException;
  
  Registry<IArgParser> getRegistry();
}


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\command\argparser\IArgParserManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */