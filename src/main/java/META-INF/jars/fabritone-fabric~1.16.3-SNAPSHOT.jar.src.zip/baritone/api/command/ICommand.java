/*    */ package baritone.api.command;
/*    */ 
/*    */ import baritone.api.command.argument.IArgConsumer;
/*    */ import baritone.api.command.exception.CommandException;
/*    */ import baritone.api.utils.Helper;
/*    */ import java.util.List;
/*    */ import java.util.stream.Stream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ICommand
/*    */   extends Helper
/*    */ {
/*    */   void execute(String paramString, IArgConsumer paramIArgConsumer) throws CommandException;
/*    */   
/*    */   Stream<String> tabComplete(String paramString, IArgConsumer paramIArgConsumer) throws CommandException;
/*    */   
/*    */   String getShortDesc();
/*    */   
/*    */   List<String> getLongDesc();
/*    */   
/*    */   List<String> getNames();
/*    */   
/*    */   default boolean hiddenFromHelp() {
/* 65 */     return false;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\command\ICommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */