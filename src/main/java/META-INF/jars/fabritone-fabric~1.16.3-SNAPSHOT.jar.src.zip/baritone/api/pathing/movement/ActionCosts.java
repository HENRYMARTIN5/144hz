/*    */ package baritone.api.pathing.movement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ActionCosts
/*    */ {
/*    */   public static final double WALK_ONE_BLOCK_COST = 4.63284688441047D;
/*    */   public static final double WALK_ONE_IN_WATER_COST = 9.09090909090909D;
/*    */   public static final double WALK_ONE_OVER_SOUL_SAND_COST = 9.26569376882094D;
/*    */   public static final double LADDER_UP_ONE_COST = 8.51063829787234D;
/*    */   public static final double LADDER_DOWN_ONE_COST = 6.666666666666667D;
/*    */   public static final double SNEAK_ONE_BLOCK_COST = 15.384615384615383D;
/*    */   public static final double SPRINT_ONE_BLOCK_COST = 3.563791874554526D;
/*    */   public static final double SPRINT_MULTIPLIER = 0.7692444761225944D;
/*    */   public static final double WALK_OFF_BLOCK_COST = 3.7062775075283763D;
/*    */   public static final double CENTER_AFTER_FALL_COST = 0.9265693768820937D;
/*    */   public static final double COST_INF = 1000000.0D;
/* 48 */   public static final double[] FALL_N_BLOCKS_COST = generateFallNBlocksCost();
/*    */   
/* 50 */   public static final double FALL_1_25_BLOCKS_COST = distanceToTicks(1.25D);
/* 51 */   public static final double FALL_0_25_BLOCKS_COST = distanceToTicks(0.25D);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 64 */   public static final double JUMP_ONE_BLOCK_COST = FALL_1_25_BLOCKS_COST - FALL_0_25_BLOCKS_COST;
/*    */ 
/*    */   
/*    */   static double[] generateFallNBlocksCost() {
/* 68 */     double[] costs = new double[257];
/* 69 */     for (int i = 0; i < 257; i++) {
/* 70 */       costs[i] = distanceToTicks(i);
/*    */     }
/* 72 */     return costs;
/*    */   }
/*    */   
/*    */   static double velocity(int ticks) {
/* 76 */     return (Math.pow(0.98D, ticks) - 1.0D) * -3.92D;
/*    */   }
/*    */   
/*    */   static double oldFormula(double ticks) {
/* 80 */     return -3.92D * (99.0D - 49.5D * (Math.pow(0.98D, ticks) + 1.0D) - ticks);
/*    */   }
/*    */   
/*    */   static double distanceToTicks(double distance) {
/* 84 */     if (distance == 0.0D) {
/* 85 */       return 0.0D;
/*    */     }
/* 87 */     double tmpDistance = distance;
/* 88 */     int tickCount = 0;
/*    */     while (true) {
/* 90 */       double fallDistance = velocity(tickCount);
/* 91 */       if (tmpDistance <= fallDistance) {
/* 92 */         return tickCount + tmpDistance / fallDistance;
/*    */       }
/* 94 */       tmpDistance -= fallDistance;
/* 95 */       tickCount++;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\pathing\movement\ActionCosts.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */