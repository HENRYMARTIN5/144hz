/*    */ package baritone.api.utils;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import java.util.function.Function;
/*    */ import java.util.stream.Stream;
/*    */ import net.minecraft.class_1799;
/*    */ import net.minecraft.class_2248;
/*    */ import net.minecraft.class_2680;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlockOptionalMetaLookup
/*    */ {
/*    */   private final BlockOptionalMeta[] boms;
/*    */   
/*    */   public BlockOptionalMetaLookup(BlockOptionalMeta... boms) {
/* 33 */     this.boms = boms;
/*    */   }
/*    */   
/*    */   public BlockOptionalMetaLookup(class_2248... blocks) {
/* 37 */     this
/*    */       
/* 39 */       .boms = (BlockOptionalMeta[])Stream.<class_2248>of(blocks).map(BlockOptionalMeta::new).toArray(x$0 -> new BlockOptionalMeta[x$0]);
/*    */   }
/*    */   
/*    */   public BlockOptionalMetaLookup(List<class_2248> blocks) {
/* 43 */     this
/*    */       
/* 45 */       .boms = (BlockOptionalMeta[])blocks.stream().map(BlockOptionalMeta::new).toArray(x$0 -> new BlockOptionalMeta[x$0]);
/*    */   }
/*    */   
/*    */   public BlockOptionalMetaLookup(String... blocks) {
/* 49 */     this
/*    */       
/* 51 */       .boms = (BlockOptionalMeta[])Stream.<String>of(blocks).map(BlockOptionalMeta::new).toArray(x$0 -> new BlockOptionalMeta[x$0]);
/*    */   }
/*    */   
/*    */   public boolean has(class_2248 block) {
/* 55 */     for (BlockOptionalMeta bom : this.boms) {
/* 56 */       if (bom.getBlock() == block) {
/* 57 */         return true;
/*    */       }
/*    */     } 
/*    */     
/* 61 */     return false;
/*    */   }
/*    */   
/*    */   public boolean has(class_2680 state) {
/* 65 */     for (BlockOptionalMeta bom : this.boms) {
/* 66 */       if (bom.matches(state)) {
/* 67 */         return true;
/*    */       }
/*    */     } 
/*    */     
/* 71 */     return false;
/*    */   }
/*    */   
/*    */   public boolean has(class_1799 stack) {
/* 75 */     for (BlockOptionalMeta bom : this.boms) {
/* 76 */       if (bom.matches(stack)) {
/* 77 */         return true;
/*    */       }
/*    */     } 
/*    */     
/* 81 */     return false;
/*    */   }
/*    */   
/*    */   public List<BlockOptionalMeta> blocks() {
/* 85 */     return Arrays.asList(this.boms);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 90 */     return String.format("BlockOptionalMetaLookup{%s}", new Object[] {
/*    */           
/* 92 */           Arrays.toString((Object[])this.boms)
/*    */         });
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\ap\\utils\BlockOptionalMetaLookup.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */