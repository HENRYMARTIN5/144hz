package baritone.api.process;

import java.nio.file.Path;

public interface IExploreProcess extends IBaritoneProcess {
  void explore(int paramInt1, int paramInt2);
  
  void applyJsonFilter(Path paramPath, boolean paramBoolean) throws Exception;
}


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\process\IExploreProcess.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */