/*    */ package baritone.api.process;
/*    */ 
/*    */ import baritone.api.pathing.goals.Goal;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ICustomGoalProcess
/*    */   extends IBaritoneProcess
/*    */ {
/*    */   void setGoal(Goal paramGoal);
/*    */   
/*    */   void path();
/*    */   
/*    */   Goal getGoal();
/*    */   
/*    */   default void setGoalAndPath(Goal goal) {
/* 47 */     setGoal(goal);
/* 48 */     path();
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\process\ICustomGoalProcess.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */