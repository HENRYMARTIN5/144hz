package baritone.api.cache;

import java.util.ArrayList;
import net.minecraft.class_2338;
import net.minecraft.class_2818;

public interface ICachedWorld {
  ICachedRegion getRegion(int paramInt1, int paramInt2);
  
  void queueForPacking(class_2818 paramclass_2818);
  
  boolean isCached(int paramInt1, int paramInt2);
  
  ArrayList<class_2338> getLocationsOf(String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  void reloadAllFromDisk();
  
  void save();
}


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\cache\ICachedWorld.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */