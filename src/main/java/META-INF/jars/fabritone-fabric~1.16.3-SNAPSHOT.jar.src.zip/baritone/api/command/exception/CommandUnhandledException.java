/*    */ package baritone.api.command.exception;
/*    */ 
/*    */ import baritone.api.command.ICommand;
/*    */ import baritone.api.command.argument.ICommandArgument;
/*    */ import baritone.api.utils.Helper;
/*    */ import java.util.List;
/*    */ import net.minecraft.class_124;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CommandUnhandledException
/*    */   extends RuntimeException
/*    */   implements ICommandException
/*    */ {
/*    */   public CommandUnhandledException(String message) {
/* 31 */     super(message);
/*    */   }
/*    */   
/*    */   public CommandUnhandledException(Throwable cause) {
/* 35 */     super(cause);
/*    */   }
/*    */ 
/*    */   
/*    */   public void handle(ICommand command, List<ICommandArgument> args) {
/* 40 */     Helper.HELPER.logDirect("An unhandled exception occurred. The error is in your game's log, please report this at https://github.com/cabaletta/baritone/issues", class_124.field_1061);
/*    */ 
/*    */ 
/*    */     
/* 44 */     printStackTrace();
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\command\exception\CommandUnhandledException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */