package baritone.api.behavior;

import baritone.api.utils.Rotation;

public interface ILookBehavior extends IBehavior {
  void updateTarget(Rotation paramRotation, boolean paramBoolean);
}


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\behavior\ILookBehavior.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */