/*    */ package baritone.api.utils;
/*    */ 
/*    */ import net.minecraft.class_1297;
/*    */ import net.minecraft.class_239;
/*    */ import net.minecraft.class_243;
/*    */ import net.minecraft.class_3959;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RayTraceUtils
/*    */ {
/*    */   public static class_239 rayTraceTowards(class_1297 entity, Rotation rotation, double blockReachDistance) {
/* 44 */     return rayTraceTowards(entity, rotation, blockReachDistance, false);
/*    */   }
/*    */   
/*    */   public static class_239 rayTraceTowards(class_1297 entity, Rotation rotation, double blockReachDistance, boolean wouldSneak) {
/*    */     class_243 start;
/* 49 */     if (wouldSneak) {
/* 50 */       start = inferSneakingEyePosition(entity);
/*    */     } else {
/* 52 */       start = entity.method_5836(1.0F);
/*    */     } 
/* 54 */     class_243 direction = RotationUtils.calcVector3dFromRotation(rotation);
/* 55 */     class_243 end = start.method_1031(direction.field_1352 * blockReachDistance, direction.field_1351 * blockReachDistance, direction.field_1350 * blockReachDistance);
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 60 */     return (class_239)entity.field_6002.method_17742(new class_3959(start, end, class_3959.class_3960.field_17559, class_3959.class_242.field_1348, entity));
/*    */   }
/*    */   
/*    */   public static class_243 inferSneakingEyePosition(class_1297 entity) {
/* 64 */     return new class_243(entity.method_23317(), entity.method_23318() + IPlayerContext.eyeHeight(true), entity.method_23321());
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\ap\\utils\RayTraceUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */