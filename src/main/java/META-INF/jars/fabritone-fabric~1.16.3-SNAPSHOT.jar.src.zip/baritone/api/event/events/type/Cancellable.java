/*    */ package baritone.api.event.events.type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Cancellable
/*    */   implements ICancellable
/*    */ {
/*    */   private boolean cancelled;
/*    */   
/*    */   public final void cancel() {
/* 33 */     this.cancelled = true;
/*    */   }
/*    */ 
/*    */   
/*    */   public final boolean isCancelled() {
/* 38 */     return this.cancelled;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\event\events\type\Cancellable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */