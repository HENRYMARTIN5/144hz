package baritone.api.utils;

import baritone.api.behavior.IBehavior;
import baritone.api.utils.input.Input;

public interface IInputOverrideHandler extends IBehavior {
  boolean isInputForcedDown(Input paramInput);
  
  void setInputForceState(Input paramInput, boolean paramBoolean);
  
  void clearAllKeys();
}


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\ap\\utils\IInputOverrideHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */