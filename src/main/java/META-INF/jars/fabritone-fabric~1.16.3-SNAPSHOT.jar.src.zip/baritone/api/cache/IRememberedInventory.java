package baritone.api.cache;

import java.util.List;
import net.minecraft.class_1799;

public interface IRememberedInventory {
  List<class_1799> getContents();
  
  int getSize();
}


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\cache\IRememberedInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */