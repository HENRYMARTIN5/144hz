/*    */ package baritone.api.process;
/*    */ 
/*    */ import baritone.api.schematic.ISchematic;
/*    */ import java.io.File;
/*    */ import java.util.List;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_2382;
/*    */ import net.minecraft.class_2680;
/*    */ import net.minecraft.class_310;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IBuilderProcess
/*    */   extends IBaritoneProcess
/*    */ {
/*    */   void build(String paramString, ISchematic paramISchematic, class_2382 paramclass_2382);
/*    */   
/*    */   boolean build(String paramString, File paramFile, class_2382 paramclass_2382);
/*    */   
/*    */   default boolean build(String schematicFile, class_2338 origin) {
/* 55 */     File file = new File(new File((class_310.method_1551()).field_1697, "schematics"), schematicFile);
/* 56 */     return build(schematicFile, file, (class_2382)origin);
/*    */   }
/*    */   
/*    */   void buildOpenSchematic();
/*    */   
/*    */   void pause();
/*    */   
/*    */   boolean isPaused();
/*    */   
/*    */   void resume();
/*    */   
/*    */   void clearArea(class_2338 paramclass_23381, class_2338 paramclass_23382);
/*    */   
/*    */   List<class_2680> getApproxPlaceable();
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\process\IBuilderProcess.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */