/*     */ package baritone.api.cache;
/*     */ 
/*     */ import baritone.api.utils.BetterBlockPos;
/*     */ import java.util.Date;
/*     */ import net.minecraft.class_2338;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Waypoint
/*     */   implements IWaypoint
/*     */ {
/*     */   private final String name;
/*     */   private final IWaypoint.Tag tag;
/*     */   private final long creationTimestamp;
/*     */   private final BetterBlockPos location;
/*     */   
/*     */   public Waypoint(String name, IWaypoint.Tag tag, BetterBlockPos location) {
/*  37 */     this(name, tag, location, System.currentTimeMillis());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Waypoint(String name, IWaypoint.Tag tag, BetterBlockPos location, long creationTimestamp) {
/*  50 */     this.name = name;
/*  51 */     this.tag = tag;
/*  52 */     this.location = location;
/*  53 */     this.creationTimestamp = creationTimestamp;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  58 */     return this.name.hashCode() ^ this.tag.hashCode() ^ this.location.hashCode() ^ Long.hashCode(this.creationTimestamp);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  63 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public IWaypoint.Tag getTag() {
/*  68 */     return this.tag;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getCreationTimestamp() {
/*  73 */     return this.creationTimestamp;
/*     */   }
/*     */ 
/*     */   
/*     */   public BetterBlockPos getLocation() {
/*  78 */     return this.location;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  83 */     return String.format("%s %s %s", new Object[] { this.name, 
/*     */ 
/*     */           
/*  86 */           BetterBlockPos.from((class_2338)this.location).toString(), (new Date(this.creationTimestamp))
/*  87 */           .toString() });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  93 */     if (o == null) {
/*  94 */       return false;
/*     */     }
/*  96 */     if (!(o instanceof IWaypoint)) {
/*  97 */       return false;
/*     */     }
/*  99 */     IWaypoint w = (IWaypoint)o;
/* 100 */     return (this.name.equals(w.getName()) && this.tag == w.getTag() && this.location.equals(w.getLocation()));
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\cache\Waypoint.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */