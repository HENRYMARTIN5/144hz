/*    */ package baritone.api.command.datatypes;
/*    */ 
/*    */ import baritone.api.command.argument.IArgConsumer;
/*    */ import baritone.api.command.exception.CommandException;
/*    */ import java.util.regex.Matcher;
/*    */ import java.util.regex.Pattern;
/*    */ import java.util.stream.Stream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum RelativeCoordinate
/*    */   implements IDatatypePost<Double, Double>
/*    */ {
/* 28 */   INSTANCE; static {
/* 29 */     PATTERN = Pattern.compile("^(~?)([+-]?(?:\\d+(?:\\.\\d*)?|\\.\\d+)([k-k]?)|)$");
/*    */   }
/*    */   private static Pattern PATTERN;
/*    */   public Double apply(IDatatypeContext ctx, Double origin) throws CommandException {
/* 33 */     if (origin == null) {
/* 34 */       origin = Double.valueOf(0.0D);
/*    */     }
/*    */     
/* 37 */     Matcher matcher = PATTERN.matcher(ctx.getConsumer().getString());
/* 38 */     if (!matcher.matches()) {
/* 39 */       throw new IllegalArgumentException("pattern doesn't match");
/*    */     }
/*    */     
/* 42 */     boolean isRelative = !matcher.group(1).isEmpty();
/*    */     
/* 44 */     double offset = matcher.group(2).isEmpty() ? 0.0D : Double.parseDouble(matcher.group(2).replaceAll("k", ""));
/*    */     
/* 46 */     if (matcher.group(2).contains("k")) {
/* 47 */       offset *= 1000.0D;
/*    */     }
/*    */     
/* 50 */     if (isRelative) {
/* 51 */       return Double.valueOf(origin.doubleValue() + offset);
/*    */     }
/* 53 */     return Double.valueOf(offset);
/*    */   }
/*    */ 
/*    */   
/*    */   public Stream<String> tabComplete(IDatatypeContext ctx) throws CommandException {
/* 58 */     IArgConsumer consumer = ctx.getConsumer();
/* 59 */     if (!consumer.has(2) && consumer.getString().matches("^(~|$)")) {
/* 60 */       return Stream.of("~");
/*    */     }
/* 62 */     return Stream.empty();
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\command\datatypes\RelativeCoordinate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */