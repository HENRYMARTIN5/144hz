/*     */ package baritone.api.process;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface IBaritoneProcess
/*     */ {
/*     */   public static final double DEFAULT_PRIORITY = -1.0D;
/*     */   
/*     */   boolean isActive();
/*     */   
/*     */   PathingCommand onTick(boolean paramBoolean1, boolean paramBoolean2);
/*     */   
/*     */   boolean isTemporary();
/*     */   
/*     */   void onLostControl();
/*     */   
/*     */   default double priority() {
/*  96 */     return -1.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default String displayName() {
/* 105 */     if (!isActive())
/*     */     {
/*     */       
/* 108 */       return "INACTIVE";
/*     */     }
/* 110 */     return displayName0();
/*     */   }
/*     */   
/*     */   String displayName0();
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\process\IBaritoneProcess.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */