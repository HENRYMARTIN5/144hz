/*    */ package baritone.api;
/*    */ 
/*    */ import baritone.api.utils.SettingsUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BaritoneAPI
/*    */ {
/*    */   private static final IBaritoneProvider provider;
/* 34 */   private static final Settings settings = new Settings(); static {
/* 35 */     SettingsUtil.readAndApply(settings);
/*    */     
/*    */     try {
/* 38 */       provider = (IBaritoneProvider)Class.forName("baritone.BaritoneProvider").newInstance();
/* 39 */     } catch (ReflectiveOperationException ex) {
/* 40 */       throw new RuntimeException(ex);
/*    */     } 
/*    */   }
/*    */   
/*    */   public static IBaritoneProvider getProvider() {
/* 45 */     return provider;
/*    */   }
/*    */   
/*    */   public static Settings getSettings() {
/* 49 */     return settings;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\BaritoneAPI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */