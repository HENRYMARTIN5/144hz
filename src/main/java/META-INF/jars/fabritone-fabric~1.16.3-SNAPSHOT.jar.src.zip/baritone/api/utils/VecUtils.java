/*     */ package baritone.api.utils;
/*     */ 
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1922;
/*     */ import net.minecraft.class_1937;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_265;
/*     */ import net.minecraft.class_2680;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class VecUtils
/*     */ {
/*     */   public static class_243 calculateBlockCenter(class_1937 world, class_2338 pos) {
/*  46 */     class_2680 b = world.method_8320(pos);
/*  47 */     class_265 shape = b.method_26220((class_1922)world, pos);
/*  48 */     if (shape.method_1110()) {
/*  49 */       return getBlockPosCenter(pos);
/*     */     }
/*  51 */     double xDiff = (shape.method_1091(class_2350.class_2351.field_11048) + shape.method_1105(class_2350.class_2351.field_11048)) / 2.0D;
/*  52 */     double yDiff = (shape.method_1091(class_2350.class_2351.field_11052) + shape.method_1105(class_2350.class_2351.field_11052)) / 2.0D;
/*  53 */     double zDiff = (shape.method_1091(class_2350.class_2351.field_11051) + shape.method_1105(class_2350.class_2351.field_11051)) / 2.0D;
/*  54 */     if (Double.isNaN(xDiff) || Double.isNaN(yDiff) || Double.isNaN(zDiff)) {
/*  55 */       throw new IllegalStateException(b + " " + pos + " " + shape);
/*     */     }
/*  57 */     if (b.method_26204() instanceof net.minecraft.class_2358) {
/*  58 */       yDiff = 0.0D;
/*     */     }
/*  60 */     return new class_243(pos
/*  61 */         .method_10263() + xDiff, pos
/*  62 */         .method_10264() + yDiff, pos
/*  63 */         .method_10260() + zDiff);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class_243 getBlockPosCenter(class_2338 pos) {
/*  78 */     return new class_243(pos.method_10263() + 0.5D, pos.method_10264() + 0.5D, pos.method_10260() + 0.5D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double distanceToCenter(class_2338 pos, double x, double y, double z) {
/*  92 */     double xdiff = pos.method_10263() + 0.5D - x;
/*  93 */     double ydiff = pos.method_10264() + 0.5D - y;
/*  94 */     double zdiff = pos.method_10260() + 0.5D - z;
/*  95 */     return Math.sqrt(xdiff * xdiff + ydiff * ydiff + zdiff * zdiff);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double entityDistanceToCenter(class_1297 entity, class_2338 pos) {
/* 108 */     return distanceToCenter(pos, entity.method_23317(), entity.method_23318(), entity.method_23321());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double entityFlatDistanceToCenter(class_1297 entity, class_2338 pos) {
/* 121 */     return distanceToCenter(pos, entity.method_23317(), pos.method_10264() + 0.5D, entity.method_23321());
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\ap\\utils\VecUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */