/*    */ package baritone.api.schematic;
/*    */ 
/*    */ import baritone.api.utils.BlockOptionalMetaLookup;
/*    */ import net.minecraft.class_2680;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReplaceSchematic
/*    */   extends MaskSchematic
/*    */ {
/*    */   private final BlockOptionalMetaLookup filter;
/*    */   private final Boolean[][][] cache;
/*    */   
/*    */   public ReplaceSchematic(ISchematic schematic, BlockOptionalMetaLookup filter) {
/* 29 */     super(schematic);
/* 30 */     this.filter = filter;
/* 31 */     this.cache = new Boolean[widthX()][heightY()][lengthZ()];
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean partOfMask(int x, int y, int z, class_2680 currentState) {
/* 36 */     if (this.cache[x][y][z] == null) {
/* 37 */       this.cache[x][y][z] = Boolean.valueOf(this.filter.has(currentState));
/*    */     }
/* 39 */     return this.cache[x][y][z].booleanValue();
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\schematic\ReplaceSchematic.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */