/*    */ package baritone.api.command;
/*    */ 
/*    */ import baritone.api.IBaritone;
/*    */ import baritone.api.utils.IPlayerContext;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.Locale;
/*    */ import java.util.stream.Collectors;
/*    */ import java.util.stream.Stream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Command
/*    */   implements ICommand
/*    */ {
/*    */   protected IBaritone baritone;
/*    */   protected IPlayerContext ctx;
/*    */   protected final List<String> names;
/*    */   
/*    */   protected Command(IBaritone baritone, String... names) {
/* 57 */     this.names = Collections.unmodifiableList((List<? extends String>)Stream.<String>of(names)
/* 58 */         .map(s -> s.toLowerCase(Locale.US))
/* 59 */         .collect(Collectors.toList()));
/* 60 */     this.baritone = baritone;
/* 61 */     this.ctx = baritone.getPlayerContext();
/*    */   }
/*    */ 
/*    */   
/*    */   public final List<String> getNames() {
/* 66 */     return this.names;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\command\Command.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */