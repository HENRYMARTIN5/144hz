package baritone.api.schematic.format;

import baritone.api.schematic.IStaticSchematic;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

public interface ISchematicFormat {
  IStaticSchematic parse(InputStream paramInputStream) throws IOException;
  
  boolean isFileType(File paramFile);
}


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\schematic\format\ISchematicFormat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */