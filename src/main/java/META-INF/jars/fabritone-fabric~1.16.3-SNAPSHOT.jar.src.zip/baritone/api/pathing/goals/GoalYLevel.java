/*    */ package baritone.api.pathing.goals;
/*    */ 
/*    */ import baritone.api.pathing.movement.ActionCosts;
/*    */ import baritone.api.utils.SettingsUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GoalYLevel
/*    */   implements Goal, ActionCosts
/*    */ {
/*    */   public final int level;
/*    */   
/*    */   public GoalYLevel(int level) {
/* 36 */     this.level = level;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isInGoal(int x, int y, int z) {
/* 41 */     return (y == this.level);
/*    */   }
/*    */ 
/*    */   
/*    */   public double heuristic(int x, int y, int z) {
/* 46 */     return calculate(this.level, y);
/*    */   }
/*    */   
/*    */   public static double calculate(int goalY, int currentY) {
/* 50 */     if (currentY > goalY)
/*    */     {
/* 52 */       return FALL_N_BLOCKS_COST[2] / 2.0D * (currentY - goalY);
/*    */     }
/* 54 */     if (currentY < goalY)
/*    */     {
/* 56 */       return (goalY - currentY) * JUMP_ONE_BLOCK_COST;
/*    */     }
/* 58 */     return 0.0D;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 63 */     return String.format("GoalYLevel{y=%s}", new Object[] {
/*    */           
/* 65 */           SettingsUtil.maybeCensor(this.level)
/*    */         });
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\pathing\goals\GoalYLevel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */