package baritone.api.command.datatypes;

import baritone.api.command.exception.CommandException;
import java.util.stream.Stream;

public interface IDatatype {
  Stream<String> tabComplete(IDatatypeContext paramIDatatypeContext) throws CommandException;
}


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\command\datatypes\IDatatype.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */