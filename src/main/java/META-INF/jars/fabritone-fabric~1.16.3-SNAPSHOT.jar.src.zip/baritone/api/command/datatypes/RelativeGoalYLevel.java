/*    */ package baritone.api.command.datatypes;
/*    */ 
/*    */ import baritone.api.command.argument.IArgConsumer;
/*    */ import baritone.api.command.exception.CommandException;
/*    */ import baritone.api.pathing.goals.GoalYLevel;
/*    */ import baritone.api.utils.BetterBlockPos;
/*    */ import java.util.stream.Stream;
/*    */ import net.minecraft.class_3532;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum RelativeGoalYLevel
/*    */   implements IDatatypePost<GoalYLevel, BetterBlockPos>
/*    */ {
/* 29 */   INSTANCE;
/*    */ 
/*    */   
/*    */   public GoalYLevel apply(IDatatypeContext ctx, BetterBlockPos origin) throws CommandException {
/* 33 */     if (origin == null) {
/* 34 */       origin = BetterBlockPos.ORIGIN;
/*    */     }
/*    */     
/* 37 */     return new GoalYLevel(
/* 38 */         class_3532.method_15357(((Double)ctx.getConsumer().getDatatypePost(RelativeCoordinate.INSTANCE, Double.valueOf(origin.y))).doubleValue()));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Stream<String> tabComplete(IDatatypeContext ctx) {
/* 44 */     IArgConsumer consumer = ctx.getConsumer();
/* 45 */     if (consumer.hasAtMost(1)) {
/* 46 */       return consumer.tabCompleteDatatype(RelativeCoordinate.INSTANCE);
/*    */     }
/* 48 */     return Stream.empty();
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\command\datatypes\RelativeGoalYLevel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */