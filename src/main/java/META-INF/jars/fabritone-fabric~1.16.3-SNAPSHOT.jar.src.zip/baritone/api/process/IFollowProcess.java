/*    */ package baritone.api.process;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.function.Predicate;
/*    */ import net.minecraft.class_1297;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IFollowProcess
/*    */   extends IBaritoneProcess
/*    */ {
/*    */   void follow(Predicate<class_1297> paramPredicate);
/*    */   
/*    */   List<class_1297> following();
/*    */   
/*    */   Predicate<class_1297> currentFilter();
/*    */   
/*    */   default void cancel() {
/* 49 */     onLostControl();
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\process\IFollowProcess.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */