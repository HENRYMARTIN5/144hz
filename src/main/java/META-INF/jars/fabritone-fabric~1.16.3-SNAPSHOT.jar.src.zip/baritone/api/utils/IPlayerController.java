/*    */ package baritone.api.utils;
/*    */ 
/*    */ import baritone.api.BaritoneAPI;
/*    */ import net.minecraft.class_1268;
/*    */ import net.minecraft.class_1269;
/*    */ import net.minecraft.class_1657;
/*    */ import net.minecraft.class_1713;
/*    */ import net.minecraft.class_1799;
/*    */ import net.minecraft.class_1934;
/*    */ import net.minecraft.class_1937;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_2350;
/*    */ import net.minecraft.class_3965;
/*    */ import net.minecraft.class_746;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IPlayerController
/*    */ {
/*    */   void syncHeldItem();
/*    */   
/*    */   boolean hasBrokenBlock();
/*    */   
/*    */   boolean onPlayerDamageBlock(class_2338 paramclass_2338, class_2350 paramclass_2350);
/*    */   
/*    */   void resetBlockRemoving();
/*    */   
/*    */   class_1799 windowClick(int paramInt1, int paramInt2, int paramInt3, class_1713 paramclass_1713, class_1657 paramclass_1657);
/*    */   
/*    */   class_1934 getGameType();
/*    */   
/*    */   class_1269 processRightClickBlock(class_746 paramclass_746, class_1937 paramclass_1937, class_1268 paramclass_1268, class_3965 paramclass_3965);
/*    */   
/*    */   class_1269 processRightClick(class_746 paramclass_746, class_1937 paramclass_1937, class_1268 paramclass_1268);
/*    */   
/*    */   boolean clickBlock(class_2338 paramclass_2338, class_2350 paramclass_2350);
/*    */   
/*    */   void setHittingBlock(boolean paramBoolean);
/*    */   
/*    */   default double getBlockReachDistance() {
/* 60 */     return getGameType().method_8386() ? 5.0D : ((Float)(BaritoneAPI.getSettings()).blockReachDistance.value).floatValue();
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\ap\\utils\IPlayerController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */