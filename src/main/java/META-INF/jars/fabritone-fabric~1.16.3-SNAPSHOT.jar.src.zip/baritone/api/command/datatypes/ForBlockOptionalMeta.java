/*    */ package baritone.api.command.datatypes;
/*    */ 
/*    */ import baritone.api.command.exception.CommandException;
/*    */ import baritone.api.utils.BlockOptionalMeta;
/*    */ import java.util.stream.Stream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ForBlockOptionalMeta
/*    */   implements IDatatypeFor<BlockOptionalMeta>
/*    */ {
/* 26 */   INSTANCE;
/*    */ 
/*    */   
/*    */   public BlockOptionalMeta get(IDatatypeContext ctx) throws CommandException {
/* 30 */     return new BlockOptionalMeta(ctx.getConsumer().getString());
/*    */   }
/*    */ 
/*    */   
/*    */   public Stream<String> tabComplete(IDatatypeContext ctx) {
/* 35 */     return ctx.getConsumer().tabCompleteDatatype(BlockById.INSTANCE);
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\command\datatypes\ForBlockOptionalMeta.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */