/*    */ package baritone.api.schematic;
/*    */ 
/*    */ import java.util.List;
/*    */ import net.minecraft.class_2350;
/*    */ import net.minecraft.class_2680;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ISchematic
/*    */ {
/*    */   default boolean inSchematic(int x, int y, int z, class_2680 currentState) {
/* 48 */     return (x >= 0 && x < widthX() && y >= 0 && y < heightY() && z >= 0 && z < lengthZ());
/*    */   }
/*    */   
/*    */   default int size(class_2350.class_2351 axis) {
/* 52 */     switch (axis) {
/*    */       case field_11048:
/* 54 */         return widthX();
/*    */       case field_11052:
/* 56 */         return heightY();
/*    */       case field_11051:
/* 58 */         return lengthZ();
/*    */     } 
/* 60 */     throw new UnsupportedOperationException(axis + "");
/*    */   }
/*    */   
/*    */   class_2680 desiredState(int paramInt1, int paramInt2, int paramInt3, class_2680 paramclass_2680, List<class_2680> paramList);
/*    */   
/*    */   int widthX();
/*    */   
/*    */   int heightY();
/*    */   
/*    */   int lengthZ();
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\schematic\ISchematic.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */