/*    */ package baritone.api.pathing.goals;
/*    */ 
/*    */ import baritone.api.utils.SettingsUtil;
/*    */ import baritone.api.utils.interfaces.IGoalRenderPos;
/*    */ import net.minecraft.class_2338;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GoalBlock
/*    */   implements Goal, IGoalRenderPos
/*    */ {
/*    */   public final int x;
/*    */   public final int y;
/*    */   public final int z;
/*    */   
/*    */   public GoalBlock(class_2338 pos) {
/* 47 */     this(pos.method_10263(), pos.method_10264(), pos.method_10260());
/*    */   }
/*    */   
/*    */   public GoalBlock(int x, int y, int z) {
/* 51 */     this.x = x;
/* 52 */     this.y = y;
/* 53 */     this.z = z;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isInGoal(int x, int y, int z) {
/* 58 */     return (x == this.x && y == this.y && z == this.z);
/*    */   }
/*    */ 
/*    */   
/*    */   public double heuristic(int x, int y, int z) {
/* 63 */     int xDiff = x - this.x;
/* 64 */     int yDiff = y - this.y;
/* 65 */     int zDiff = z - this.z;
/* 66 */     return calculate(xDiff, yDiff, zDiff);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 71 */     return String.format("GoalBlock{x=%s,y=%s,z=%s}", new Object[] {
/*    */           
/* 73 */           SettingsUtil.maybeCensor(this.x), 
/* 74 */           SettingsUtil.maybeCensor(this.y), 
/* 75 */           SettingsUtil.maybeCensor(this.z)
/*    */         });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public class_2338 getGoalPos() {
/* 84 */     return new class_2338(this.x, this.y, this.z);
/*    */   }
/*    */   
/*    */   public static double calculate(double xDiff, int yDiff, double zDiff) {
/* 88 */     double heuristic = 0.0D;
/*    */ 
/*    */ 
/*    */     
/* 92 */     heuristic += GoalYLevel.calculate(yDiff, 0);
/*    */ 
/*    */     
/* 95 */     heuristic += GoalXZ.calculate(xDiff, zDiff);
/* 96 */     return heuristic;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\pathing\goals\GoalBlock.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */