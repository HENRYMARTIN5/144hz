/*    */ package baritone.api.pathing.goals;
/*    */ 
/*    */ import baritone.api.utils.SettingsUtil;
/*    */ import baritone.api.utils.interfaces.IGoalRenderPos;
/*    */ import net.minecraft.class_2338;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GoalNear
/*    */   implements Goal, IGoalRenderPos
/*    */ {
/*    */   private final int x;
/*    */   private final int y;
/*    */   private final int z;
/*    */   private final int rangeSq;
/*    */   
/*    */   public GoalNear(class_2338 pos, int range) {
/* 32 */     this.x = pos.method_10263();
/* 33 */     this.y = pos.method_10264();
/* 34 */     this.z = pos.method_10260();
/* 35 */     this.rangeSq = range * range;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isInGoal(int x, int y, int z) {
/* 40 */     int xDiff = x - this.x;
/* 41 */     int yDiff = y - this.y;
/* 42 */     int zDiff = z - this.z;
/* 43 */     return (xDiff * xDiff + yDiff * yDiff + zDiff * zDiff <= this.rangeSq);
/*    */   }
/*    */ 
/*    */   
/*    */   public double heuristic(int x, int y, int z) {
/* 48 */     int xDiff = x - this.x;
/* 49 */     int yDiff = y - this.y;
/* 50 */     int zDiff = z - this.z;
/* 51 */     return GoalBlock.calculate(xDiff, yDiff, zDiff);
/*    */   }
/*    */ 
/*    */   
/*    */   public class_2338 getGoalPos() {
/* 56 */     return new class_2338(this.x, this.y, this.z);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 61 */     return String.format("GoalNear{x=%s, y=%s, z=%s, rangeSq=%d}", new Object[] {
/*    */           
/* 63 */           SettingsUtil.maybeCensor(this.x), 
/* 64 */           SettingsUtil.maybeCensor(this.y), 
/* 65 */           SettingsUtil.maybeCensor(this.z), 
/* 66 */           Integer.valueOf(this.rangeSq)
/*    */         });
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\pathing\goals\GoalNear.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */