/*     */ package baritone.api.process;
/*     */ 
/*     */ import baritone.api.utils.BlockOptionalMeta;
/*     */ import baritone.api.utils.BlockOptionalMetaLookup;
/*     */ import java.util.function.Function;
/*     */ import java.util.stream.Stream;
/*     */ import net.minecraft.class_2248;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface IMineProcess
/*     */   extends IBaritoneProcess
/*     */ {
/*     */   default void mine(BlockOptionalMetaLookup filter) {
/*  58 */     mine(0, filter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void mineByName(String... blocks) {
/*  67 */     mineByName(0, blocks);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void mine(int quantity, BlockOptionalMeta... boms) {
/*  76 */     mine(quantity, new BlockOptionalMetaLookup(boms));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void mine(BlockOptionalMeta... boms) {
/*  85 */     mine(0, boms);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void mine(int quantity, class_2248... blocks) {
/*  95 */     mine(quantity, new BlockOptionalMetaLookup(
/*  96 */           (BlockOptionalMeta[])Stream.<class_2248>of(blocks)
/*  97 */           .map(BlockOptionalMeta::new)
/*  98 */           .toArray(x$0 -> new BlockOptionalMeta[x$0])));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void mine(class_2248... blocks) {
/* 108 */     mine(0, blocks);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void cancel() {
/* 115 */     onLostControl();
/*     */   }
/*     */   
/*     */   void mineByName(int paramInt, String... paramVarArgs);
/*     */   
/*     */   void mine(int paramInt, BlockOptionalMetaLookup paramBlockOptionalMetaLookup);
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\process\IMineProcess.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */