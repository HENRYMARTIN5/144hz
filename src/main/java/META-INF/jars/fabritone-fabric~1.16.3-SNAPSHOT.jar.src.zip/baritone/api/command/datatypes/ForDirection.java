/*    */ package baritone.api.command.datatypes;
/*    */ 
/*    */ import baritone.api.command.exception.CommandException;
/*    */ import baritone.api.command.helpers.TabCompleteHelper;
/*    */ import java.util.Locale;
/*    */ import java.util.stream.Stream;
/*    */ import net.minecraft.class_2350;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ForDirection
/*    */   implements IDatatypeFor<class_2350>
/*    */ {
/* 28 */   INSTANCE;
/*    */ 
/*    */   
/*    */   public class_2350 get(IDatatypeContext ctx) throws CommandException {
/* 32 */     return class_2350.valueOf(ctx.getConsumer().getString().toUpperCase(Locale.US));
/*    */   }
/*    */ 
/*    */   
/*    */   public Stream<String> tabComplete(IDatatypeContext ctx) throws CommandException {
/* 37 */     return (new TabCompleteHelper())
/* 38 */       .append(Stream.<class_2350>of(class_2350.values())
/* 39 */         .map(class_2350::method_10151).map(String::toLowerCase))
/* 40 */       .filterPrefix(ctx.getConsumer().getString())
/* 41 */       .stream();
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\command\datatypes\ForDirection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */