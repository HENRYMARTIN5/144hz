/*    */ package baritone.api.pathing.movement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum MovementStatus
/*    */ {
/* 29 */   PREPPING(false),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 34 */   WAITING(false),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 39 */   RUNNING(false),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 44 */   SUCCESS(true),
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 50 */   UNREACHABLE(true),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 55 */   FAILED(true),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 60 */   CANCELED(true);
/*    */ 
/*    */   
/*    */   private final boolean complete;
/*    */ 
/*    */ 
/*    */   
/*    */   MovementStatus(boolean complete) {
/* 68 */     this.complete = complete;
/*    */   }
/*    */   
/*    */   public final boolean isComplete() {
/* 72 */     return this.complete;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\pathing\movement\MovementStatus.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */