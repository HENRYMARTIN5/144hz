/*    */ package baritone.api.utils;
/*    */ 
/*    */ import baritone.api.pathing.calc.IPath;
/*    */ import java.util.Objects;
/*    */ import java.util.Optional;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PathCalculationResult
/*    */ {
/*    */   private final IPath path;
/*    */   private final Type type;
/*    */   
/*    */   public PathCalculationResult(Type type) {
/* 31 */     this(type, null);
/*    */   }
/*    */   
/*    */   public PathCalculationResult(Type type, IPath path) {
/* 35 */     Objects.requireNonNull(type);
/* 36 */     this.path = path;
/* 37 */     this.type = type;
/*    */   }
/*    */   
/*    */   public final Optional<IPath> getPath() {
/* 41 */     return Optional.ofNullable(this.path);
/*    */   }
/*    */   
/*    */   public final Type getType() {
/* 45 */     return this.type;
/*    */   }
/*    */   
/*    */   public enum Type {
/* 49 */     SUCCESS_TO_GOAL,
/* 50 */     SUCCESS_SEGMENT,
/* 51 */     FAILURE,
/* 52 */     CANCELLATION,
/* 53 */     EXCEPTION;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\ap\\utils\PathCalculationResult.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */