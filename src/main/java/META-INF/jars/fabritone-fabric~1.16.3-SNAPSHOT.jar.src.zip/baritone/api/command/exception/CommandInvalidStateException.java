/*    */ package baritone.api.command.exception;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CommandInvalidStateException
/*    */   extends CommandErrorMessageException
/*    */ {
/*    */   public CommandInvalidStateException(String reason) {
/* 23 */     super(reason);
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\command\exception\CommandInvalidStateException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */