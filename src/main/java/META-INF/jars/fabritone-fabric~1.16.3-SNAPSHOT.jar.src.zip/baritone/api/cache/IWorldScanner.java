/*    */ package baritone.api.cache;
/*    */ 
/*    */ import baritone.api.utils.BlockOptionalMetaLookup;
/*    */ import baritone.api.utils.IPlayerContext;
/*    */ import java.util.List;
/*    */ import net.minecraft.class_1923;
/*    */ import net.minecraft.class_2248;
/*    */ import net.minecraft.class_2338;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IWorldScanner
/*    */ {
/*    */   List<class_2338> scanChunkRadius(IPlayerContext paramIPlayerContext, BlockOptionalMetaLookup paramBlockOptionalMetaLookup, int paramInt1, int paramInt2, int paramInt3);
/*    */   
/*    */   default List<class_2338> scanChunkRadius(IPlayerContext ctx, List<class_2248> filter, int max, int yLevelThreshold, int maxSearchRadius) {
/* 48 */     return scanChunkRadius(ctx, new BlockOptionalMetaLookup(filter.<class_2248>toArray(new class_2248[0])), max, yLevelThreshold, maxSearchRadius);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   List<class_2338> scanChunk(IPlayerContext paramIPlayerContext, BlockOptionalMetaLookup paramBlockOptionalMetaLookup, class_1923 paramclass_1923, int paramInt1, int paramInt2);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default List<class_2338> scanChunk(IPlayerContext ctx, List<class_2248> blocks, class_1923 pos, int max, int yLevelThreshold) {
/* 76 */     return scanChunk(ctx, new BlockOptionalMetaLookup(blocks), pos, max, yLevelThreshold);
/*    */   }
/*    */   
/*    */   int repack(IPlayerContext paramIPlayerContext);
/*    */   
/*    */   int repack(IPlayerContext paramIPlayerContext, int paramInt);
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\cache\IWorldScanner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */