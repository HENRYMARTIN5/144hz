/*    */ package baritone.api.schematic;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import net.minecraft.class_2680;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompositeSchematic
/*    */   extends AbstractSchematic
/*    */ {
/*    */   private final List<CompositeSchematicEntry> schematics;
/*    */   private CompositeSchematicEntry[] schematicArr;
/*    */   
/*    */   private void recalcArr() {
/* 31 */     this.schematicArr = this.schematics.<CompositeSchematicEntry>toArray(new CompositeSchematicEntry[0]);
/* 32 */     for (CompositeSchematicEntry entry : this.schematicArr) {
/* 33 */       this.x = Math.max(this.x, entry.x + entry.schematic.widthX());
/* 34 */       this.y = Math.max(this.y, entry.y + entry.schematic.heightY());
/* 35 */       this.z = Math.max(this.z, entry.z + entry.schematic.lengthZ());
/*    */     } 
/*    */   }
/*    */   
/*    */   public CompositeSchematic(int x, int y, int z) {
/* 40 */     super(x, y, z);
/* 41 */     this.schematics = new ArrayList<>();
/* 42 */     recalcArr();
/*    */   }
/*    */   
/*    */   public void put(ISchematic extra, int x, int y, int z) {
/* 46 */     this.schematics.add(new CompositeSchematicEntry(extra, x, y, z));
/* 47 */     recalcArr();
/*    */   }
/*    */   
/*    */   private CompositeSchematicEntry getSchematic(int x, int y, int z, class_2680 currentState) {
/* 51 */     for (CompositeSchematicEntry entry : this.schematicArr) {
/* 52 */       if (x >= entry.x && y >= entry.y && z >= entry.z && entry.schematic
/* 53 */         .inSchematic(x - entry.x, y - entry.y, z - entry.z, currentState)) {
/* 54 */         return entry;
/*    */       }
/*    */     } 
/* 57 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean inSchematic(int x, int y, int z, class_2680 currentState) {
/* 62 */     CompositeSchematicEntry entry = getSchematic(x, y, z, currentState);
/* 63 */     return (entry != null && entry.schematic.inSchematic(x - entry.x, y - entry.y, z - entry.z, currentState));
/*    */   }
/*    */ 
/*    */   
/*    */   public class_2680 desiredState(int x, int y, int z, class_2680 current, List<class_2680> approxPlaceable) {
/* 68 */     CompositeSchematicEntry entry = getSchematic(x, y, z, current);
/* 69 */     if (entry == null) {
/* 70 */       throw new IllegalStateException("couldn't find schematic for this position");
/*    */     }
/* 72 */     return entry.schematic.desiredState(x - entry.x, y - entry.y, z - entry.z, current, approxPlaceable);
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\schematic\CompositeSchematic.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */