/*    */ package baritone.api.process;
/*    */ 
/*    */ import baritone.api.utils.BlockOptionalMeta;
/*    */ import net.minecraft.class_2248;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IGetToBlockProcess
/*    */   extends IBaritoneProcess
/*    */ {
/*    */   void getToBlock(BlockOptionalMeta paramBlockOptionalMeta);
/*    */   
/*    */   default void getToBlock(class_2248 block) {
/* 31 */     getToBlock(new BlockOptionalMeta(block));
/*    */   }
/*    */   
/*    */   boolean blacklistClosest();
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\process\IGetToBlockProcess.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */