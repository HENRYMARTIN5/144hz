package baritone.api.schematic;

import baritone.api.command.registry.Registry;
import baritone.api.schematic.format.ISchematicFormat;
import java.io.File;
import java.util.Optional;

public interface ISchematicSystem {
  Registry<ISchematicFormat> getRegistry();
  
  Optional<ISchematicFormat> getByFile(File paramFile);
}


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\schematic\ISchematicSystem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */