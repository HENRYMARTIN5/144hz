package baritone.api.behavior;

import baritone.api.event.listener.AbstractGameEventListener;

public interface IBehavior extends AbstractGameEventListener {}


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\behavior\IBehavior.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */