/*     */ package baritone.api.utils;
/*     */ 
/*     */ import baritone.api.BaritoneAPI;
/*     */ import baritone.api.IBaritone;
/*     */ import java.util.Optional;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1922;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_239;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_259;
/*     */ import net.minecraft.class_265;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_3532;
/*     */ import net.minecraft.class_3965;
/*     */ import net.minecraft.class_746;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RotationUtils
/*     */ {
/*     */   public static final double DEG_TO_RAD = 0.017453292519943295D;
/*     */   public static final double RAD_TO_DEG = 57.29577951308232D;
/*  53 */   private static final class_243[] BLOCK_SIDE_MULTIPLIERS = new class_243[] { new class_243(0.5D, 0.0D, 0.5D), new class_243(0.5D, 1.0D, 0.5D), new class_243(0.5D, 0.5D, 0.0D), new class_243(0.5D, 0.5D, 1.0D), new class_243(0.0D, 0.5D, 0.5D), new class_243(1.0D, 0.5D, 0.5D) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Rotation calcRotationFromCoords(class_2338 orig, class_2338 dest) {
/*  72 */     return calcRotationFromVec3d(new class_243(orig.method_10263(), orig.method_10264(), orig.method_10260()), new class_243(dest.method_10263(), dest.method_10264(), dest.method_10260()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Rotation wrapAnglesToRelative(Rotation current, Rotation target) {
/*  85 */     if (current.yawIsReallyClose(target)) {
/*  86 */       return new Rotation(current.getYaw(), target.getPitch());
/*     */     }
/*  88 */     return target.subtract(current).normalize().add(current);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Rotation calcRotationFromVec3d(class_243 orig, class_243 dest, Rotation current) {
/* 102 */     return wrapAnglesToRelative(current, calcRotationFromVec3d(orig, dest));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Rotation calcRotationFromVec3d(class_243 orig, class_243 dest) {
/* 113 */     double[] delta = { orig.field_1352 - dest.field_1352, orig.field_1351 - dest.field_1351, orig.field_1350 - dest.field_1350 };
/* 114 */     double yaw = class_3532.method_15349(delta[0], -delta[2]);
/* 115 */     double dist = Math.sqrt(delta[0] * delta[0] + delta[2] * delta[2]);
/* 116 */     double pitch = class_3532.method_15349(delta[1], dist);
/* 117 */     return new Rotation((float)(yaw * 57.29577951308232D), (float)(pitch * 57.29577951308232D));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class_243 calcVector3dFromRotation(Rotation rotation) {
/* 130 */     float f = class_3532.method_15362(-rotation.getYaw() * 0.017453292F - 3.1415927F);
/* 131 */     float f1 = class_3532.method_15374(-rotation.getYaw() * 0.017453292F - 3.1415927F);
/* 132 */     float f2 = -class_3532.method_15362(-rotation.getPitch() * 0.017453292F);
/* 133 */     float f3 = class_3532.method_15374(-rotation.getPitch() * 0.017453292F);
/* 134 */     return new class_243((f1 * f2), f3, (f * f2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Optional<Rotation> reachable(IPlayerContext ctx, class_2338 pos) {
/* 144 */     return reachable(ctx.player(), pos, ctx.playerController().getBlockReachDistance());
/*     */   }
/*     */   
/*     */   public static Optional<Rotation> reachable(IPlayerContext ctx, class_2338 pos, boolean wouldSneak) {
/* 148 */     return reachable(ctx.player(), pos, ctx.playerController().getBlockReachDistance(), wouldSneak);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Optional<Rotation> reachable(class_746 entity, class_2338 pos, double blockReachDistance) {
/* 164 */     return reachable(entity, pos, blockReachDistance, false);
/*     */   }
/*     */   
/*     */   public static Optional<Rotation> reachable(class_746 entity, class_2338 pos, double blockReachDistance, boolean wouldSneak) {
/* 168 */     IBaritone baritone = BaritoneAPI.getProvider().getBaritoneForPlayer(entity);
/* 169 */     if (baritone.getPlayerContext().isLookingAt(pos)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 180 */       Rotation hypothetical = new Rotation(entity.field_6031, entity.field_5965 + 1.0E-4F);
/* 181 */       if (wouldSneak) {
/*     */         
/* 183 */         class_239 result = RayTraceUtils.rayTraceTowards((class_1297)entity, hypothetical, blockReachDistance, true);
/* 184 */         if (result != null && result.method_17783() == class_239.class_240.field_1332 && ((class_3965)result).method_17777().equals(pos)) {
/* 185 */           return Optional.of(hypothetical);
/*     */         }
/*     */       } else {
/* 188 */         return Optional.of(hypothetical);
/*     */       } 
/*     */     } 
/* 191 */     Optional<Rotation> possibleRotation = reachableCenter((class_1297)entity, pos, blockReachDistance, wouldSneak);
/*     */     
/* 193 */     if (possibleRotation.isPresent()) {
/* 194 */       return possibleRotation;
/*     */     }
/*     */     
/* 197 */     class_2680 state = entity.field_6002.method_8320(pos);
/* 198 */     class_265 shape = state.method_26218((class_1922)entity.field_6002, pos);
/* 199 */     if (shape.method_1110()) {
/* 200 */       shape = class_259.method_1077();
/*     */     }
/* 202 */     for (class_243 sideOffset : BLOCK_SIDE_MULTIPLIERS) {
/* 203 */       double xDiff = shape.method_1091(class_2350.class_2351.field_11048) * sideOffset.field_1352 + shape.method_1105(class_2350.class_2351.field_11048) * (1.0D - sideOffset.field_1352);
/* 204 */       double yDiff = shape.method_1091(class_2350.class_2351.field_11052) * sideOffset.field_1351 + shape.method_1105(class_2350.class_2351.field_11052) * (1.0D - sideOffset.field_1351);
/* 205 */       double zDiff = shape.method_1091(class_2350.class_2351.field_11051) * sideOffset.field_1350 + shape.method_1105(class_2350.class_2351.field_11051) * (1.0D - sideOffset.field_1350);
/* 206 */       possibleRotation = reachableOffset((class_1297)entity, pos, (new class_243(pos.method_10263(), pos.method_10264(), pos.method_10260())).method_1031(xDiff, yDiff, zDiff), blockReachDistance, wouldSneak);
/* 207 */       if (possibleRotation.isPresent()) {
/* 208 */         return possibleRotation;
/*     */       }
/*     */     } 
/* 211 */     return Optional.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Optional<Rotation> reachableOffset(class_1297 entity, class_2338 pos, class_243 offsetPos, double blockReachDistance, boolean wouldSneak) {
/* 226 */     class_243 eyes = wouldSneak ? RayTraceUtils.inferSneakingEyePosition(entity) : entity.method_5836(1.0F);
/* 227 */     Rotation rotation = calcRotationFromVec3d(eyes, offsetPos, new Rotation(entity.field_6031, entity.field_5965));
/* 228 */     class_239 result = RayTraceUtils.rayTraceTowards(entity, rotation, blockReachDistance, wouldSneak);
/*     */     
/* 230 */     if (result != null && result.method_17783() == class_239.class_240.field_1332) {
/* 231 */       if (((class_3965)result).method_17777().equals(pos)) {
/* 232 */         return Optional.of(rotation);
/*     */       }
/* 234 */       if (entity.field_6002.method_8320(pos).method_26204() instanceof net.minecraft.class_2358 && ((class_3965)result).method_17777().equals(pos.method_10074())) {
/* 235 */         return Optional.of(rotation);
/*     */       }
/*     */     } 
/* 238 */     return Optional.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Optional<Rotation> reachableCenter(class_1297 entity, class_2338 pos, double blockReachDistance, boolean wouldSneak) {
/* 251 */     return reachableOffset(entity, pos, VecUtils.calculateBlockCenter(entity.field_6002, pos), blockReachDistance, wouldSneak);
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\ap\\utils\RotationUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */