/*     */ package baritone.api.behavior;
/*     */ 
/*     */ import baritone.api.pathing.calc.IPath;
/*     */ import baritone.api.pathing.calc.IPathFinder;
/*     */ import baritone.api.pathing.goals.Goal;
/*     */ import baritone.api.pathing.path.IPathExecutor;
/*     */ import java.util.Optional;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface IPathingBehavior
/*     */   extends IBehavior
/*     */ {
/*     */   default Optional<Double> ticksRemainingInSegment() {
/*  41 */     return ticksRemainingInSegment(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Optional<Double> ticksRemainingInSegment(boolean includeCurrentMovement) {
/*  53 */     IPathExecutor current = getCurrent();
/*  54 */     if (current == null) {
/*  55 */       return Optional.empty();
/*     */     }
/*  57 */     int start = includeCurrentMovement ? current.getPosition() : (current.getPosition() + 1);
/*  58 */     return Optional.of(Double.valueOf(current.getPath().ticksRemainingFrom(start)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Goal getGoal();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isPathing();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean hasPath() {
/*  78 */     return (getCurrent() != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean cancelEverything();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void forceCancel();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Optional<IPath> getPath() {
/* 104 */     return Optional.<IPathExecutor>ofNullable(getCurrent()).map(IPathExecutor::getPath);
/*     */   }
/*     */   
/*     */   Optional<? extends IPathFinder> getInProgress();
/*     */   
/*     */   IPathExecutor getCurrent();
/*     */   
/*     */   IPathExecutor getNext();
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\behavior\IPathingBehavior.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */