/*    */ package baritone.api.command.exception;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CommandNotEnoughArgumentsException
/*    */   extends CommandErrorMessageException
/*    */ {
/*    */   public CommandNotEnoughArgumentsException(int minArgs) {
/* 23 */     super(String.format("Not enough arguments (expected at least %d)", new Object[] { Integer.valueOf(minArgs) }));
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\command\exception\CommandNotEnoughArgumentsException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */