/*    */ package baritone.api.utils;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import net.minecraft.class_2248;
/*    */ import net.minecraft.class_2378;
/*    */ import net.minecraft.class_2960;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlockUtils
/*    */ {
/* 29 */   private static transient Map<String, class_2248> resourceCache = new HashMap<>();
/*    */   
/*    */   public static String blockToString(class_2248 block) {
/* 32 */     class_2960 loc = class_2378.field_11146.method_10221(block);
/* 33 */     String name = loc.method_12832();
/* 34 */     if (!loc.method_12836().equals("minecraft"))
/*    */     {
/* 36 */       name = loc.toString();
/*    */     }
/* 38 */     return name;
/*    */   }
/*    */   
/*    */   public static class_2248 stringToBlockRequired(String name) {
/* 42 */     class_2248 block = stringToBlockNullable(name);
/*    */     
/* 44 */     if (block == null) {
/* 45 */       throw new IllegalArgumentException(String.format("Invalid block name %s", new Object[] { name }));
/*    */     }
/*    */     
/* 48 */     return block;
/*    */   }
/*    */ 
/*    */   
/*    */   public static class_2248 stringToBlockNullable(String name) {
/* 53 */     class_2248 block = resourceCache.get(name);
/* 54 */     if (block != null) {
/* 55 */       return block;
/*    */     }
/* 57 */     if (resourceCache.containsKey(name)) {
/* 58 */       return null;
/*    */     }
/* 60 */     block = class_2378.field_11146.method_17966(class_2960.method_12829(name.contains(":") ? name : ("minecraft:" + name))).orElse(null);
/* 61 */     Map<String, class_2248> copy = new HashMap<>(resourceCache);
/* 62 */     copy.put(name, block);
/* 63 */     resourceCache = copy;
/* 64 */     return block;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\ap\\utils\BlockUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */