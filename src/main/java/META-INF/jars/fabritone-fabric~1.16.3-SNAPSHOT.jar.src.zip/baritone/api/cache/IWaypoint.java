/*     */ package baritone.api.cache;
/*     */ 
/*     */ import baritone.api.utils.BetterBlockPos;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface IWaypoint
/*     */ {
/*     */   String getName();
/*     */   
/*     */   Tag getTag();
/*     */   
/*     */   long getCreationTimestamp();
/*     */   
/*     */   BetterBlockPos getLocation();
/*     */   
/*     */   public enum Tag
/*     */   {
/*  67 */     HOME((String)new String[] { "home", "base"
/*     */ 
/*     */ 
/*     */       
/*     */       }),
/*  72 */     DEATH((String)new String[] { "death"
/*     */ 
/*     */ 
/*     */       
/*     */       }),
/*  77 */     BED((String)new String[] { "bed", "spawn"
/*     */ 
/*     */ 
/*     */       
/*     */       }),
/*  82 */     USER((String)new String[] { "user" });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  87 */     private static final List<Tag> TAG_LIST = Collections.unmodifiableList(Arrays.asList(values()));
/*     */     public final String[] names;
/*     */     
/*     */     static {
/*     */     
/*     */     }
/*     */     
/*     */     Tag(String... names) {
/*  95 */       this.names = names;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getName() {
/* 102 */       return this.names[0];
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Tag getByName(String name) {
/* 112 */       for (Tag action : values()) {
/* 113 */         for (String alias : action.names) {
/* 114 */           if (alias.equalsIgnoreCase(name)) {
/* 115 */             return action;
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 120 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static String[] getAllNames() {
/* 127 */       Set<String> names = new HashSet<>();
/*     */       
/* 129 */       for (Tag tag : values()) {
/* 130 */         names.addAll(Arrays.asList(tag.names));
/*     */       }
/*     */       
/* 133 */       return names.<String>toArray(new String[0]);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\cache\IWaypoint.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */