package baritone.api.selection;

import baritone.api.utils.BetterBlockPos;
import net.minecraft.class_2350;

public interface ISelectionManager {
  ISelection addSelection(ISelection paramISelection);
  
  ISelection addSelection(BetterBlockPos paramBetterBlockPos1, BetterBlockPos paramBetterBlockPos2);
  
  ISelection removeSelection(ISelection paramISelection);
  
  ISelection[] removeAllSelections();
  
  ISelection[] getSelections();
  
  ISelection getOnlySelection();
  
  ISelection getLastSelection();
  
  ISelection expand(ISelection paramISelection, class_2350 paramclass_2350, int paramInt);
  
  ISelection contract(ISelection paramISelection, class_2350 paramclass_2350, int paramInt);
  
  ISelection shift(ISelection paramISelection, class_2350 paramclass_2350, int paramInt);
}


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\selection\ISelectionManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */