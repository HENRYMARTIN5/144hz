/*    */ package baritone.api.utils.gui;
/*    */ 
/*    */ import net.minecraft.class_2561;
/*    */ import net.minecraft.class_2960;
/*    */ import net.minecraft.class_368;
/*    */ import net.minecraft.class_374;
/*    */ import net.minecraft.class_4493;
/*    */ import net.minecraft.class_4587;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BaritoneToast
/*    */   implements class_368
/*    */ {
/*    */   private String title;
/*    */   private String subtitle;
/*    */   private long firstDrawTime;
/*    */   private boolean newDisplay;
/*    */   private long totalShowTime;
/*    */   
/*    */   public BaritoneToast(class_2561 titleComponent, class_2561 subtitleComponent, long totalShowTime) {
/* 38 */     this.title = titleComponent.getString();
/* 39 */     this.subtitle = (subtitleComponent == null) ? null : subtitleComponent.getString();
/* 40 */     this.totalShowTime = totalShowTime;
/*    */   }
/*    */   
/*    */   public class_368.class_369 method_1986(class_4587 stack, class_374 toastGui, long delta) {
/* 44 */     if (this.newDisplay) {
/* 45 */       this.firstDrawTime = delta;
/* 46 */       this.newDisplay = false;
/*    */     } 
/*    */     
/* 49 */     toastGui.method_1995().method_1531().method_22813(new class_2960("textures/gui/toasts.png"));
/* 50 */     class_4493.method_22000(1.0F, 1.0F, 1.0F, 255.0F);
/* 51 */     toastGui.method_25302(stack, 0, 0, 0, 32, 160, 32);
/*    */     
/* 53 */     if (this.subtitle == null) {
/* 54 */       (toastGui.method_1995()).field_1772.method_1729(stack, this.title, 18.0F, 12.0F, -11534256);
/*    */     } else {
/* 56 */       (toastGui.method_1995()).field_1772.method_1729(stack, this.title, 18.0F, 7.0F, -11534256);
/* 57 */       (toastGui.method_1995()).field_1772.method_1729(stack, this.subtitle, 18.0F, 18.0F, -16777216);
/*    */     } 
/*    */     
/* 60 */     return (delta - this.firstDrawTime < this.totalShowTime) ? class_368.class_369.field_2210 : class_368.class_369.field_2209;
/*    */   }
/*    */   
/*    */   public void setDisplayedText(class_2561 titleComponent, class_2561 subtitleComponent) {
/* 64 */     this.title = titleComponent.getString();
/* 65 */     this.subtitle = (subtitleComponent == null) ? null : subtitleComponent.getString();
/* 66 */     this.newDisplay = true;
/*    */   }
/*    */   
/*    */   public static void addOrUpdate(class_374 toast, class_2561 title, class_2561 subtitle, long totalShowTime) {
/* 70 */     BaritoneToast baritonetoast = (BaritoneToast)toast.method_1997(BaritoneToast.class, new Object());
/*    */     
/* 72 */     if (baritonetoast == null) {
/* 73 */       toast.method_1999(new BaritoneToast(title, subtitle, totalShowTime));
/*    */     } else {
/* 75 */       baritonetoast.setDisplayedText(title, subtitle);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\ap\\utils\gui\BaritoneToast.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */