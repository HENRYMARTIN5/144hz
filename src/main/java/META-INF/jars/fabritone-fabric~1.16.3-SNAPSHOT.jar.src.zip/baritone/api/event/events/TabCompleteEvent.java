/*    */ package baritone.api.event.events;
/*    */ 
/*    */ import baritone.api.event.events.type.Cancellable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class TabCompleteEvent
/*    */   extends Cancellable
/*    */ {
/*    */   public final String prefix;
/*    */   public String[] completions;
/*    */   
/*    */   public TabCompleteEvent(String prefix) {
/* 32 */     this.prefix = prefix;
/* 33 */     this.completions = null;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\event\events\TabCompleteEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */