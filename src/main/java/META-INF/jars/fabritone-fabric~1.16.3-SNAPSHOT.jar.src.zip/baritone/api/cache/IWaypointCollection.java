package baritone.api.cache;

import java.util.Set;

public interface IWaypointCollection {
  void addWaypoint(IWaypoint paramIWaypoint);
  
  void removeWaypoint(IWaypoint paramIWaypoint);
  
  IWaypoint getMostRecentByTag(IWaypoint.Tag paramTag);
  
  Set<IWaypoint> getByTag(IWaypoint.Tag paramTag);
  
  Set<IWaypoint> getAllWaypoints();
}


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\cache\IWaypointCollection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */