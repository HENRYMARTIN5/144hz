/*    */ package baritone.api.pathing.goals;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GoalInverted
/*    */   implements Goal
/*    */ {
/*    */   public final Goal origin;
/*    */   
/*    */   public GoalInverted(Goal origin) {
/* 35 */     this.origin = origin;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isInGoal(int x, int y, int z) {
/* 40 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public double heuristic(int x, int y, int z) {
/* 45 */     return -this.origin.heuristic(x, y, z);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 50 */     return String.format("GoalInverted{%s}", new Object[] { this.origin.toString() });
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\pathing\goals\GoalInverted.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */