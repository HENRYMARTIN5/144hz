/*    */ package baritone.api.command.exception;
/*    */ 
/*    */ import baritone.api.command.ICommand;
/*    */ import baritone.api.command.argument.ICommandArgument;
/*    */ import baritone.api.utils.Helper;
/*    */ import java.util.List;
/*    */ import net.minecraft.class_124;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ICommandException
/*    */ {
/*    */   String getMessage();
/*    */   
/*    */   default void handle(ICommand command, List<ICommandArgument> args) {
/* 53 */     Helper.HELPER.logDirect(getMessage(), class_124.field_1061);
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\command\exception\ICommandException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */