/*     */ package baritone.api.utils;
/*     */ 
/*     */ import javax.annotation.Nonnull;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_2382;
/*     */ import net.minecraft.class_3532;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BetterBlockPos
/*     */   extends class_2338
/*     */ {
/*  38 */   public static final BetterBlockPos ORIGIN = new BetterBlockPos(0, 0, 0);
/*     */   
/*     */   public final int x;
/*     */   public final int y;
/*     */   public final int z;
/*     */   
/*     */   public BetterBlockPos(int x, int y, int z) {
/*  45 */     super(x, y, z);
/*  46 */     this.x = x;
/*  47 */     this.y = y;
/*  48 */     this.z = z;
/*     */   }
/*     */   
/*     */   public BetterBlockPos(double x, double y, double z) {
/*  52 */     this(class_3532.method_15357(x), class_3532.method_15357(y), class_3532.method_15357(z));
/*     */   }
/*     */   
/*     */   public BetterBlockPos(class_2338 pos) {
/*  56 */     this(pos.method_10263(), pos.method_10264(), pos.method_10260());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BetterBlockPos from(class_2338 pos) {
/*  66 */     if (pos == null) {
/*  67 */       return null;
/*     */     }
/*     */     
/*  70 */     return new BetterBlockPos(pos);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  75 */     return (int)longHash(this.x, this.y, this.z);
/*     */   }
/*     */   
/*     */   public static long longHash(BetterBlockPos pos) {
/*  79 */     return longHash(pos.x, pos.y, pos.z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long longHash(int x, int y, int z) {
/*  96 */     long hash = 3241L;
/*  97 */     hash = 3457689L * hash + x;
/*  98 */     hash = 8734625L * hash + y;
/*  99 */     hash = 2873465L * hash + z;
/* 100 */     return hash;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 105 */     if (o == null) {
/* 106 */       return false;
/*     */     }
/* 108 */     if (o instanceof BetterBlockPos) {
/* 109 */       BetterBlockPos betterBlockPos = (BetterBlockPos)o;
/* 110 */       return (betterBlockPos.x == this.x && betterBlockPos.y == this.y && betterBlockPos.z == this.z);
/*     */     } 
/*     */ 
/*     */     
/* 114 */     class_2338 oth = (class_2338)o;
/* 115 */     return (oth.method_10263() == this.x && oth.method_10264() == this.y && oth.method_10260() == this.z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BetterBlockPos up() {
/* 129 */     return new BetterBlockPos(this.x, this.y + 1, this.z);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BetterBlockPos up(int amt) {
/* 135 */     return (amt == 0) ? this : new BetterBlockPos(this.x, this.y + amt, this.z);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BetterBlockPos down() {
/* 141 */     return new BetterBlockPos(this.x, this.y - 1, this.z);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BetterBlockPos down(int amt) {
/* 147 */     return (amt == 0) ? this : new BetterBlockPos(this.x, this.y - amt, this.z);
/*     */   }
/*     */ 
/*     */   
/*     */   public BetterBlockPos offset(class_2350 dir) {
/* 152 */     class_2382 vec = dir.method_10163();
/* 153 */     return new BetterBlockPos(this.x + vec.method_10263(), this.y + vec.method_10264(), this.z + vec.method_10260());
/*     */   }
/*     */ 
/*     */   
/*     */   public BetterBlockPos offset(class_2350 dir, int dist) {
/* 158 */     if (dist == 0) {
/* 159 */       return this;
/*     */     }
/* 161 */     class_2382 vec = dir.method_10163();
/* 162 */     return new BetterBlockPos(this.x + vec.method_10263() * dist, this.y + vec.method_10264() * dist, this.z + vec.method_10260() * dist);
/*     */   }
/*     */ 
/*     */   
/*     */   public BetterBlockPos north() {
/* 167 */     return new BetterBlockPos(this.x, this.y, this.z - 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public BetterBlockPos north(int amt) {
/* 172 */     return (amt == 0) ? this : new BetterBlockPos(this.x, this.y, this.z - amt);
/*     */   }
/*     */ 
/*     */   
/*     */   public BetterBlockPos south() {
/* 177 */     return new BetterBlockPos(this.x, this.y, this.z + 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public BetterBlockPos south(int amt) {
/* 182 */     return (amt == 0) ? this : new BetterBlockPos(this.x, this.y, this.z + amt);
/*     */   }
/*     */ 
/*     */   
/*     */   public BetterBlockPos east() {
/* 187 */     return new BetterBlockPos(this.x + 1, this.y, this.z);
/*     */   }
/*     */ 
/*     */   
/*     */   public BetterBlockPos east(int amt) {
/* 192 */     return (amt == 0) ? this : new BetterBlockPos(this.x + amt, this.y, this.z);
/*     */   }
/*     */ 
/*     */   
/*     */   public BetterBlockPos west() {
/* 197 */     return new BetterBlockPos(this.x - 1, this.y, this.z);
/*     */   }
/*     */ 
/*     */   
/*     */   public BetterBlockPos west(int amt) {
/* 202 */     return (amt == 0) ? this : new BetterBlockPos(this.x - amt, this.y, this.z);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nonnull
/*     */   public String toString() {
/* 208 */     return String.format("BetterBlockPos{x=%s,y=%s,z=%s}", new Object[] {
/*     */           
/* 210 */           SettingsUtil.maybeCensor(this.x), 
/* 211 */           SettingsUtil.maybeCensor(this.y), 
/* 212 */           SettingsUtil.maybeCensor(this.z)
/*     */         });
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\ap\\utils\BetterBlockPos.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */