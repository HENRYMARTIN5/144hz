/*    */ package baritone.api.event.events;
/*    */ 
/*    */ import baritone.api.event.events.type.EventState;
/*    */ import net.minecraft.class_2535;
/*    */ import net.minecraft.class_2596;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PacketEvent
/*    */ {
/*    */   private final class_2535 networkManager;
/*    */   private final EventState state;
/*    */   private final class_2596<?> packet;
/*    */   
/*    */   public PacketEvent(class_2535 networkManager, EventState state, class_2596<?> packet) {
/* 37 */     this.networkManager = networkManager;
/* 38 */     this.state = state;
/* 39 */     this.packet = packet;
/*    */   }
/*    */   
/*    */   public final class_2535 getNetworkManager() {
/* 43 */     return this.networkManager;
/*    */   }
/*    */   
/*    */   public final EventState getState() {
/* 47 */     return this.state;
/*    */   }
/*    */   
/*    */   public final class_2596<?> getPacket() {
/* 51 */     return this.packet;
/*    */   }
/*    */ 
/*    */   
/*    */   public final <T extends class_2596<?>> T cast() {
/* 56 */     return (T)this.packet;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\event\events\PacketEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */