package baritone.api.command.datatypes;

import baritone.api.command.exception.CommandException;

public interface IDatatypeFor<T> extends IDatatype {
  T get(IDatatypeContext paramIDatatypeContext) throws CommandException;
}


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\command\datatypes\IDatatypeFor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */