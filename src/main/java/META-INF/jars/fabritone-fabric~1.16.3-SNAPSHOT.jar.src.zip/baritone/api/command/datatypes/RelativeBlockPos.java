/*    */ package baritone.api.command.datatypes;
/*    */ 
/*    */ import baritone.api.command.argument.IArgConsumer;
/*    */ import baritone.api.command.exception.CommandException;
/*    */ import baritone.api.utils.BetterBlockPos;
/*    */ import java.util.stream.Stream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum RelativeBlockPos
/*    */   implements IDatatypePost<BetterBlockPos, BetterBlockPos>
/*    */ {
/* 27 */   INSTANCE;
/*    */ 
/*    */   
/*    */   public BetterBlockPos apply(IDatatypeContext ctx, BetterBlockPos origin) throws CommandException {
/* 31 */     if (origin == null) {
/* 32 */       origin = BetterBlockPos.ORIGIN;
/*    */     }
/*    */     
/* 35 */     IArgConsumer consumer = ctx.getConsumer();
/* 36 */     return new BetterBlockPos(((Double)consumer
/* 37 */         .getDatatypePost(RelativeCoordinate.INSTANCE, Double.valueOf(origin.x))).doubleValue(), ((Double)consumer
/* 38 */         .getDatatypePost(RelativeCoordinate.INSTANCE, Double.valueOf(origin.y))).doubleValue(), ((Double)consumer
/* 39 */         .getDatatypePost(RelativeCoordinate.INSTANCE, Double.valueOf(origin.z))).doubleValue());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Stream<String> tabComplete(IDatatypeContext ctx) throws CommandException {
/* 45 */     IArgConsumer consumer = ctx.getConsumer();
/* 46 */     if (consumer.hasAny() && !consumer.has(4)) {
/* 47 */       while (consumer.has(2) && 
/* 48 */         consumer.peekDatatypeOrNull(RelativeCoordinate.INSTANCE) != null)
/*    */       {
/*    */         
/* 51 */         consumer.get();
/*    */       }
/* 53 */       return consumer.tabCompleteDatatype(RelativeCoordinate.INSTANCE);
/*    */     } 
/* 55 */     return Stream.empty();
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\command\datatypes\RelativeBlockPos.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */