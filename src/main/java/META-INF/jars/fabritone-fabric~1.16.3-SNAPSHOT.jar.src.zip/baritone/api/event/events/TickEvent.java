/*    */ package baritone.api.event.events;
/*    */ 
/*    */ import baritone.api.event.events.type.EventState;
/*    */ import java.util.function.BiFunction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class TickEvent
/*    */ {
/*    */   private static int overallTickCount;
/*    */   private final EventState state;
/*    */   private final Type type;
/*    */   private final int count;
/*    */   
/*    */   public TickEvent(EventState state, Type type, int count) {
/* 33 */     this.state = state;
/* 34 */     this.type = type;
/* 35 */     this.count = count;
/*    */   }
/*    */   
/*    */   public int getCount() {
/* 39 */     return this.count;
/*    */   }
/*    */   
/*    */   public Type getType() {
/* 43 */     return this.type;
/*    */   }
/*    */   
/*    */   public EventState getState() {
/* 47 */     return this.state;
/*    */   }
/*    */   
/*    */   public static synchronized BiFunction<EventState, Type, TickEvent> createNextProvider() {
/* 51 */     int count = overallTickCount++;
/* 52 */     return (state, type) -> new TickEvent(state, type, count);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public enum Type
/*    */   {
/* 60 */     IN,
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 65 */     OUT;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\event\events\TickEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */