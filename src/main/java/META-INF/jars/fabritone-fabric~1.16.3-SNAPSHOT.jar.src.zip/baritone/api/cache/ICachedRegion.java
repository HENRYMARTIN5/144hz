package baritone.api.cache;

public interface ICachedRegion extends IBlockTypeAccess {
  boolean isCached(int paramInt1, int paramInt2);
  
  int getX();
  
  int getZ();
}


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\cache\ICachedRegion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */