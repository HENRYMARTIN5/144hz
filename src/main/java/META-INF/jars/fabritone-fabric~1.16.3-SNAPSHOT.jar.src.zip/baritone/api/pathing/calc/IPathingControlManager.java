package baritone.api.pathing.calc;

import baritone.api.process.IBaritoneProcess;
import baritone.api.process.PathingCommand;
import java.util.Optional;

public interface IPathingControlManager {
  void registerProcess(IBaritoneProcess paramIBaritoneProcess);
  
  Optional<IBaritoneProcess> mostRecentInControl();
  
  Optional<PathingCommand> mostRecentCommand();
}


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\pathing\calc\IPathingControlManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */