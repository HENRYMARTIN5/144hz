package baritone.api.command.argument;

import baritone.api.command.exception.CommandInvalidTypeException;

public interface ICommandArgument {
  int getIndex();
  
  String getValue();
  
  String getRawRest();
  
  <E extends Enum<?>> E getEnum(Class<E> paramClass) throws CommandInvalidTypeException;
  
  <T> T getAs(Class<T> paramClass) throws CommandInvalidTypeException;
  
  <T> boolean is(Class<T> paramClass);
  
  <T, S> T getAs(Class<T> paramClass, Class<S> paramClass1, S paramS) throws CommandInvalidTypeException;
  
  <T, S> boolean is(Class<T> paramClass, Class<S> paramClass1, S paramS);
}


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\command\argument\ICommandArgument.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */