/*    */ package baritone.api.event.events;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RotationMoveEvent
/*    */ {
/*    */   private final Type type;
/*    */   private float yaw;
/*    */   
/*    */   public RotationMoveEvent(Type type, float yaw) {
/* 41 */     this.type = type;
/* 42 */     this.yaw = yaw;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void setYaw(float yaw) {
/* 51 */     this.yaw = yaw;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final float getYaw() {
/* 58 */     return this.yaw;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final Type getType() {
/* 65 */     return this.type;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public enum Type
/*    */   {
/* 75 */     MOTION_UPDATE,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 82 */     JUMP;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\event\events\RotationMoveEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */