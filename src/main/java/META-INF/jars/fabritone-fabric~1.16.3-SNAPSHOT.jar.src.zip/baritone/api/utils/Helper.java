/*     */ package baritone.api.utils;
/*     */ 
/*     */ import baritone.api.BaritoneAPI;
/*     */ import baritone.api.utils.gui.BaritoneToast;
/*     */ import java.util.Arrays;
/*     */ import java.util.Calendar;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.stream.Stream;
/*     */ import net.minecraft.class_124;
/*     */ import net.minecraft.class_2554;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_2585;
/*     */ import net.minecraft.class_310;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface Helper
/*     */ {
/*  44 */   public static final Helper HELPER = new Helper()
/*     */     {
/*     */     
/*     */     };
/*     */   
/*  49 */   public static final class_310 mc = class_310.method_1551();
/*     */ 
/*     */   
/*     */   static class_2561 getPrefix() {
/*  53 */     Calendar now = Calendar.getInstance();
/*  54 */     boolean xd = (now.get(2) == 3 && now.get(5) <= 3);
/*  55 */     class_2585 class_25851 = new class_2585(xd ? "Baritoe" : (((Boolean)(BaritoneAPI.getSettings()).shortBaritonePrefix.value).booleanValue() ? "B" : "Baritone"));
/*  56 */     class_25851.method_10862(class_25851.method_10866().method_27706(class_124.field_1076));
/*     */ 
/*     */     
/*  59 */     class_2585 class_25852 = new class_2585("");
/*  60 */     class_25852.method_10862(class_25851.method_10866().method_27706(class_124.field_1064));
/*  61 */     class_25852.method_27693("[");
/*  62 */     class_25852.method_10852((class_2561)class_25851);
/*  63 */     class_25852.method_27693("]");
/*     */     
/*  65 */     return (class_2561)class_25852;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void logToast(class_2561 title, class_2561 message) {
/*  75 */     mc.execute(() -> BaritoneToast.addOrUpdate(mc.method_1566(), title, message, ((Long)(BaritoneAPI.getSettings()).toastTimer.value).longValue()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void logToast(String title, String message) {
/*  85 */     logToast((class_2561)new class_2585(title), (class_2561)new class_2585(message));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void logToast(String message) {
/*  94 */     logToast(getPrefix(), (class_2561)new class_2585(message));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void logDebug(String message) {
/* 103 */     if (!((Boolean)(BaritoneAPI.getSettings()).chatDebug.value).booleanValue()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 110 */     logDirect(message, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void logDirect(boolean logAsToast, class_2561... components) {
/* 120 */     class_2585 class_2585 = new class_2585("");
/* 121 */     if (!logAsToast) {
/*     */ 
/*     */       
/* 124 */       class_2585.method_10852(getPrefix());
/* 125 */       class_2585.method_10852((class_2561)new class_2585(" "));
/*     */     } 
/* 127 */     Arrays.<class_2561>asList(components).forEach(class_2585::method_10852);
/* 128 */     if (logAsToast) {
/* 129 */       logToast(getPrefix(), (class_2561)class_2585);
/*     */     } else {
/* 131 */       mc.execute(() -> ((Consumer<class_2554>)(BaritoneAPI.getSettings()).logger.value).accept(component));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void logDirect(class_2561... components) {
/* 141 */     logDirect(((Boolean)(BaritoneAPI.getSettings()).logAsToast.value).booleanValue(), components);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void logDirect(String message, class_124 color, boolean logAsToast) {
/* 153 */     Stream.<String>of(message.split("\n")).forEach(line -> {
/*     */           class_2585 class_2585 = new class_2585(line.replace("\t", "    "));
/*     */           class_2585.method_10862(class_2585.method_10866().method_27706(color));
/*     */           logDirect(logAsToast, new class_2561[] { (class_2561)class_2585 });
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void logDirect(String message, class_124 color) {
/* 168 */     logDirect(message, color, ((Boolean)(BaritoneAPI.getSettings()).logAsToast.value).booleanValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void logDirect(String message, boolean logAsToast) {
/* 179 */     logDirect(message, class_124.field_1080, logAsToast);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void logDirect(String message) {
/* 189 */     logDirect(message, ((Boolean)(BaritoneAPI.getSettings()).logAsToast.value).booleanValue());
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\ap\\utils\Helper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */