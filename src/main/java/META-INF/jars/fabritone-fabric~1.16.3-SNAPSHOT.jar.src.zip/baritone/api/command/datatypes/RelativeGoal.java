/*    */ package baritone.api.command.datatypes;
/*    */ 
/*    */ import baritone.api.command.argument.IArgConsumer;
/*    */ import baritone.api.command.exception.CommandException;
/*    */ import baritone.api.pathing.goals.Goal;
/*    */ import baritone.api.pathing.goals.GoalBlock;
/*    */ import baritone.api.pathing.goals.GoalXZ;
/*    */ import baritone.api.pathing.goals.GoalYLevel;
/*    */ import baritone.api.utils.BetterBlockPos;
/*    */ import java.util.stream.Stream;
/*    */ import net.minecraft.class_2338;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum RelativeGoal
/*    */   implements IDatatypePost<Goal, BetterBlockPos>
/*    */ {
/* 34 */   INSTANCE;
/*    */ 
/*    */   
/*    */   public Goal apply(IDatatypeContext ctx, BetterBlockPos origin) throws CommandException {
/* 38 */     if (origin == null) {
/* 39 */       origin = BetterBlockPos.ORIGIN;
/*    */     }
/*    */     
/* 42 */     IArgConsumer consumer = ctx.getConsumer();
/*    */     
/* 44 */     GoalBlock goalBlock = (GoalBlock)consumer.peekDatatypePostOrNull(RelativeGoalBlock.INSTANCE, origin);
/* 45 */     if (goalBlock != null) {
/* 46 */       return (Goal)goalBlock;
/*    */     }
/*    */     
/* 49 */     GoalXZ goalXZ = (GoalXZ)consumer.peekDatatypePostOrNull(RelativeGoalXZ.INSTANCE, origin);
/* 50 */     if (goalXZ != null) {
/* 51 */       return (Goal)goalXZ;
/*    */     }
/*    */     
/* 54 */     GoalYLevel goalYLevel = (GoalYLevel)consumer.peekDatatypePostOrNull(RelativeGoalYLevel.INSTANCE, origin);
/* 55 */     if (goalYLevel != null) {
/* 56 */       return (Goal)goalYLevel;
/*    */     }
/*    */ 
/*    */     
/* 60 */     return (Goal)new GoalBlock((class_2338)origin);
/*    */   }
/*    */ 
/*    */   
/*    */   public Stream<String> tabComplete(IDatatypeContext ctx) {
/* 65 */     return ctx.getConsumer().tabCompleteDatatype(RelativeCoordinate.INSTANCE);
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\command\datatypes\RelativeGoal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */