/*    */ package baritone.api.schematic;
/*    */ 
/*    */ import net.minecraft.class_2680;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IStaticSchematic
/*    */   extends ISchematic
/*    */ {
/*    */   class_2680 getDirect(int paramInt1, int paramInt2, int paramInt3);
/*    */   
/*    */   default class_2680[] getColumn(int x, int z) {
/* 54 */     class_2680[] column = new class_2680[heightY()];
/* 55 */     for (int i = 0; i < heightY(); i++) {
/* 56 */       column[i] = getDirect(x, i, z);
/*    */     }
/* 58 */     return column;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\schematic\IStaticSchematic.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */