/*    */ package baritone.api.utils.input;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum Input
/*    */ {
/* 30 */   MOVE_FORWARD,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 35 */   MOVE_BACK,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 40 */   MOVE_LEFT,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 45 */   MOVE_RIGHT,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 50 */   CLICK_LEFT,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 55 */   CLICK_RIGHT,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 60 */   JUMP,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 65 */   SNEAK,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 70 */   SPRINT;
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\ap\\utils\input\Input.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */