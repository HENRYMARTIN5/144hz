/*     */ package baritone.api.command.datatypes;
/*     */ 
/*     */ import baritone.api.command.argument.IArgConsumer;
/*     */ import baritone.api.command.exception.CommandException;
/*     */ import baritone.api.utils.Helper;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.UncheckedIOException;
/*     */ import java.nio.file.FileSystems;
/*     */ import java.nio.file.InvalidPathException;
/*     */ import java.nio.file.Path;
/*     */ import java.util.Locale;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Stream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum RelativeFile
/*     */   implements IDatatypePost<File, File>
/*     */ {
/*  36 */   INSTANCE;
/*     */   
/*     */   public File apply(IDatatypeContext ctx, File original) throws CommandException {
/*     */     Path path;
/*  40 */     if (original == null) {
/*  41 */       original = new File("./");
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/*  46 */       path = FileSystems.getDefault().getPath(ctx.getConsumer().getString(), new String[0]);
/*  47 */     } catch (InvalidPathException e) {
/*  48 */       throw new IllegalArgumentException("invalid path");
/*     */     } 
/*  50 */     return getCanonicalFileUnchecked(original.toPath().resolve(path).toFile());
/*     */   }
/*     */ 
/*     */   
/*     */   public Stream<String> tabComplete(IDatatypeContext ctx) {
/*  55 */     return Stream.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static File getCanonicalFileUnchecked(File file) {
/*     */     try {
/*  67 */       return file.getCanonicalFile();
/*  68 */     } catch (IOException e) {
/*  69 */       throw new UncheckedIOException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Stream<String> tabComplete(IArgConsumer consumer, File base0) throws CommandException {
/*  79 */     File base = getCanonicalFileUnchecked(base0);
/*  80 */     String currentPathStringThing = consumer.getString();
/*  81 */     Path currentPath = FileSystems.getDefault().getPath(currentPathStringThing, new String[0]);
/*  82 */     Path basePath = currentPath.isAbsolute() ? currentPath.getRoot() : base.toPath();
/*  83 */     boolean useParent = (!currentPathStringThing.isEmpty() && !currentPathStringThing.endsWith(File.separator));
/*  84 */     File currentFile = currentPath.isAbsolute() ? currentPath.toFile() : new File(base, currentPathStringThing);
/*  85 */     return Stream.<Object>of((Object[])Objects.requireNonNull(getCanonicalFileUnchecked(useParent ? currentFile
/*     */             
/*  87 */             .getParentFile() : currentFile)
/*     */           
/*  89 */           .listFiles()))
/*  90 */       .map(f -> (currentPath.isAbsolute() ? (String)f : basePath.relativize(f.toPath()).toString()) + (f.isDirectory() ? File.separator : ""))
/*     */       
/*  92 */       .filter(s -> s.toLowerCase(Locale.US).startsWith(currentPathStringThing.toLowerCase(Locale.US)))
/*  93 */       .filter(s -> !s.contains(" "));
/*     */   }
/*     */   
/*     */   public static File gameDir() {
/*  97 */     File gameDir = Helper.mc.field_1697.getAbsoluteFile();
/*  98 */     if (gameDir.getName().equals(".")) {
/*  99 */       return gameDir.getParentFile();
/*     */     }
/* 101 */     return gameDir;
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\command\datatypes\RelativeFile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */