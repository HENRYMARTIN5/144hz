/*    */ package baritone.api.schematic;
/*    */ 
/*    */ import baritone.api.utils.BlockOptionalMeta;
/*    */ import java.util.List;
/*    */ import net.minecraft.class_2246;
/*    */ import net.minecraft.class_2680;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FillSchematic
/*    */   extends AbstractSchematic
/*    */ {
/*    */   private final BlockOptionalMeta bom;
/*    */   
/*    */   public FillSchematic(int x, int y, int z, BlockOptionalMeta bom) {
/* 31 */     super(x, y, z);
/* 32 */     this.bom = bom;
/*    */   }
/*    */   
/*    */   public FillSchematic(int x, int y, int z, class_2680 state) {
/* 36 */     this(x, y, z, new BlockOptionalMeta(state.method_26204()));
/*    */   }
/*    */   
/*    */   public BlockOptionalMeta getBom() {
/* 40 */     return this.bom;
/*    */   }
/*    */ 
/*    */   
/*    */   public class_2680 desiredState(int x, int y, int z, class_2680 current, List<class_2680> approxPlaceable) {
/* 45 */     if (this.bom.matches(current))
/* 46 */       return current; 
/* 47 */     if (current.method_26204() != class_2246.field_10124) {
/* 48 */       return class_2246.field_10124.method_9564();
/*    */     }
/* 50 */     for (class_2680 placeable : approxPlaceable) {
/* 51 */       if (this.bom.matches(placeable)) {
/* 52 */         return placeable;
/*    */       }
/*    */     } 
/* 55 */     return this.bom.getAnyBlockState();
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\schematic\FillSchematic.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */