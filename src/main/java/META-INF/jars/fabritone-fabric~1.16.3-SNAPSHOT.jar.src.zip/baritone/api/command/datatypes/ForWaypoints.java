/*    */ package baritone.api.command.datatypes;
/*    */ 
/*    */ import baritone.api.IBaritone;
/*    */ import baritone.api.cache.IWaypoint;
/*    */ import baritone.api.cache.IWaypointCollection;
/*    */ import baritone.api.command.exception.CommandException;
/*    */ import baritone.api.command.helpers.TabCompleteHelper;
/*    */ import java.util.Comparator;
/*    */ import java.util.stream.Stream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ForWaypoints
/*    */   implements IDatatypeFor<IWaypoint[]>
/*    */ {
/* 30 */   INSTANCE;
/*    */ 
/*    */   
/*    */   public IWaypoint[] get(IDatatypeContext ctx) throws CommandException {
/* 34 */     String input = ctx.getConsumer().getString();
/* 35 */     IWaypoint.Tag tag = IWaypoint.Tag.getByName(input);
/*    */ 
/*    */     
/* 38 */     return (tag == null) ? 
/* 39 */       getWaypointsByName(ctx.getBaritone(), input) : 
/* 40 */       getWaypointsByTag(ctx.getBaritone(), tag);
/*    */   }
/*    */ 
/*    */   
/*    */   public Stream<String> tabComplete(IDatatypeContext ctx) throws CommandException {
/* 45 */     return (new TabCompleteHelper())
/* 46 */       .append(getWaypointNames(ctx.getBaritone()))
/* 47 */       .sortAlphabetically()
/* 48 */       .prepend(IWaypoint.Tag.getAllNames())
/* 49 */       .filterPrefix(ctx.getConsumer().getString())
/* 50 */       .stream();
/*    */   }
/*    */   
/*    */   public static IWaypointCollection waypoints(IBaritone baritone) {
/* 54 */     return baritone.getWorldProvider().getCurrentWorld().getWaypoints();
/*    */   }
/*    */   
/*    */   public static IWaypoint[] getWaypoints(IBaritone baritone) {
/* 58 */     return (IWaypoint[])waypoints(baritone).getAllWaypoints().stream()
/* 59 */       .sorted(Comparator.comparingLong(IWaypoint::getCreationTimestamp).reversed())
/* 60 */       .toArray(x$0 -> new IWaypoint[x$0]);
/*    */   }
/*    */   
/*    */   public static String[] getWaypointNames(IBaritone baritone) {
/* 64 */     return (String[])Stream.<IWaypoint>of(getWaypoints(baritone))
/* 65 */       .map(IWaypoint::getName)
/* 66 */       .filter(name -> !name.isEmpty())
/* 67 */       .toArray(x$0 -> new String[x$0]);
/*    */   }
/*    */   
/*    */   public static IWaypoint[] getWaypointsByTag(IBaritone baritone, IWaypoint.Tag tag) {
/* 71 */     return (IWaypoint[])waypoints(baritone).getByTag(tag).stream()
/* 72 */       .sorted(Comparator.comparingLong(IWaypoint::getCreationTimestamp).reversed())
/* 73 */       .toArray(x$0 -> new IWaypoint[x$0]);
/*    */   }
/*    */   
/*    */   public static IWaypoint[] getWaypointsByName(IBaritone baritone, String name) {
/* 77 */     return (IWaypoint[])Stream.<IWaypoint>of(getWaypoints(baritone))
/* 78 */       .filter(waypoint -> waypoint.getName().equalsIgnoreCase(name))
/* 79 */       .toArray(x$0 -> new IWaypoint[x$0]);
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\command\datatypes\ForWaypoints.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */