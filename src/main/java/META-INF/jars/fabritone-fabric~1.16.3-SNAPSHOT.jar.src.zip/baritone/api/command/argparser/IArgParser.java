package baritone.api.command.argparser;

import baritone.api.command.argument.ICommandArgument;

public interface IArgParser<T> {
  Class<T> getTarget();
  
  public static interface Stated<T, S> extends IArgParser<T> {
    Class<S> getStateType();
    
    T parseArg(ICommandArgument param1ICommandArgument, S param1S) throws Exception;
  }
  
  public static interface Stateless<T> extends IArgParser<T> {
    T parseArg(ICommandArgument param1ICommandArgument) throws Exception;
  }
}


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\command\argparser\IArgParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */