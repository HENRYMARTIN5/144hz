/*     */ package baritone.api.utils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Rotation
/*     */ {
/*     */   private float yaw;
/*     */   private float pitch;
/*     */   
/*     */   public Rotation(float yaw, float pitch) {
/*  37 */     this.yaw = yaw;
/*  38 */     this.pitch = pitch;
/*  39 */     if (Float.isInfinite(yaw) || Float.isNaN(yaw) || Float.isInfinite(pitch) || Float.isNaN(pitch)) {
/*  40 */       throw new IllegalStateException(yaw + " " + pitch);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getYaw() {
/*  48 */     return this.yaw;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getPitch() {
/*  55 */     return this.pitch;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Rotation add(Rotation other) {
/*  66 */     return new Rotation(this.yaw + other.yaw, this.pitch + other.pitch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Rotation subtract(Rotation other) {
/*  80 */     return new Rotation(this.yaw - other.yaw, this.pitch - other.pitch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Rotation clamp() {
/*  90 */     return new Rotation(this.yaw, 
/*     */         
/*  92 */         clampPitch(this.pitch));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Rotation normalize() {
/* 100 */     return new Rotation(
/* 101 */         normalizeYaw(this.yaw), this.pitch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Rotation normalizeAndClamp() {
/* 110 */     return new Rotation(
/* 111 */         normalizeYaw(this.yaw), 
/* 112 */         clampPitch(this.pitch));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReallyCloseTo(Rotation other) {
/* 123 */     return (yawIsReallyClose(other) && Math.abs(this.pitch - other.pitch) < 0.01D);
/*     */   }
/*     */   
/*     */   public boolean yawIsReallyClose(Rotation other) {
/* 127 */     float yawDiff = Math.abs(normalizeYaw(this.yaw) - normalizeYaw(other.yaw));
/* 128 */     return (yawDiff < 0.01D || yawDiff > 359.99D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float clampPitch(float pitch) {
/* 138 */     return Math.max(-90.0F, Math.min(90.0F, pitch));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float normalizeYaw(float yaw) {
/* 148 */     float newYaw = yaw % 360.0F;
/* 149 */     if (newYaw < -180.0F) {
/* 150 */       newYaw += 360.0F;
/*     */     }
/* 152 */     if (newYaw > 180.0F) {
/* 153 */       newYaw -= 360.0F;
/*     */     }
/* 155 */     return newYaw;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 160 */     return "Yaw: " + this.yaw + ", Pitch: " + this.pitch;
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\ap\\utils\Rotation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */