/*    */ package baritone.api.schematic;
/*    */ 
/*    */ import java.util.List;
/*    */ import net.minecraft.class_2680;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class MaskSchematic
/*    */   extends AbstractSchematic
/*    */ {
/*    */   private final ISchematic schematic;
/*    */   
/*    */   public MaskSchematic(ISchematic schematic) {
/* 29 */     super(schematic.widthX(), schematic.heightY(), schematic.lengthZ());
/* 30 */     this.schematic = schematic;
/*    */   }
/*    */ 
/*    */   
/*    */   protected abstract boolean partOfMask(int paramInt1, int paramInt2, int paramInt3, class_2680 paramclass_2680);
/*    */   
/*    */   public boolean inSchematic(int x, int y, int z, class_2680 currentState) {
/* 37 */     return (this.schematic.inSchematic(x, y, z, currentState) && partOfMask(x, y, z, currentState));
/*    */   }
/*    */ 
/*    */   
/*    */   public class_2680 desiredState(int x, int y, int z, class_2680 current, List<class_2680> approxPlaceable) {
/* 42 */     return this.schematic.desiredState(x, y, z, current, approxPlaceable);
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\schematic\MaskSchematic.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */