/*    */ package baritone.api;
/*    */ 
/*    */ import baritone.api.cache.IWorldScanner;
/*    */ import baritone.api.command.ICommandSystem;
/*    */ import baritone.api.schematic.ISchematicSystem;
/*    */ import java.util.List;
/*    */ import java.util.Objects;
/*    */ import net.minecraft.class_746;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IBaritoneProvider
/*    */ {
/*    */   IBaritone getPrimaryBaritone();
/*    */   
/*    */   List<IBaritone> getAllBaritones();
/*    */   
/*    */   default IBaritone getBaritoneForPlayer(class_746 player) {
/* 63 */     for (IBaritone baritone : getAllBaritones()) {
/* 64 */       if (Objects.equals(player, baritone.getPlayerContext().player())) {
/* 65 */         return baritone;
/*    */       }
/*    */     } 
/* 68 */     return null;
/*    */   }
/*    */   
/*    */   IWorldScanner getWorldScanner();
/*    */   
/*    */   ICommandSystem getCommandSystem();
/*    */   
/*    */   ISchematicSystem getSchematicSystem();
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\IBaritoneProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */