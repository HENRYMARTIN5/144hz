/*     */ package baritone.api.command.helpers;
/*     */ 
/*     */ import baritone.api.command.argument.IArgConsumer;
/*     */ import baritone.api.command.exception.CommandException;
/*     */ import baritone.api.command.exception.CommandInvalidTypeException;
/*     */ import baritone.api.utils.Helper;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.function.Function;
/*     */ import net.minecraft.class_124;
/*     */ import net.minecraft.class_2558;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_2568;
/*     */ import net.minecraft.class_2585;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Paginator<E>
/*     */   implements Helper
/*     */ {
/*     */   public final List<E> entries;
/*  34 */   public int pageSize = 8;
/*  35 */   public int page = 1;
/*     */   
/*     */   public Paginator(List<E> entries) {
/*  38 */     this.entries = entries;
/*     */   }
/*     */   
/*     */   public Paginator(E... entries) {
/*  42 */     this.entries = Arrays.asList(entries);
/*     */   }
/*     */   
/*     */   public Paginator<E> setPageSize(int pageSize) {
/*  46 */     this.pageSize = pageSize;
/*  47 */     return this;
/*     */   }
/*     */   
/*     */   public int getMaxPage() {
/*  51 */     return (this.entries.size() - 1) / this.pageSize + 1;
/*     */   }
/*     */   
/*     */   public boolean validPage(int page) {
/*  55 */     return (page > 0 && page <= getMaxPage());
/*     */   }
/*     */   
/*     */   public Paginator<E> skipPages(int pages) {
/*  59 */     this.page += pages;
/*  60 */     return this;
/*     */   }
/*     */   
/*     */   public void display(Function<E, class_2561> transform, String commandPrefix) {
/*  64 */     int offset = (this.page - 1) * this.pageSize;
/*  65 */     for (int i = offset; i < offset + this.pageSize; i++) {
/*  66 */       if (i < this.entries.size()) {
/*  67 */         logDirect(new class_2561[] { transform.apply(this.entries.get(i)) });
/*     */       } else {
/*  69 */         logDirect("--", class_124.field_1063);
/*     */       } 
/*     */     } 
/*  72 */     boolean hasPrevPage = (commandPrefix != null && validPage(this.page - 1));
/*  73 */     boolean hasNextPage = (commandPrefix != null && validPage(this.page + 1));
/*  74 */     class_2585 class_25851 = new class_2585("<<");
/*  75 */     if (hasPrevPage) {
/*  76 */       class_25851.method_10862(class_25851.method_10866()
/*  77 */           .method_10958(new class_2558(class_2558.class_2559.field_11750, 
/*     */               
/*  79 */               String.format("%s %d", new Object[] { commandPrefix, Integer.valueOf(this.page - 1)
/*     */                 
/*  81 */                 }))).method_10949(new class_2568(class_2568.class_5247.field_24342, new class_2585("Click to view previous page"))));
/*     */     
/*     */     }
/*     */     else {
/*     */       
/*  86 */       class_25851.method_10862(class_25851.method_10866().method_27706(class_124.field_1063));
/*     */     } 
/*  88 */     class_2585 class_25852 = new class_2585(">>");
/*  89 */     if (hasNextPage) {
/*  90 */       class_25852.method_10862(class_25852.method_10866()
/*  91 */           .method_10958(new class_2558(class_2558.class_2559.field_11750, 
/*     */               
/*  93 */               String.format("%s %d", new Object[] { commandPrefix, Integer.valueOf(this.page + 1)
/*     */                 
/*  95 */                 }))).method_10949(new class_2568(class_2568.class_5247.field_24342, new class_2585("Click to view next page"))));
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 100 */       class_25852.method_10862(class_25852.method_10866().method_27706(class_124.field_1063));
/*     */     } 
/* 102 */     class_2585 class_25853 = new class_2585("");
/* 103 */     class_25853.method_10862(class_25853.method_10866().method_27706(class_124.field_1080));
/* 104 */     class_25853.method_10852((class_2561)class_25851);
/* 105 */     class_25853.method_27693(" | ");
/* 106 */     class_25853.method_10852((class_2561)class_25852);
/* 107 */     class_25853.method_27693(String.format(" %d/%d", new Object[] { Integer.valueOf(this.page), Integer.valueOf(getMaxPage()) }));
/* 108 */     logDirect(new class_2561[] { (class_2561)class_25853 });
/*     */   }
/*     */   
/*     */   public void display(Function<E, class_2561> transform) {
/* 112 */     display(transform, (String)null);
/*     */   }
/*     */   
/*     */   public static <T> void paginate(IArgConsumer consumer, Paginator<T> pagi, Runnable pre, Function<T, class_2561> transform, String commandPrefix) throws CommandException {
/* 116 */     int page = 1;
/* 117 */     consumer.requireMax(1);
/* 118 */     if (consumer.hasAny()) {
/* 119 */       page = ((Integer)consumer.getAs(Integer.class)).intValue();
/* 120 */       if (!pagi.validPage(page)) {
/* 121 */         throw new CommandInvalidTypeException(consumer
/* 122 */             .consumed(), 
/* 123 */             String.format("a valid page (1-%d)", new Object[] {
/*     */                 
/* 125 */                 Integer.valueOf(pagi.getMaxPage())
/*     */               
/* 127 */               }), consumer.consumed().getValue());
/*     */       }
/*     */     } 
/*     */     
/* 131 */     pagi.skipPages(page - pagi.page);
/* 132 */     if (pre != null) {
/* 133 */       pre.run();
/*     */     }
/* 135 */     pagi.display(transform, commandPrefix);
/*     */   }
/*     */   
/*     */   public static <T> void paginate(IArgConsumer consumer, List<T> elems, Runnable pre, Function<T, class_2561> transform, String commandPrefix) throws CommandException {
/* 139 */     paginate(consumer, new Paginator<>(elems), pre, transform, commandPrefix);
/*     */   }
/*     */   
/*     */   public static <T> void paginate(IArgConsumer consumer, T[] elems, Runnable pre, Function<T, class_2561> transform, String commandPrefix) throws CommandException {
/* 143 */     paginate(consumer, Arrays.asList(elems), pre, transform, commandPrefix);
/*     */   }
/*     */   
/*     */   public static <T> void paginate(IArgConsumer consumer, Paginator<T> pagi, Function<T, class_2561> transform, String commandPrefix) throws CommandException {
/* 147 */     paginate(consumer, pagi, (Runnable)null, transform, commandPrefix);
/*     */   }
/*     */   
/*     */   public static <T> void paginate(IArgConsumer consumer, List<T> elems, Function<T, class_2561> transform, String commandPrefix) throws CommandException {
/* 151 */     paginate(consumer, new Paginator<>(elems), (Runnable)null, transform, commandPrefix);
/*     */   }
/*     */   
/*     */   public static <T> void paginate(IArgConsumer consumer, T[] elems, Function<T, class_2561> transform, String commandPrefix) throws CommandException {
/* 155 */     paginate(consumer, Arrays.asList(elems), (Runnable)null, transform, commandPrefix);
/*     */   }
/*     */   
/*     */   public static <T> void paginate(IArgConsumer consumer, Paginator<T> pagi, Runnable pre, Function<T, class_2561> transform) throws CommandException {
/* 159 */     paginate(consumer, pagi, pre, transform, (String)null);
/*     */   }
/*     */   
/*     */   public static <T> void paginate(IArgConsumer consumer, List<T> elems, Runnable pre, Function<T, class_2561> transform) throws CommandException {
/* 163 */     paginate(consumer, new Paginator<>(elems), pre, transform, (String)null);
/*     */   }
/*     */   
/*     */   public static <T> void paginate(IArgConsumer consumer, T[] elems, Runnable pre, Function<T, class_2561> transform) throws CommandException {
/* 167 */     paginate(consumer, Arrays.asList(elems), pre, transform, (String)null);
/*     */   }
/*     */   
/*     */   public static <T> void paginate(IArgConsumer consumer, Paginator<T> pagi, Function<T, class_2561> transform) throws CommandException {
/* 171 */     paginate(consumer, pagi, (Runnable)null, transform, (String)null);
/*     */   }
/*     */   
/*     */   public static <T> void paginate(IArgConsumer consumer, List<T> elems, Function<T, class_2561> transform) throws CommandException {
/* 175 */     paginate(consumer, new Paginator<>(elems), (Runnable)null, transform, (String)null);
/*     */   }
/*     */   
/*     */   public static <T> void paginate(IArgConsumer consumer, T[] elems, Function<T, class_2561> transform) throws CommandException {
/* 179 */     paginate(consumer, Arrays.asList(elems), (Runnable)null, transform, (String)null);
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\command\helpers\Paginator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */