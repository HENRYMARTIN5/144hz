/*    */ package baritone.api.command.datatypes;
/*    */ 
/*    */ import baritone.api.command.exception.CommandException;
/*    */ import baritone.api.command.helpers.TabCompleteHelper;
/*    */ import java.util.List;
/*    */ import java.util.stream.Stream;
/*    */ import net.minecraft.class_1657;
/*    */ import net.minecraft.class_2561;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum NearbyPlayer
/*    */   implements IDatatypeFor<class_1657>
/*    */ {
/* 34 */   INSTANCE;
/*    */ 
/*    */   
/*    */   public class_1657 get(IDatatypeContext ctx) throws CommandException {
/* 38 */     String username = ctx.getConsumer().getString();
/* 39 */     return getPlayers(ctx).stream()
/* 40 */       .filter(s -> s.method_5477().getString().equalsIgnoreCase(username))
/* 41 */       .findFirst().orElse(null);
/*    */   }
/*    */ 
/*    */   
/*    */   public Stream<String> tabComplete(IDatatypeContext ctx) throws CommandException {
/* 46 */     return (new TabCompleteHelper())
/* 47 */       .append(getPlayers(ctx).stream().map(class_1657::method_5477).map(class_2561::getString))
/* 48 */       .filterPrefix(ctx.getConsumer().getString())
/* 49 */       .sortAlphabetically()
/* 50 */       .stream();
/*    */   }
/*    */   
/*    */   private static List<? extends class_1657> getPlayers(IDatatypeContext ctx) {
/* 54 */     return ctx.getBaritone().getPlayerContext().world().method_18456();
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\command\datatypes\NearbyPlayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */