/*    */ package baritone.api.event.events;
/*    */ 
/*    */ import net.minecraft.class_1159;
/*    */ import net.minecraft.class_4587;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RenderEvent
/*    */ {
/*    */   private final float partialTicks;
/*    */   private final class_1159 projectionMatrix;
/*    */   private final class_4587 modelViewStack;
/*    */   
/*    */   public RenderEvent(float partialTicks, class_4587 modelViewStack, class_1159 projectionMatrix) {
/* 38 */     this.partialTicks = partialTicks;
/* 39 */     this.modelViewStack = modelViewStack;
/* 40 */     this.projectionMatrix = projectionMatrix;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final float getPartialTicks() {
/* 47 */     return this.partialTicks;
/*    */   }
/*    */   
/*    */   public class_4587 getModelViewStack() {
/* 51 */     return this.modelViewStack;
/*    */   }
/*    */   
/*    */   public class_1159 getProjectionMatrix() {
/* 55 */     return this.projectionMatrix;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\event\events\RenderEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */