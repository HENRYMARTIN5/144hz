package baritone.api.pathing.movement;

import baritone.api.utils.BetterBlockPos;
import net.minecraft.class_2338;

public interface IMovement {
  double getCost();
  
  MovementStatus update();
  
  void reset();
  
  void resetBlockCache();
  
  boolean safeToCancel();
  
  boolean calculatedWhileLoaded();
  
  BetterBlockPos getSrc();
  
  BetterBlockPos getDest();
  
  class_2338 getDirection();
}


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\pathing\movement\IMovement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */