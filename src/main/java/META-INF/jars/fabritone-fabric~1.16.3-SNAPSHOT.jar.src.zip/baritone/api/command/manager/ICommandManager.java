package baritone.api.command.manager;

import baritone.api.IBaritone;
import baritone.api.command.ICommand;
import baritone.api.command.argument.ICommandArgument;
import baritone.api.command.registry.Registry;
import java.util.List;
import java.util.stream.Stream;
import net.minecraft.class_3545;

public interface ICommandManager {
  IBaritone getBaritone();
  
  Registry<ICommand> getRegistry();
  
  ICommand getCommand(String paramString);
  
  boolean execute(String paramString);
  
  boolean execute(class_3545<String, List<ICommandArgument>> paramclass_3545);
  
  Stream<String> tabComplete(class_3545<String, List<ICommandArgument>> paramclass_3545);
  
  Stream<String> tabComplete(String paramString);
}


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\command\manager\ICommandManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */