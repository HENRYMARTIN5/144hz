/*    */ package baritone.api.event.events;
/*    */ 
/*    */ import net.minecraft.class_2338;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BlockInteractEvent
/*    */ {
/*    */   private final class_2338 pos;
/*    */   private final Type type;
/*    */   
/*    */   public BlockInteractEvent(class_2338 pos, Type type) {
/* 41 */     this.pos = pos;
/* 42 */     this.type = type;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final class_2338 getPos() {
/* 49 */     return this.pos;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final Type getType() {
/* 56 */     return this.type;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public enum Type
/*    */   {
/* 64 */     START_BREAK,
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 69 */     USE;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\event\events\BlockInteractEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */