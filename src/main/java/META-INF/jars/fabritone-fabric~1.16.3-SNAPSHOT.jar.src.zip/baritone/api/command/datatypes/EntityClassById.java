/*    */ package baritone.api.command.datatypes;
/*    */ 
/*    */ import baritone.api.command.exception.CommandException;
/*    */ import baritone.api.command.helpers.TabCompleteHelper;
/*    */ import java.util.stream.Stream;
/*    */ import net.minecraft.class_1299;
/*    */ import net.minecraft.class_2378;
/*    */ import net.minecraft.class_2960;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum EntityClassById
/*    */   implements IDatatypeFor<class_1299>
/*    */ {
/* 29 */   INSTANCE;
/*    */ 
/*    */   
/*    */   public class_1299 get(IDatatypeContext ctx) throws CommandException {
/* 33 */     class_2960 id = new class_2960(ctx.getConsumer().getString());
/*    */     class_1299 entity;
/* 35 */     if ((entity = class_2378.field_11145.method_17966(id).orElse(null)) == null) {
/* 36 */       throw new IllegalArgumentException("no entity found by that id");
/*    */     }
/* 38 */     return entity;
/*    */   }
/*    */ 
/*    */   
/*    */   public Stream<String> tabComplete(IDatatypeContext ctx) throws CommandException {
/* 43 */     return (new TabCompleteHelper())
/* 44 */       .append(class_2378.field_11145.method_10220().map(Object::toString))
/* 45 */       .filterPrefixNamespaced(ctx.getConsumer().getString())
/* 46 */       .sortAlphabetically()
/* 47 */       .stream();
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\command\datatypes\EntityClassById.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */