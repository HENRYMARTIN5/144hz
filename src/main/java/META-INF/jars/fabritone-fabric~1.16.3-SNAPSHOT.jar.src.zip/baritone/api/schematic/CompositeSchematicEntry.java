/*    */ package baritone.api.schematic;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompositeSchematicEntry
/*    */ {
/*    */   public final ISchematic schematic;
/*    */   public final int x;
/*    */   public final int y;
/*    */   public final int z;
/*    */   
/*    */   public CompositeSchematicEntry(ISchematic schematic, int x, int y, int z) {
/* 28 */     this.schematic = schematic;
/* 29 */     this.x = x;
/* 30 */     this.y = y;
/* 31 */     this.z = z;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\schematic\CompositeSchematicEntry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */