/*    */ package baritone.api.command.exception;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CommandTooManyArgumentsException
/*    */   extends CommandErrorMessageException
/*    */ {
/*    */   public CommandTooManyArgumentsException(int maxArgs) {
/* 23 */     super(String.format("Too many arguments (expected at most %d)", new Object[] { Integer.valueOf(maxArgs) }));
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\command\exception\CommandTooManyArgumentsException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */