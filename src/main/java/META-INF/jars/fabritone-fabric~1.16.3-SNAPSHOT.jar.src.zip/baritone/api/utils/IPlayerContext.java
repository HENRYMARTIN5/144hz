/*     */ package baritone.api.utils;
/*     */ 
/*     */ import baritone.api.cache.IWorldData;
/*     */ import java.util.Optional;
/*     */ import java.util.stream.Stream;
/*     */ import java.util.stream.StreamSupport;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1937;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_239;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_3965;
/*     */ import net.minecraft.class_638;
/*     */ import net.minecraft.class_746;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface IPlayerContext
/*     */ {
/*     */   class_746 player();
/*     */   
/*     */   IPlayerController playerController();
/*     */   
/*     */   class_1937 world();
/*     */   
/*     */   default Iterable<class_1297> entities() {
/*  48 */     return ((class_638)world()).method_18112();
/*     */   }
/*     */   
/*     */   default Stream<class_1297> entitiesStream() {
/*  52 */     return StreamSupport.stream(entities().spliterator(), false);
/*     */   }
/*     */ 
/*     */   
/*     */   IWorldData worldData();
/*     */ 
/*     */   
/*     */   class_239 objectMouseOver();
/*     */   
/*     */   default BetterBlockPos playerFeet() {
/*  62 */     BetterBlockPos feet = new BetterBlockPos(player().method_23317(), player().method_23318() + 0.1251D, player().method_23321());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  73 */       if (world().method_8320(feet).method_26204() instanceof net.minecraft.class_2482) {
/*  74 */         return feet.up();
/*     */       }
/*  76 */     } catch (NullPointerException nullPointerException) {}
/*     */     
/*  78 */     return feet;
/*     */   }
/*     */   
/*     */   default class_243 playerFeetAsVec() {
/*  82 */     return new class_243(player().method_23317(), player().method_23318(), player().method_23321());
/*     */   }
/*     */   
/*     */   default class_243 playerHead() {
/*  86 */     return new class_243(player().method_23317(), player().method_23318() + player().method_5751(), player().method_23321());
/*     */   }
/*     */   
/*     */   default Rotation playerRotations() {
/*  90 */     return new Rotation((player()).field_6031, (player()).field_5965);
/*     */   }
/*     */   
/*     */   static double eyeHeight(boolean ifSneaking) {
/*  94 */     return ifSneaking ? 1.27D : 1.62D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Optional<class_2338> getSelectedBlock() {
/* 103 */     class_239 result = objectMouseOver();
/* 104 */     if (result != null && result.method_17783() == class_239.class_240.field_1332) {
/* 105 */       return Optional.of(((class_3965)result).method_17777());
/*     */     }
/* 107 */     return Optional.empty();
/*     */   }
/*     */   
/*     */   default boolean isLookingAt(class_2338 pos) {
/* 111 */     return getSelectedBlock().equals(Optional.of(pos));
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\ap\\utils\IPlayerContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */