/*    */ package baritone.api.command.exception;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class CommandErrorMessageException
/*    */   extends CommandException
/*    */ {
/*    */   protected CommandErrorMessageException(String reason) {
/* 23 */     super(reason);
/*    */   }
/*    */   
/*    */   protected CommandErrorMessageException(String reason, Throwable cause) {
/* 27 */     super(reason, cause);
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\command\exception\CommandErrorMessageException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */