/*    */ package baritone.api.pathing.goals;
/*    */ 
/*    */ import baritone.api.utils.SettingsUtil;
/*    */ import baritone.api.utils.interfaces.IGoalRenderPos;
/*    */ import net.minecraft.class_2338;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GoalGetToBlock
/*    */   implements Goal, IGoalRenderPos
/*    */ {
/*    */   public final int x;
/*    */   public final int y;
/*    */   public final int z;
/*    */   
/*    */   public GoalGetToBlock(class_2338 pos) {
/* 37 */     this.x = pos.method_10263();
/* 38 */     this.y = pos.method_10264();
/* 39 */     this.z = pos.method_10260();
/*    */   }
/*    */ 
/*    */   
/*    */   public class_2338 getGoalPos() {
/* 44 */     return new class_2338(this.x, this.y, this.z);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isInGoal(int x, int y, int z) {
/* 49 */     int xDiff = x - this.x;
/* 50 */     int yDiff = y - this.y;
/* 51 */     int zDiff = z - this.z;
/* 52 */     return (Math.abs(xDiff) + Math.abs((yDiff < 0) ? (yDiff + 1) : yDiff) + Math.abs(zDiff) <= 1);
/*    */   }
/*    */ 
/*    */   
/*    */   public double heuristic(int x, int y, int z) {
/* 57 */     int xDiff = x - this.x;
/* 58 */     int yDiff = y - this.y;
/* 59 */     int zDiff = z - this.z;
/* 60 */     return GoalBlock.calculate(xDiff, (yDiff < 0) ? (yDiff + 1) : yDiff, zDiff);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 65 */     return String.format("GoalGetToBlock{x=%s,y=%s,z=%s}", new Object[] {
/*    */           
/* 67 */           SettingsUtil.maybeCensor(this.x), 
/* 68 */           SettingsUtil.maybeCensor(this.y), 
/* 69 */           SettingsUtil.maybeCensor(this.z)
/*    */         });
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\pathing\goals\GoalGetToBlock.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */