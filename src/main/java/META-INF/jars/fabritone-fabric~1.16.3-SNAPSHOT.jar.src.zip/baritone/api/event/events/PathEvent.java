/*    */ package baritone.api.event.events;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum PathEvent
/*    */ {
/* 21 */   CALC_STARTED,
/* 22 */   CALC_FINISHED_NOW_EXECUTING,
/* 23 */   CALC_FAILED,
/* 24 */   NEXT_SEGMENT_CALC_STARTED,
/* 25 */   NEXT_SEGMENT_CALC_FINISHED,
/* 26 */   CONTINUING_ONTO_PLANNED_NEXT,
/* 27 */   SPLICING_ONTO_NEXT_EARLY,
/* 28 */   AT_GOAL,
/* 29 */   PATH_FINISHED_NEXT_STILL_CALCULATING,
/* 30 */   NEXT_CALC_FAILED,
/* 31 */   DISCARD_NEXT,
/* 32 */   CANCELED;
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\event\events\PathEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */