/*    */ package baritone.api.event.events;
/*    */ 
/*    */ import baritone.api.event.events.type.EventState;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PlayerUpdateEvent
/*    */ {
/*    */   private final EventState state;
/*    */   
/*    */   public PlayerUpdateEvent(EventState state) {
/* 34 */     this.state = state;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final EventState getState() {
/* 41 */     return this.state;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\event\events\PlayerUpdateEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */