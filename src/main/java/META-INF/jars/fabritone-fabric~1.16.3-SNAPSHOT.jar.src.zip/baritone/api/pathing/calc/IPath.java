/*     */ package baritone.api.pathing.calc;
/*     */ 
/*     */ import baritone.api.pathing.goals.Goal;
/*     */ import baritone.api.pathing.movement.IMovement;
/*     */ import baritone.api.utils.BetterBlockPos;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface IPath
/*     */ {
/*     */   List<IMovement> movements();
/*     */   
/*     */   List<BetterBlockPos> positions();
/*     */   
/*     */   default IPath postProcess() {
/*  58 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default int length() {
/*  67 */     return positions().size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Goal getGoal();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getNumNodesConsidered();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default BetterBlockPos getSrc() {
/*  90 */     return positions().get(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default BetterBlockPos getDest() {
/* 100 */     List<BetterBlockPos> pos = positions();
/* 101 */     return pos.get(pos.size() - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default double ticksRemainingFrom(int pathPosition) {
/* 111 */     double sum = 0.0D;
/*     */     
/* 113 */     List<IMovement> movements = movements();
/* 114 */     for (int i = pathPosition; i < movements.size(); i++) {
/* 115 */       sum += ((IMovement)movements.get(i)).getCost();
/*     */     }
/* 117 */     return sum;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default IPath cutoffAtLoadedChunks(Object bsi) {
/* 130 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default IPath staticCutoff(Goal destination) {
/* 143 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void sanityCheck() {
/* 151 */     List<BetterBlockPos> path = positions();
/* 152 */     List<IMovement> movements = movements();
/* 153 */     if (!getSrc().equals(path.get(0))) {
/* 154 */       throw new IllegalStateException("Start node does not equal first path element");
/*     */     }
/* 156 */     if (!getDest().equals(path.get(path.size() - 1))) {
/* 157 */       throw new IllegalStateException("End node does not equal last path element");
/*     */     }
/* 159 */     if (path.size() != movements.size() + 1) {
/* 160 */       throw new IllegalStateException("Size of path array is unexpected");
/*     */     }
/* 162 */     HashSet<BetterBlockPos> seenSoFar = new HashSet<>();
/* 163 */     for (int i = 0; i < path.size() - 1; i++) {
/* 164 */       BetterBlockPos src = path.get(i);
/* 165 */       BetterBlockPos dest = path.get(i + 1);
/* 166 */       IMovement movement = movements.get(i);
/* 167 */       if (!src.equals(movement.getSrc())) {
/* 168 */         throw new IllegalStateException("Path source is not equal to the movement source");
/*     */       }
/* 170 */       if (!dest.equals(movement.getDest())) {
/* 171 */         throw new IllegalStateException("Path destination is not equal to the movement destination");
/*     */       }
/* 173 */       if (seenSoFar.contains(src)) {
/* 174 */         throw new IllegalStateException("Path doubles back on itself, making a loop");
/*     */       }
/* 176 */       seenSoFar.add(src);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\pathing\calc\IPath.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */