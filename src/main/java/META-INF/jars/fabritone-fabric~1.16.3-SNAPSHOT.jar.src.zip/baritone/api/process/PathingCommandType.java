/*    */ package baritone.api.process;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum PathingCommandType
/*    */ {
/* 29 */   SET_GOAL_AND_PATH,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 34 */   REQUEST_PAUSE,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 39 */   CANCEL_AND_SET_GOAL,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 47 */   REVALIDATE_GOAL_AND_PATH,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 54 */   FORCE_REVALIDATE_GOAL_AND_PATH,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 59 */   DEFER;
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\process\PathingCommandType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */