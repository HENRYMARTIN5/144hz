/*    */ package baritone.api.pathing.goals;
/*    */ 
/*    */ import net.minecraft.class_2338;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface Goal
/*    */ {
/*    */   boolean isInGoal(int paramInt1, int paramInt2, int paramInt3);
/*    */   
/*    */   double heuristic(int paramInt1, int paramInt2, int paramInt3);
/*    */   
/*    */   default boolean isInGoal(class_2338 pos) {
/* 51 */     return isInGoal(pos.method_10263(), pos.method_10264(), pos.method_10260());
/*    */   }
/*    */   
/*    */   default double heuristic(class_2338 pos) {
/* 55 */     return heuristic(pos.method_10263(), pos.method_10264(), pos.method_10260());
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\pathing\goals\Goal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */