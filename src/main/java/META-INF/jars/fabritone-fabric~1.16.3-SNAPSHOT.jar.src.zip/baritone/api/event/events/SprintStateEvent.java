/*    */ package baritone.api.event.events;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SprintStateEvent
/*    */ {
/*    */   private Boolean state;
/*    */   
/*    */   public final void setState(boolean state) {
/* 29 */     this.state = Boolean.valueOf(state);
/*    */   }
/*    */   
/*    */   public final Boolean getState() {
/* 33 */     return this.state;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\event\events\SprintStateEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */