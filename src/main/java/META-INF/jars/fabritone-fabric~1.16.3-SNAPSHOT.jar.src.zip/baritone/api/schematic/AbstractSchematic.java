/*    */ package baritone.api.schematic;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractSchematic
/*    */   implements ISchematic
/*    */ {
/*    */   protected int x;
/*    */   protected int y;
/*    */   protected int z;
/*    */   
/*    */   public AbstractSchematic() {
/* 27 */     this(0, 0, 0);
/*    */   }
/*    */   
/*    */   public AbstractSchematic(int x, int y, int z) {
/* 31 */     this.x = x;
/* 32 */     this.y = y;
/* 33 */     this.z = z;
/*    */   }
/*    */ 
/*    */   
/*    */   public int widthX() {
/* 38 */     return this.x;
/*    */   }
/*    */ 
/*    */   
/*    */   public int heightY() {
/* 43 */     return this.y;
/*    */   }
/*    */ 
/*    */   
/*    */   public int lengthZ() {
/* 48 */     return this.z;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\schematic\AbstractSchematic.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */