/*    */ package baritone.api.pathing.goals;
/*    */ 
/*    */ import baritone.api.utils.SettingsUtil;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_2350;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GoalStrictDirection
/*    */   implements Goal
/*    */ {
/*    */   public final int x;
/*    */   public final int y;
/*    */   public final int z;
/*    */   public final int dx;
/*    */   public final int dz;
/*    */   
/*    */   public GoalStrictDirection(class_2338 origin, class_2350 direction) {
/* 36 */     this.x = origin.method_10263();
/* 37 */     this.y = origin.method_10264();
/* 38 */     this.z = origin.method_10260();
/* 39 */     this.dx = direction.method_10148();
/* 40 */     this.dz = direction.method_10165();
/* 41 */     if (this.dx == 0 && this.dz == 0) {
/* 42 */       throw new IllegalArgumentException(direction + "");
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isInGoal(int x, int y, int z) {
/* 48 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public double heuristic(int x, int y, int z) {
/* 53 */     int distanceFromStartInDesiredDirection = (x - this.x) * this.dx + (z - this.z) * this.dz;
/*    */     
/* 55 */     int distanceFromStartInIncorrectDirection = Math.abs((x - this.x) * this.dz) + Math.abs((z - this.z) * this.dx);
/*    */     
/* 57 */     int verticalDistanceFromStart = Math.abs(y - this.y);
/*    */ 
/*    */     
/* 60 */     double heuristic = (-distanceFromStartInDesiredDirection * 100);
/*    */     
/* 62 */     heuristic += (distanceFromStartInIncorrectDirection * 1000);
/* 63 */     heuristic += (verticalDistanceFromStart * 1000);
/* 64 */     return heuristic;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 69 */     return String.format("GoalStrictDirection{x=%s, y=%s, z=%s, dx=%s, dz=%s}", new Object[] {
/*    */           
/* 71 */           SettingsUtil.maybeCensor(this.x), 
/* 72 */           SettingsUtil.maybeCensor(this.y), 
/* 73 */           SettingsUtil.maybeCensor(this.z), 
/* 74 */           SettingsUtil.maybeCensor(this.dx), 
/* 75 */           SettingsUtil.maybeCensor(this.dz)
/*    */         });
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\pathing\goals\GoalStrictDirection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */