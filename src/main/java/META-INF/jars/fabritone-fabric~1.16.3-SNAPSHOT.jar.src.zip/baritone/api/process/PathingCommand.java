/*    */ package baritone.api.process;
/*    */ 
/*    */ import baritone.api.pathing.goals.Goal;
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PathingCommand
/*    */ {
/*    */   public final Goal goal;
/*    */   public final PathingCommandType commandType;
/*    */   
/*    */   public PathingCommand(Goal goal, PathingCommandType commandType) {
/* 51 */     Objects.requireNonNull(commandType);
/*    */     
/* 53 */     this.goal = goal;
/* 54 */     this.commandType = commandType;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 59 */     return this.commandType + " " + this.goal;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\process\PathingCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */