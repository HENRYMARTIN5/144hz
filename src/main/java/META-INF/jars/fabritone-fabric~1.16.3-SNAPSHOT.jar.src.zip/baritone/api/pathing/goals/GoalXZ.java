/*     */ package baritone.api.pathing.goals;
/*     */ 
/*     */ import baritone.api.BaritoneAPI;
/*     */ import baritone.api.utils.BetterBlockPos;
/*     */ import baritone.api.utils.SettingsUtil;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_3532;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GoalXZ
/*     */   implements Goal
/*     */ {
/*  33 */   private static final double SQRT_2 = Math.sqrt(2.0D);
/*     */ 
/*     */ 
/*     */   
/*     */   private final int x;
/*     */ 
/*     */ 
/*     */   
/*     */   private final int z;
/*     */ 
/*     */ 
/*     */   
/*     */   public GoalXZ(int x, int z) {
/*  46 */     this.x = x;
/*  47 */     this.z = z;
/*     */   }
/*     */   
/*     */   public GoalXZ(BetterBlockPos pos) {
/*  51 */     this.x = pos.x;
/*  52 */     this.z = pos.z;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isInGoal(int x, int y, int z) {
/*  57 */     return (x == this.x && z == this.z);
/*     */   }
/*     */ 
/*     */   
/*     */   public double heuristic(int x, int y, int z) {
/*  62 */     int xDiff = x - this.x;
/*  63 */     int zDiff = z - this.z;
/*  64 */     return calculate(xDiff, zDiff);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  69 */     return String.format("GoalXZ{x=%s,z=%s}", new Object[] {
/*     */           
/*  71 */           SettingsUtil.maybeCensor(this.x), 
/*  72 */           SettingsUtil.maybeCensor(this.z)
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double calculate(double xDiff, double zDiff) {
/*  82 */     double straight, diagonal, x = Math.abs(xDiff);
/*  83 */     double z = Math.abs(zDiff);
/*     */ 
/*     */     
/*  86 */     if (x < z) {
/*  87 */       straight = z - x;
/*  88 */       diagonal = x;
/*     */     } else {
/*  90 */       straight = x - z;
/*  91 */       diagonal = z;
/*     */     } 
/*  93 */     diagonal *= SQRT_2;
/*  94 */     return (diagonal + straight) * ((Double)(BaritoneAPI.getSettings()).costHeuristic.value).doubleValue();
/*     */   }
/*     */   
/*     */   public static GoalXZ fromDirection(class_243 origin, float yaw, double distance) {
/*  98 */     float theta = (float)Math.toRadians(yaw);
/*  99 */     double x = origin.field_1352 - class_3532.method_15374(theta) * distance;
/* 100 */     double z = origin.field_1350 + class_3532.method_15362(theta) * distance;
/* 101 */     return new GoalXZ(class_3532.method_15357(x), class_3532.method_15357(z));
/*     */   }
/*     */   
/*     */   public int getX() {
/* 105 */     return this.x;
/*     */   }
/*     */   
/*     */   public int getZ() {
/* 109 */     return this.z;
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\pathing\goals\GoalXZ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */