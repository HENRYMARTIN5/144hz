/*    */ package baritone.api.command.exception;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CommandNoParserForTypeException
/*    */   extends CommandUnhandledException
/*    */ {
/*    */   public CommandNoParserForTypeException(Class<?> klass) {
/* 23 */     super(String.format("Could not find a handler for type %s", new Object[] { klass.getSimpleName() }));
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\command\exception\CommandNoParserForTypeException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */