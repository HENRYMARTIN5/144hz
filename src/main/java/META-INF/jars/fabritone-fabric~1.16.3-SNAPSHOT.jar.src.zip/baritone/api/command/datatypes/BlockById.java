/*    */ package baritone.api.command.datatypes;
/*    */ 
/*    */ import baritone.api.command.exception.CommandException;
/*    */ import baritone.api.command.helpers.TabCompleteHelper;
/*    */ import java.util.stream.Stream;
/*    */ import net.minecraft.class_2248;
/*    */ import net.minecraft.class_2378;
/*    */ import net.minecraft.class_2960;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum BlockById
/*    */   implements IDatatypeFor<class_2248>
/*    */ {
/* 29 */   INSTANCE;
/*    */ 
/*    */   
/*    */   public class_2248 get(IDatatypeContext ctx) throws CommandException {
/* 33 */     class_2960 id = new class_2960(ctx.getConsumer().getString());
/*    */     class_2248 block;
/* 35 */     if ((block = class_2378.field_11146.method_17966(id).orElse(null)) == null) {
/* 36 */       throw new IllegalArgumentException("no block found by that id");
/*    */     }
/* 38 */     return block;
/*    */   }
/*    */ 
/*    */   
/*    */   public Stream<String> tabComplete(IDatatypeContext ctx) throws CommandException {
/* 43 */     return (new TabCompleteHelper())
/* 44 */       .append(class_2378.field_11146
/* 45 */         .method_10235()
/* 46 */         .stream()
/* 47 */         .map(Object::toString))
/*    */       
/* 49 */       .filterPrefixNamespaced(ctx.getConsumer().getString())
/* 50 */       .sortAlphabetically()
/* 51 */       .stream();
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\command\datatypes\BlockById.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */