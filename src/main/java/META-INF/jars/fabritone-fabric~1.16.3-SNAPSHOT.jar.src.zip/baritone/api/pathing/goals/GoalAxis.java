/*    */ package baritone.api.pathing.goals;
/*    */ 
/*    */ import baritone.api.BaritoneAPI;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GoalAxis
/*    */   implements Goal
/*    */ {
/* 24 */   private static final double SQRT_2_OVER_2 = Math.sqrt(2.0D) / 2.0D;
/*    */ 
/*    */   
/*    */   public boolean isInGoal(int x, int y, int z) {
/* 28 */     return (y == ((Integer)(BaritoneAPI.getSettings()).axisHeight.value).intValue() && (x == 0 || z == 0 || Math.abs(x) == Math.abs(z)));
/*    */   }
/*    */ 
/*    */   
/*    */   public double heuristic(int x0, int y, int z0) {
/* 33 */     int x = Math.abs(x0);
/* 34 */     int z = Math.abs(z0);
/*    */     
/* 36 */     int shrt = Math.min(x, z);
/* 37 */     int lng = Math.max(x, z);
/* 38 */     int diff = lng - shrt;
/*    */     
/* 40 */     double flatAxisDistance = Math.min(x, Math.min(z, diff * SQRT_2_OVER_2));
/*    */     
/* 42 */     return flatAxisDistance * ((Double)(BaritoneAPI.getSettings()).costHeuristic.value).doubleValue() + GoalYLevel.calculate(((Integer)(BaritoneAPI.getSettings()).axisHeight.value).intValue(), y);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 47 */     return "GoalAxis";
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\pathing\goals\GoalAxis.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */