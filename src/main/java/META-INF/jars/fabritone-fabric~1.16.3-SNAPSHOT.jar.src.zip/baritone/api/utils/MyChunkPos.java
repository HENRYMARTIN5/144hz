/*    */ package baritone.api.utils;
/*    */ 
/*    */ import com.google.gson.annotations.SerializedName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MyChunkPos
/*    */ {
/*    */   @SerializedName("x")
/*    */   public int x;
/*    */   @SerializedName("z")
/*    */   public int z;
/*    */   
/*    */   public String toString() {
/* 35 */     return this.x + ", " + this.z;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\ap\\utils\MyChunkPos.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */