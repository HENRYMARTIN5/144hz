/*    */ package baritone.api.command.exception;
/*    */ 
/*    */ import baritone.api.command.ICommand;
/*    */ import baritone.api.command.argument.ICommandArgument;
/*    */ import baritone.api.utils.Helper;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CommandNotFoundException
/*    */   extends CommandException
/*    */ {
/*    */   public final String command;
/*    */   
/*    */   public CommandNotFoundException(String command) {
/* 32 */     super(String.format("Command not found: %s", new Object[] { command }));
/* 33 */     this.command = command;
/*    */   }
/*    */ 
/*    */   
/*    */   public void handle(ICommand command, List<ICommandArgument> args) {
/* 38 */     Helper.HELPER.logDirect(getMessage());
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\command\exception\CommandNotFoundException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */