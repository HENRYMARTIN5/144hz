/*    */ package baritone.api.command.datatypes;
/*    */ 
/*    */ import baritone.api.command.argument.IArgConsumer;
/*    */ import baritone.api.command.exception.CommandException;
/*    */ import baritone.api.pathing.goals.GoalXZ;
/*    */ import baritone.api.utils.BetterBlockPos;
/*    */ import java.util.stream.Stream;
/*    */ import net.minecraft.class_3532;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum RelativeGoalXZ
/*    */   implements IDatatypePost<GoalXZ, BetterBlockPos>
/*    */ {
/* 29 */   INSTANCE;
/*    */ 
/*    */   
/*    */   public GoalXZ apply(IDatatypeContext ctx, BetterBlockPos origin) throws CommandException {
/* 33 */     if (origin == null) {
/* 34 */       origin = BetterBlockPos.ORIGIN;
/*    */     }
/*    */     
/* 37 */     IArgConsumer consumer = ctx.getConsumer();
/* 38 */     return new GoalXZ(
/* 39 */         class_3532.method_15357(((Double)consumer.getDatatypePost(RelativeCoordinate.INSTANCE, Double.valueOf(origin.x))).doubleValue()), 
/* 40 */         class_3532.method_15357(((Double)consumer.getDatatypePost(RelativeCoordinate.INSTANCE, Double.valueOf(origin.z))).doubleValue()));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Stream<String> tabComplete(IDatatypeContext ctx) {
/* 46 */     IArgConsumer consumer = ctx.getConsumer();
/* 47 */     if (consumer.hasAtMost(2)) {
/* 48 */       return consumer.tabCompleteDatatype(RelativeCoordinate.INSTANCE);
/*    */     }
/* 50 */     return Stream.empty();
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\command\datatypes\RelativeGoalXZ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */