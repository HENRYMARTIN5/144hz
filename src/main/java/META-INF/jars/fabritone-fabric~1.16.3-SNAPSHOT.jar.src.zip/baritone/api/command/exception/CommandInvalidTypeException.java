/*    */ package baritone.api.command.exception;
/*    */ 
/*    */ import baritone.api.command.argument.ICommandArgument;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CommandInvalidTypeException
/*    */   extends CommandInvalidArgumentException
/*    */ {
/*    */   public CommandInvalidTypeException(ICommandArgument arg, String expected) {
/* 25 */     super(arg, String.format("Expected %s", new Object[] { expected }));
/*    */   }
/*    */   
/*    */   public CommandInvalidTypeException(ICommandArgument arg, String expected, Throwable cause) {
/* 29 */     super(arg, String.format("Expected %s", new Object[] { expected }), cause);
/*    */   }
/*    */   
/*    */   public CommandInvalidTypeException(ICommandArgument arg, String expected, String got) {
/* 33 */     super(arg, String.format("Expected %s, but got %s instead", new Object[] { expected, got }));
/*    */   }
/*    */   
/*    */   public CommandInvalidTypeException(ICommandArgument arg, String expected, String got, Throwable cause) {
/* 37 */     super(arg, String.format("Expected %s, but got %s instead", new Object[] { expected, got }), cause);
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\command\exception\CommandInvalidTypeException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */