package baritone.api.command.argument;

import baritone.api.command.datatypes.IDatatypeFor;
import baritone.api.command.datatypes.IDatatypePost;
import baritone.api.command.exception.CommandException;
import baritone.api.command.exception.CommandInvalidTypeException;
import baritone.api.command.exception.CommandNotEnoughArgumentsException;
import baritone.api.command.exception.CommandTooManyArgumentsException;
import java.util.Deque;
import java.util.LinkedList;
import java.util.stream.Stream;

public interface IArgConsumer {
  LinkedList<ICommandArgument> getArgs();
  
  Deque<ICommandArgument> getConsumed();
  
  boolean has(int paramInt);
  
  boolean hasAny();
  
  boolean hasAtMost(int paramInt);
  
  boolean hasAtMostOne();
  
  boolean hasExactly(int paramInt);
  
  boolean hasExactlyOne();
  
  ICommandArgument peek(int paramInt) throws CommandNotEnoughArgumentsException;
  
  ICommandArgument peek() throws CommandNotEnoughArgumentsException;
  
  boolean is(Class<?> paramClass, int paramInt) throws CommandNotEnoughArgumentsException;
  
  boolean is(Class<?> paramClass) throws CommandNotEnoughArgumentsException;
  
  String peekString(int paramInt) throws CommandNotEnoughArgumentsException;
  
  String peekString() throws CommandNotEnoughArgumentsException;
  
  <E extends Enum<?>> E peekEnum(Class<E> paramClass, int paramInt) throws CommandInvalidTypeException, CommandNotEnoughArgumentsException;
  
  <E extends Enum<?>> E peekEnum(Class<E> paramClass) throws CommandInvalidTypeException, CommandNotEnoughArgumentsException;
  
  <E extends Enum<?>> E peekEnumOrNull(Class<E> paramClass, int paramInt) throws CommandNotEnoughArgumentsException;
  
  <E extends Enum<?>> E peekEnumOrNull(Class<E> paramClass) throws CommandNotEnoughArgumentsException;
  
  <T> T peekAs(Class<T> paramClass, int paramInt) throws CommandInvalidTypeException, CommandNotEnoughArgumentsException;
  
  <T> T peekAs(Class<T> paramClass) throws CommandInvalidTypeException, CommandNotEnoughArgumentsException;
  
  <T> T peekAsOrDefault(Class<T> paramClass, T paramT, int paramInt) throws CommandNotEnoughArgumentsException;
  
  <T> T peekAsOrDefault(Class<T> paramClass, T paramT) throws CommandNotEnoughArgumentsException;
  
  <T> T peekAsOrNull(Class<T> paramClass, int paramInt) throws CommandNotEnoughArgumentsException;
  
  <T> T peekAsOrNull(Class<T> paramClass) throws CommandNotEnoughArgumentsException;
  
  <T> T peekDatatype(IDatatypeFor<T> paramIDatatypeFor) throws CommandInvalidTypeException, CommandNotEnoughArgumentsException;
  
  <T, O> T peekDatatype(IDatatypePost<T, O> paramIDatatypePost) throws CommandInvalidTypeException, CommandNotEnoughArgumentsException;
  
  <T, O> T peekDatatype(IDatatypePost<T, O> paramIDatatypePost, O paramO) throws CommandInvalidTypeException, CommandNotEnoughArgumentsException;
  
  <T> T peekDatatypeOrNull(IDatatypeFor<T> paramIDatatypeFor);
  
  <T, O> T peekDatatypeOrNull(IDatatypePost<T, O> paramIDatatypePost);
  
  <T, O, D extends IDatatypePost<T, O>> T peekDatatypePost(D paramD, O paramO) throws CommandInvalidTypeException, CommandNotEnoughArgumentsException;
  
  <T, O, D extends IDatatypePost<T, O>> T peekDatatypePostOrDefault(D paramD, O paramO, T paramT);
  
  <T, O, D extends IDatatypePost<T, O>> T peekDatatypePostOrNull(D paramD, O paramO);
  
  <T, D extends IDatatypeFor<T>> T peekDatatypeFor(Class<D> paramClass);
  
  <T, D extends IDatatypeFor<T>> T peekDatatypeForOrDefault(Class<D> paramClass, T paramT);
  
  <T, D extends IDatatypeFor<T>> T peekDatatypeForOrNull(Class<D> paramClass);
  
  ICommandArgument get() throws CommandNotEnoughArgumentsException;
  
  String getString() throws CommandNotEnoughArgumentsException;
  
  <E extends Enum<?>> E getEnum(Class<E> paramClass) throws CommandInvalidTypeException, CommandNotEnoughArgumentsException;
  
  <E extends Enum<?>> E getEnumOrDefault(Class<E> paramClass, E paramE) throws CommandNotEnoughArgumentsException;
  
  <E extends Enum<?>> E getEnumOrNull(Class<E> paramClass) throws CommandNotEnoughArgumentsException;
  
  <T> T getAs(Class<T> paramClass) throws CommandInvalidTypeException, CommandNotEnoughArgumentsException;
  
  <T> T getAsOrDefault(Class<T> paramClass, T paramT) throws CommandNotEnoughArgumentsException;
  
  <T> T getAsOrNull(Class<T> paramClass) throws CommandNotEnoughArgumentsException;
  
  <T, O, D extends IDatatypePost<T, O>> T getDatatypePost(D paramD, O paramO) throws CommandInvalidTypeException, CommandNotEnoughArgumentsException;
  
  <T, O, D extends IDatatypePost<T, O>> T getDatatypePostOrDefault(D paramD, O paramO, T paramT);
  
  <T, O, D extends IDatatypePost<T, O>> T getDatatypePostOrNull(D paramD, O paramO);
  
  <T, D extends IDatatypeFor<T>> T getDatatypeFor(D paramD) throws CommandInvalidTypeException, CommandNotEnoughArgumentsException;
  
  <T, D extends IDatatypeFor<T>> T getDatatypeForOrDefault(D paramD, T paramT);
  
  <T, D extends IDatatypeFor<T>> T getDatatypeForOrNull(D paramD);
  
  <T extends baritone.api.command.datatypes.IDatatype> Stream<String> tabCompleteDatatype(T paramT);
  
  String rawRest();
  
  void requireMin(int paramInt) throws CommandNotEnoughArgumentsException;
  
  void requireMax(int paramInt) throws CommandTooManyArgumentsException;
  
  void requireExactly(int paramInt) throws CommandException;
  
  boolean hasConsumed();
  
  ICommandArgument consumed();
  
  String consumedString();
  
  IArgConsumer copy();
}


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\command\argument\IArgConsumer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */