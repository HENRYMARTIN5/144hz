/*    */ package baritone.api.cache;
/*    */ 
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_2680;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IBlockTypeAccess
/*    */ {
/*    */   class_2680 getBlock(int paramInt1, int paramInt2, int paramInt3);
/*    */   
/*    */   default class_2680 getBlock(class_2338 pos) {
/* 32 */     return getBlock(pos.method_10263(), pos.method_10264(), pos.method_10260());
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\cache\IBlockTypeAccess.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */