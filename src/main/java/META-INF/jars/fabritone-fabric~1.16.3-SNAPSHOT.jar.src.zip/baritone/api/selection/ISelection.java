package baritone.api.selection;

import baritone.api.utils.BetterBlockPos;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2382;

public interface ISelection {
  BetterBlockPos pos1();
  
  BetterBlockPos pos2();
  
  BetterBlockPos min();
  
  BetterBlockPos max();
  
  class_2382 size();
  
  class_238 aabb();
  
  ISelection expand(class_2350 paramclass_2350, int paramInt);
  
  ISelection contract(class_2350 paramclass_2350, int paramInt);
  
  ISelection shift(class_2350 paramclass_2350, int paramInt);
}


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\selection\ISelection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */