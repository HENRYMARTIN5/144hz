/*    */ package baritone.api.event.events;
/*    */ 
/*    */ import baritone.api.event.events.type.EventState;
/*    */ import net.minecraft.class_638;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class WorldEvent
/*    */ {
/*    */   private final class_638 world;
/*    */   private final EventState state;
/*    */   
/*    */   public WorldEvent(class_638 world, EventState state) {
/* 40 */     this.world = world;
/* 41 */     this.state = state;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final class_638 getWorld() {
/* 48 */     return this.world;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final EventState getState() {
/* 55 */     return this.state;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\event\events\WorldEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */