/*     */ package baritone.api.utils;
/*     */ 
/*     */ import baritone.api.BaritoneAPI;
/*     */ import baritone.api.Settings;
/*     */ import java.awt.Color;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.NoSuchFileException;
/*     */ import java.nio.file.Path;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ import net.minecraft.class_1792;
/*     */ import net.minecraft.class_2248;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_2378;
/*     */ import net.minecraft.class_2382;
/*     */ import net.minecraft.class_2960;
/*     */ import net.minecraft.class_310;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SettingsUtil
/*     */ {
/*  52 */   private static final Path SETTINGS_PATH = (class_310.method_1551()).field_1697.toPath().resolve("baritone").resolve("settings.txt");
/*  53 */   private static final Pattern SETTING_PATTERN = Pattern.compile("^(?<setting>[^ ]+) +(?<value>.+)");
/*     */ 
/*     */   
/*     */   private static boolean isComment(String line) {
/*  57 */     return (line.startsWith("#") || line.startsWith("//"));
/*     */   }
/*     */   
/*     */   private static void forEachLine(Path file, Consumer<String> consumer) throws IOException {
/*  61 */     try (BufferedReader scan = Files.newBufferedReader(file)) {
/*     */       String line;
/*  63 */       while ((line = scan.readLine()) != null) {
/*  64 */         if (line.isEmpty() || isComment(line)) {
/*     */           continue;
/*     */         }
/*  67 */         consumer.accept(line);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void readAndApply(Settings settings) {
/*     */     try {
/*  74 */       forEachLine(SETTINGS_PATH, line -> {
/*     */             Matcher matcher = SETTING_PATTERN.matcher(line);
/*     */             
/*     */             if (!matcher.matches()) {
/*     */               System.out.println("Invalid syntax in setting file: " + line);
/*     */               return;
/*     */             } 
/*     */             String settingName = matcher.group("setting").toLowerCase();
/*     */             String settingValue = matcher.group("value");
/*     */             try {
/*     */               parseAndApply(settings, settingName, settingValue);
/*  85 */             } catch (Exception ex) {
/*     */               System.out.println("Unable to parse line " + line);
/*     */               ex.printStackTrace();
/*     */             } 
/*     */           });
/*  90 */     } catch (NoSuchFileException ignored) {
/*  91 */       System.out.println("Baritone settings file not found, resetting.");
/*  92 */     } catch (Exception ex) {
/*  93 */       System.out.println("Exception while reading Baritone settings, some settings may be reset to default values!");
/*  94 */       ex.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static synchronized void save(Settings settings) {
/*  99 */     try (BufferedWriter out = Files.newBufferedWriter(SETTINGS_PATH, new java.nio.file.OpenOption[0])) {
/* 100 */       for (Settings.Setting setting : modifiedSettings(settings)) {
/* 101 */         out.write(settingToString(setting) + "\n");
/*     */       }
/* 103 */     } catch (Exception ex) {
/* 104 */       System.out.println("Exception thrown while saving Baritone settings!");
/* 105 */       ex.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static List<Settings.Setting> modifiedSettings(Settings settings) {
/* 110 */     List<Settings.Setting> modified = new ArrayList<>();
/* 111 */     for (Settings.Setting setting : settings.allSettings) {
/* 112 */       if (setting.value == null) {
/* 113 */         System.out.println("NULL SETTING?" + setting.getName());
/*     */         continue;
/*     */       } 
/* 116 */       if (setting.getName().equals("logger")) {
/*     */         continue;
/*     */       }
/* 119 */       if (setting.value == setting.defaultValue) {
/*     */         continue;
/*     */       }
/* 122 */       modified.add(setting);
/*     */     } 
/* 124 */     return modified;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String settingTypeToString(Settings.Setting setting) {
/* 137 */     return setting.getType().getTypeName()
/* 138 */       .replaceAll("(?:\\w+\\.)+(\\w+)", "$1");
/*     */   }
/*     */   
/*     */   public static <T> String settingValueToString(Settings.Setting<T> setting, T value) throws IllegalArgumentException {
/* 142 */     Parser io = Parser.getParser(setting.getType());
/*     */     
/* 144 */     if (io == null) {
/* 145 */       throw new IllegalStateException("Missing " + setting.getValueClass() + " " + setting.getName());
/*     */     }
/*     */     
/* 148 */     return io.toString(new ParserContext(setting), value);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String settingValueToString(Settings.Setting setting) throws IllegalArgumentException {
/* 153 */     return settingValueToString(setting, setting.value);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String settingDefaultToString(Settings.Setting setting) throws IllegalArgumentException {
/* 158 */     return settingValueToString(setting, setting.defaultValue);
/*     */   }
/*     */   
/*     */   public static String maybeCensor(int coord) {
/* 162 */     if (((Boolean)(BaritoneAPI.getSettings()).censorCoordinates.value).booleanValue()) {
/* 163 */       return "<censored>";
/*     */     }
/*     */     
/* 166 */     return Integer.toString(coord);
/*     */   }
/*     */   
/*     */   public static String settingToString(Settings.Setting setting) throws IllegalStateException {
/* 170 */     if (setting.getName().equals("logger")) {
/* 171 */       return "logger";
/*     */     }
/*     */     
/* 174 */     return setting.getName() + " " + settingValueToString(setting);
/*     */   }
/*     */   
/*     */   public static void parseAndApply(Settings settings, String settingName, String settingValue) throws IllegalStateException, NumberFormatException {
/* 178 */     Settings.Setting setting = (Settings.Setting)settings.byLowerName.get(settingName);
/* 179 */     if (setting == null) {
/* 180 */       throw new IllegalStateException("No setting by that name");
/*     */     }
/* 182 */     Class intendedType = setting.getValueClass();
/* 183 */     ISettingParser ioMethod = Parser.getParser(setting.getType());
/* 184 */     Object parsed = ioMethod.parse(new ParserContext(setting), settingValue);
/* 185 */     if (!intendedType.isInstance(parsed)) {
/* 186 */       throw new IllegalStateException(ioMethod + " parser returned incorrect type, expected " + intendedType + " got " + parsed + " which is " + parsed.getClass());
/*     */     }
/* 188 */     setting.value = parsed;
/*     */   }
/*     */   
/*     */   private static interface ISettingParser<T>
/*     */   {
/*     */     T parse(SettingsUtil.ParserContext param1ParserContext, String param1String);
/*     */     
/*     */     String toString(SettingsUtil.ParserContext param1ParserContext, T param1T);
/*     */     
/*     */     boolean accepts(Type param1Type);
/*     */   }
/*     */   
/*     */   private static class ParserContext
/*     */   {
/*     */     private final Settings.Setting<?> setting;
/*     */     
/*     */     private ParserContext(Settings.Setting<?> setting) {
/* 205 */       this.setting = setting;
/*     */     }
/*     */     
/*     */     private Settings.Setting<?> getSetting() {
/* 209 */       return this.setting;
/*     */     }
/*     */   }
/*     */   
/*     */   private enum Parser
/*     */     implements ISettingParser {
/* 215 */     DOUBLE((String)Double.class, Double::parseDouble),
/* 216 */     BOOLEAN((String)Boolean.class, Boolean::parseBoolean),
/* 217 */     INTEGER((String)Integer.class, Integer::parseInt),
/* 218 */     FLOAT((String)Float.class, Float::parseFloat),
/* 219 */     LONG((String)Long.class, Long::parseLong),
/* 220 */     STRING((String)String.class, String::new),
/* 221 */     DIRECTION((String)class_2350.class, class_2350::method_10168),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 242 */     LIST
/*     */     {
/*     */       public Object parse(SettingsUtil.ParserContext context, String raw) {
/* 245 */         Type type = ((ParameterizedType)context.getSetting().getType()).getActualTypeArguments()[0];
/* 246 */         Parser parser = getParser(type);
/* 247 */         return Stream.<String>of(raw.split(","))
/* 248 */           .map(s -> parser.parse(context, s))
/* 249 */           .collect(Collectors.toList());
/*     */       }
/*     */ 
/*     */       
/*     */       public String toString(SettingsUtil.ParserContext context, Object value) {
/* 254 */         Type type = ((ParameterizedType)context.getSetting().getType()).getActualTypeArguments()[0];
/* 255 */         Parser parser = getParser(type);
/*     */         
/* 257 */         return ((List)value).stream()
/* 258 */           .map(o -> parser.toString(context, o))
/* 259 */           .collect(Collectors.joining(","));
/*     */       }
/*     */       
/*     */       public boolean accepts(Type type)
/*     */       {
/* 264 */         return List.class.isAssignableFrom(TypeUtils.resolveBaseClass(type));
/*     */       }
/*     */     },
/*     */     COLOR,
/*     */     VEC3I,
/*     */     BLOCK,
/*     */     ITEM;
/*     */     
/*     */     Parser() {
/* 273 */       this.cla$$ = null;
/* 274 */       this.parser = null;
/* 275 */       this.toString = null;
/*     */     } static {
/*     */       COLOR = new Parser("COLOR", 7, (Class)Color.class, str -> new Color(Integer.parseInt(str.split(",")[0]), Integer.parseInt(str.split(",")[1]), Integer.parseInt(str.split(",")[2])), color -> color.getRed() + "," + color.getGreen() + "," + color.getBlue());
/*     */       VEC3I = new Parser("VEC3I", 8, (Class)class_2382.class, str -> new class_2382(Integer.parseInt(str.split(",")[0]), Integer.parseInt(str.split(",")[1]), Integer.parseInt(str.split(",")[2])), vec -> vec.method_10263() + "," + vec.method_10264() + "," + vec.method_10260());
/*     */       BLOCK = new Parser("BLOCK", 9, (Class)class_2248.class, str -> BlockUtils.stringToBlockRequired(str.trim()), BlockUtils::blockToString);
/*     */       ITEM = new Parser("ITEM", 10, (Class)class_1792.class, str -> (class_1792)class_2378.field_11142.method_10223(new class_2960(str.trim())), item -> class_2378.field_11142.method_29113(item).toString());
/*     */     } private final Class<?> cla$$; private final Function<String, Object> parser; private final Function<Object, String> toString;
/*     */     <T> Parser(Class<T> cla$$, Function<String, T> parser, Function<T, String> toString) {
/* 283 */       this.cla$$ = cla$$;
/* 284 */       this.parser = parser::apply;
/* 285 */       this.toString = (x -> (String)toString.apply(x));
/*     */     }
/*     */ 
/*     */     
/*     */     public Object parse(SettingsUtil.ParserContext context, String raw) {
/* 290 */       Object parsed = this.parser.apply(raw);
/* 291 */       Objects.requireNonNull(parsed);
/* 292 */       return parsed;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString(SettingsUtil.ParserContext context, Object value) {
/* 297 */       return this.toString.apply(value);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean accepts(Type type) {
/* 302 */       return (type instanceof Class && this.cla$$.isAssignableFrom((Class)type));
/*     */     }
/*     */     
/*     */     public static Parser getParser(Type type) {
/* 306 */       return Stream.<Parser>of(values())
/* 307 */         .filter(parser -> parser.accepts(type))
/* 308 */         .findFirst().orElse(null);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\ap\\utils\SettingsUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */