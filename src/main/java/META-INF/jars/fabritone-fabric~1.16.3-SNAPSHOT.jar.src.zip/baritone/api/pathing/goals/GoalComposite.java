/*    */ package baritone.api.pathing.goals;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GoalComposite
/*    */   implements Goal
/*    */ {
/*    */   private final Goal[] goals;
/*    */   
/*    */   public GoalComposite(Goal... goals) {
/* 37 */     this.goals = goals;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isInGoal(int x, int y, int z) {
/* 42 */     for (Goal goal : this.goals) {
/* 43 */       if (goal.isInGoal(x, y, z)) {
/* 44 */         return true;
/*    */       }
/*    */     } 
/* 47 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public double heuristic(int x, int y, int z) {
/* 52 */     double min = Double.MAX_VALUE;
/* 53 */     for (Goal g : this.goals)
/*    */     {
/* 55 */       min = Math.min(min, g.heuristic(x, y, z));
/*    */     }
/* 57 */     return min;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 62 */     return "GoalComposite" + Arrays.toString((Object[])this.goals);
/*    */   }
/*    */   
/*    */   public Goal[] goals() {
/* 66 */     return this.goals;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\pathing\goals\GoalComposite.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */