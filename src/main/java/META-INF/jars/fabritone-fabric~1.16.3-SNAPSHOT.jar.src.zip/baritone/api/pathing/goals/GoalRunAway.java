/*    */ package baritone.api.pathing.goals;
/*    */ 
/*    */ import baritone.api.utils.SettingsUtil;
/*    */ import java.util.Arrays;
/*    */ import net.minecraft.class_2338;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GoalRunAway
/*    */   implements Goal
/*    */ {
/*    */   private final class_2338[] from;
/*    */   private final double distanceSq;
/*    */   private final Integer maintainY;
/*    */   
/*    */   public GoalRunAway(double distance, class_2338... from) {
/* 39 */     this(distance, null, from);
/*    */   }
/*    */   
/*    */   public GoalRunAway(double distance, Integer maintainY, class_2338... from) {
/* 43 */     if (from.length == 0) {
/* 44 */       throw new IllegalArgumentException();
/*    */     }
/* 46 */     this.from = from;
/* 47 */     this.distanceSq = distance * distance;
/* 48 */     this.maintainY = maintainY;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isInGoal(int x, int y, int z) {
/* 53 */     if (this.maintainY != null && this.maintainY.intValue() != y) {
/* 54 */       return false;
/*    */     }
/* 56 */     for (class_2338 p : this.from) {
/* 57 */       int diffX = x - p.method_10263();
/* 58 */       int diffZ = z - p.method_10260();
/* 59 */       double distSq = (diffX * diffX + diffZ * diffZ);
/* 60 */       if (distSq < this.distanceSq) {
/* 61 */         return false;
/*    */       }
/*    */     } 
/* 64 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public double heuristic(int x, int y, int z) {
/* 69 */     double min = Double.MAX_VALUE;
/* 70 */     for (class_2338 p : this.from) {
/* 71 */       double h = GoalXZ.calculate((p.method_10263() - x), (p.method_10260() - z));
/* 72 */       if (h < min) {
/* 73 */         min = h;
/*    */       }
/*    */     } 
/* 76 */     min = -min;
/* 77 */     if (this.maintainY != null) {
/* 78 */       min = min * 0.6D + GoalYLevel.calculate(this.maintainY.intValue(), y) * 1.5D;
/*    */     }
/* 80 */     return min;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 85 */     if (this.maintainY != null) {
/* 86 */       return String.format("GoalRunAwayFromMaintainY y=%s, %s", new Object[] {
/*    */             
/* 88 */             SettingsUtil.maybeCensor(this.maintainY.intValue()), 
/* 89 */             Arrays.asList(this.from)
/*    */           });
/*    */     }
/* 92 */     return "GoalRunAwayFrom" + Arrays.<class_2338>asList(this.from);
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\pathing\goals\GoalRunAway.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */