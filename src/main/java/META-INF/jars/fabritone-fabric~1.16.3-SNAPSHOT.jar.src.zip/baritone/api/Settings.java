/*      */ package baritone.api;
/*      */ 
/*      */ import baritone.api.utils.SettingsUtil;
/*      */ import baritone.api.utils.TypeUtils;
/*      */ import java.awt.Color;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.ParameterizedType;
/*      */ import java.lang.reflect.Type;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.function.Consumer;
/*      */ import net.minecraft.class_1792;
/*      */ import net.minecraft.class_2246;
/*      */ import net.minecraft.class_2248;
/*      */ import net.minecraft.class_2382;
/*      */ import net.minecraft.class_2561;
/*      */ import net.minecraft.class_310;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class Settings
/*      */ {
/*   47 */   public final Setting<Boolean> allowBreak = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   52 */   public final Setting<Boolean> allowSprint = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   57 */   public final Setting<Boolean> allowPlace = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   62 */   public final Setting<Boolean> allowInventory = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   70 */   public final Setting<Boolean> assumeExternalAutoTool = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   75 */   public final Setting<Boolean> disableAutoTool = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   83 */   public final Setting<Double> blockPlacementPenalty = new Setting<>(Double.valueOf(20.0D));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   90 */   public final Setting<Double> blockBreakAdditionalPenalty = new Setting<>(Double.valueOf(2.0D));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   95 */   public final Setting<Double> jumpPenalty = new Setting<>(Double.valueOf(2.0D));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  100 */   public final Setting<Double> walkOnWaterOnePenalty = new Setting<>(Double.valueOf(3.0D));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  106 */   public final Setting<Boolean> allowWaterBucketFall = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  112 */   public final Setting<Boolean> assumeWalkOnWater = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  117 */   public final Setting<Boolean> assumeWalkOnLava = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  122 */   public final Setting<Boolean> assumeStep = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  131 */   public final Setting<Boolean> assumeSafeWalk = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  138 */   public final Setting<Boolean> allowJumpAt256 = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  145 */   public final Setting<Boolean> allowParkourAscend = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  154 */   public final Setting<Boolean> allowDiagonalDescend = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  161 */   public final Setting<Boolean> allowDiagonalAscend = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  168 */   public final Setting<Boolean> allowDownward = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  173 */   public final Setting<List<class_1792>> acceptableThrowawayItems = new Setting<>(new ArrayList(Arrays.asList((Object[])new class_1792[] { class_2246.field_10566
/*  174 */             .method_8389(), class_2246.field_10445
/*  175 */             .method_8389(), class_2246.field_10515
/*  176 */             .method_8389(), class_2246.field_10340
/*  177 */             .method_8389() })));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  183 */   public final Setting<List<class_2248>> blocksToAvoid = new Setting<>(new ArrayList());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  190 */   public final Setting<List<class_2248>> blocksToAvoidBreaking = new Setting<>(new ArrayList(Arrays.asList((Object[])new class_2248[] { class_2246.field_9980, class_2246.field_10181, class_2246.field_10034, class_2246.field_10380 })));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  202 */   public final Setting<List<class_2248>> buildIgnoreBlocks = new Setting<>(new ArrayList(Arrays.asList((Object[])new class_2248[0])));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  211 */   public final Setting<List<class_2248>> okIfAir = new Setting<>(new ArrayList(Arrays.asList((Object[])new class_2248[0])));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  218 */   public final Setting<Boolean> buildIgnoreExisting = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  225 */   public final Setting<Boolean> avoidUpdatingFallingBlocks = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  233 */   public final Setting<Boolean> allowVines = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  239 */   public final Setting<Boolean> allowWalkOnBottomSlab = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  248 */   public final Setting<Boolean> allowParkour = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  255 */   public final Setting<Boolean> allowParkourPlace = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  260 */   public final Setting<Boolean> considerPotionEffects = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  265 */   public final Setting<Boolean> sprintAscends = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  272 */   public final Setting<Boolean> overshootTraverse = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  277 */   public final Setting<Boolean> pauseMiningForFallingBlocks = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  282 */   public final Setting<Integer> rightClickSpeed = new Setting<>(Integer.valueOf(4));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  287 */   public final Setting<Double> randomLooking113 = new Setting<>(Double.valueOf(2.0D));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  292 */   public final Setting<Float> blockReachDistance = new Setting<>(Float.valueOf(4.5F));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  297 */   public final Setting<Double> randomLooking = new Setting<>(Double.valueOf(0.01D));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  314 */   public final Setting<Double> costHeuristic = new Setting<>(Double.valueOf(3.563D));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  321 */   public final Setting<Integer> pathingMaxChunkBorderFetch = new Setting<>(Integer.valueOf(50));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  328 */   public final Setting<Double> backtrackCostFavoringCoefficient = new Setting<>(Double.valueOf(0.5D));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  338 */   public final Setting<Boolean> avoidance = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  345 */   public final Setting<Double> mobSpawnerAvoidanceCoefficient = new Setting<>(Double.valueOf(2.0D));
/*      */   
/*  347 */   public final Setting<Integer> mobSpawnerAvoidanceRadius = new Setting<>(Integer.valueOf(16));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  354 */   public final Setting<Double> mobAvoidanceCoefficient = new Setting<>(Double.valueOf(1.5D));
/*      */   
/*  356 */   public final Setting<Integer> mobAvoidanceRadius = new Setting<>(Integer.valueOf(8));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  362 */   public final Setting<Boolean> rightClickContainerOnArrival = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  368 */   public final Setting<Boolean> enterPortal = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  374 */   public final Setting<Boolean> minimumImprovementRepropagation = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  384 */   public final Setting<Boolean> cutoffAtLoadBoundary = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  390 */   public final Setting<Double> maxCostIncrease = new Setting<>(Double.valueOf(10.0D));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  397 */   public final Setting<Integer> costVerificationLookahead = new Setting<>(Integer.valueOf(5));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  402 */   public final Setting<Double> pathCutoffFactor = new Setting<>(Double.valueOf(0.9D));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  407 */   public final Setting<Integer> pathCutoffMinimumLength = new Setting<>(Integer.valueOf(30));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  412 */   public final Setting<Integer> planningTickLookahead = new Setting<>(Integer.valueOf(150));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  417 */   public final Setting<Integer> pathingMapDefaultSize = new Setting<>(Integer.valueOf(1024));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  424 */   public final Setting<Float> pathingMapLoadFactor = new Setting<>(Float.valueOf(0.75F));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  431 */   public final Setting<Integer> maxFallHeightNoWater = new Setting<>(Integer.valueOf(3));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  437 */   public final Setting<Integer> maxFallHeightBucket = new Setting<>(Integer.valueOf(20));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  446 */   public final Setting<Boolean> allowOvershootDiagonalDescend = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  455 */   public final Setting<Boolean> simplifyUnloadedYCoord = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  460 */   public final Setting<Boolean> repackOnAnyBlockChange = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  465 */   public final Setting<Integer> movementTimeoutTicks = new Setting<>(Integer.valueOf(100));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  472 */   public final Setting<Long> primaryTimeoutMS = new Setting<>(Long.valueOf(500L));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  477 */   public final Setting<Long> failureTimeoutMS = new Setting<>(Long.valueOf(2000L));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  484 */   public final Setting<Long> planAheadPrimaryTimeoutMS = new Setting<>(Long.valueOf(4000L));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  489 */   public final Setting<Long> planAheadFailureTimeoutMS = new Setting<>(Long.valueOf(5000L));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  494 */   public final Setting<Boolean> slowPath = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  499 */   public final Setting<Long> slowPathTimeDelayMS = new Setting<>(Long.valueOf(100L));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  504 */   public final Setting<Long> slowPathTimeoutMS = new Setting<>(Long.valueOf(40000L));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  509 */   public final Setting<Boolean> chunkCaching = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  520 */   public final Setting<Boolean> pruneRegionsFromRAM = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  527 */   public final Setting<Boolean> containerMemory = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  532 */   public final Setting<Boolean> backfill = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  537 */   public final Setting<Boolean> logAsToast = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  544 */   public final Setting<Long> toastTimer = new Setting<>(Long.valueOf(5000L));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  549 */   public final Setting<Boolean> chatDebug = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  555 */   public final Setting<Boolean> chatControl = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  560 */   public final Setting<Boolean> chatControlAnyway = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  565 */   public final Setting<Boolean> renderPath = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  570 */   public final Setting<Boolean> renderPathAsLine = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  575 */   public final Setting<Boolean> renderGoal = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  580 */   public final Setting<Boolean> renderSelectionBoxes = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  585 */   public final Setting<Boolean> renderGoalIgnoreDepth = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  591 */   public final Setting<Boolean> renderGoalXZBeacon = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  596 */   public final Setting<Boolean> renderSelectionBoxesIgnoreDepth = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  601 */   public final Setting<Boolean> renderPathIgnoreDepth = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  606 */   public final Setting<Float> pathRenderLineWidthPixels = new Setting<>(Float.valueOf(5.0F));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  611 */   public final Setting<Float> goalRenderLineWidthPixels = new Setting<>(Float.valueOf(3.0F));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  617 */   public final Setting<Boolean> fadePath = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  622 */   public final Setting<Boolean> freeLook = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  630 */   public final Setting<Boolean> antiCheatCompatibility = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  637 */   public final Setting<Boolean> pathThroughCachedOnly = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  642 */   public final Setting<Boolean> sprintInWater = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  650 */   public final Setting<Boolean> blacklistClosestOnFailure = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  663 */   public final Setting<Boolean> renderCachedChunks = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  669 */   public final Setting<Float> cachedChunksOpacity = new Setting<>(Float.valueOf(0.5F));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  674 */   public final Setting<Boolean> prefixControl = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  679 */   public final Setting<String> prefix = new Setting<>("#");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  684 */   public final Setting<Boolean> shortBaritonePrefix = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  689 */   public final Setting<Boolean> echoCommands = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  694 */   public final Setting<Boolean> censorCoordinates = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  699 */   public final Setting<Boolean> censorRanCommands = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  705 */   public final Setting<Boolean> preferSilkTouch = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  710 */   public final Setting<Boolean> walkWhileBreaking = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  720 */   public final Setting<Boolean> splicePath = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  725 */   public final Setting<Integer> maxPathHistoryLength = new Setting<>(Integer.valueOf(300));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  730 */   public final Setting<Integer> pathHistoryCutoffAmount = new Setting<>(Integer.valueOf(50));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  736 */   public final Setting<Integer> mineGoalUpdateInterval = new Setting<>(Integer.valueOf(5));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  741 */   public final Setting<Integer> maxCachedWorldScanCount = new Setting<>(Integer.valueOf(10));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  746 */   public final Setting<Integer> minYLevelWhileMining = new Setting<>(Integer.valueOf(0));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  751 */   public final Setting<Boolean> allowOnlyExposedOres = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  758 */   public final Setting<Integer> allowOnlyExposedOresDistance = new Setting<>(Integer.valueOf(1));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  763 */   public final Setting<Boolean> exploreForBlocks = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  770 */   public final Setting<Integer> worldExploringChunkOffset = new Setting<>(Integer.valueOf(0));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  775 */   public final Setting<Integer> exploreChunkSetMinimumSize = new Setting<>(Integer.valueOf(10));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  782 */   public final Setting<Integer> exploreMaintainY = new Setting<>(Integer.valueOf(64));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  787 */   public final Setting<Boolean> replantCrops = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  792 */   public final Setting<Boolean> replantNetherWart = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  799 */   public final Setting<Boolean> extendCacheOnThreshold = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  804 */   public final Setting<Boolean> buildInLayers = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  811 */   public final Setting<Boolean> layerOrder = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  817 */   public final Setting<Integer> startAtLayer = new Setting<>(Integer.valueOf(0));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  822 */   public final Setting<Boolean> skipFailedLayers = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  827 */   public final Setting<class_2382> buildRepeat = new Setting<>(new class_2382(0, 0, 0));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  832 */   public final Setting<Integer> buildRepeatCount = new Setting<>(Integer.valueOf(-1));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  839 */   public final Setting<Boolean> breakFromAbove = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  846 */   public final Setting<Boolean> goalBreakFromAbove = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  851 */   public final Setting<Boolean> mapArtMode = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  856 */   public final Setting<Boolean> okIfWater = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  861 */   public final Setting<Integer> incorrectSize = new Setting<>(Integer.valueOf(100));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  866 */   public final Setting<Double> breakCorrectBlockPenaltyMultiplier = new Setting<>(Double.valueOf(10.0D));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  871 */   public final Setting<Boolean> schematicOrientationX = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  876 */   public final Setting<Boolean> schematicOrientationY = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  881 */   public final Setting<Boolean> schematicOrientationZ = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  887 */   public final Setting<String> schematicFallbackExtension = new Setting<>("schematic");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  893 */   public final Setting<Integer> builderTickScanRadius = new Setting<>(Integer.valueOf(5));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  898 */   public final Setting<Boolean> mineScanDroppedItems = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  906 */   public final Setting<Long> mineDropLoiterDurationMSThanksLouca = new Setting<>(Long.valueOf(250L));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  911 */   public final Setting<Boolean> distanceTrim = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  926 */   public final Setting<Boolean> cancelOnGoalInvalidation = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  931 */   public final Setting<Integer> axisHeight = new Setting<>(Integer.valueOf(120));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  936 */   public final Setting<Boolean> disconnectOnArrival = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  943 */   public final Setting<Boolean> legitMine = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  948 */   public final Setting<Integer> legitMineYLevel = new Setting<>(Integer.valueOf(11));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  961 */   public final Setting<Boolean> legitMineIncludeDiagonals = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  968 */   public final Setting<Boolean> forceInternalMining = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  974 */   public final Setting<Boolean> internalMiningAirException = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  981 */   public final Setting<Double> followOffsetDistance = new Setting<>(Double.valueOf(0.0D));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  986 */   public final Setting<Float> followOffsetDirection = new Setting<>(Float.valueOf(0.0F));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  991 */   public final Setting<Integer> followRadius = new Setting<>(Integer.valueOf(3));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  997 */   public final Setting<Boolean> disableCompletionCheck = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1019 */   public final Setting<Long> cachedChunksExpirySeconds = new Setting<>(Long.valueOf(-1L));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1026 */   public final Setting<Consumer<class_2561>> logger = new Setting<>((class_310.method_1551()).field_1705.method_1743()::method_1812);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1031 */   public final Setting<Boolean> verboseCommandExceptions = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1036 */   public final Setting<Double> yLevelBoxSize = new Setting<>(Double.valueOf(15.0D));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1041 */   public final Setting<Color> colorCurrentPath = new Setting<>(Color.RED);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1046 */   public final Setting<Color> colorNextPath = new Setting<>(Color.MAGENTA);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1051 */   public final Setting<Color> colorBlocksToBreak = new Setting<>(Color.RED);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1056 */   public final Setting<Color> colorBlocksToPlace = new Setting<>(Color.GREEN);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1061 */   public final Setting<Color> colorBlocksToWalkInto = new Setting<>(Color.MAGENTA);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1066 */   public final Setting<Color> colorBestPathSoFar = new Setting<>(Color.BLUE);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1071 */   public final Setting<Color> colorMostRecentConsidered = new Setting<>(Color.CYAN);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1076 */   public final Setting<Color> colorGoalBox = new Setting<>(Color.GREEN);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1081 */   public final Setting<Color> colorInvertedGoalBox = new Setting<>(Color.RED);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1086 */   public final Setting<Color> colorSelection = new Setting<>(Color.CYAN);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1091 */   public final Setting<Color> colorSelectionPos1 = new Setting<>(Color.BLACK);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1096 */   public final Setting<Color> colorSelectionPos2 = new Setting<>(Color.ORANGE);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1101 */   public final Setting<Float> selectionOpacity = new Setting<>(Float.valueOf(0.5F));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1106 */   public final Setting<Float> selectionLineWidth = new Setting<>(Float.valueOf(2.0F));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1111 */   public final Setting<Boolean> renderSelection = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1116 */   public final Setting<Boolean> renderSelectionIgnoreDepth = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1121 */   public final Setting<Boolean> renderSelectionCorners = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1126 */   public final Setting<Boolean> desktopNotifications = new Setting<>(Boolean.valueOf(false));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1131 */   public final Setting<Boolean> notificationOnPathComplete = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1136 */   public final Setting<Boolean> notificationOnFarmFail = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1141 */   public final Setting<Boolean> notificationOnBuildFinished = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1146 */   public final Setting<Boolean> notificationOnExploreFinished = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1151 */   public final Setting<Boolean> notificationOnMineFail = new Setting<>(Boolean.valueOf(true));
/*      */ 
/*      */   
/*      */   public final Map<String, Setting<?>> byLowerName;
/*      */ 
/*      */   
/*      */   public final List<Setting<?>> allSettings;
/*      */ 
/*      */   
/*      */   public final Map<Setting<?>, Type> settingTypes;
/*      */ 
/*      */   
/*      */   public final class Setting<T>
/*      */   {
/*      */     public T value;
/*      */     
/*      */     public final T defaultValue;
/*      */     
/*      */     private String name;
/*      */ 
/*      */     
/*      */     private Setting(T value) {
/* 1173 */       if (value == null) {
/* 1174 */         throw new IllegalArgumentException("Cannot determine value type class from null");
/*      */       }
/* 1176 */       this.value = value;
/* 1177 */       this.defaultValue = value;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Deprecated
/*      */     public final T get() {
/* 1187 */       return this.value;
/*      */     }
/*      */     
/*      */     public final String getName() {
/* 1191 */       return this.name;
/*      */     }
/*      */ 
/*      */     
/*      */     public Class<T> getValueClass() {
/* 1196 */       return TypeUtils.resolveBaseClass(getType());
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1201 */       return SettingsUtil.settingToString(this);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void reset() {
/* 1208 */       this.value = this.defaultValue;
/*      */     }
/*      */     
/*      */     public final Type getType() {
/* 1212 */       return Settings.this.settingTypes.get(this);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   Settings() {
/* 1219 */     Field[] temp = getClass().getFields();
/*      */     
/* 1221 */     Map<String, Setting<?>> tmpByName = new HashMap<>();
/* 1222 */     List<Setting<?>> tmpAll = new ArrayList<>();
/* 1223 */     Map<Setting<?>, Type> tmpSettingTypes = new HashMap<>();
/*      */     
/*      */     try {
/* 1226 */       for (Field field : temp) {
/* 1227 */         if (field.getType().equals(Setting.class)) {
/* 1228 */           Setting<?> setting = (Setting)field.get(this);
/* 1229 */           String name = field.getName();
/* 1230 */           setting.name = name;
/* 1231 */           name = name.toLowerCase();
/* 1232 */           if (tmpByName.containsKey(name)) {
/* 1233 */             throw new IllegalStateException("Duplicate setting name");
/*      */           }
/* 1235 */           tmpByName.put(name, setting);
/* 1236 */           tmpAll.add(setting);
/* 1237 */           tmpSettingTypes.put(setting, ((ParameterizedType)field.getGenericType()).getActualTypeArguments()[0]);
/*      */         } 
/*      */       } 
/* 1240 */     } catch (IllegalAccessException e) {
/* 1241 */       throw new IllegalStateException(e);
/*      */     } 
/* 1243 */     this.byLowerName = Collections.unmodifiableMap(tmpByName);
/* 1244 */     this.allSettings = Collections.unmodifiableList(tmpAll);
/* 1245 */     this.settingTypes = Collections.unmodifiableMap(tmpSettingTypes);
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> List<Setting<T>> getAllValuesByType(Class<T> cla$$) {
/* 1250 */     List<Setting<T>> result = new ArrayList<>();
/* 1251 */     for (Setting<?> setting : this.allSettings) {
/* 1252 */       if (setting.getValueClass().equals(cla$$)) {
/* 1253 */         result.add(setting);
/*      */       }
/*      */     } 
/* 1256 */     return result;
/*      */   }
/*      */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\Settings.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */