package baritone.api.pathing.calc;

import baritone.api.pathing.goals.Goal;
import baritone.api.utils.PathCalculationResult;
import java.util.Optional;

public interface IPathFinder {
  Goal getGoal();
  
  PathCalculationResult calculate(long paramLong1, long paramLong2);
  
  boolean isFinished();
  
  Optional<IPath> pathToMostRecentNodeConsidered();
  
  Optional<IPath> bestPathSoFar();
}


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\pathing\calc\IPathFinder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */