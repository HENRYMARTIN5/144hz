/*    */ package baritone.api.event.events.type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Overrideable<T>
/*    */ {
/*    */   private T value;
/*    */   private boolean modified;
/*    */   
/*    */   public Overrideable(T current) {
/* 29 */     this.value = current;
/*    */   }
/*    */   
/*    */   public T get() {
/* 33 */     return this.value;
/*    */   }
/*    */   
/*    */   public void set(T newValue) {
/* 37 */     this.value = newValue;
/* 38 */     this.modified = true;
/*    */   }
/*    */   
/*    */   public boolean wasModified() {
/* 42 */     return this.modified;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 47 */     return String.format("Overrideable{modified=%b,value=%s}", new Object[] {
/*    */           
/* 49 */           Boolean.valueOf(this.modified), this.value
/* 50 */           .toString()
/*    */         });
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\event\events\type\Overrideable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */