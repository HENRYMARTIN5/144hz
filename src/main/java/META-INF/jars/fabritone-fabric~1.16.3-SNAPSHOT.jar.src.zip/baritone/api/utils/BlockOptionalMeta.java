/*     */ package baritone.api.utils;
/*     */ 
/*     */ import baritone.api.utils.accessor.IItemStack;
/*     */ import com.google.common.collect.ImmutableSet;
/*     */ import io.netty.util.concurrent.ThreadPerTaskExecutor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Random;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.regex.MatchResult;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import java.util.stream.Stream;
/*     */ import javax.annotation.Nonnull;
/*     */ import net.minecraft.class_173;
/*     */ import net.minecraft.class_1792;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_181;
/*     */ import net.minecraft.class_1935;
/*     */ import net.minecraft.class_2248;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_2960;
/*     */ import net.minecraft.class_3262;
/*     */ import net.minecraft.class_3264;
/*     */ import net.minecraft.class_3283;
/*     */ import net.minecraft.class_3285;
/*     */ import net.minecraft.class_3286;
/*     */ import net.minecraft.class_3288;
/*     */ import net.minecraft.class_3302;
/*     */ import net.minecraft.class_3304;
/*     */ import net.minecraft.class_39;
/*     */ import net.minecraft.class_3902;
/*     */ import net.minecraft.class_4567;
/*     */ import net.minecraft.class_47;
/*     */ import net.minecraft.class_60;
/*     */ 
/*     */ public final class BlockOptionalMeta
/*     */ {
/*     */   private final class_2248 block;
/*     */   private final Set<class_2680> blockstates;
/*  51 */   private static final Pattern pattern = Pattern.compile("^(.+?)(?::(\\d+))?$"); private final ImmutableSet<Integer> stateHashes; private final ImmutableSet<Integer> stackHashes;
/*     */   private static class_60 manager;
/*  53 */   private static class_4567 predicate = new class_4567();
/*  54 */   private static Map<class_2248, List<class_1792>> drops = new HashMap<>();
/*     */   
/*     */   public BlockOptionalMeta(@Nonnull class_2248 block) {
/*  57 */     this.block = block;
/*  58 */     this.blockstates = getStates(block);
/*  59 */     this.stateHashes = getStateHashes(this.blockstates);
/*  60 */     this.stackHashes = getStackHashes(this.blockstates);
/*     */   }
/*     */   
/*     */   public BlockOptionalMeta(@Nonnull String selector) {
/*  64 */     Matcher matcher = pattern.matcher(selector);
/*     */     
/*  66 */     if (!matcher.find()) {
/*  67 */       throw new IllegalArgumentException("invalid block selector");
/*     */     }
/*     */     
/*  70 */     MatchResult matchResult = matcher.toMatchResult();
/*     */     
/*  72 */     this.block = BlockUtils.stringToBlockRequired(matchResult.group(1));
/*  73 */     this.blockstates = getStates(this.block);
/*  74 */     this.stateHashes = getStateHashes(this.blockstates);
/*  75 */     this.stackHashes = getStackHashes(this.blockstates);
/*     */   }
/*     */   
/*     */   private static Set<class_2680> getStates(@Nonnull class_2248 block) {
/*  79 */     return new HashSet<>((Collection<? extends class_2680>)block.method_9595().method_11662());
/*     */   }
/*     */   
/*     */   private static ImmutableSet<Integer> getStateHashes(Set<class_2680> blockstates) {
/*  83 */     return ImmutableSet.copyOf(blockstates
/*  84 */         .stream()
/*  85 */         .map(Object::hashCode)
/*  86 */         .toArray(x$0 -> new Integer[x$0]));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static ImmutableSet<Integer> getStackHashes(Set<class_2680> blockstates) {
/*  92 */     return ImmutableSet.copyOf(blockstates
/*  93 */         .stream()
/*  94 */         .flatMap(state -> drops(state.method_26204()).stream().map(()))
/*     */ 
/*     */ 
/*     */         
/*  98 */         .map(stack -> Integer.valueOf(((IItemStack)stack).getBaritoneHash()))
/*  99 */         .toArray(x$0 -> new Integer[x$0]));
/*     */   }
/*     */ 
/*     */   
/*     */   public class_2248 getBlock() {
/* 104 */     return this.block;
/*     */   }
/*     */   
/*     */   public boolean matches(@Nonnull class_2248 block) {
/* 108 */     return (block == this.block);
/*     */   }
/*     */   
/*     */   public boolean matches(@Nonnull class_2680 blockstate) {
/* 112 */     class_2248 block = blockstate.method_26204();
/* 113 */     return (block == this.block && this.stateHashes.contains(Integer.valueOf(blockstate.hashCode())));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean matches(class_1799 stack) {
/* 118 */     int hash = ((IItemStack)stack).getBaritoneHash();
/*     */     
/* 120 */     hash -= stack.method_7919();
/*     */     
/* 122 */     return this.stackHashes.contains(Integer.valueOf(hash));
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 127 */     return String.format("BlockOptionalMeta{block=%s}", new Object[] { this.block });
/*     */   }
/*     */   
/*     */   public class_2680 getAnyBlockState() {
/* 131 */     if (this.blockstates.size() > 0) {
/* 132 */       return this.blockstates.iterator().next();
/*     */     }
/*     */     
/* 135 */     return null;
/*     */   }
/*     */   
/*     */   public static class_60 getManager() {
/* 139 */     if (manager == null) {
/* 140 */       class_3283 rpl = new class_3283(class_3288::new, new class_3285[] { (class_3285)new class_3286() });
/* 141 */       rpl.method_14445();
/* 142 */       class_3262 thePack = ((class_3288)rpl.method_14441().iterator().next()).method_14458();
/* 143 */       class_3304 class_3304 = new class_3304(class_3264.field_14190);
/* 144 */       manager = new class_60(predicate);
/* 145 */       class_3304.method_14477((class_3302)manager);
/*     */       try {
/* 147 */         class_3304.method_14478((Executor)new ThreadPerTaskExecutor(Thread::new), (Executor)new ThreadPerTaskExecutor(Thread::new), Collections.singletonList(thePack), CompletableFuture.completedFuture(class_3902.field_17274)).get();
/* 148 */       } catch (Exception exception) {
/* 149 */         throw new RuntimeException(exception);
/*     */       } 
/*     */     } 
/* 152 */     return manager;
/*     */   }
/*     */   
/*     */   public static class_4567 getPredicateManager() {
/* 156 */     return predicate;
/*     */   }
/*     */   
/*     */   private static synchronized List<class_1792> drops(class_2248 b) {
/* 160 */     return drops.computeIfAbsent(b, block -> {
/*     */           class_2960 lootTableLocation = block.method_26162();
/*     */           if (lootTableLocation == class_39.field_844)
/*     */             return Collections.emptyList(); 
/*     */           List<class_1792> items = new ArrayList<>();
/*     */           getManager().method_367(lootTableLocation).method_320((new class_47.class_48(null)).method_311(new Random()).method_312(class_181.field_24424, class_243.method_24954(class_2338.field_11176)).method_312(class_181.field_1229, class_1799.field_8037).method_306(class_181.field_1228, null).method_312(class_181.field_1224, block.method_9564()).method_309(class_173.field_1172), ());
/*     */           return items;
/*     */         });
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\ap\\utils\BlockOptionalMeta.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */