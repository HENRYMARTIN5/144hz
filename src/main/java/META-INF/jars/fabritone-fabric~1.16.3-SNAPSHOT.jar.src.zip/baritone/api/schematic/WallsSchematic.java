/*    */ package baritone.api.schematic;
/*    */ 
/*    */ import net.minecraft.class_2680;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WallsSchematic
/*    */   extends MaskSchematic
/*    */ {
/*    */   public WallsSchematic(ISchematic schematic) {
/* 25 */     super(schematic);
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean partOfMask(int x, int y, int z, class_2680 currentState) {
/* 30 */     return (x == 0 || z == 0 || x == widthX() - 1 || z == lengthZ() - 1);
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\schematic\WallsSchematic.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */