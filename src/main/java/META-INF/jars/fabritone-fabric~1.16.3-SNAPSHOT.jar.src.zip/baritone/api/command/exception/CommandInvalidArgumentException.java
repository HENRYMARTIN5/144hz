/*    */ package baritone.api.command.exception;
/*    */ 
/*    */ import baritone.api.command.argument.ICommandArgument;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class CommandInvalidArgumentException
/*    */   extends CommandErrorMessageException
/*    */ {
/*    */   public final ICommandArgument arg;
/*    */   
/*    */   protected CommandInvalidArgumentException(ICommandArgument arg, String message) {
/* 27 */     super(formatMessage(arg, message));
/* 28 */     this.arg = arg;
/*    */   }
/*    */   
/*    */   protected CommandInvalidArgumentException(ICommandArgument arg, String message, Throwable cause) {
/* 32 */     super(formatMessage(arg, message), cause);
/* 33 */     this.arg = arg;
/*    */   }
/*    */   
/*    */   private static String formatMessage(ICommandArgument arg, String message) {
/* 37 */     return String.format("Error at argument #%s: %s", new Object[] {
/*    */           
/* 39 */           (arg.getIndex() == -1) ? "<unknown>" : Integer.toString(arg.getIndex() + 1), message
/*    */         });
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\command\exception\CommandInvalidArgumentException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */