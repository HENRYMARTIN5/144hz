/*     */ package baritone.api.command.helpers;
/*     */ 
/*     */ import baritone.api.BaritoneAPI;
/*     */ import baritone.api.Settings;
/*     */ import baritone.api.command.ICommand;
/*     */ import baritone.api.command.manager.ICommandManager;
/*     */ import baritone.api.utils.SettingsUtil;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.stream.Stream;
/*     */ import net.minecraft.class_2960;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TabCompleteHelper
/*     */ {
/*     */   private Stream<String> stream;
/*     */   
/*     */   public TabCompleteHelper(String[] base) {
/*  58 */     this.stream = Stream.of(base);
/*     */   }
/*     */   
/*     */   public TabCompleteHelper(List<String> base) {
/*  62 */     this.stream = base.stream();
/*     */   }
/*     */   
/*     */   public TabCompleteHelper() {
/*  66 */     this.stream = Stream.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TabCompleteHelper append(Stream<String> source) {
/*  78 */     this.stream = Stream.concat(this.stream, source);
/*  79 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TabCompleteHelper append(String... source) {
/*  91 */     return append(Stream.of(source));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TabCompleteHelper append(Class<? extends Enum<?>> num) {
/* 103 */     return append(
/* 104 */         Stream.of(num.getEnumConstants())
/* 105 */         .map(Enum::name)
/* 106 */         .map(String::toLowerCase));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TabCompleteHelper prepend(Stream<String> source) {
/* 119 */     this.stream = Stream.concat(source, this.stream);
/* 120 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TabCompleteHelper prepend(String... source) {
/* 132 */     return prepend(Stream.of(source));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TabCompleteHelper prepend(Class<? extends Enum<?>> num) {
/* 144 */     return prepend(
/* 145 */         Stream.of(num.getEnumConstants())
/* 146 */         .map(Enum::name)
/* 147 */         .map(String::toLowerCase));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TabCompleteHelper map(Function<String, String> transform) {
/* 159 */     this.stream = this.stream.map(transform);
/* 160 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TabCompleteHelper filter(Predicate<String> filter) {
/* 171 */     this.stream = this.stream.filter(filter);
/* 172 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TabCompleteHelper sort(Comparator<String> comparator) {
/* 183 */     this.stream = this.stream.sorted(comparator);
/* 184 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TabCompleteHelper sortAlphabetically() {
/* 194 */     return sort(String.CASE_INSENSITIVE_ORDER);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TabCompleteHelper filterPrefix(String prefix) {
/* 204 */     return filter(x -> x.toLowerCase(Locale.US).startsWith(prefix.toLowerCase(Locale.US)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TabCompleteHelper filterPrefixNamespaced(String prefix) {
/* 216 */     return filterPrefix((new class_2960(prefix)).toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] build() {
/* 224 */     return this.stream.<String>toArray(x$0 -> new String[x$0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Stream<String> stream() {
/* 232 */     return this.stream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TabCompleteHelper addCommands(ICommandManager manager) {
/* 243 */     return append(manager.getRegistry().descendingStream()
/* 244 */         .flatMap(command -> command.getNames().stream())
/* 245 */         .distinct());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TabCompleteHelper addSettings() {
/* 255 */     return append(
/* 256 */         (BaritoneAPI.getSettings()).allSettings.stream()
/* 257 */         .map(Settings.Setting::getName)
/* 258 */         .filter(s -> !s.equalsIgnoreCase("logger"))
/* 259 */         .sorted(String.CASE_INSENSITIVE_ORDER));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TabCompleteHelper addModifiedSettings() {
/* 269 */     return append(
/* 270 */         SettingsUtil.modifiedSettings(BaritoneAPI.getSettings()).stream()
/* 271 */         .map(Settings.Setting::getName)
/* 272 */         .sorted(String.CASE_INSENSITIVE_ORDER));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TabCompleteHelper addToggleableSettings() {
/* 282 */     return append(
/* 283 */         BaritoneAPI.getSettings().getAllValuesByType(Boolean.class).stream()
/* 284 */         .map(Settings.Setting::getName)
/* 285 */         .sorted(String.CASE_INSENSITIVE_ORDER));
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\command\helpers\TabCompleteHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */