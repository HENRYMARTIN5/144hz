/*    */ package baritone.api.pathing.goals;
/*    */ 
/*    */ import baritone.api.utils.SettingsUtil;
/*    */ import baritone.api.utils.interfaces.IGoalRenderPos;
/*    */ import net.minecraft.class_2338;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GoalTwoBlocks
/*    */   implements Goal, IGoalRenderPos
/*    */ {
/*    */   protected final int x;
/*    */   protected final int y;
/*    */   protected final int z;
/*    */   
/*    */   public GoalTwoBlocks(class_2338 pos) {
/* 48 */     this(pos.method_10263(), pos.method_10264(), pos.method_10260());
/*    */   }
/*    */   
/*    */   public GoalTwoBlocks(int x, int y, int z) {
/* 52 */     this.x = x;
/* 53 */     this.y = y;
/* 54 */     this.z = z;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isInGoal(int x, int y, int z) {
/* 59 */     return (x == this.x && (y == this.y || y == this.y - 1) && z == this.z);
/*    */   }
/*    */ 
/*    */   
/*    */   public double heuristic(int x, int y, int z) {
/* 64 */     int xDiff = x - this.x;
/* 65 */     int yDiff = y - this.y;
/* 66 */     int zDiff = z - this.z;
/* 67 */     return GoalBlock.calculate(xDiff, (yDiff < 0) ? (yDiff + 1) : yDiff, zDiff);
/*    */   }
/*    */ 
/*    */   
/*    */   public class_2338 getGoalPos() {
/* 72 */     return new class_2338(this.x, this.y, this.z);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 77 */     return String.format("GoalTwoBlocks{x=%s,y=%s,z=%s}", new Object[] {
/*    */           
/* 79 */           SettingsUtil.maybeCensor(this.x), 
/* 80 */           SettingsUtil.maybeCensor(this.y), 
/* 81 */           SettingsUtil.maybeCensor(this.z)
/*    */         });
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\api\pathing\goals\GoalTwoBlocks.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */