package baritone.launch.mixins;

import baritone.utils.accessor.IPlayerControllerMP;
import net.minecraft.class_2338;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin({class_636.class})
public abstract class MixinPlayerController implements IPlayerControllerMP {
  @Accessor
  public abstract void setBreakingBlock(boolean paramBoolean);
  
  @Accessor
  public abstract class_2338 getCurrentBreakingPos();
  
  @Invoker
  public abstract void callSyncSelectedSlot();
}


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\launch\mixins\MixinPlayerController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */