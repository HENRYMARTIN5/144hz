/*     */ package baritone.launch.mixins;
/*     */ 
/*     */ import baritone.api.BaritoneAPI;
/*     */ import baritone.api.IBaritone;
/*     */ import baritone.api.event.events.TickEvent;
/*     */ import baritone.api.event.events.WorldEvent;
/*     */ import baritone.api.event.events.type.EventState;
/*     */ import baritone.utils.BaritoneAutoTest;
/*     */ import java.util.function.BiFunction;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_437;
/*     */ import net.minecraft.class_638;
/*     */ import net.minecraft.class_746;
/*     */ import org.spongepowered.asm.mixin.Mixin;
/*     */ import org.spongepowered.asm.mixin.Shadow;
/*     */ import org.spongepowered.asm.mixin.injection.At;
/*     */ import org.spongepowered.asm.mixin.injection.Inject;
/*     */ import org.spongepowered.asm.mixin.injection.Redirect;
/*     */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Mixin({class_310.class})
/*     */ public class MixinMinecraft
/*     */ {
/*     */   @Shadow
/*     */   public class_746 field_1724;
/*     */   @Shadow
/*     */   public class_638 field_1687;
/*     */   
/*     */   @Inject(method = {"<init>"}, at = {@At("RETURN")})
/*     */   private void postInit(CallbackInfo ci) {
/*  57 */     BaritoneAPI.getProvider().getPrimaryBaritone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject(method = {"<init>"}, at = {@At("RETURN")})
/*     */   private void preInit(CallbackInfo ci) {
/*  66 */     BaritoneAutoTest.INSTANCE.onPreInit();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject(method = {"tick"}, at = {@At(value = "FIELD", opcode = 180, target = "Lnet/minecraft/client/MinecraftClient;currentScreen:Lnet/minecraft/client/gui/screen/Screen;", ordinal = 5, shift = At.Shift.BY, by = -3)})
/*     */   private void runTick(CallbackInfo ci) {
/*  81 */     BiFunction<EventState, TickEvent.Type, TickEvent> tickProvider = TickEvent.createNextProvider();
/*     */     
/*  83 */     for (IBaritone baritone : BaritoneAPI.getProvider().getAllBaritones()) {
/*     */       
/*  85 */       TickEvent.Type type = (baritone.getPlayerContext().player() != null && baritone.getPlayerContext().world() != null) ? TickEvent.Type.IN : TickEvent.Type.OUT;
/*     */ 
/*     */ 
/*     */       
/*  89 */       baritone.getGameEventHandler().onTick(tickProvider.apply(EventState.PRE, type));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject(method = {"joinWorld"}, at = {@At("HEAD")})
/*     */   private void preLoadWorld(class_638 world, CallbackInfo ci) {
/* 100 */     if (this.field_1687 == null && world == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 106 */     BaritoneAPI.getProvider().getPrimaryBaritone().getGameEventHandler().onWorldEvent(new WorldEvent(world, EventState.PRE));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject(method = {"joinWorld"}, at = {@At("RETURN")})
/*     */   private void postLoadWorld(class_638 world, CallbackInfo ci) {
/* 122 */     BaritoneAPI.getProvider().getPrimaryBaritone().getGameEventHandler().onWorldEvent(new WorldEvent(world, EventState.POST));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Redirect(method = {"tick"}, at = @At(value = "FIELD", opcode = 180, target = "net/minecraft/client/gui/screen/Screen.passEvents:Z"))
/*     */   private boolean passEvents(class_437 screen) {
/* 140 */     return ((BaritoneAPI.getProvider().getPrimaryBaritone().getPathingBehavior().isPathing() && this.field_1724 != null) || screen.field_22792);
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\launch\mixins\MixinMinecraft.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */