/*    */ package baritone.launch.mixins;
/*    */ 
/*    */ import baritone.api.BaritoneAPI;
/*    */ import baritone.api.event.events.RotationMoveEvent;
/*    */ import net.minecraft.class_1297;
/*    */ import net.minecraft.class_746;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_1297.class})
/*    */ public class MixinEntity
/*    */ {
/*    */   @Shadow
/*    */   private float field_6031;
/*    */   float yawRestore;
/*    */   
/*    */   @Inject(method = {"updateVelocity"}, at = {@At("HEAD")})
/*    */   private void moveRelativeHead(CallbackInfo info) {
/* 43 */     this.yawRestore = this.field_6031;
/*    */     
/* 45 */     if (!class_746.class.isInstance(this) || BaritoneAPI.getProvider().getBaritoneForPlayer((class_746)this) == null) {
/*    */       return;
/*    */     }
/* 48 */     RotationMoveEvent motionUpdateRotationEvent = new RotationMoveEvent(RotationMoveEvent.Type.MOTION_UPDATE, this.field_6031);
/* 49 */     BaritoneAPI.getProvider().getBaritoneForPlayer((class_746)this).getGameEventHandler().onPlayerRotationMove(motionUpdateRotationEvent);
/* 50 */     this.field_6031 = motionUpdateRotationEvent.getYaw();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Inject(method = {"updateVelocity"}, at = {@At("RETURN")})
/*    */   private void moveRelativeReturn(CallbackInfo info) {
/* 58 */     this.field_6031 = this.yawRestore;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\launch\mixins\MixinEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */