/*     */ package baritone.launch;
/*     */ 
/*     */ import com.google.common.base.Strings;
/*     */ import com.google.gson.GsonBuilder;
/*     */ import com.mojang.authlib.Agent;
/*     */ import com.mojang.authlib.exceptions.AuthenticationException;
/*     */ import com.mojang.authlib.properties.PropertyMap;
/*     */ import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
/*     */ import com.mojang.authlib.yggdrasil.YggdrasilUserAuthentication;
/*     */ import java.io.File;
/*     */ import java.lang.reflect.Field;
/*     */ import java.net.Proxy;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.minecraft.launchwrapper.Launch;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LaunchTesting
/*     */ {
/*     */   public static void main(String[] args) {
/*  46 */     Map<String, String> arguments = new HashMap<>();
/*     */     
/*  48 */     hackNatives();
/*  49 */     arguments.put("version", "BaritownedDeveloperEnvironment");
/*     */     
/*  51 */     arguments.put("assetsDir", System.getenv().getOrDefault("assetDirectory", "assets"));
/*  52 */     arguments.put("accessToken", "FML");
/*  53 */     arguments.put("userProperties", "{}");
/*  54 */     arguments.put("tweakClass", System.getenv("tweakClass"));
/*  55 */     String password = System.getenv("password");
/*  56 */     if (password != null && !password.isEmpty()) {
/*  57 */       attemptLogin(arguments, System.getenv("username"), System.getenv("password"));
/*     */     }
/*     */     
/*  60 */     List<String> argsArray = new ArrayList<>();
/*  61 */     arguments.forEach((k, v) -> {
/*     */           argsArray.add("--" + k);
/*     */           
/*     */           argsArray.add(v);
/*     */         });
/*  66 */     Launch.main(argsArray.<String>toArray(new String[0]));
/*     */   }
/*     */   
/*     */   private static void hackNatives() {
/*  70 */     String paths = System.getProperty("java.library.path");
/*  71 */     String nativesDir = System.getenv().get("nativesDirectory");
/*     */     
/*  73 */     if (Strings.isNullOrEmpty(paths)) {
/*  74 */       paths = nativesDir;
/*     */     } else {
/*  76 */       paths = paths + File.pathSeparator + nativesDir;
/*     */     } 
/*  78 */     System.setProperty("java.library.path", paths);
/*     */ 
/*     */     
/*     */     try {
/*  82 */       Field sysPathsField = ClassLoader.class.getDeclaredField("sys_paths");
/*  83 */       sysPathsField.setAccessible(true);
/*  84 */       sysPathsField.set(null, null);
/*  85 */     } catch (Throwable throwable) {}
/*     */   }
/*     */   
/*     */   private static void attemptLogin(Map<String, String> argMap, String username, String password) {
/*  89 */     YggdrasilUserAuthentication auth = (YggdrasilUserAuthentication)(new YggdrasilAuthenticationService(Proxy.NO_PROXY, "1")).createUserAuthentication(Agent.MINECRAFT);
/*  90 */     auth.setUsername(username);
/*  91 */     auth.setPassword(password);
/*     */     
/*     */     try {
/*  94 */       auth.logIn();
/*  95 */     } catch (AuthenticationException var4) {
/*  96 */       throw new RuntimeException(var4);
/*     */     } 
/*     */     
/*  99 */     argMap.put("accessToken", auth.getAuthenticatedToken());
/* 100 */     argMap.put("uuid", auth.getSelectedProfile().getId().toString().replace("-", ""));
/* 101 */     argMap.put("username", auth.getSelectedProfile().getName());
/* 102 */     argMap.put("userType", auth.getUserType().getName());
/* 103 */     argMap.put("userProperties", (new GsonBuilder()).registerTypeAdapter(PropertyMap.class, new PropertyMap.Serializer()).create().toJson(auth.getUserProperties()));
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\launch\LaunchTesting.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */