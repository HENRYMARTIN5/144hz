/*    */ package baritone.launch;
/*    */ 
/*    */ import io.github.impactdevelopment.simpletweaker.SimpleTweaker;
/*    */ import java.util.List;
/*    */ import net.minecraft.launchwrapper.Launch;
/*    */ import net.minecraft.launchwrapper.LaunchClassLoader;
/*    */ import org.spongepowered.asm.launch.MixinBootstrap;
/*    */ import org.spongepowered.asm.mixin.MixinEnvironment;
/*    */ import org.spongepowered.asm.mixin.Mixins;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BaritoneTweaker
/*    */   extends SimpleTweaker
/*    */ {
/*    */   public void injectIntoClassLoader(LaunchClassLoader classLoader) {
/* 38 */     super.injectIntoClassLoader(classLoader);
/*    */     
/* 40 */     MixinBootstrap.init();
/*    */ 
/*    */     
/* 43 */     List<String> tweakClasses = (List<String>)Launch.blackboard.get("TweakClasses");
/*    */     
/* 45 */     String obfuscation = "notch";
/* 46 */     if (tweakClasses.stream().anyMatch(s -> s.contains("net.minecraftforge.fml.common.launcher"))) {
/* 47 */       obfuscation = "searge";
/*    */     }
/*    */     
/* 50 */     MixinEnvironment.getDefaultEnvironment().setSide(MixinEnvironment.Side.CLIENT);
/* 51 */     MixinEnvironment.getDefaultEnvironment().setObfuscationContext(obfuscation);
/*    */     
/* 53 */     Mixins.addConfiguration("mixins.baritone.json");
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\launch\BaritoneTweaker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */