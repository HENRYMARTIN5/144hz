/*    */ package baritone.launch.mixins;
/*    */ 
/*    */ import baritone.utils.accessor.IEntityRenderManager;
/*    */ import net.minecraft.class_898;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_898.class})
/*    */ public class MixinEntityRenderManager
/*    */   implements IEntityRenderManager
/*    */ {
/*    */   public double renderPosX() {
/* 30 */     return (((class_898)this).field_4686.method_19326()).field_1352;
/*    */   }
/*    */ 
/*    */   
/*    */   public double renderPosY() {
/* 35 */     return (((class_898)this).field_4686.method_19326()).field_1351;
/*    */   }
/*    */ 
/*    */   
/*    */   public double renderPosZ() {
/* 40 */     return (((class_898)this).field_4686.method_19326()).field_1350;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\launch\mixins\MixinEntityRenderManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */