/*    */ package baritone.launch.mixins;
/*    */ 
/*    */ import baritone.utils.accessor.IChunkArray;
/*    */ import java.util.concurrent.atomic.AtomicReferenceArray;
/*    */ import net.minecraft.class_1923;
/*    */ import net.minecraft.class_2818;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin(targets = {"net.minecraft.client.world.ClientChunkManager$ClientChunkMap"})
/*    */ public abstract class MixinChunkArray
/*    */   implements IChunkArray
/*    */ {
/*    */   @Shadow
/*    */   private AtomicReferenceArray<class_2818> field_16251;
/*    */   @Shadow
/*    */   private int field_16253;
/*    */   @Shadow
/*    */   private int field_16252;
/*    */   @Shadow
/*    */   private int field_19204;
/*    */   @Shadow
/*    */   private int field_19205;
/*    */   @Shadow
/*    */   private int field_19143;
/*    */   
/*    */   @Shadow
/*    */   protected abstract boolean method_16034(int paramInt1, int paramInt2);
/*    */   
/*    */   @Shadow
/*    */   protected abstract int method_16027(int paramInt1, int paramInt2);
/*    */   
/*    */   @Shadow
/*    */   protected abstract void method_16031(int paramInt, class_2818 paramclass_2818);
/*    */   
/*    */   public int centerX() {
/* 55 */     return this.field_19204;
/*    */   }
/*    */ 
/*    */   
/*    */   public int centerZ() {
/* 60 */     return this.field_19205;
/*    */   }
/*    */ 
/*    */   
/*    */   public int viewDistance() {
/* 65 */     return this.field_16253;
/*    */   }
/*    */ 
/*    */   
/*    */   public AtomicReferenceArray<class_2818> getChunks() {
/* 70 */     return this.field_16251;
/*    */   }
/*    */ 
/*    */   
/*    */   public void copyFrom(IChunkArray other) {
/* 75 */     this.field_19204 = other.centerX();
/* 76 */     this.field_19205 = other.centerZ();
/*    */     
/* 78 */     AtomicReferenceArray<class_2818> copyingFrom = other.getChunks();
/* 79 */     for (int k = 0; k < copyingFrom.length(); k++) {
/* 80 */       class_2818 chunk = copyingFrom.get(k);
/* 81 */       if (chunk != null) {
/* 82 */         class_1923 chunkpos = chunk.method_12004();
/* 83 */         if (method_16034(chunkpos.field_9181, chunkpos.field_9180)) {
/* 84 */           int index = method_16027(chunkpos.field_9181, chunkpos.field_9180);
/* 85 */           if (this.field_16251.get(index) != null) {
/* 86 */             throw new IllegalStateException("Doing this would mutate the client's REAL loaded chunks?!");
/*    */           }
/* 88 */           method_16031(index, chunk);
/*    */         } 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\launch\mixins\MixinChunkArray.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */