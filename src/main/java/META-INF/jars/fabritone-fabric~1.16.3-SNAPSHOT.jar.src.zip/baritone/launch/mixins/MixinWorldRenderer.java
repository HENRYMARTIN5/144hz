/*    */ package baritone.launch.mixins;
/*    */ 
/*    */ import baritone.api.BaritoneAPI;
/*    */ import baritone.api.IBaritone;
/*    */ import baritone.api.event.events.RenderEvent;
/*    */ import net.minecraft.class_1159;
/*    */ import net.minecraft.class_4184;
/*    */ import net.minecraft.class_4587;
/*    */ import net.minecraft.class_757;
/*    */ import net.minecraft.class_761;
/*    */ import net.minecraft.class_765;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ import org.spongepowered.asm.mixin.injection.callback.LocalCapture;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_761.class})
/*    */ public class MixinWorldRenderer
/*    */ {
/*    */   @Inject(method = {"render"}, at = {@At("RETURN")}, locals = LocalCapture.CAPTURE_FAILSOFT)
/*    */   private void onStartHand(class_4587 matrixStackIn, float partialTicks, long finishTimeNano, boolean drawBlockOutline, class_4184 activeRenderInfoIn, class_757 gameRendererIn, class_765 lightmapIn, class_1159 projectionIn, CallbackInfo ci) {
/* 48 */     for (IBaritone ibaritone : BaritoneAPI.getProvider().getAllBaritones())
/* 49 */       ibaritone.getGameEventHandler().onRenderPass(new RenderEvent(partialTicks, matrixStackIn, projectionIn)); 
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\launch\mixins\MixinWorldRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */