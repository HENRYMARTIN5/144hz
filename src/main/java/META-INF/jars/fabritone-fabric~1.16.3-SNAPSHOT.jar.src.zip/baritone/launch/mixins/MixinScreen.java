package baritone.launch.mixins;

import baritone.utils.accessor.IGuiScreen;
import java.net.URI;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin({class_437.class})
public abstract class MixinScreen implements IGuiScreen {
  @Invoker("openLink")
  public abstract void openLinkInvoker(URI paramURI);
}


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\launch\mixins\MixinScreen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */