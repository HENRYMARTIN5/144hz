/*    */ package baritone.launch;
/*    */ 
/*    */ import org.spongepowered.asm.mixin.Mixins;
/*    */ import org.spongepowered.asm.mixin.connect.IMixinConnector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BaritoneMixinConnector
/*    */   implements IMixinConnector
/*    */ {
/*    */   public void connect() {
/* 27 */     Mixins.addConfiguration("mixins.baritone.json");
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\launch\BaritoneMixinConnector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */