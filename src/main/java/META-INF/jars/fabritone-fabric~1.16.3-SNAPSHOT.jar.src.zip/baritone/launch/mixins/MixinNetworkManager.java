/*     */ package baritone.launch.mixins;
/*     */ 
/*     */ import baritone.api.BaritoneAPI;
/*     */ import baritone.api.IBaritone;
/*     */ import baritone.api.event.events.PacketEvent;
/*     */ import baritone.api.event.events.type.EventState;
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import io.netty.util.concurrent.GenericFutureListener;
/*     */ import net.minecraft.class_2535;
/*     */ import net.minecraft.class_2596;
/*     */ import net.minecraft.class_2598;
/*     */ import org.spongepowered.asm.mixin.Final;
/*     */ import org.spongepowered.asm.mixin.Mixin;
/*     */ import org.spongepowered.asm.mixin.Shadow;
/*     */ import org.spongepowered.asm.mixin.injection.At;
/*     */ import org.spongepowered.asm.mixin.injection.Inject;
/*     */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Mixin({class_2535.class})
/*     */ public class MixinNetworkManager
/*     */ {
/*     */   @Shadow
/*     */   private Channel field_11651;
/*     */   @Shadow
/*     */   @Final
/*     */   private class_2598 field_11643;
/*     */   
/*     */   @Inject(method = {"sendImmediately"}, at = {@At("HEAD")})
/*     */   private void preDispatchPacket(class_2596<?> inPacket, GenericFutureListener<? extends Future<? super Void>> futureListeners, CallbackInfo ci) {
/*  57 */     if (this.field_11643 != class_2598.field_11942) {
/*     */       return;
/*     */     }
/*     */     
/*  61 */     for (IBaritone ibaritone : BaritoneAPI.getProvider().getAllBaritones()) {
/*  62 */       if (ibaritone.getPlayerContext().player() != null && (ibaritone.getPlayerContext().player()).field_3944.method_2872() == (class_2535)this) {
/*  63 */         ibaritone.getGameEventHandler().onSendPacket(new PacketEvent((class_2535)this, EventState.PRE, inPacket));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject(method = {"sendImmediately"}, at = {@At("RETURN")})
/*     */   private void postDispatchPacket(class_2596<?> inPacket, GenericFutureListener<? extends Future<? super Void>> futureListeners, CallbackInfo ci) {
/*  73 */     if (this.field_11643 != class_2598.field_11942) {
/*     */       return;
/*     */     }
/*     */     
/*  77 */     for (IBaritone ibaritone : BaritoneAPI.getProvider().getAllBaritones()) {
/*  78 */       if (ibaritone.getPlayerContext().player() != null && (ibaritone.getPlayerContext().player()).field_3944.method_2872() == (class_2535)this) {
/*  79 */         ibaritone.getGameEventHandler().onSendPacket(new PacketEvent((class_2535)this, EventState.POST, inPacket));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject(method = {"channelRead0"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/network/ClientConnection;handlePacket(Lnet/minecraft/network/Packet;Lnet/minecraft/network/listener/PacketListener;)V")})
/*     */   private void preProcessPacket(ChannelHandlerContext context, class_2596<?> packet, CallbackInfo ci) {
/*  92 */     if (this.field_11643 != class_2598.field_11942) {
/*     */       return;
/*     */     }
/*  95 */     for (IBaritone ibaritone : BaritoneAPI.getProvider().getAllBaritones()) {
/*  96 */       if (ibaritone.getPlayerContext().player() != null && (ibaritone.getPlayerContext().player()).field_3944.method_2872() == (class_2535)this) {
/*  97 */         ibaritone.getGameEventHandler().onReceivePacket(new PacketEvent((class_2535)this, EventState.PRE, packet));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject(method = {"channelRead0"}, at = {@At("RETURN")})
/*     */   private void postProcessPacket(ChannelHandlerContext context, class_2596<?> packet, CallbackInfo ci) {
/* 107 */     if (!this.field_11651.isOpen() || this.field_11643 != class_2598.field_11942) {
/*     */       return;
/*     */     }
/* 110 */     for (IBaritone ibaritone : BaritoneAPI.getProvider().getAllBaritones()) {
/* 111 */       if (ibaritone.getPlayerContext().player() != null && (ibaritone.getPlayerContext().player()).field_3944.method_2872() == (class_2535)this)
/* 112 */         ibaritone.getGameEventHandler().onReceivePacket(new PacketEvent((class_2535)this, EventState.POST, packet)); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\launch\mixins\MixinNetworkManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */