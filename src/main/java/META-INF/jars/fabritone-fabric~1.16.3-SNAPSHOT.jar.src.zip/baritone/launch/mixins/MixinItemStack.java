/*    */ package baritone.launch.mixins;
/*    */ 
/*    */ import baritone.api.utils.accessor.IItemStack;
/*    */ import net.minecraft.class_1792;
/*    */ import net.minecraft.class_1799;
/*    */ import org.spongepowered.asm.mixin.Final;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.Unique;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_1799.class})
/*    */ public abstract class MixinItemStack
/*    */   implements IItemStack
/*    */ {
/*    */   @Shadow
/*    */   @Final
/*    */   private class_1792 field_8038;
/*    */   @Unique
/*    */   private int baritoneHash;
/*    */   
/*    */   @Shadow
/*    */   protected abstract int method_7919();
/*    */   
/*    */   private void recalculateHash() {
/* 45 */     this.baritoneHash = (this.field_8038 == null) ? -1 : (this.field_8038.hashCode() + method_7919());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Inject(method = {"<init>*"}, at = {@At("RETURN")})
/*    */   private void onInit(CallbackInfo ci) {
/* 53 */     recalculateHash();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Inject(method = {"setDamage"}, at = {@At("TAIL")})
/*    */   private void onItemDamageSet(CallbackInfo ci) {
/* 61 */     recalculateHash();
/*    */   }
/*    */ 
/*    */   
/*    */   public int getBaritoneHash() {
/* 66 */     return this.baritoneHash;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\launch\mixins\MixinItemStack.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */