/*    */ package baritone.launch.mixins;
/*    */ 
/*    */ import baritone.api.BaritoneAPI;
/*    */ import baritone.api.event.events.TabCompleteEvent;
/*    */ import com.mojang.brigadier.context.StringRange;
/*    */ import com.mojang.brigadier.suggestion.Suggestion;
/*    */ import com.mojang.brigadier.suggestion.Suggestions;
/*    */ import java.util.List;
/*    */ import java.util.concurrent.CompletableFuture;
/*    */ import java.util.stream.Collectors;
/*    */ import java.util.stream.Stream;
/*    */ import net.minecraft.class_342;
/*    */ import net.minecraft.class_4717;
/*    */ import org.spongepowered.asm.mixin.Final;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_4717.class})
/*    */ public class MixinCommandSuggestionHelper
/*    */ {
/*    */   @Shadow
/*    */   @Final
/*    */   private class_342 field_21599;
/*    */   @Shadow
/*    */   @Final
/*    */   private List<String> field_21607;
/*    */   @Shadow
/*    */   private CompletableFuture<Suggestions> field_21611;
/*    */   
/*    */   @Inject(method = {"refresh"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void preUpdateSuggestion(CallbackInfo ci) {
/* 64 */     String prefix = this.field_21599.method_1882().substring(0, Math.min(this.field_21599.method_1882().length(), this.field_21599.method_1881()));
/*    */     
/* 66 */     TabCompleteEvent event = new TabCompleteEvent(prefix);
/* 67 */     BaritoneAPI.getProvider().getPrimaryBaritone().getGameEventHandler().onPreTabComplete(event);
/*    */     
/* 69 */     if (event.isCancelled()) {
/* 70 */       ci.cancel();
/*    */       
/*    */       return;
/*    */     } 
/* 74 */     if (event.completions != null) {
/* 75 */       ci.cancel();
/*    */ 
/*    */       
/* 78 */       this.field_21607.clear();
/*    */       
/* 80 */       if (event.completions.length == 0) {
/* 81 */         this.field_21611 = Suggestions.empty();
/*    */       }
/*    */       else {
/*    */         
/* 85 */         int offset = this.field_21599.method_1882().endsWith(" ") ? this.field_21599.method_1881() : (this.field_21599.method_1882().lastIndexOf(" ") + 1);
/*    */ 
/*    */ 
/*    */         
/* 89 */         List<Suggestion> suggestionList = (List<Suggestion>)Stream.<String>of(event.completions).map(s -> new Suggestion(StringRange.between(offset, offset + s.length()), s)).collect(Collectors.toList());
/*    */ 
/*    */         
/* 92 */         Suggestions suggestions = new Suggestions(StringRange.between(offset, offset + suggestionList.stream().mapToInt(s -> s.getText().length()).max().orElse(0)), suggestionList);
/*    */ 
/*    */         
/* 95 */         this.field_21611 = new CompletableFuture<>();
/* 96 */         this.field_21611.complete(suggestions);
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\launch\mixins\MixinCommandSuggestionHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */