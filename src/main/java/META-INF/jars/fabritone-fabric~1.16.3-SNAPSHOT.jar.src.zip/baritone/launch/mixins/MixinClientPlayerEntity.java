/*     */ package baritone.launch.mixins;
/*     */ 
/*     */ import baritone.api.BaritoneAPI;
/*     */ import baritone.api.IBaritone;
/*     */ import baritone.api.event.events.ChatEvent;
/*     */ import baritone.api.event.events.PlayerUpdateEvent;
/*     */ import baritone.api.event.events.SprintStateEvent;
/*     */ import baritone.api.event.events.type.EventState;
/*     */ import baritone.behavior.LookBehavior;
/*     */ import net.minecraft.class_1656;
/*     */ import net.minecraft.class_304;
/*     */ import net.minecraft.class_746;
/*     */ import org.spongepowered.asm.mixin.Mixin;
/*     */ import org.spongepowered.asm.mixin.injection.At;
/*     */ import org.spongepowered.asm.mixin.injection.Inject;
/*     */ import org.spongepowered.asm.mixin.injection.Redirect;
/*     */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Mixin({class_746.class})
/*     */ public class MixinClientPlayerEntity
/*     */ {
/*     */   @Inject(method = {"sendChatMessage"}, at = {@At("HEAD")}, cancellable = true)
/*     */   private void sendChatMessage(String msg, CallbackInfo ci) {
/*  49 */     ChatEvent event = new ChatEvent(msg);
/*  50 */     IBaritone baritone = BaritoneAPI.getProvider().getBaritoneForPlayer((class_746)this);
/*  51 */     if (baritone == null) {
/*     */       return;
/*     */     }
/*  54 */     baritone.getGameEventHandler().onSendChatMessage(event);
/*  55 */     if (event.isCancelled()) {
/*  56 */       ci.cancel();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject(method = {"tick"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/client/network/ClientPlayerEntity;hasVehicle()Z", shift = At.Shift.BY, by = -3)})
/*     */   private void onPreUpdate(CallbackInfo ci) {
/*  70 */     IBaritone baritone = BaritoneAPI.getProvider().getBaritoneForPlayer((class_746)this);
/*  71 */     if (baritone != null) {
/*  72 */       baritone.getGameEventHandler().onPlayerUpdate(new PlayerUpdateEvent(EventState.PRE));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject(method = {"tick"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/client/network/ClientPlayerEntity;sendMovementPackets()V", shift = At.Shift.BY, by = 2)})
/*     */   private void onPostUpdate(CallbackInfo ci) {
/*  86 */     IBaritone baritone = BaritoneAPI.getProvider().getBaritoneForPlayer((class_746)this);
/*  87 */     if (baritone != null) {
/*  88 */       baritone.getGameEventHandler().onPlayerUpdate(new PlayerUpdateEvent(EventState.POST));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Redirect(method = {"tickMovement"}, at = @At(value = "FIELD", target = "net/minecraft/entity/player/PlayerAbilities.allowFlying:Z"))
/*     */   private boolean isAllowFlying(class_1656 capabilities) {
/* 100 */     IBaritone baritone = BaritoneAPI.getProvider().getBaritoneForPlayer((class_746)this);
/* 101 */     if (baritone == null) {
/* 102 */       return capabilities.field_7478;
/*     */     }
/* 104 */     return (!baritone.getPathingBehavior().isPathing() && capabilities.field_7478);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Redirect(method = {"tickMovement"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/options/KeyBinding;isPressed()Z"))
/*     */   private boolean isKeyDown(class_304 keyBinding) {
/* 115 */     IBaritone baritone = BaritoneAPI.getProvider().getBaritoneForPlayer((class_746)this);
/* 116 */     if (baritone == null) {
/* 117 */       return keyBinding.method_1434();
/*     */     }
/* 119 */     SprintStateEvent event = new SprintStateEvent();
/* 120 */     baritone.getGameEventHandler().onPlayerSprintState(event);
/* 121 */     if (event.getState() != null) {
/* 122 */       return event.getState().booleanValue();
/*     */     }
/* 124 */     if (baritone != BaritoneAPI.getProvider().getPrimaryBaritone())
/*     */     {
/* 126 */       return false;
/*     */     }
/* 128 */     return keyBinding.method_1434();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject(method = {"tickRiding"}, at = {@At("HEAD")})
/*     */   private void updateRidden(CallbackInfo cb) {
/* 138 */     IBaritone baritone = BaritoneAPI.getProvider().getBaritoneForPlayer((class_746)this);
/* 139 */     if (baritone != null)
/* 140 */       ((LookBehavior)baritone.getLookBehavior()).pig(); 
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\launch\mixins\MixinClientPlayerEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */