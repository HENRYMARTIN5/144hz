/*    */ package baritone.launch.mixins;
/*    */ 
/*    */ import baritone.api.BaritoneAPI;
/*    */ import baritone.api.IBaritone;
/*    */ import baritone.api.event.events.RotationMoveEvent;
/*    */ import net.minecraft.class_1297;
/*    */ import net.minecraft.class_1299;
/*    */ import net.minecraft.class_1309;
/*    */ import net.minecraft.class_1937;
/*    */ import net.minecraft.class_746;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.Redirect;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_1309.class})
/*    */ public abstract class MixinLivingEntity
/*    */   extends class_1297
/*    */ {
/*    */   private RotationMoveEvent jumpRotationEvent;
/*    */   
/*    */   public MixinLivingEntity(class_1299<?> entityTypeIn, class_1937 worldIn) {
/* 49 */     super(entityTypeIn, worldIn);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Inject(method = {"jump"}, at = {@At("HEAD")})
/*    */   private void preMoveRelative(CallbackInfo ci) {
/* 58 */     if (class_746.class.isInstance(this)) {
/* 59 */       IBaritone baritone = BaritoneAPI.getProvider().getBaritoneForPlayer((class_746)this);
/* 60 */       if (baritone != null) {
/* 61 */         this.jumpRotationEvent = new RotationMoveEvent(RotationMoveEvent.Type.JUMP, this.field_6031);
/* 62 */         baritone.getGameEventHandler().onPlayerRotationMove(this.jumpRotationEvent);
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Redirect(method = {"jump"}, at = @At(value = "FIELD", opcode = 180, target = "net/minecraft/entity/LivingEntity.yaw:F"))
/*    */   private float overrideYaw(class_1309 self) {
/* 76 */     if (self instanceof class_746 && BaritoneAPI.getProvider().getBaritoneForPlayer((class_746)this) != null) {
/* 77 */       return this.jumpRotationEvent.getYaw();
/*    */     }
/* 79 */     return self.field_6031;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\launch\mixins\MixinLivingEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */