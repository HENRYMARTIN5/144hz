/*    */ package baritone.launch.mixins;
/*    */ 
/*    */ import baritone.utils.accessor.IChunkArray;
/*    */ import baritone.utils.accessor.IClientChunkProvider;
/*    */ import java.lang.reflect.Field;
/*    */ import java.util.Arrays;
/*    */ import net.minecraft.class_631;
/*    */ import net.minecraft.class_638;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_631.class})
/*    */ public class MixinClientChunkProvider
/*    */   implements IClientChunkProvider
/*    */ {
/*    */   @Shadow
/*    */   private class_638 field_16525;
/*    */   
/*    */   public class_631 createThreadSafeCopy() {
/* 38 */     IChunkArray arr = extractReferenceArray();
/* 39 */     class_631 result = new class_631(this.field_16525, arr.viewDistance() - 3);
/* 40 */     IChunkArray copyArr = ((IClientChunkProvider)result).extractReferenceArray();
/* 41 */     copyArr.copyFrom(arr);
/* 42 */     if (copyArr.viewDistance() != arr.viewDistance()) {
/* 43 */       throw new IllegalStateException(copyArr.viewDistance() + " " + arr.viewDistance());
/*    */     }
/* 45 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public IChunkArray extractReferenceArray() {
/* 50 */     for (Field f : class_631.class.getDeclaredFields()) {
/* 51 */       if (IChunkArray.class.isAssignableFrom(f.getType())) {
/*    */         try {
/* 53 */           return (IChunkArray)f.get(this);
/* 54 */         } catch (IllegalAccessException e) {
/* 55 */           throw new RuntimeException(e);
/*    */         } 
/*    */       }
/*    */     } 
/* 59 */     throw new RuntimeException(Arrays.toString(class_631.class.getDeclaredFields()));
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\launch\mixins\MixinClientChunkProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */