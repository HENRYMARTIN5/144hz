/*    */ package baritone.launch.mixins;
/*    */ 
/*    */ import baritone.api.utils.BlockOptionalMeta;
/*    */ import net.minecraft.class_3218;
/*    */ import net.minecraft.class_4567;
/*    */ import net.minecraft.class_47;
/*    */ import net.minecraft.class_60;
/*    */ import net.minecraft.server.MinecraftServer;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Redirect;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_47.class_48.class})
/*    */ public class MixinLootContext
/*    */ {
/*    */   @Redirect(method = {"build"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/server/world/ServerWorld;getServer()Lnet/minecraft/server/MinecraftServer;"))
/*    */   private MinecraftServer getServer(class_3218 world) {
/* 41 */     if (world == null) {
/* 42 */       return null;
/*    */     }
/* 44 */     return world.method_8503();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Redirect(method = {"build"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/server/MinecraftServer;getLootManager()Lnet/minecraft/loot/LootManager;"))
/*    */   private class_60 getLootTableManager(MinecraftServer server) {
/* 55 */     if (server == null) {
/* 56 */       return BlockOptionalMeta.getManager();
/*    */     }
/* 58 */     return server.method_3857();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Redirect(method = {"build"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/server/MinecraftServer;getPredicateManager()Lnet/minecraft/loot/condition/LootConditionManager;"))
/*    */   private class_4567 getLootPredicateManager(MinecraftServer server) {
/* 69 */     if (server == null) {
/* 70 */       return BlockOptionalMeta.getPredicateManager();
/*    */     }
/* 72 */     return server.method_22828();
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\launch\mixins\MixinLootContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */