/*     */ package baritone.launch.mixins;
/*     */ 
/*     */ import baritone.Baritone;
/*     */ import baritone.api.BaritoneAPI;
/*     */ import baritone.api.IBaritone;
/*     */ import baritone.api.event.events.ChunkEvent;
/*     */ import baritone.api.event.events.type.EventState;
/*     */ import baritone.cache.CachedChunk;
/*     */ import net.minecraft.class_1923;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2626;
/*     */ import net.minecraft.class_2637;
/*     */ import net.minecraft.class_2672;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_2698;
/*     */ import net.minecraft.class_634;
/*     */ import net.minecraft.class_746;
/*     */ import org.spongepowered.asm.mixin.Mixin;
/*     */ import org.spongepowered.asm.mixin.injection.At;
/*     */ import org.spongepowered.asm.mixin.injection.Inject;
/*     */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Mixin({class_634.class})
/*     */ public class MixinClientPlayNetHandler
/*     */ {
/*     */   @Inject(method = {"onChunkData"}, at = {@At("RETURN")})
/*     */   private void postHandleChunkData(class_2672 packetIn, CallbackInfo ci) {
/*  74 */     for (IBaritone ibaritone : BaritoneAPI.getProvider().getAllBaritones()) {
/*  75 */       class_746 player = ibaritone.getPlayerContext().player();
/*  76 */       if (player != null && player.field_3944 == (class_634)this) {
/*  77 */         ibaritone.getGameEventHandler().onChunkEvent(new ChunkEvent(EventState.POST, 
/*     */ 
/*     */               
/*  80 */               packetIn.method_11530() ? ChunkEvent.Type.POPULATE_FULL : ChunkEvent.Type.POPULATE_PARTIAL, packetIn
/*  81 */               .method_11523(), packetIn
/*  82 */               .method_11524()));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject(method = {"onBlockUpdate"}, at = {@At("RETURN")})
/*     */   private void postHandleBlockChange(class_2626 packetIn, CallbackInfo ci) {
/*  94 */     if (!((Boolean)(Baritone.settings()).repackOnAnyBlockChange.value).booleanValue()) {
/*     */       return;
/*     */     }
/*  97 */     if (!CachedChunk.BLOCKS_TO_KEEP_TRACK_OF.contains(packetIn.method_11308().method_26204())) {
/*     */       return;
/*     */     }
/* 100 */     for (IBaritone ibaritone : BaritoneAPI.getProvider().getAllBaritones()) {
/* 101 */       class_746 player = ibaritone.getPlayerContext().player();
/* 102 */       if (player != null && player.field_3944 == (class_634)this) {
/* 103 */         ibaritone.getGameEventHandler().onChunkEvent(new ChunkEvent(EventState.POST, ChunkEvent.Type.POPULATE_FULL, packetIn
/*     */ 
/*     */ 
/*     */               
/* 107 */               .method_11309().method_10263() >> 4, packetIn
/* 108 */               .method_11309().method_10260() >> 4));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject(method = {"onChunkDeltaUpdate"}, at = {@At("RETURN")})
/*     */   private void postHandleMultiBlockChange(class_2637 packetIn, CallbackInfo ci) {
/* 120 */     if (!((Boolean)(Baritone.settings()).repackOnAnyBlockChange.value).booleanValue()) {
/*     */       return;
/*     */     }
/* 123 */     class_1923[] chunkPos = new class_1923[1];
/* 124 */     packetIn.method_30621((pos, state) -> {
/*     */           if (CachedChunk.BLOCKS_TO_KEEP_TRACK_OF.contains(state.method_26204())) {
/*     */             chunkPos[0] = new class_1923(pos);
/*     */           }
/*     */         });
/* 129 */     if (chunkPos[0] == null) {
/*     */       return;
/*     */     }
/* 132 */     for (IBaritone ibaritone : BaritoneAPI.getProvider().getAllBaritones()) {
/* 133 */       class_746 player = ibaritone.getPlayerContext().player();
/* 134 */       if (player != null && player.field_3944 == (class_634)this) {
/* 135 */         ibaritone.getGameEventHandler().onChunkEvent(new ChunkEvent(EventState.POST, ChunkEvent.Type.POPULATE_FULL, (chunkPos[0]).field_9181, (chunkPos[0]).field_9180));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject(method = {"onCombatEvent"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/client/MinecraftClient;openScreen(Lnet/minecraft/client/gui/screen/Screen;)V")})
/*     */   private void onPlayerDeath(class_2698 packetIn, CallbackInfo ci) {
/* 155 */     for (IBaritone ibaritone : BaritoneAPI.getProvider().getAllBaritones()) {
/* 156 */       class_746 player = ibaritone.getPlayerContext().player();
/* 157 */       if (player != null && player.field_3944 == (class_634)this)
/* 158 */         ibaritone.getGameEventHandler().onPlayerDeath(); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\launch\mixins\MixinClientPlayNetHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */