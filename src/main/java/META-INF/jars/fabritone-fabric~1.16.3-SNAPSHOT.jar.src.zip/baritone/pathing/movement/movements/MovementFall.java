/*     */ package baritone.pathing.movement.movements;
/*     */ 
/*     */ import baritone.api.IBaritone;
/*     */ import baritone.api.pathing.movement.MovementStatus;
/*     */ import baritone.api.utils.BetterBlockPos;
/*     */ import baritone.api.utils.Rotation;
/*     */ import baritone.api.utils.RotationUtils;
/*     */ import baritone.api.utils.VecUtils;
/*     */ import baritone.api.utils.input.Input;
/*     */ import baritone.pathing.movement.CalculationContext;
/*     */ import baritone.pathing.movement.Movement;
/*     */ import baritone.pathing.movement.MovementHelper;
/*     */ import baritone.pathing.movement.MovementState;
/*     */ import baritone.utils.pathing.MutableMoveResult;
/*     */ import java.util.HashSet;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import net.minecraft.class_1661;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_1802;
/*     */ import net.minecraft.class_1935;
/*     */ import net.minecraft.class_1937;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2248;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_2382;
/*     */ import net.minecraft.class_2399;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_2769;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MovementFall
/*     */   extends Movement
/*     */ {
/*  53 */   private static final class_1799 STACK_BUCKET_WATER = new class_1799((class_1935)class_1802.field_8705);
/*  54 */   private static final class_1799 STACK_BUCKET_EMPTY = new class_1799((class_1935)class_1802.field_8550);
/*     */   
/*     */   public MovementFall(IBaritone baritone, BetterBlockPos src, BetterBlockPos dest) {
/*  57 */     super(baritone, src, dest, buildPositionsToBreak(src, dest));
/*     */   }
/*     */ 
/*     */   
/*     */   public double calculateCost(CalculationContext context) {
/*  62 */     MutableMoveResult result = new MutableMoveResult();
/*  63 */     MovementDescend.cost(context, this.src.x, this.src.y, this.src.z, this.dest.x, this.dest.z, result);
/*  64 */     if (result.y != this.dest.y) {
/*  65 */       return 1000000.0D;
/*     */     }
/*  67 */     return result.cost;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Set<BetterBlockPos> calculateValidPositions() {
/*  72 */     Set<BetterBlockPos> set = new HashSet<>();
/*  73 */     set.add(this.src);
/*  74 */     for (int y = this.src.y - this.dest.y; y >= 0; y--) {
/*  75 */       set.add(this.dest.up(y));
/*     */     }
/*  77 */     return set;
/*     */   }
/*     */   
/*     */   private boolean willPlaceBucket() {
/*  81 */     CalculationContext context = new CalculationContext(this.baritone);
/*  82 */     MutableMoveResult result = new MutableMoveResult();
/*  83 */     return MovementDescend.dynamicFallCost(context, this.src.x, this.src.y, this.src.z, this.dest.x, this.dest.z, 0.0D, context.get(this.dest.x, this.src.y - 2, this.dest.z), result);
/*     */   }
/*     */   
/*     */   public MovementState updateState(MovementState state) {
/*     */     class_2338 class_2338;
/*  88 */     super.updateState(state);
/*  89 */     if (state.getStatus() != MovementStatus.RUNNING) {
/*  90 */       return state;
/*     */     }
/*     */     
/*  93 */     BetterBlockPos betterBlockPos = this.ctx.playerFeet();
/*  94 */     Rotation toDest = RotationUtils.calcRotationFromVec3d(this.ctx.playerHead(), VecUtils.getBlockPosCenter((class_2338)this.dest), this.ctx.playerRotations());
/*  95 */     Rotation targetRotation = null;
/*  96 */     class_2680 destState = this.ctx.world().method_8320((class_2338)this.dest);
/*  97 */     class_2248 destBlock = destState.method_26204();
/*  98 */     boolean isWater = destState.method_26227().method_15772() instanceof net.minecraft.class_3621;
/*  99 */     if (!isWater && willPlaceBucket() && !betterBlockPos.equals(this.dest)) {
/* 100 */       if (!class_1661.method_7380((this.ctx.player()).field_7514.method_7395(STACK_BUCKET_WATER)) || this.ctx.world().method_27983() == class_1937.field_25180) {
/* 101 */         return state.setStatus(MovementStatus.UNREACHABLE);
/*     */       }
/*     */       
/* 104 */       if (this.ctx.player().method_23318() - this.dest.method_10264() < this.ctx.playerController().getBlockReachDistance() && !this.ctx.player().method_24828()) {
/* 105 */         (this.ctx.player()).field_7514.field_7545 = (this.ctx.player()).field_7514.method_7395(STACK_BUCKET_WATER);
/*     */         
/* 107 */         targetRotation = new Rotation(toDest.getYaw(), 90.0F);
/*     */         
/* 109 */         if (this.ctx.isLookingAt((class_2338)this.dest) || this.ctx.isLookingAt((class_2338)this.dest.down())) {
/* 110 */           state.setInput(Input.CLICK_RIGHT, true);
/*     */         }
/*     */       } 
/*     */     } 
/* 114 */     if (targetRotation != null) {
/* 115 */       state.setTarget(new MovementState.MovementTarget(targetRotation, true));
/*     */     } else {
/* 117 */       state.setTarget(new MovementState.MovementTarget(toDest, false));
/*     */     } 
/* 119 */     if (betterBlockPos.equals(this.dest) && (this.ctx.player().method_23318() - betterBlockPos.method_10264() < 0.094D || isWater)) {
/* 120 */       if (isWater) {
/* 121 */         if (class_1661.method_7380((this.ctx.player()).field_7514.method_7395(STACK_BUCKET_EMPTY))) {
/* 122 */           (this.ctx.player()).field_7514.field_7545 = (this.ctx.player()).field_7514.method_7395(STACK_BUCKET_EMPTY);
/* 123 */           if ((this.ctx.player().method_18798()).field_1351 >= 0.0D) {
/* 124 */             return state.setInput(Input.CLICK_RIGHT, true);
/*     */           }
/* 126 */           return state;
/*     */         } 
/*     */         
/* 129 */         if ((this.ctx.player().method_18798()).field_1351 >= 0.0D) {
/* 130 */           return state.setStatus(MovementStatus.SUCCESS);
/*     */         }
/*     */       } else {
/*     */         
/* 134 */         return state.setStatus(MovementStatus.SUCCESS);
/*     */       } 
/*     */     }
/* 137 */     class_243 destCenter = VecUtils.getBlockPosCenter((class_2338)this.dest);
/* 138 */     if (Math.abs(this.ctx.player().method_23317() + (this.ctx.player().method_18798()).field_1352 - destCenter.field_1352) > 0.1D || Math.abs(this.ctx.player().method_23321() + (this.ctx.player().method_18798()).field_1350 - destCenter.field_1350) > 0.1D) {
/* 139 */       if (!this.ctx.player().method_24828() && Math.abs((this.ctx.player().method_18798()).field_1351) > 0.4D) {
/* 140 */         state.setInput(Input.SNEAK, true);
/*     */       }
/* 142 */       state.setInput(Input.MOVE_FORWARD, true);
/*     */     } 
/* 144 */     class_2382 avoid = Optional.<class_2350>ofNullable(avoid()).map(class_2350::method_10163).orElse(null);
/* 145 */     if (avoid == null) {
/* 146 */       class_2338 = this.src.method_10059((class_2382)this.dest);
/*     */     } else {
/* 148 */       double dist = Math.abs(class_2338.method_10263() * (destCenter.field_1352 - class_2338.method_10263() / 2.0D - this.ctx.player().method_23317())) + Math.abs(class_2338.method_10260() * (destCenter.field_1350 - class_2338.method_10260() / 2.0D - this.ctx.player().method_23321()));
/* 149 */       if (dist < 0.6D) {
/* 150 */         state.setInput(Input.MOVE_FORWARD, true);
/* 151 */       } else if (!this.ctx.player().method_24828()) {
/* 152 */         state.setInput(Input.SNEAK, false);
/*     */       } 
/*     */     } 
/* 155 */     if (targetRotation == null) {
/* 156 */       class_243 destCenterOffset = new class_243(destCenter.field_1352 + 0.125D * class_2338.method_10263(), destCenter.field_1351, destCenter.field_1350 + 0.125D * class_2338.method_10260());
/* 157 */       state.setTarget(new MovementState.MovementTarget(RotationUtils.calcRotationFromVec3d(this.ctx.playerHead(), destCenterOffset, this.ctx.playerRotations()), false));
/*     */     } 
/* 159 */     return state;
/*     */   }
/*     */   
/*     */   private class_2350 avoid() {
/* 163 */     for (int i = 0; i < 15; i++) {
/* 164 */       class_2680 state = this.ctx.world().method_8320((class_2338)this.ctx.playerFeet().down(i));
/* 165 */       if (state.method_26204() == class_2246.field_9983) {
/* 166 */         return (class_2350)state.method_11654((class_2769)class_2399.field_11253);
/*     */       }
/*     */     } 
/* 169 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean safeToCancel(MovementState state) {
/* 176 */     return (this.ctx.playerFeet().equals(this.src) || state.getStatus() != MovementStatus.RUNNING);
/*     */   }
/*     */ 
/*     */   
/*     */   private static BetterBlockPos[] buildPositionsToBreak(BetterBlockPos src, BetterBlockPos dest) {
/* 181 */     int diffX = src.method_10263() - dest.method_10263();
/* 182 */     int diffZ = src.method_10260() - dest.method_10260();
/* 183 */     int diffY = src.method_10264() - dest.method_10264();
/* 184 */     BetterBlockPos[] toBreak = new BetterBlockPos[diffY + 2];
/* 185 */     for (int i = 0; i < toBreak.length; i++) {
/* 186 */       toBreak[i] = new BetterBlockPos(src.method_10263() - diffX, src.method_10264() + 1 - i, src.method_10260() - diffZ);
/*     */     }
/* 188 */     return toBreak;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean prepared(MovementState state) {
/* 193 */     if (state.getStatus() == MovementStatus.WAITING) {
/* 194 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 198 */     for (int i = 0; i < 4 && i < this.positionsToBreak.length; i++) {
/* 199 */       if (!MovementHelper.canWalkThrough(this.ctx, this.positionsToBreak[i])) {
/* 200 */         return super.prepared(state);
/*     */       }
/*     */     } 
/* 203 */     return true;
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\pathing\movement\movements\MovementFall.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */