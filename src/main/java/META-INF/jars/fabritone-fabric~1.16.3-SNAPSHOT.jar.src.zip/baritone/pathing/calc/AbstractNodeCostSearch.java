/*     */ package baritone.pathing.calc;
/*     */ 
/*     */ import baritone.Baritone;
/*     */ import baritone.api.pathing.calc.IPath;
/*     */ import baritone.api.pathing.calc.IPathFinder;
/*     */ import baritone.api.pathing.goals.Goal;
/*     */ import baritone.api.utils.BetterBlockPos;
/*     */ import baritone.api.utils.Helper;
/*     */ import baritone.api.utils.PathCalculationResult;
/*     */ import baritone.pathing.movement.CalculationContext;
/*     */ import baritone.utils.NotificationHelper;
/*     */ import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
/*     */ import java.util.Optional;
/*     */ import net.minecraft.class_2338;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractNodeCostSearch
/*     */   implements IPathFinder, Helper
/*     */ {
/*     */   protected final int startX;
/*     */   protected final int startY;
/*     */   protected final int startZ;
/*     */   protected final Goal goal;
/*     */   private final CalculationContext context;
/*     */   private final Long2ObjectOpenHashMap<PathNode> map;
/*     */   protected PathNode startNode;
/*     */   protected PathNode mostRecentConsidered;
/*  57 */   protected final PathNode[] bestSoFar = new PathNode[COEFFICIENTS.length];
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile boolean isFinished;
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean cancelRequested;
/*     */ 
/*     */ 
/*     */   
/*  69 */   protected static final double[] COEFFICIENTS = new double[] { 1.5D, 2.0D, 2.5D, 3.0D, 4.0D, 5.0D, 10.0D };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final double MIN_DIST_PATH = 5.0D;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final double MIN_IMPROVEMENT = 0.01D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AbstractNodeCostSearch(int startX, int startY, int startZ, Goal goal, CalculationContext context) {
/*  86 */     this.startX = startX;
/*  87 */     this.startY = startY;
/*  88 */     this.startZ = startZ;
/*  89 */     this.goal = goal;
/*  90 */     this.context = context;
/*  91 */     this.map = new Long2ObjectOpenHashMap(((Integer)(Baritone.settings()).pathingMapDefaultSize.value).intValue(), ((Float)(Baritone.settings()).pathingMapLoadFactor.value).floatValue());
/*     */   }
/*     */   
/*     */   public void cancel() {
/*  95 */     this.cancelRequested = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized PathCalculationResult calculate(long primaryTimeout, long failureTimeout) {
/* 100 */     if (this.isFinished) {
/* 101 */       throw new IllegalStateException("Path finder cannot be reused!");
/*     */     }
/* 103 */     this.cancelRequested = false;
/*     */     try {
/* 105 */       IPath path = calculate0(primaryTimeout, failureTimeout).<IPath>map(IPath::postProcess).orElse(null);
/* 106 */       if (this.cancelRequested) {
/* 107 */         return new PathCalculationResult(PathCalculationResult.Type.CANCELLATION);
/*     */       }
/* 109 */       if (path == null) {
/* 110 */         return new PathCalculationResult(PathCalculationResult.Type.FAILURE);
/*     */       }
/* 112 */       int previousLength = path.length();
/* 113 */       path = path.cutoffAtLoadedChunks(this.context.bsi);
/* 114 */       if (path.length() < previousLength) {
/* 115 */         Helper.HELPER.logDebug("Cutting off path at edge of loaded chunks");
/* 116 */         Helper.HELPER.logDebug("Length decreased by " + (previousLength - path.length()));
/*     */       } else {
/* 118 */         Helper.HELPER.logDebug("Path ends within loaded chunks");
/*     */       } 
/* 120 */       previousLength = path.length();
/* 121 */       path = path.staticCutoff(this.goal);
/* 122 */       if (path.length() < previousLength) {
/* 123 */         Helper.HELPER.logDebug("Static cutoff " + previousLength + " to " + path.length());
/*     */       }
/* 125 */       if (this.goal.isInGoal((class_2338)path.getDest())) {
/* 126 */         return new PathCalculationResult(PathCalculationResult.Type.SUCCESS_TO_GOAL, path);
/*     */       }
/* 128 */       return new PathCalculationResult(PathCalculationResult.Type.SUCCESS_SEGMENT, path);
/*     */     }
/* 130 */     catch (Exception e) {
/* 131 */       Helper.HELPER.logDirect("Pathing exception: " + e);
/* 132 */       e.printStackTrace();
/* 133 */       return new PathCalculationResult(PathCalculationResult.Type.EXCEPTION);
/*     */     } finally {
/*     */       
/* 136 */       this.isFinished = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected double getDistFromStartSq(PathNode n) {
/* 151 */     int xDiff = n.x - this.startX;
/* 152 */     int yDiff = n.y - this.startY;
/* 153 */     int zDiff = n.z - this.startZ;
/* 154 */     return (xDiff * xDiff + yDiff * yDiff + zDiff * zDiff);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected PathNode getNodeAtPosition(int x, int y, int z, long hashCode) {
/* 171 */     PathNode node = (PathNode)this.map.get(hashCode);
/* 172 */     if (node == null) {
/* 173 */       node = new PathNode(x, y, z, this.goal);
/* 174 */       this.map.put(hashCode, node);
/*     */     } 
/* 176 */     return node;
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<IPath> pathToMostRecentNodeConsidered() {
/* 181 */     return Optional.<PathNode>ofNullable(this.mostRecentConsidered).map(node -> new Path(this.startNode, node, 0, this.goal, this.context));
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<IPath> bestPathSoFar() {
/* 186 */     return bestSoFar(false, 0);
/*     */   }
/*     */   
/*     */   protected Optional<IPath> bestSoFar(boolean logInfo, int numNodes) {
/* 190 */     if (this.startNode == null) {
/* 191 */       return Optional.empty();
/*     */     }
/* 193 */     double bestDist = 0.0D;
/* 194 */     for (int i = 0; i < COEFFICIENTS.length; i++) {
/* 195 */       if (this.bestSoFar[i] != null) {
/*     */ 
/*     */         
/* 198 */         double dist = getDistFromStartSq(this.bestSoFar[i]);
/* 199 */         if (dist > bestDist) {
/* 200 */           bestDist = dist;
/*     */         }
/* 202 */         if (dist > 25.0D) {
/* 203 */           if (logInfo) {
/* 204 */             if (COEFFICIENTS[i] >= 3.0D) {
/* 205 */               System.out.println("Warning: cost coefficient is greater than three! Probably means that");
/* 206 */               System.out.println("the path I found is pretty terrible (like sneak-bridging for dozens of blocks)");
/* 207 */               System.out.println("But I'm going to do it anyway, because yolo");
/*     */             } 
/* 209 */             System.out.println("Path goes for " + Math.sqrt(dist) + " blocks");
/* 210 */             logDebug("A* cost coefficient " + COEFFICIENTS[i]);
/*     */           } 
/* 212 */           return (Optional)Optional.of(new Path(this.startNode, this.bestSoFar[i], numNodes, this.goal, this.context));
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 217 */     if (logInfo) {
/* 218 */       logDebug("Even with a cost coefficient of " + COEFFICIENTS[COEFFICIENTS.length - 1] + ", I couldn't get more than " + Math.sqrt(bestDist) + " blocks");
/* 219 */       logDebug("No path found =(");
/* 220 */       if (((Boolean)(Baritone.settings()).desktopNotifications.value).booleanValue()) {
/* 221 */         NotificationHelper.notify("No path found =(", true);
/*     */       }
/*     */     } 
/* 224 */     return Optional.empty();
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isFinished() {
/* 229 */     return this.isFinished;
/*     */   }
/*     */ 
/*     */   
/*     */   public final Goal getGoal() {
/* 234 */     return this.goal;
/*     */   }
/*     */   
/*     */   public BetterBlockPos getStart() {
/* 238 */     return new BetterBlockPos(this.startX, this.startY, this.startZ);
/*     */   }
/*     */   
/*     */   protected int mapSize() {
/* 242 */     return this.map.size();
/*     */   }
/*     */   
/*     */   protected abstract Optional<IPath> calculate0(long paramLong1, long paramLong2);
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\pathing\calc\AbstractNodeCostSearch.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */