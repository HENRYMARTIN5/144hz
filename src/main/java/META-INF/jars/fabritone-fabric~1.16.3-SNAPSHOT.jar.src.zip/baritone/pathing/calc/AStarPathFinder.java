/*     */ package baritone.pathing.calc;
/*     */ 
/*     */ import baritone.Baritone;
/*     */ import baritone.api.pathing.calc.IPath;
/*     */ import baritone.api.pathing.goals.Goal;
/*     */ import baritone.api.utils.BetterBlockPos;
/*     */ import baritone.pathing.calc.openset.BinaryHeapOpenSet;
/*     */ import baritone.pathing.movement.CalculationContext;
/*     */ import baritone.pathing.movement.Moves;
/*     */ import baritone.utils.pathing.BetterWorldBorder;
/*     */ import baritone.utils.pathing.Favoring;
/*     */ import baritone.utils.pathing.MutableMoveResult;
/*     */ import java.util.Optional;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AStarPathFinder
/*     */   extends AbstractNodeCostSearch
/*     */ {
/*     */   private final Favoring favoring;
/*     */   private final CalculationContext calcContext;
/*     */   
/*     */   public AStarPathFinder(int startX, int startY, int startZ, Goal goal, Favoring favoring, CalculationContext context) {
/*  45 */     super(startX, startY, startZ, goal, context);
/*  46 */     this.favoring = favoring;
/*  47 */     this.calcContext = context;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Optional<IPath> calculate0(long primaryTimeout, long failureTimeout) {
/*  52 */     this.startNode = getNodeAtPosition(this.startX, this.startY, this.startZ, BetterBlockPos.longHash(this.startX, this.startY, this.startZ));
/*  53 */     this.startNode.cost = 0.0D;
/*  54 */     this.startNode.combinedCost = this.startNode.estimatedCostToGoal;
/*  55 */     BinaryHeapOpenSet openSet = new BinaryHeapOpenSet();
/*  56 */     openSet.insert(this.startNode);
/*  57 */     double[] bestHeuristicSoFar = new double[COEFFICIENTS.length];
/*  58 */     for (int i = 0; i < bestHeuristicSoFar.length; i++) {
/*  59 */       bestHeuristicSoFar[i] = this.startNode.estimatedCostToGoal;
/*  60 */       this.bestSoFar[i] = this.startNode;
/*     */     } 
/*  62 */     MutableMoveResult res = new MutableMoveResult();
/*  63 */     BetterWorldBorder worldBorder = new BetterWorldBorder(this.calcContext.world.method_8621());
/*  64 */     long startTime = System.currentTimeMillis();
/*  65 */     boolean slowPath = ((Boolean)(Baritone.settings()).slowPath.value).booleanValue();
/*  66 */     if (slowPath) {
/*  67 */       logDebug("slowPath is on, path timeout will be " + (Baritone.settings()).slowPathTimeoutMS.value + "ms instead of " + primaryTimeout + "ms");
/*     */     }
/*  69 */     long primaryTimeoutTime = startTime + (slowPath ? ((Long)(Baritone.settings()).slowPathTimeoutMS.value).longValue() : primaryTimeout);
/*  70 */     long failureTimeoutTime = startTime + (slowPath ? ((Long)(Baritone.settings()).slowPathTimeoutMS.value).longValue() : failureTimeout);
/*  71 */     boolean failing = true;
/*  72 */     int numNodes = 0;
/*  73 */     int numMovementsConsidered = 0;
/*  74 */     int numEmptyChunk = 0;
/*  75 */     boolean isFavoring = !this.favoring.isEmpty();
/*  76 */     int timeCheckInterval = 64;
/*  77 */     int pathingMaxChunkBorderFetch = ((Integer)(Baritone.settings()).pathingMaxChunkBorderFetch.value).intValue();
/*  78 */     double minimumImprovement = ((Boolean)(Baritone.settings()).minimumImprovementRepropagation.value).booleanValue() ? 0.01D : 0.0D;
/*  79 */     Moves[] allMoves = Moves.values();
/*  80 */     while (!openSet.isEmpty() && numEmptyChunk < pathingMaxChunkBorderFetch && !this.cancelRequested) {
/*  81 */       if ((numNodes & timeCheckInterval - 1) == 0) {
/*  82 */         long now = System.currentTimeMillis();
/*  83 */         if (now - failureTimeoutTime >= 0L || (!failing && now - primaryTimeoutTime >= 0L)) {
/*     */           break;
/*     */         }
/*     */       } 
/*  87 */       if (slowPath) {
/*     */         try {
/*  89 */           Thread.sleep(((Long)(Baritone.settings()).slowPathTimeDelayMS.value).longValue());
/*  90 */         } catch (InterruptedException interruptedException) {}
/*     */       }
/*  92 */       PathNode currentNode = openSet.removeLowest();
/*  93 */       this.mostRecentConsidered = currentNode;
/*  94 */       numNodes++;
/*  95 */       if (this.goal.isInGoal(currentNode.x, currentNode.y, currentNode.z)) {
/*  96 */         logDebug("Took " + (System.currentTimeMillis() - startTime) + "ms, " + numMovementsConsidered + " movements considered");
/*  97 */         return (Optional)Optional.of(new Path(this.startNode, currentNode, numNodes, this.goal, this.calcContext));
/*     */       } 
/*  99 */       for (Moves moves : allMoves) {
/* 100 */         int newX = currentNode.x + moves.xOffset;
/* 101 */         int newZ = currentNode.z + moves.zOffset;
/* 102 */         if ((newX >> 4 != currentNode.x >> 4 || newZ >> 4 != currentNode.z >> 4) && !this.calcContext.isLoaded(newX, newZ)) {
/*     */           
/* 104 */           if (!moves.dynamicXZ) {
/* 105 */             numEmptyChunk++;
/*     */           
/*     */           }
/*     */         }
/* 109 */         else if (moves.dynamicXZ || worldBorder.entirelyContains(newX, newZ)) {
/*     */ 
/*     */           
/* 112 */           if (currentNode.y + moves.yOffset <= 256 && currentNode.y + moves.yOffset >= 0) {
/*     */ 
/*     */             
/* 115 */             res.reset();
/* 116 */             moves.apply(this.calcContext, currentNode.x, currentNode.y, currentNode.z, res);
/* 117 */             numMovementsConsidered++;
/* 118 */             double actionCost = res.cost;
/* 119 */             if (actionCost < 1000000.0D) {
/*     */ 
/*     */               
/* 122 */               if (actionCost <= 0.0D || Double.isNaN(actionCost)) {
/* 123 */                 throw new IllegalStateException(moves + " calculated implausible cost " + actionCost);
/*     */               }
/*     */               
/* 126 */               if (!moves.dynamicXZ || worldBorder.entirelyContains(res.x, res.z)) {
/*     */ 
/*     */                 
/* 129 */                 if (!moves.dynamicXZ && (res.x != newX || res.z != newZ)) {
/* 130 */                   throw new IllegalStateException(moves + " " + res.x + " " + newX + " " + res.z + " " + newZ);
/*     */                 }
/* 132 */                 if (!moves.dynamicY && res.y != currentNode.y + moves.yOffset) {
/* 133 */                   throw new IllegalStateException(moves + " " + res.y + " " + (currentNode.y + moves.yOffset));
/*     */                 }
/* 135 */                 long hashCode = BetterBlockPos.longHash(res.x, res.y, res.z);
/* 136 */                 if (isFavoring)
/*     */                 {
/* 138 */                   actionCost *= this.favoring.calculate(hashCode);
/*     */                 }
/* 140 */                 PathNode neighbor = getNodeAtPosition(res.x, res.y, res.z, hashCode);
/* 141 */                 double tentativeCost = currentNode.cost + actionCost;
/* 142 */                 if (neighbor.cost - tentativeCost > minimumImprovement) {
/* 143 */                   neighbor.previous = currentNode;
/* 144 */                   neighbor.cost = tentativeCost;
/* 145 */                   neighbor.combinedCost = tentativeCost + neighbor.estimatedCostToGoal;
/* 146 */                   if (neighbor.isOpen()) {
/* 147 */                     openSet.update(neighbor);
/*     */                   } else {
/* 149 */                     openSet.insert(neighbor);
/*     */                   } 
/* 151 */                   for (int j = 0; j < COEFFICIENTS.length; j++)
/* 152 */                   { double heuristic = neighbor.estimatedCostToGoal + neighbor.cost / COEFFICIENTS[j];
/* 153 */                     if (bestHeuristicSoFar[j] - heuristic > minimumImprovement)
/* 154 */                     { bestHeuristicSoFar[j] = heuristic;
/* 155 */                       this.bestSoFar[j] = neighbor;
/* 156 */                       if (failing && getDistFromStartSq(neighbor) > 25.0D)
/* 157 */                         failing = false;  }  } 
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 164 */     }  if (this.cancelRequested) {
/* 165 */       return Optional.empty();
/*     */     }
/* 167 */     System.out.println(numMovementsConsidered + " movements considered");
/* 168 */     System.out.println("Open set size: " + openSet.size());
/* 169 */     System.out.println("PathNode map size: " + mapSize());
/* 170 */     System.out.println((int)(numNodes * 1.0D / ((float)(System.currentTimeMillis() - startTime) / 1000.0F)) + " nodes per second");
/* 171 */     Optional<IPath> result = bestSoFar(true, numNodes);
/* 172 */     if (result.isPresent()) {
/* 173 */       logDebug("Took " + (System.currentTimeMillis() - startTime) + "ms, " + numMovementsConsidered + " movements considered");
/*     */     }
/* 175 */     return result;
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\pathing\calc\AStarPathFinder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */