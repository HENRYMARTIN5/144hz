package baritone.pathing.calc.openset;

import baritone.pathing.calc.PathNode;

public interface IOpenSet {
  void insert(PathNode paramPathNode);
  
  boolean isEmpty();
  
  PathNode removeLowest();
  
  void update(PathNode paramPathNode);
}


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\pathing\calc\openset\IOpenSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */