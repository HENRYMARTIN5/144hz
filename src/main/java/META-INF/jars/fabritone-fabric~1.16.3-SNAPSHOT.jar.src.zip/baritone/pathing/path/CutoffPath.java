/*    */ package baritone.pathing.path;
/*    */ 
/*    */ import baritone.api.pathing.calc.IPath;
/*    */ import baritone.api.pathing.goals.Goal;
/*    */ import baritone.api.pathing.movement.IMovement;
/*    */ import baritone.api.utils.BetterBlockPos;
/*    */ import baritone.utils.pathing.PathBase;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CutoffPath
/*    */   extends PathBase
/*    */ {
/*    */   private final List<BetterBlockPos> path;
/*    */   private final List<IMovement> movements;
/*    */   private final int numNodes;
/*    */   private final Goal goal;
/*    */   
/*    */   public CutoffPath(IPath prev, int firstPositionToInclude, int lastPositionToInclude) {
/* 40 */     this.path = prev.positions().subList(firstPositionToInclude, lastPositionToInclude + 1);
/* 41 */     this.movements = prev.movements().subList(firstPositionToInclude, lastPositionToInclude);
/* 42 */     this.numNodes = prev.getNumNodesConsidered();
/* 43 */     this.goal = prev.getGoal();
/* 44 */     sanityCheck();
/*    */   }
/*    */   
/*    */   public CutoffPath(IPath prev, int lastPositionToInclude) {
/* 48 */     this(prev, 0, lastPositionToInclude);
/*    */   }
/*    */ 
/*    */   
/*    */   public Goal getGoal() {
/* 53 */     return this.goal;
/*    */   }
/*    */ 
/*    */   
/*    */   public List<IMovement> movements() {
/* 58 */     return Collections.unmodifiableList(this.movements);
/*    */   }
/*    */ 
/*    */   
/*    */   public List<BetterBlockPos> positions() {
/* 63 */     return Collections.unmodifiableList(this.path);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getNumNodesConsidered() {
/* 68 */     return this.numNodes;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\pathing\path\CutoffPath.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */