/*    */ package baritone.pathing.movement;
/*    */ 
/*    */ import baritone.api.pathing.movement.MovementStatus;
/*    */ import baritone.api.utils.Rotation;
/*    */ import baritone.api.utils.input.Input;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.Optional;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MovementState
/*    */ {
/*    */   private MovementStatus status;
/* 33 */   private MovementTarget target = new MovementTarget();
/* 34 */   private final Map<Input, Boolean> inputState = new HashMap<>();
/*    */   
/*    */   public MovementState setStatus(MovementStatus status) {
/* 37 */     this.status = status;
/* 38 */     return this;
/*    */   }
/*    */   
/*    */   public MovementStatus getStatus() {
/* 42 */     return this.status;
/*    */   }
/*    */   
/*    */   public MovementTarget getTarget() {
/* 46 */     return this.target;
/*    */   }
/*    */   
/*    */   public MovementState setTarget(MovementTarget target) {
/* 50 */     this.target = target;
/* 51 */     return this;
/*    */   }
/*    */   
/*    */   public MovementState setInput(Input input, boolean forced) {
/* 55 */     this.inputState.put(input, Boolean.valueOf(forced));
/* 56 */     return this;
/*    */   }
/*    */   
/*    */   public Map<Input, Boolean> getInputStates() {
/* 60 */     return this.inputState;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static class MovementTarget
/*    */   {
/*    */     public Rotation rotation;
/*    */ 
/*    */ 
/*    */     
/*    */     private boolean forceRotations;
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public MovementTarget() {
/* 78 */       this(null, false);
/*    */     }
/*    */     
/*    */     public MovementTarget(Rotation rotation, boolean forceRotations) {
/* 82 */       this.rotation = rotation;
/* 83 */       this.forceRotations = forceRotations;
/*    */     }
/*    */     
/*    */     public final Optional<Rotation> getRotation() {
/* 87 */       return Optional.ofNullable(this.rotation);
/*    */     }
/*    */     
/*    */     public boolean hasToForceRotations() {
/* 91 */       return this.forceRotations;
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\pathing\movement\MovementState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */