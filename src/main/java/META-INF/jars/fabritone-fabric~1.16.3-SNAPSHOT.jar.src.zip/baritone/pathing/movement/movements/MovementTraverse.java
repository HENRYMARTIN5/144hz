/*     */ package baritone.pathing.movement.movements;
/*     */ 
/*     */ import baritone.Baritone;
/*     */ import baritone.api.IBaritone;
/*     */ import baritone.api.pathing.movement.MovementStatus;
/*     */ import baritone.api.utils.BetterBlockPos;
/*     */ import baritone.api.utils.Rotation;
/*     */ import baritone.api.utils.RotationUtils;
/*     */ import baritone.api.utils.VecUtils;
/*     */ import baritone.api.utils.input.Input;
/*     */ import baritone.pathing.movement.CalculationContext;
/*     */ import baritone.pathing.movement.Movement;
/*     */ import baritone.pathing.movement.MovementHelper;
/*     */ import baritone.pathing.movement.MovementState;
/*     */ import baritone.utils.BlockStateInterface;
/*     */ import com.google.common.collect.ImmutableSet;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2248;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_2382;
/*     */ import net.minecraft.class_2399;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_2482;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_2769;
/*     */ import net.minecraft.class_2771;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MovementTraverse
/*     */   extends Movement
/*     */ {
/*     */   private boolean wasTheBridgeBlockAlwaysThere = true;
/*     */   
/*     */   public MovementTraverse(IBaritone baritone, BetterBlockPos from, BetterBlockPos to) {
/*  51 */     super(baritone, from, to, new BetterBlockPos[] { to.up(), to }, to.down());
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() {
/*  56 */     super.reset();
/*  57 */     this.wasTheBridgeBlockAlwaysThere = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public double calculateCost(CalculationContext context) {
/*  62 */     return cost(context, this.src.x, this.src.y, this.src.z, this.dest.x, this.dest.z);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Set<BetterBlockPos> calculateValidPositions() {
/*  67 */     return (Set<BetterBlockPos>)ImmutableSet.of(this.src, this.dest);
/*     */   }
/*     */   
/*     */   public static double cost(CalculationContext context, int x, int y, int z, int destX, int destZ) {
/*  71 */     class_2680 pb0 = context.get(destX, y + 1, destZ);
/*  72 */     class_2680 pb1 = context.get(destX, y, destZ);
/*  73 */     class_2680 destOn = context.get(destX, y - 1, destZ);
/*  74 */     class_2680 down = context.get(x, y - 1, z);
/*  75 */     class_2248 srcDown = down.method_26204();
/*  76 */     if (MovementHelper.canWalkOn(context.bsi, destX, y - 1, destZ, destOn)) {
/*  77 */       double WC = 4.63284688441047D;
/*  78 */       boolean water = false;
/*  79 */       if (MovementHelper.isWater(pb0) || MovementHelper.isWater(pb1)) {
/*  80 */         WC = context.waterWalkSpeed;
/*  81 */         water = true;
/*     */       } else {
/*  83 */         if (destOn.method_26204() == class_2246.field_10114) {
/*  84 */           WC += 2.316423442205235D;
/*  85 */         } else if (destOn.method_26204() == class_2246.field_10382) {
/*  86 */           WC += context.walkOnWaterOnePenalty;
/*     */         } 
/*  88 */         if (srcDown == class_2246.field_10114) {
/*  89 */           WC += 2.316423442205235D;
/*     */         }
/*     */       } 
/*  92 */       double hardness1 = MovementHelper.getMiningDurationTicks(context, destX, y, destZ, pb1, false);
/*  93 */       if (hardness1 >= 1000000.0D) {
/*  94 */         return 1000000.0D;
/*     */       }
/*  96 */       double hardness2 = MovementHelper.getMiningDurationTicks(context, destX, y + 1, destZ, pb0, true);
/*  97 */       if (hardness1 == 0.0D && hardness2 == 0.0D) {
/*  98 */         if (!water && context.canSprint)
/*     */         {
/*     */ 
/*     */           
/* 102 */           WC *= 0.7692444761225944D;
/*     */         }
/* 104 */         return WC;
/*     */       } 
/* 106 */       if (srcDown == class_2246.field_9983 || srcDown == class_2246.field_10597) {
/* 107 */         hardness1 *= 5.0D;
/* 108 */         hardness2 *= 5.0D;
/*     */       } 
/* 110 */       return WC + hardness1 + hardness2;
/*     */     } 
/* 112 */     if (srcDown == class_2246.field_9983 || srcDown == class_2246.field_10597) {
/* 113 */       return 1000000.0D;
/*     */     }
/* 115 */     if (MovementHelper.isReplaceable(destX, y - 1, destZ, destOn, context.bsi)) {
/* 116 */       boolean throughWater = (MovementHelper.isWater(pb0) || MovementHelper.isWater(pb1));
/* 117 */       if (MovementHelper.isWater(destOn) && throughWater)
/*     */       {
/* 119 */         return 1000000.0D;
/*     */       }
/* 121 */       double placeCost = context.costOfPlacingAt(destX, y - 1, destZ, destOn);
/* 122 */       if (placeCost >= 1000000.0D) {
/* 123 */         return 1000000.0D;
/*     */       }
/* 125 */       double hardness1 = MovementHelper.getMiningDurationTicks(context, destX, y, destZ, pb1, false);
/* 126 */       if (hardness1 >= 1000000.0D) {
/* 127 */         return 1000000.0D;
/*     */       }
/* 129 */       double hardness2 = MovementHelper.getMiningDurationTicks(context, destX, y + 1, destZ, pb0, true);
/* 130 */       double WC = throughWater ? context.waterWalkSpeed : 4.63284688441047D;
/* 131 */       for (int i = 0; i < 5; i++) {
/* 132 */         int againstX = destX + HORIZONTALS_BUT_ALSO_DOWN_____SO_EVERY_DIRECTION_EXCEPT_UP[i].method_10148();
/* 133 */         int againstY = y - 1 + HORIZONTALS_BUT_ALSO_DOWN_____SO_EVERY_DIRECTION_EXCEPT_UP[i].method_10164();
/* 134 */         int againstZ = destZ + HORIZONTALS_BUT_ALSO_DOWN_____SO_EVERY_DIRECTION_EXCEPT_UP[i].method_10165();
/* 135 */         if (againstX != x || againstZ != z)
/*     */         {
/*     */           
/* 138 */           if (MovementHelper.canPlaceAgainst(context.bsi, againstX, againstY, againstZ)) {
/* 139 */             return WC + placeCost + hardness1 + hardness2;
/*     */           }
/*     */         }
/*     */       } 
/* 143 */       if (srcDown == class_2246.field_10114 || (srcDown instanceof class_2482 && down.method_11654((class_2769)class_2482.field_11501) != class_2771.field_12682)) {
/* 144 */         return 1000000.0D;
/*     */       }
/* 146 */       if (down.method_26227().method_15772() instanceof net.minecraft.class_3621) {
/* 147 */         return 1000000.0D;
/*     */       }
/* 149 */       WC *= 3.3207692307692307D;
/* 150 */       return WC + placeCost + hardness1 + hardness2;
/*     */     } 
/* 152 */     return 1000000.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MovementState updateState(MovementState state) {
/* 158 */     super.updateState(state);
/* 159 */     class_2680 pb0 = BlockStateInterface.get(this.ctx, (class_2338)this.positionsToBreak[0]);
/* 160 */     class_2680 pb1 = BlockStateInterface.get(this.ctx, (class_2338)this.positionsToBreak[1]);
/* 161 */     if (state.getStatus() != MovementStatus.RUNNING) {
/*     */       
/* 163 */       if (!((Boolean)(Baritone.settings()).walkWhileBreaking.value).booleanValue()) {
/* 164 */         return state;
/*     */       }
/*     */       
/* 167 */       if (state.getStatus() != MovementStatus.PREPPING) {
/* 168 */         return state;
/*     */       }
/*     */       
/* 171 */       if (MovementHelper.avoidWalkingInto(pb0)) {
/* 172 */         return state;
/*     */       }
/* 174 */       if (MovementHelper.avoidWalkingInto(pb1)) {
/* 175 */         return state;
/*     */       }
/*     */       
/* 178 */       double dist = Math.max(Math.abs(this.ctx.player().method_23317() - this.dest.method_10263() + 0.5D), Math.abs(this.ctx.player().method_23321() - this.dest.method_10260() + 0.5D));
/* 179 */       if (dist < 0.83D) {
/* 180 */         return state;
/*     */       }
/* 182 */       if (!state.getTarget().getRotation().isPresent())
/*     */       {
/* 184 */         return state;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 189 */       float yawToDest = RotationUtils.calcRotationFromVec3d(this.ctx.playerHead(), VecUtils.calculateBlockCenter(this.ctx.world(), (class_2338)this.dest), this.ctx.playerRotations()).getYaw();
/* 190 */       float pitchToBreak = ((Rotation)state.getTarget().getRotation().get()).getPitch();
/* 191 */       if (MovementHelper.isBlockNormalCube(pb0) || (pb0.method_26204() instanceof net.minecraft.class_2189 && (MovementHelper.isBlockNormalCube(pb1) || pb1.method_26204() instanceof net.minecraft.class_2189)))
/*     */       {
/* 193 */         pitchToBreak = 26.0F;
/*     */       }
/*     */       
/* 196 */       return state.setTarget(new MovementState.MovementTarget(new Rotation(yawToDest, pitchToBreak), true))
/* 197 */         .setInput(Input.MOVE_FORWARD, true)
/* 198 */         .setInput(Input.SPRINT, true);
/*     */     } 
/*     */ 
/*     */     
/* 202 */     state.setInput(Input.SNEAK, false);
/*     */     
/* 204 */     class_2248 fd = BlockStateInterface.get(this.ctx, (class_2338)this.src.down()).method_26204();
/* 205 */     boolean ladder = (fd == class_2246.field_9983 || fd == class_2246.field_10597);
/*     */     
/* 207 */     if (pb0.method_26204() instanceof net.minecraft.class_2323 || pb1.method_26204() instanceof net.minecraft.class_2323) {
/* 208 */       boolean notPassable = ((pb0.method_26204() instanceof net.minecraft.class_2323 && !MovementHelper.isDoorPassable(this.ctx, (class_2338)this.src, (class_2338)this.dest)) || (pb1.method_26204() instanceof net.minecraft.class_2323 && !MovementHelper.isDoorPassable(this.ctx, (class_2338)this.dest, (class_2338)this.src)));
/* 209 */       boolean canOpen = (!class_2246.field_9973.equals(pb0.method_26204()) && !class_2246.field_9973.equals(pb1.method_26204()));
/*     */       
/* 211 */       if (notPassable && canOpen) {
/* 212 */         return state.setTarget(new MovementState.MovementTarget(RotationUtils.calcRotationFromVec3d(this.ctx.playerHead(), VecUtils.calculateBlockCenter(this.ctx.world(), (class_2338)this.positionsToBreak[0]), this.ctx.playerRotations()), true))
/* 213 */           .setInput(Input.CLICK_RIGHT, true);
/*     */       }
/*     */     } 
/*     */     
/* 217 */     if (pb0.method_26204() instanceof net.minecraft.class_2349 || pb1.method_26204() instanceof net.minecraft.class_2349) {
/*     */       
/* 219 */       BetterBlockPos betterBlockPos1 = !MovementHelper.isGatePassable(this.ctx, (class_2338)this.positionsToBreak[0], (class_2338)this.src.up()) ? this.positionsToBreak[0] : (!MovementHelper.isGatePassable(this.ctx, (class_2338)this.positionsToBreak[1], (class_2338)this.src) ? this.positionsToBreak[1] : null);
/*     */       
/* 221 */       if (betterBlockPos1 != null) {
/* 222 */         Optional<Rotation> rotation = RotationUtils.reachable(this.ctx, (class_2338)betterBlockPos1);
/* 223 */         if (rotation.isPresent()) {
/* 224 */           return state.setTarget(new MovementState.MovementTarget(rotation.get(), true)).setInput(Input.CLICK_RIGHT, true);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 229 */     boolean isTheBridgeBlockThere = (MovementHelper.canWalkOn(this.ctx, this.positionToPlace) || ladder);
/* 230 */     BetterBlockPos betterBlockPos = this.ctx.playerFeet();
/* 231 */     if (betterBlockPos.method_10264() != this.dest.method_10264() && !ladder) {
/* 232 */       logDebug("Wrong Y coordinate");
/* 233 */       if (betterBlockPos.method_10264() < this.dest.method_10264()) {
/* 234 */         return state.setInput(Input.JUMP, true);
/*     */       }
/* 236 */       return state;
/*     */     } 
/*     */     
/* 239 */     if (isTheBridgeBlockThere) {
/* 240 */       if (betterBlockPos.equals(this.dest)) {
/* 241 */         return state.setStatus(MovementStatus.SUCCESS);
/*     */       }
/* 243 */       if (((Boolean)(Baritone.settings()).overshootTraverse.value).booleanValue() && (betterBlockPos.equals(this.dest.method_10081((class_2382)getDirection())) || betterBlockPos.equals(this.dest.method_10081((class_2382)getDirection()).method_10081((class_2382)getDirection())))) {
/* 244 */         return state.setStatus(MovementStatus.SUCCESS);
/*     */       }
/* 246 */       class_2248 low = BlockStateInterface.get(this.ctx, (class_2338)this.src).method_26204();
/* 247 */       class_2248 high = BlockStateInterface.get(this.ctx, (class_2338)this.src.up()).method_26204();
/* 248 */       if (this.ctx.player().method_23318() > this.src.y + 0.1D && !this.ctx.player().method_24828() && (low == class_2246.field_10597 || low == class_2246.field_9983 || high == class_2246.field_10597 || high == class_2246.field_9983))
/*     */       {
/*     */         
/* 251 */         return state;
/*     */       }
/* 253 */       class_2338 into = this.dest.method_10059((class_2382)this.src).method_10081((class_2382)this.dest);
/* 254 */       class_2680 intoBelow = BlockStateInterface.get(this.ctx, into);
/* 255 */       class_2680 intoAbove = BlockStateInterface.get(this.ctx, into.method_10084());
/* 256 */       if (this.wasTheBridgeBlockAlwaysThere && (!MovementHelper.isLiquid(this.ctx, (class_2338)betterBlockPos) || ((Boolean)(Baritone.settings()).sprintInWater.value).booleanValue()) && (!MovementHelper.avoidWalkingInto(intoBelow) || MovementHelper.isWater(intoBelow)) && !MovementHelper.avoidWalkingInto(intoAbove)) {
/* 257 */         state.setInput(Input.SPRINT, true);
/*     */       }
/*     */       
/* 260 */       class_2680 destDown = BlockStateInterface.get(this.ctx, (class_2338)this.dest.down());
/* 261 */       BetterBlockPos betterBlockPos1 = this.positionsToBreak[0];
/* 262 */       if (betterBlockPos.method_10264() != this.dest.method_10264() && ladder && (destDown.method_26204() == class_2246.field_10597 || destDown.method_26204() == class_2246.field_9983)) {
/* 263 */         betterBlockPos1 = (destDown.method_26204() == class_2246.field_10597) ? (BetterBlockPos)MovementPillar.getAgainst(new CalculationContext(this.baritone), this.dest.down()) : this.dest.offset(((class_2350)destDown.method_11654((class_2769)class_2399.field_11253)).method_10153());
/* 264 */         if (betterBlockPos1 == null) {
/* 265 */           logDirect("Unable to climb vines. Consider disabling allowVines.");
/* 266 */           return state.setStatus(MovementStatus.UNREACHABLE);
/*     */         } 
/*     */       } 
/* 269 */       MovementHelper.moveTowards(this.ctx, state, (class_2338)betterBlockPos1);
/* 270 */       return state;
/*     */     } 
/* 272 */     this.wasTheBridgeBlockAlwaysThere = false;
/* 273 */     class_2248 standingOn = BlockStateInterface.get(this.ctx, betterBlockPos.method_10074()).method_26204();
/* 274 */     if (standingOn.equals(class_2246.field_10114) || standingOn instanceof class_2482) {
/* 275 */       double dist = Math.max(Math.abs(this.dest.method_10263() + 0.5D - this.ctx.player().method_23317()), Math.abs(this.dest.method_10260() + 0.5D - this.ctx.player().method_23321()));
/* 276 */       if (dist < 0.85D) {
/* 277 */         MovementHelper.moveTowards(this.ctx, state, (class_2338)this.dest);
/* 278 */         return state.setInput(Input.MOVE_FORWARD, false)
/* 279 */           .setInput(Input.MOVE_BACK, true);
/*     */       } 
/*     */     } 
/* 282 */     double dist1 = Math.max(Math.abs(this.ctx.player().method_23317() - this.dest.method_10263() + 0.5D), Math.abs(this.ctx.player().method_23321() - this.dest.method_10260() + 0.5D));
/* 283 */     MovementHelper.PlaceResult p = MovementHelper.attemptToPlaceABlock(state, this.baritone, (class_2338)this.dest.down(), false, true);
/* 284 */     if ((p == MovementHelper.PlaceResult.READY_TO_PLACE || dist1 < 0.6D) && !((Boolean)(Baritone.settings()).assumeSafeWalk.value).booleanValue()) {
/* 285 */       state.setInput(Input.SNEAK, true);
/*     */     }
/* 287 */     switch (p) {
/*     */       case READY_TO_PLACE:
/* 289 */         if (this.ctx.player().method_5715() || ((Boolean)(Baritone.settings()).assumeSafeWalk.value).booleanValue()) {
/* 290 */           state.setInput(Input.CLICK_RIGHT, true);
/*     */         }
/* 292 */         return state;
/*     */       
/*     */       case ATTEMPTING:
/* 295 */         if (dist1 > 0.83D) {
/*     */           
/* 297 */           float yaw = RotationUtils.calcRotationFromVec3d(this.ctx.playerHead(), VecUtils.getBlockPosCenter((class_2338)this.dest), this.ctx.playerRotations()).getYaw();
/* 298 */           if (Math.abs((state.getTarget()).rotation.getYaw() - yaw) < 0.1D)
/*     */           {
/* 300 */             return state.setInput(Input.MOVE_FORWARD, true);
/*     */           }
/* 302 */         } else if (this.ctx.playerRotations().isReallyCloseTo((state.getTarget()).rotation)) {
/*     */           
/* 304 */           return state.setInput(Input.CLICK_LEFT, true);
/*     */         } 
/* 306 */         return state;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 311 */     if (betterBlockPos.equals(this.dest)) {
/*     */ 
/*     */       
/* 314 */       double faceX = ((this.dest.method_10263() + this.src.method_10263()) + 1.0D) * 0.5D;
/* 315 */       double faceY = ((this.dest.method_10264() + this.src.method_10264()) - 1.0D) * 0.5D;
/* 316 */       double faceZ = ((this.dest.method_10260() + this.src.method_10260()) + 1.0D) * 0.5D;
/*     */       
/* 318 */       BetterBlockPos betterBlockPos1 = this.src.down();
/*     */       
/* 320 */       Rotation backToFace = RotationUtils.calcRotationFromVec3d(this.ctx.playerHead(), new class_243(faceX, faceY, faceZ), this.ctx.playerRotations());
/* 321 */       float pitch = backToFace.getPitch();
/* 322 */       double dist2 = Math.max(Math.abs(this.ctx.player().method_23317() - faceX), Math.abs(this.ctx.player().method_23321() - faceZ));
/* 323 */       if (dist2 < 0.29D) {
/* 324 */         float yaw = RotationUtils.calcRotationFromVec3d(VecUtils.getBlockPosCenter((class_2338)this.dest), this.ctx.playerHead(), this.ctx.playerRotations()).getYaw();
/* 325 */         state.setTarget(new MovementState.MovementTarget(new Rotation(yaw, pitch), true));
/* 326 */         state.setInput(Input.MOVE_BACK, true);
/*     */       } else {
/* 328 */         state.setTarget(new MovementState.MovementTarget(backToFace, true));
/*     */       } 
/* 330 */       if (this.ctx.isLookingAt((class_2338)betterBlockPos1)) {
/* 331 */         return state.setInput(Input.CLICK_RIGHT, true);
/*     */       }
/*     */       
/* 334 */       if (this.ctx.playerRotations().isReallyCloseTo((state.getTarget()).rotation)) {
/* 335 */         state.setInput(Input.CLICK_LEFT, true);
/*     */       }
/* 337 */       return state;
/*     */     } 
/* 339 */     MovementHelper.moveTowards(this.ctx, state, (class_2338)this.positionsToBreak[0]);
/* 340 */     return state;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean safeToCancel(MovementState state) {
/* 350 */     return (state.getStatus() != MovementStatus.RUNNING || MovementHelper.canWalkOn(this.ctx, this.dest.down()));
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean prepared(MovementState state) {
/* 355 */     if (this.ctx.playerFeet().equals(this.src) || this.ctx.playerFeet().equals(this.src.down())) {
/* 356 */       class_2248 block = BlockStateInterface.getBlock(this.ctx, (class_2338)this.src.down());
/* 357 */       if (block == class_2246.field_9983 || block == class_2246.field_10597) {
/* 358 */         state.setInput(Input.SNEAK, true);
/*     */       }
/*     */     } 
/* 361 */     return super.prepared(state);
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\pathing\movement\movements\MovementTraverse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */