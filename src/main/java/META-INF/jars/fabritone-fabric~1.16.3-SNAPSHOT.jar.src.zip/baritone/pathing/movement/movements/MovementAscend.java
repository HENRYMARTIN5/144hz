/*     */ package baritone.pathing.movement.movements;
/*     */ 
/*     */ import baritone.Baritone;
/*     */ import baritone.api.IBaritone;
/*     */ import baritone.api.pathing.movement.MovementStatus;
/*     */ import baritone.api.utils.BetterBlockPos;
/*     */ import baritone.api.utils.input.Input;
/*     */ import baritone.pathing.movement.CalculationContext;
/*     */ import baritone.pathing.movement.Movement;
/*     */ import baritone.pathing.movement.MovementHelper;
/*     */ import baritone.pathing.movement.MovementState;
/*     */ import baritone.utils.BlockStateInterface;
/*     */ import com.google.common.collect.ImmutableSet;
/*     */ import java.util.Set;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_2382;
/*     */ import net.minecraft.class_2680;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MovementAscend
/*     */   extends Movement
/*     */ {
/*  40 */   private int ticksWithoutPlacement = 0;
/*     */   
/*     */   public MovementAscend(IBaritone baritone, BetterBlockPos src, BetterBlockPos dest) {
/*  43 */     super(baritone, src, dest, new BetterBlockPos[] { dest, src.up(2), dest.up() }, dest.down());
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() {
/*  48 */     super.reset();
/*  49 */     this.ticksWithoutPlacement = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public double calculateCost(CalculationContext context) {
/*  54 */     return cost(context, this.src.x, this.src.y, this.src.z, this.dest.x, this.dest.z);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Set<BetterBlockPos> calculateValidPositions() {
/*  59 */     BetterBlockPos prior = new BetterBlockPos(this.src.method_10059((class_2382)getDirection()).method_10084());
/*  60 */     return (Set<BetterBlockPos>)ImmutableSet.of(this.src, this.src
/*  61 */         .up(), this.dest, prior, prior
/*     */ 
/*     */         
/*  64 */         .up());
/*     */   }
/*     */   
/*     */   public static double cost(CalculationContext context, int x, int y, int z, int destX, int destZ) {
/*     */     double walk;
/*  69 */     class_2680 toPlace = context.get(destX, y, destZ);
/*  70 */     double additionalPlacementCost = 0.0D;
/*  71 */     if (!MovementHelper.canWalkOn(context.bsi, destX, y, destZ, toPlace)) {
/*  72 */       additionalPlacementCost = context.costOfPlacingAt(destX, y, destZ, toPlace);
/*  73 */       if (additionalPlacementCost >= 1000000.0D) {
/*  74 */         return 1000000.0D;
/*     */       }
/*  76 */       if (!MovementHelper.isReplaceable(destX, y, destZ, toPlace, context.bsi)) {
/*  77 */         return 1000000.0D;
/*     */       }
/*  79 */       boolean foundPlaceOption = false;
/*  80 */       for (int i = 0; i < 5; i++) {
/*  81 */         int againstX = destX + HORIZONTALS_BUT_ALSO_DOWN_____SO_EVERY_DIRECTION_EXCEPT_UP[i].method_10148();
/*  82 */         int againstY = y + HORIZONTALS_BUT_ALSO_DOWN_____SO_EVERY_DIRECTION_EXCEPT_UP[i].method_10164();
/*  83 */         int againstZ = destZ + HORIZONTALS_BUT_ALSO_DOWN_____SO_EVERY_DIRECTION_EXCEPT_UP[i].method_10165();
/*  84 */         if (againstX != x || againstZ != z)
/*     */         {
/*     */           
/*  87 */           if (MovementHelper.canPlaceAgainst(context.bsi, againstX, againstY, againstZ)) {
/*  88 */             foundPlaceOption = true;
/*     */             break;
/*     */           }  } 
/*     */       } 
/*  92 */       if (!foundPlaceOption) {
/*  93 */         return 1000000.0D;
/*     */       }
/*     */     } 
/*  96 */     class_2680 srcUp2 = context.get(x, y + 2, z);
/*  97 */     if (context.get(x, y + 3, z).method_26204() instanceof net.minecraft.class_2346 && (MovementHelper.canWalkThrough(context.bsi, x, y + 1, z) || !(srcUp2.method_26204() instanceof net.minecraft.class_2346)))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 109 */       return 1000000.0D;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 115 */     class_2680 srcDown = context.get(x, y - 1, z);
/* 116 */     if (srcDown.method_26204() == class_2246.field_9983 || srcDown.method_26204() == class_2246.field_10597) {
/* 117 */       return 1000000.0D;
/*     */     }
/*     */     
/* 120 */     boolean jumpingFromBottomSlab = MovementHelper.isBottomSlab(srcDown);
/* 121 */     boolean jumpingToBottomSlab = MovementHelper.isBottomSlab(toPlace);
/* 122 */     if (jumpingFromBottomSlab && !jumpingToBottomSlab) {
/* 123 */       return 1000000.0D;
/*     */     }
/*     */     
/* 126 */     if (jumpingToBottomSlab) {
/* 127 */       if (jumpingFromBottomSlab) {
/* 128 */         walk = Math.max(JUMP_ONE_BLOCK_COST, 4.63284688441047D);
/* 129 */         walk += context.jumpPenalty;
/*     */       } else {
/* 131 */         walk = 4.63284688441047D;
/*     */       } 
/*     */     } else {
/*     */       
/* 135 */       if (toPlace.method_26204() == class_2246.field_10114) {
/* 136 */         walk = 9.26569376882094D;
/*     */       } else {
/* 138 */         walk = Math.max(JUMP_ONE_BLOCK_COST, 4.63284688441047D);
/*     */       } 
/* 140 */       walk += context.jumpPenalty;
/*     */     } 
/*     */     
/* 143 */     double totalCost = walk + additionalPlacementCost;
/*     */ 
/*     */     
/* 146 */     totalCost += MovementHelper.getMiningDurationTicks(context, x, y + 2, z, srcUp2, false);
/* 147 */     if (totalCost >= 1000000.0D) {
/* 148 */       return 1000000.0D;
/*     */     }
/* 150 */     totalCost += MovementHelper.getMiningDurationTicks(context, destX, y + 1, destZ, false);
/* 151 */     if (totalCost >= 1000000.0D) {
/* 152 */       return 1000000.0D;
/*     */     }
/* 154 */     totalCost += MovementHelper.getMiningDurationTicks(context, destX, y + 2, destZ, true);
/* 155 */     return totalCost;
/*     */   }
/*     */ 
/*     */   
/*     */   public MovementState updateState(MovementState state) {
/* 160 */     if ((this.ctx.playerFeet()).y < this.src.y)
/*     */     {
/* 162 */       return state.setStatus(MovementStatus.UNREACHABLE);
/*     */     }
/* 164 */     super.updateState(state);
/*     */ 
/*     */     
/* 167 */     if (state.getStatus() != MovementStatus.RUNNING) {
/* 168 */       return state;
/*     */     }
/*     */     
/* 171 */     if (this.ctx.playerFeet().equals(this.dest) || this.ctx.playerFeet().equals(this.dest.method_10081((class_2382)getDirection().method_10074()))) {
/* 172 */       return state.setStatus(MovementStatus.SUCCESS);
/*     */     }
/*     */     
/* 175 */     class_2680 jumpingOnto = BlockStateInterface.get(this.ctx, (class_2338)this.positionToPlace);
/* 176 */     if (!MovementHelper.canWalkOn(this.ctx, this.positionToPlace, jumpingOnto)) {
/* 177 */       this.ticksWithoutPlacement++;
/* 178 */       if (MovementHelper.attemptToPlaceABlock(state, this.baritone, (class_2338)this.dest.down(), false, true) == MovementHelper.PlaceResult.READY_TO_PLACE) {
/* 179 */         state.setInput(Input.SNEAK, true);
/* 180 */         if (this.ctx.player().method_5715()) {
/* 181 */           state.setInput(Input.CLICK_RIGHT, true);
/*     */         }
/*     */       } 
/* 184 */       if (this.ticksWithoutPlacement > 10)
/*     */       {
/* 186 */         state.setInput(Input.MOVE_BACK, true);
/*     */       }
/*     */       
/* 189 */       return state;
/*     */     } 
/* 191 */     MovementHelper.moveTowards(this.ctx, state, (class_2338)this.dest);
/* 192 */     if (MovementHelper.isBottomSlab(jumpingOnto) && !MovementHelper.isBottomSlab(BlockStateInterface.get(this.ctx, (class_2338)this.src.down()))) {
/* 193 */       return state;
/*     */     }
/*     */     
/* 196 */     if (((Boolean)(Baritone.settings()).assumeStep.value).booleanValue() || this.ctx.playerFeet().equals(this.src.up()))
/*     */     {
/* 198 */       return state;
/*     */     }
/*     */     
/* 201 */     int xAxis = Math.abs(this.src.method_10263() - this.dest.method_10263());
/* 202 */     int zAxis = Math.abs(this.src.method_10260() - this.dest.method_10260());
/* 203 */     double flatDistToNext = xAxis * Math.abs(this.dest.method_10263() + 0.5D - this.ctx.player().method_23317()) + zAxis * Math.abs(this.dest.method_10260() + 0.5D - this.ctx.player().method_23321());
/* 204 */     double sideDist = zAxis * Math.abs(this.dest.method_10263() + 0.5D - this.ctx.player().method_23317()) + xAxis * Math.abs(this.dest.method_10260() + 0.5D - this.ctx.player().method_23321());
/*     */     
/* 206 */     double lateralMotion = xAxis * (this.ctx.player().method_18798()).field_1350 + zAxis * (this.ctx.player().method_18798()).field_1352;
/* 207 */     if (Math.abs(lateralMotion) > 0.1D) {
/* 208 */       return state;
/*     */     }
/*     */     
/* 211 */     if (headBonkClear()) {
/* 212 */       return state.setInput(Input.JUMP, true);
/*     */     }
/*     */     
/* 215 */     if (flatDistToNext > 1.2D || sideDist > 0.2D) {
/* 216 */       return state;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 222 */     return state.setInput(Input.JUMP, true);
/*     */   }
/*     */   
/*     */   public boolean headBonkClear() {
/* 226 */     BetterBlockPos startUp = this.src.up(2);
/* 227 */     for (int i = 0; i < 4; i++) {
/* 228 */       BetterBlockPos check = startUp.offset(class_2350.method_10139(i));
/* 229 */       if (!MovementHelper.canWalkThrough(this.ctx, check))
/*     */       {
/* 231 */         return false;
/*     */       }
/*     */     } 
/* 234 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean safeToCancel(MovementState state) {
/* 240 */     return (state.getStatus() != MovementStatus.RUNNING || this.ticksWithoutPlacement == 0);
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\pathing\movement\movements\MovementAscend.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */