/*     */ package baritone.pathing.calc;
/*     */ 
/*     */ import baritone.api.pathing.calc.IPath;
/*     */ import baritone.api.pathing.goals.Goal;
/*     */ import baritone.api.pathing.movement.IMovement;
/*     */ import baritone.api.utils.BetterBlockPos;
/*     */ import baritone.api.utils.Helper;
/*     */ import baritone.pathing.movement.CalculationContext;
/*     */ import baritone.pathing.movement.Movement;
/*     */ import baritone.pathing.movement.Moves;
/*     */ import baritone.pathing.path.CutoffPath;
/*     */ import baritone.utils.pathing.PathBase;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import net.minecraft.class_2382;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Path
/*     */   extends PathBase
/*     */ {
/*     */   private final BetterBlockPos start;
/*     */   private final BetterBlockPos end;
/*     */   private final List<BetterBlockPos> path;
/*     */   private final List<Movement> movements;
/*     */   private final List<PathNode> nodes;
/*     */   private final Goal goal;
/*     */   private final int numNodes;
/*     */   private final CalculationContext context;
/*     */   private volatile boolean verified;
/*     */   
/*     */   Path(PathNode start, PathNode end, int numNodes, Goal goal, CalculationContext context) {
/*  72 */     this.start = new BetterBlockPos(start.x, start.y, start.z);
/*  73 */     this.end = new BetterBlockPos(end.x, end.y, end.z);
/*  74 */     this.numNodes = numNodes;
/*  75 */     this.movements = new ArrayList<>();
/*  76 */     this.goal = goal;
/*  77 */     this.context = context;
/*  78 */     PathNode current = end;
/*  79 */     LinkedList<BetterBlockPos> tempPath = new LinkedList<>();
/*  80 */     LinkedList<PathNode> tempNodes = new LinkedList<>();
/*     */ 
/*     */     
/*  83 */     while (current != null) {
/*  84 */       tempNodes.addFirst(current);
/*  85 */       tempPath.addFirst(new BetterBlockPos(current.x, current.y, current.z));
/*  86 */       current = current.previous;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  91 */     this.path = new ArrayList<>(tempPath);
/*  92 */     this.nodes = new ArrayList<>(tempNodes);
/*     */   }
/*     */ 
/*     */   
/*     */   public Goal getGoal() {
/*  97 */     return this.goal;
/*     */   }
/*     */   
/*     */   private boolean assembleMovements() {
/* 101 */     if (this.path.isEmpty() || !this.movements.isEmpty()) {
/* 102 */       throw new IllegalStateException();
/*     */     }
/* 104 */     for (int i = 0; i < this.path.size() - 1; i++) {
/* 105 */       double cost = ((PathNode)this.nodes.get(i + 1)).cost - ((PathNode)this.nodes.get(i)).cost;
/* 106 */       Movement move = runBackwards(this.path.get(i), this.path.get(i + 1), cost);
/* 107 */       if (move == null) {
/* 108 */         return true;
/*     */       }
/* 110 */       this.movements.add(move);
/*     */     } 
/*     */     
/* 113 */     return false;
/*     */   }
/*     */   
/*     */   private Movement runBackwards(BetterBlockPos src, BetterBlockPos dest, double cost) {
/* 117 */     for (Moves moves : Moves.values()) {
/* 118 */       Movement move = moves.apply0(this.context, src);
/* 119 */       if (move.getDest().equals(dest)) {
/*     */ 
/*     */ 
/*     */         
/* 123 */         move.override(Math.min(move.calculateCost(this.context), cost));
/* 124 */         return move;
/*     */       } 
/*     */     } 
/*     */     
/* 128 */     Helper.HELPER.logDebug("Movement became impossible during calculation " + src + " " + dest + " " + dest.method_10059((class_2382)src));
/* 129 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public IPath postProcess() {
/* 134 */     if (this.verified) {
/* 135 */       throw new IllegalStateException();
/*     */     }
/* 137 */     this.verified = true;
/* 138 */     boolean failed = assembleMovements();
/* 139 */     this.movements.forEach(m -> m.checkLoadedChunk(this.context));
/*     */     
/* 141 */     if (failed) {
/* 142 */       CutoffPath res = new CutoffPath((IPath)this, movements().size());
/* 143 */       if (res.movements().size() != this.movements.size()) {
/* 144 */         throw new IllegalStateException();
/*     */       }
/* 146 */       return (IPath)res;
/*     */     } 
/*     */     
/* 149 */     sanityCheck();
/* 150 */     return (IPath)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<IMovement> movements() {
/* 155 */     if (!this.verified) {
/* 156 */       throw new IllegalStateException();
/*     */     }
/* 158 */     return (List)Collections.unmodifiableList(this.movements);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<BetterBlockPos> positions() {
/* 163 */     return Collections.unmodifiableList(this.path);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getNumNodesConsidered() {
/* 168 */     return this.numNodes;
/*     */   }
/*     */ 
/*     */   
/*     */   public BetterBlockPos getSrc() {
/* 173 */     return this.start;
/*     */   }
/*     */ 
/*     */   
/*     */   public BetterBlockPos getDest() {
/* 178 */     return this.end;
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\pathing\calc\Path.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */