/*     */ package baritone.pathing.movement;
/*     */ 
/*     */ import baritone.Baritone;
/*     */ import baritone.api.IBaritone;
/*     */ import baritone.cache.WorldData;
/*     */ import baritone.utils.BlockStateInterface;
/*     */ import baritone.utils.ToolSet;
/*     */ import baritone.utils.pathing.BetterWorldBorder;
/*     */ import net.minecraft.class_1309;
/*     */ import net.minecraft.class_1661;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_1802;
/*     */ import net.minecraft.class_1890;
/*     */ import net.minecraft.class_1935;
/*     */ import net.minecraft.class_1937;
/*     */ import net.minecraft.class_2248;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_746;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CalculationContext
/*     */ {
/*  45 */   private static final class_1799 STACK_BUCKET_WATER = new class_1799((class_1935)class_1802.field_8705);
/*     */   
/*     */   public final boolean safeForThreadedUse;
/*     */   public final IBaritone baritone;
/*     */   public final class_1937 world;
/*     */   public final WorldData worldData;
/*     */   public final BlockStateInterface bsi;
/*     */   public final ToolSet toolSet;
/*     */   public final boolean hasWaterBucket;
/*     */   public final boolean hasThrowaway;
/*     */   public final boolean canSprint;
/*     */   protected final double placeBlockCost;
/*     */   public final boolean allowBreak;
/*     */   public final boolean allowParkour;
/*     */   public final boolean allowParkourPlace;
/*     */   public final boolean allowJumpAt256;
/*     */   public final boolean allowParkourAscend;
/*     */   public final boolean assumeWalkOnWater;
/*     */   public final boolean allowDiagonalDescend;
/*     */   public final boolean allowDiagonalAscend;
/*     */   public final boolean allowDownward;
/*     */   public final int maxFallHeightNoWater;
/*     */   public final int maxFallHeightBucket;
/*     */   public final double waterWalkSpeed;
/*     */   public final double breakBlockAdditionalCost;
/*     */   public double backtrackCostFavoringCoefficient;
/*     */   public double jumpPenalty;
/*     */   public final double walkOnWaterOnePenalty;
/*     */   public final BetterWorldBorder worldBorder;
/*     */   
/*     */   public CalculationContext(IBaritone baritone) {
/*  76 */     this(baritone, false);
/*     */   }
/*     */   
/*     */   public CalculationContext(IBaritone baritone, boolean forUseOnAnotherThread) {
/*  80 */     this.safeForThreadedUse = forUseOnAnotherThread;
/*  81 */     this.baritone = baritone;
/*  82 */     class_746 player = baritone.getPlayerContext().player();
/*  83 */     this.world = baritone.getPlayerContext().world();
/*  84 */     this.worldData = (WorldData)baritone.getWorldProvider().getCurrentWorld();
/*  85 */     this.bsi = new BlockStateInterface(this.world, this.worldData, forUseOnAnotherThread);
/*  86 */     this.toolSet = new ToolSet(player);
/*  87 */     this.hasThrowaway = (((Boolean)(Baritone.settings()).allowPlace.value).booleanValue() && ((Baritone)baritone).getInventoryBehavior().hasGenericThrowaway());
/*  88 */     this.hasWaterBucket = (((Boolean)(Baritone.settings()).allowWaterBucketFall.value).booleanValue() && class_1661.method_7380(player.field_7514.method_7395(STACK_BUCKET_WATER)) && this.world.method_27983() != class_1937.field_25180);
/*  89 */     this.canSprint = (((Boolean)(Baritone.settings()).allowSprint.value).booleanValue() && player.method_7344().method_7586() > 6);
/*  90 */     this.placeBlockCost = ((Double)(Baritone.settings()).blockPlacementPenalty.value).doubleValue();
/*  91 */     this.allowBreak = ((Boolean)(Baritone.settings()).allowBreak.value).booleanValue();
/*  92 */     this.allowParkour = ((Boolean)(Baritone.settings()).allowParkour.value).booleanValue();
/*  93 */     this.allowParkourPlace = ((Boolean)(Baritone.settings()).allowParkourPlace.value).booleanValue();
/*  94 */     this.allowJumpAt256 = ((Boolean)(Baritone.settings()).allowJumpAt256.value).booleanValue();
/*  95 */     this.allowParkourAscend = ((Boolean)(Baritone.settings()).allowParkourAscend.value).booleanValue();
/*  96 */     this.assumeWalkOnWater = ((Boolean)(Baritone.settings()).assumeWalkOnWater.value).booleanValue();
/*  97 */     this.allowDiagonalDescend = ((Boolean)(Baritone.settings()).allowDiagonalDescend.value).booleanValue();
/*  98 */     this.allowDiagonalAscend = ((Boolean)(Baritone.settings()).allowDiagonalAscend.value).booleanValue();
/*  99 */     this.allowDownward = ((Boolean)(Baritone.settings()).allowDownward.value).booleanValue();
/* 100 */     this.maxFallHeightNoWater = ((Integer)(Baritone.settings()).maxFallHeightNoWater.value).intValue();
/* 101 */     this.maxFallHeightBucket = ((Integer)(Baritone.settings()).maxFallHeightBucket.value).intValue();
/* 102 */     int depth = class_1890.method_8232((class_1309)player);
/* 103 */     if (depth > 3) {
/* 104 */       depth = 3;
/*     */     }
/* 106 */     float mult = depth / 3.0F;
/* 107 */     this.waterWalkSpeed = 9.09090909090909D * (1.0F - mult) + 4.63284688441047D * mult;
/* 108 */     this.breakBlockAdditionalCost = ((Double)(Baritone.settings()).blockBreakAdditionalPenalty.value).doubleValue();
/* 109 */     this.backtrackCostFavoringCoefficient = ((Double)(Baritone.settings()).backtrackCostFavoringCoefficient.value).doubleValue();
/* 110 */     this.jumpPenalty = ((Double)(Baritone.settings()).jumpPenalty.value).doubleValue();
/* 111 */     this.walkOnWaterOnePenalty = ((Double)(Baritone.settings()).walkOnWaterOnePenalty.value).doubleValue();
/*     */ 
/*     */ 
/*     */     
/* 115 */     this.worldBorder = new BetterWorldBorder(this.world.method_8621());
/*     */   }
/*     */   
/*     */   public final IBaritone getBaritone() {
/* 119 */     return this.baritone;
/*     */   }
/*     */   
/*     */   public class_2680 get(int x, int y, int z) {
/* 123 */     return this.bsi.get0(x, y, z);
/*     */   }
/*     */   
/*     */   public boolean isLoaded(int x, int z) {
/* 127 */     return this.bsi.isLoaded(x, z);
/*     */   }
/*     */   
/*     */   public class_2680 get(class_2338 pos) {
/* 131 */     return get(pos.method_10263(), pos.method_10264(), pos.method_10260());
/*     */   }
/*     */   
/*     */   public class_2248 getBlock(int x, int y, int z) {
/* 135 */     return get(x, y, z).method_26204();
/*     */   }
/*     */   
/*     */   public double costOfPlacingAt(int x, int y, int z, class_2680 current) {
/* 139 */     if (!this.hasThrowaway) {
/* 140 */       return 1000000.0D;
/*     */     }
/* 142 */     if (isPossiblyProtected(x, y, z)) {
/* 143 */       return 1000000.0D;
/*     */     }
/* 145 */     if (!this.worldBorder.canPlaceAt(x, z))
/*     */     {
/* 147 */       return 1000000.0D;
/*     */     }
/* 149 */     return this.placeBlockCost;
/*     */   }
/*     */   
/*     */   public double breakCostMultiplierAt(int x, int y, int z, class_2680 current) {
/* 153 */     if (!this.allowBreak) {
/* 154 */       return 1000000.0D;
/*     */     }
/* 156 */     if (isPossiblyProtected(x, y, z)) {
/* 157 */       return 1000000.0D;
/*     */     }
/* 159 */     return 1.0D;
/*     */   }
/*     */   
/*     */   public double placeBucketCost() {
/* 163 */     return this.placeBlockCost;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPossiblyProtected(int x, int y, int z) {
/* 168 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\pathing\movement\CalculationContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */