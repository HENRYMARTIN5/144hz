/*     */ package baritone.pathing.movement;
/*     */ 
/*     */ import baritone.Baritone;
/*     */ import baritone.api.IBaritone;
/*     */ import baritone.api.pathing.movement.IMovement;
/*     */ import baritone.api.pathing.movement.MovementStatus;
/*     */ import baritone.api.utils.BetterBlockPos;
/*     */ import baritone.api.utils.IPlayerContext;
/*     */ import baritone.api.utils.Rotation;
/*     */ import baritone.api.utils.RotationUtils;
/*     */ import baritone.api.utils.VecUtils;
/*     */ import baritone.api.utils.input.Input;
/*     */ import baritone.behavior.PathingBehavior;
/*     */ import baritone.utils.BlockStateInterface;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import net.minecraft.class_1540;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_238;
/*     */ import net.minecraft.class_2382;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Movement
/*     */   implements IMovement, MovementHelper
/*     */ {
/*  37 */   public static final class_2350[] HORIZONTALS_BUT_ALSO_DOWN_____SO_EVERY_DIRECTION_EXCEPT_UP = new class_2350[] { class_2350.field_11043, class_2350.field_11035, class_2350.field_11034, class_2350.field_11039, class_2350.field_11033 };
/*     */   
/*     */   protected final IBaritone baritone;
/*     */   
/*     */   protected final IPlayerContext ctx;
/*  42 */   private MovementState currentState = (new MovementState()).setStatus(MovementStatus.PREPPING);
/*     */ 
/*     */   
/*     */   protected final BetterBlockPos src;
/*     */ 
/*     */   
/*     */   protected final BetterBlockPos dest;
/*     */ 
/*     */   
/*     */   protected final BetterBlockPos[] positionsToBreak;
/*     */ 
/*     */   
/*     */   protected final BetterBlockPos positionToPlace;
/*     */ 
/*     */   
/*     */   private Double cost;
/*     */ 
/*     */   
/*  60 */   public List<class_2338> toBreakCached = null;
/*  61 */   public List<class_2338> toPlaceCached = null;
/*  62 */   public List<class_2338> toWalkIntoCached = null;
/*     */   
/*  64 */   private Set<BetterBlockPos> validPositionsCached = null;
/*     */   
/*     */   private Boolean calculatedWhileLoaded;
/*     */   
/*     */   protected Movement(IBaritone baritone, BetterBlockPos src, BetterBlockPos dest, BetterBlockPos[] toBreak, BetterBlockPos toPlace) {
/*  69 */     this.baritone = baritone;
/*  70 */     this.ctx = baritone.getPlayerContext();
/*  71 */     this.src = src;
/*  72 */     this.dest = dest;
/*  73 */     this.positionsToBreak = toBreak;
/*  74 */     this.positionToPlace = toPlace;
/*     */   }
/*     */   
/*     */   protected Movement(IBaritone baritone, BetterBlockPos src, BetterBlockPos dest, BetterBlockPos[] toBreak) {
/*  78 */     this(baritone, src, dest, toBreak, null);
/*     */   }
/*     */   
/*     */   public double getCost() throws NullPointerException {
/*  82 */     return this.cost.doubleValue();
/*     */   }
/*     */   
/*     */   public double getCost(CalculationContext context) {
/*  86 */     if (this.cost == null) {
/*  87 */       this.cost = Double.valueOf(calculateCost(context));
/*     */     }
/*  89 */     return this.cost.doubleValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double recalculateCost(CalculationContext context) {
/*  95 */     this.cost = null;
/*  96 */     return getCost(context);
/*     */   }
/*     */   
/*     */   public void override(double cost) {
/* 100 */     this.cost = Double.valueOf(cost);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<BetterBlockPos> getValidPositions() {
/* 106 */     if (this.validPositionsCached == null) {
/* 107 */       this.validPositionsCached = calculateValidPositions();
/* 108 */       Objects.requireNonNull(this.validPositionsCached);
/*     */     } 
/* 110 */     return this.validPositionsCached;
/*     */   }
/*     */   
/*     */   protected boolean playerInValidPosition() {
/* 114 */     return (getValidPositions().contains(this.ctx.playerFeet()) || getValidPositions().contains(((PathingBehavior)this.baritone.getPathingBehavior()).pathStart()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MovementStatus update() {
/* 125 */     (this.ctx.player()).field_7503.field_7479 = false;
/* 126 */     this.currentState = updateState(this.currentState);
/* 127 */     if (MovementHelper.isLiquid(this.ctx, (class_2338)this.ctx.playerFeet())) {
/* 128 */       this.currentState.setInput(Input.JUMP, true);
/*     */     }
/* 130 */     if (this.ctx.player().method_5757()) {
/* 131 */       this.ctx.getSelectedBlock().ifPresent(pos -> MovementHelper.switchToBestToolFor(this.ctx, BlockStateInterface.get(this.ctx, pos)));
/* 132 */       this.currentState.setInput(Input.CLICK_LEFT, true);
/*     */     } 
/*     */ 
/*     */     
/* 136 */     this.currentState.getTarget().getRotation().ifPresent(rotation -> this.baritone.getLookBehavior().updateTarget(rotation, this.currentState.getTarget().hasToForceRotations()));
/*     */ 
/*     */ 
/*     */     
/* 140 */     this.baritone.getInputOverrideHandler().clearAllKeys();
/* 141 */     this.currentState.getInputStates().forEach((input, forced) -> this.baritone.getInputOverrideHandler().setInputForceState(input, forced.booleanValue()));
/*     */ 
/*     */     
/* 144 */     this.currentState.getInputStates().clear();
/*     */ 
/*     */     
/* 147 */     if (this.currentState.getStatus().isComplete()) {
/* 148 */       this.baritone.getInputOverrideHandler().clearAllKeys();
/*     */     }
/*     */     
/* 151 */     return this.currentState.getStatus();
/*     */   }
/*     */   
/*     */   protected boolean prepared(MovementState state) {
/* 155 */     if (state.getStatus() == MovementStatus.WAITING) {
/* 156 */       return true;
/*     */     }
/* 158 */     boolean somethingInTheWay = false;
/* 159 */     for (BetterBlockPos blockPos : this.positionsToBreak) {
/* 160 */       if (!this.ctx.world().method_21728(class_1540.class, (new class_238(0.0D, 0.0D, 0.0D, 1.0D, 1.1D, 1.0D)).method_996((class_2338)blockPos)).isEmpty() && ((Boolean)(Baritone.settings()).pauseMiningForFallingBlocks.value).booleanValue()) {
/* 161 */         return false;
/*     */       }
/* 163 */       if (!MovementHelper.canWalkThrough(this.ctx, blockPos)) {
/* 164 */         somethingInTheWay = true;
/* 165 */         MovementHelper.switchToBestToolFor(this.ctx, BlockStateInterface.get(this.ctx, (class_2338)blockPos));
/* 166 */         Optional<Rotation> reachable = RotationUtils.reachable(this.ctx.player(), (class_2338)blockPos, this.ctx.playerController().getBlockReachDistance());
/* 167 */         if (reachable.isPresent()) {
/* 168 */           Rotation rotTowardsBlock = reachable.get();
/* 169 */           state.setTarget(new MovementState.MovementTarget(rotTowardsBlock, true));
/* 170 */           if (this.ctx.isLookingAt((class_2338)blockPos) || this.ctx.playerRotations().isReallyCloseTo(rotTowardsBlock)) {
/* 171 */             state.setInput(Input.CLICK_LEFT, true);
/*     */           }
/* 173 */           return false;
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 179 */         state.setTarget(new MovementState.MovementTarget(RotationUtils.calcRotationFromVec3d(this.ctx.playerHead(), 
/* 180 */                 VecUtils.getBlockPosCenter((class_2338)blockPos), this.ctx.playerRotations()), true));
/*     */ 
/*     */         
/* 183 */         state.setInput(Input.CLICK_LEFT, true);
/* 184 */         return false;
/*     */       } 
/*     */     } 
/* 187 */     if (somethingInTheWay) {
/*     */ 
/*     */       
/* 190 */       state.setStatus(MovementStatus.UNREACHABLE);
/* 191 */       return true;
/*     */     } 
/* 193 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean safeToCancel() {
/* 198 */     return safeToCancel(this.currentState);
/*     */   }
/*     */   
/*     */   protected boolean safeToCancel(MovementState currentState) {
/* 202 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public BetterBlockPos getSrc() {
/* 207 */     return this.src;
/*     */   }
/*     */ 
/*     */   
/*     */   public BetterBlockPos getDest() {
/* 212 */     return this.dest;
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() {
/* 217 */     this.currentState = (new MovementState()).setStatus(MovementStatus.PREPPING);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MovementState updateState(MovementState state) {
/* 227 */     if (!prepared(state))
/* 228 */       return state.setStatus(MovementStatus.PREPPING); 
/* 229 */     if (state.getStatus() == MovementStatus.PREPPING) {
/* 230 */       state.setStatus(MovementStatus.WAITING);
/*     */     }
/*     */     
/* 233 */     if (state.getStatus() == MovementStatus.WAITING) {
/* 234 */       state.setStatus(MovementStatus.RUNNING);
/*     */     }
/*     */     
/* 237 */     return state;
/*     */   }
/*     */ 
/*     */   
/*     */   public class_2338 getDirection() {
/* 242 */     return getDest().method_10059((class_2382)getSrc());
/*     */   }
/*     */   
/*     */   public void checkLoadedChunk(CalculationContext context) {
/* 246 */     this.calculatedWhileLoaded = Boolean.valueOf(context.bsi.worldContainsLoadedChunk(this.dest.x, this.dest.z));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean calculatedWhileLoaded() {
/* 251 */     return this.calculatedWhileLoaded.booleanValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public void resetBlockCache() {
/* 256 */     this.toBreakCached = null;
/* 257 */     this.toPlaceCached = null;
/* 258 */     this.toWalkIntoCached = null;
/*     */   }
/*     */   
/*     */   public List<class_2338> toBreak(BlockStateInterface bsi) {
/* 262 */     if (this.toBreakCached != null) {
/* 263 */       return this.toBreakCached;
/*     */     }
/* 265 */     List<class_2338> result = new ArrayList<>();
/* 266 */     for (BetterBlockPos positionToBreak : this.positionsToBreak) {
/* 267 */       if (!MovementHelper.canWalkThrough(bsi, positionToBreak.x, positionToBreak.y, positionToBreak.z)) {
/* 268 */         result.add(positionToBreak);
/*     */       }
/*     */     } 
/* 271 */     this.toBreakCached = result;
/* 272 */     return result;
/*     */   }
/*     */   
/*     */   public List<class_2338> toPlace(BlockStateInterface bsi) {
/* 276 */     if (this.toPlaceCached != null) {
/* 277 */       return this.toPlaceCached;
/*     */     }
/* 279 */     List<class_2338> result = new ArrayList<>();
/* 280 */     if (this.positionToPlace != null && !MovementHelper.canWalkOn(bsi, this.positionToPlace.x, this.positionToPlace.y, this.positionToPlace.z)) {
/* 281 */       result.add(this.positionToPlace);
/*     */     }
/* 283 */     this.toPlaceCached = result;
/* 284 */     return result;
/*     */   }
/*     */   
/*     */   public List<class_2338> toWalkInto(BlockStateInterface bsi) {
/* 288 */     if (this.toWalkIntoCached == null) {
/* 289 */       this.toWalkIntoCached = new ArrayList<>();
/*     */     }
/* 291 */     return this.toWalkIntoCached;
/*     */   }
/*     */   
/*     */   public class_2338[] toBreakAll() {
/* 295 */     return (class_2338[])this.positionsToBreak;
/*     */   }
/*     */   
/*     */   public abstract double calculateCost(CalculationContext paramCalculationContext);
/*     */   
/*     */   protected abstract Set<BetterBlockPos> calculateValidPositions();
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\pathing\movement\Movement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */