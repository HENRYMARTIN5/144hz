/*     */ package baritone.pathing.movement.movements;
/*     */ 
/*     */ import baritone.api.IBaritone;
/*     */ import baritone.api.pathing.movement.MovementStatus;
/*     */ import baritone.api.utils.BetterBlockPos;
/*     */ import baritone.api.utils.Rotation;
/*     */ import baritone.api.utils.RotationUtils;
/*     */ import baritone.api.utils.input.Input;
/*     */ import baritone.pathing.movement.CalculationContext;
/*     */ import baritone.pathing.movement.Movement;
/*     */ import baritone.pathing.movement.MovementHelper;
/*     */ import baritone.pathing.movement.MovementState;
/*     */ import baritone.utils.BlockStateInterface;
/*     */ import baritone.utils.pathing.MutableMoveResult;
/*     */ import com.google.common.collect.ImmutableSet;
/*     */ import java.util.Set;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2248;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2382;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_746;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MovementDescend
/*     */   extends Movement
/*     */ {
/*  45 */   private int numTicks = 0;
/*     */   
/*     */   public MovementDescend(IBaritone baritone, BetterBlockPos start, BetterBlockPos end) {
/*  48 */     super(baritone, start, end, new BetterBlockPos[] { end.up(2), end.up(), end }, end.down());
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() {
/*  53 */     super.reset();
/*  54 */     this.numTicks = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public double calculateCost(CalculationContext context) {
/*  59 */     MutableMoveResult result = new MutableMoveResult();
/*  60 */     cost(context, this.src.x, this.src.y, this.src.z, this.dest.x, this.dest.z, result);
/*  61 */     if (result.y != this.dest.y) {
/*  62 */       return 1000000.0D;
/*     */     }
/*  64 */     return result.cost;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Set<BetterBlockPos> calculateValidPositions() {
/*  69 */     return (Set<BetterBlockPos>)ImmutableSet.of(this.src, this.dest.up(), this.dest);
/*     */   }
/*     */   
/*     */   public static void cost(CalculationContext context, int x, int y, int z, int destX, int destZ, MutableMoveResult res) {
/*  73 */     double totalCost = 0.0D;
/*  74 */     class_2680 destDown = context.get(destX, y - 1, destZ);
/*  75 */     totalCost += MovementHelper.getMiningDurationTicks(context, destX, y - 1, destZ, destDown, false);
/*  76 */     if (totalCost >= 1000000.0D) {
/*     */       return;
/*     */     }
/*  79 */     totalCost += MovementHelper.getMiningDurationTicks(context, destX, y, destZ, false);
/*  80 */     if (totalCost >= 1000000.0D) {
/*     */       return;
/*     */     }
/*  83 */     totalCost += MovementHelper.getMiningDurationTicks(context, destX, y + 1, destZ, true);
/*  84 */     if (totalCost >= 1000000.0D) {
/*     */       return;
/*     */     }
/*     */     
/*  88 */     class_2248 fromDown = context.get(x, y - 1, z).method_26204();
/*  89 */     if (fromDown == class_2246.field_9983 || fromDown == class_2246.field_10597) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 103 */     class_2680 below = context.get(destX, y - 2, destZ);
/* 104 */     if (!MovementHelper.canWalkOn(context.bsi, destX, y - 2, destZ, below)) {
/* 105 */       dynamicFallCost(context, x, y, z, destX, destZ, totalCost, below, res);
/*     */       
/*     */       return;
/*     */     } 
/* 109 */     if (destDown.method_26204() == class_2246.field_9983 || destDown.method_26204() == class_2246.field_10597) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 114 */     double walk = 3.7062775075283763D;
/* 115 */     if (fromDown == class_2246.field_10114)
/*     */     {
/* 117 */       walk *= 2.0D;
/*     */     }
/* 119 */     totalCost += walk + Math.max(FALL_N_BLOCKS_COST[1], 0.9265693768820937D);
/* 120 */     res.x = destX;
/* 121 */     res.y = y - 1;
/* 122 */     res.z = destZ;
/* 123 */     res.cost = totalCost;
/*     */   }
/*     */   
/*     */   public static boolean dynamicFallCost(CalculationContext context, int x, int y, int z, int destX, int destZ, double frontBreak, class_2680 below, MutableMoveResult res) {
/* 127 */     if (frontBreak != 0.0D && context.get(destX, y + 2, destZ).method_26204() instanceof net.minecraft.class_2346)
/*     */     {
/*     */ 
/*     */       
/* 131 */       return false;
/*     */     }
/* 133 */     if (!MovementHelper.canWalkThrough(context.bsi, destX, y - 2, destZ, below)) {
/* 134 */       return false;
/*     */     }
/* 136 */     double costSoFar = 0.0D;
/* 137 */     int effectiveStartHeight = y;
/* 138 */     for (int fallHeight = 3;; fallHeight++) {
/* 139 */       int newY = y - fallHeight;
/* 140 */       if (newY < 0)
/*     */       {
/*     */         
/* 143 */         return false;
/*     */       }
/* 145 */       class_2680 ontoBlock = context.get(destX, newY, destZ);
/* 146 */       int unprotectedFallHeight = fallHeight - y - effectiveStartHeight;
/* 147 */       double tentativeCost = 3.7062775075283763D + FALL_N_BLOCKS_COST[unprotectedFallHeight] + frontBreak + costSoFar;
/* 148 */       if (MovementHelper.isWater(ontoBlock)) {
/* 149 */         if (!MovementHelper.canWalkThrough(context.bsi, destX, newY, destZ, ontoBlock)) {
/* 150 */           return false;
/*     */         }
/* 152 */         if (context.assumeWalkOnWater) {
/* 153 */           return false;
/*     */         }
/* 155 */         if (MovementHelper.isFlowing(destX, newY, destZ, ontoBlock, context.bsi)) {
/* 156 */           return false;
/*     */         }
/* 158 */         if (!MovementHelper.canWalkOn(context.bsi, destX, newY - 1, destZ))
/*     */         {
/* 160 */           return false;
/*     */         }
/*     */         
/* 163 */         res.x = destX;
/* 164 */         res.y = newY;
/* 165 */         res.z = destZ;
/* 166 */         res.cost = tentativeCost;
/* 167 */         return false;
/*     */       } 
/* 169 */       if (unprotectedFallHeight <= 11 && (ontoBlock.method_26204() == class_2246.field_10597 || ontoBlock.method_26204() == class_2246.field_9983)) {
/*     */ 
/*     */         
/* 172 */         costSoFar += FALL_N_BLOCKS_COST[unprotectedFallHeight - 1];
/* 173 */         costSoFar += 6.666666666666667D;
/* 174 */         effectiveStartHeight = newY;
/*     */       
/*     */       }
/* 177 */       else if (!MovementHelper.canWalkThrough(context.bsi, destX, newY, destZ, ontoBlock)) {
/*     */ 
/*     */         
/* 180 */         if (!MovementHelper.canWalkOn(context.bsi, destX, newY, destZ, ontoBlock)) {
/* 181 */           return false;
/*     */         }
/* 183 */         if (MovementHelper.isBottomSlab(ontoBlock)) {
/* 184 */           return false;
/*     */         }
/* 186 */         if (unprotectedFallHeight <= context.maxFallHeightNoWater + 1) {
/*     */           
/* 188 */           res.x = destX;
/* 189 */           res.y = newY + 1;
/* 190 */           res.z = destZ;
/* 191 */           res.cost = tentativeCost;
/* 192 */           return false;
/*     */         } 
/* 194 */         if (context.hasWaterBucket && unprotectedFallHeight <= context.maxFallHeightBucket + 1) {
/* 195 */           res.x = destX;
/* 196 */           res.y = newY + 1;
/* 197 */           res.z = destZ;
/* 198 */           res.cost = tentativeCost + context.placeBucketCost();
/* 199 */           return true;
/*     */         } 
/* 201 */         return false;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public MovementState updateState(MovementState state) {
/* 208 */     super.updateState(state);
/* 209 */     if (state.getStatus() != MovementStatus.RUNNING) {
/* 210 */       return state;
/*     */     }
/*     */     
/* 213 */     BetterBlockPos betterBlockPos = this.ctx.playerFeet();
/* 214 */     class_2338 fakeDest = new class_2338(this.dest.method_10263() * 2 - this.src.method_10263(), this.dest.method_10264(), this.dest.method_10260() * 2 - this.src.method_10260());
/* 215 */     if ((betterBlockPos.equals(this.dest) || betterBlockPos.equals(fakeDest)) && (MovementHelper.isLiquid(this.ctx, (class_2338)this.dest) || this.ctx.player().method_23318() - this.dest.method_10264() < 0.5D))
/*     */     {
/* 217 */       return state.setStatus(MovementStatus.SUCCESS);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 222 */     if (safeMode()) {
/* 223 */       double destX = (this.src.method_10263() + 0.5D) * 0.17D + (this.dest.method_10263() + 0.5D) * 0.83D;
/* 224 */       double destZ = (this.src.method_10260() + 0.5D) * 0.17D + (this.dest.method_10260() + 0.5D) * 0.83D;
/* 225 */       class_746 player = this.ctx.player();
/* 226 */       state.setTarget(new MovementState.MovementTarget(new Rotation(
/* 227 */               RotationUtils.calcRotationFromVec3d(this.ctx.playerHead(), new class_243(destX, this.dest
/* 228 */                   .method_10264(), destZ), new Rotation(player.field_6031, player.field_5965))
/* 229 */               .getYaw(), player.field_5965), false))
/*     */         
/* 231 */         .setInput(Input.MOVE_FORWARD, true);
/* 232 */       return state;
/*     */     } 
/* 234 */     double diffX = this.ctx.player().method_23317() - this.dest.method_10263() + 0.5D;
/* 235 */     double diffZ = this.ctx.player().method_23321() - this.dest.method_10260() + 0.5D;
/* 236 */     double ab = Math.sqrt(diffX * diffX + diffZ * diffZ);
/* 237 */     double x = this.ctx.player().method_23317() - this.src.method_10263() + 0.5D;
/* 238 */     double z = this.ctx.player().method_23321() - this.src.method_10260() + 0.5D;
/* 239 */     double fromStart = Math.sqrt(x * x + z * z);
/* 240 */     if (!betterBlockPos.equals(this.dest) || ab > 0.25D) {
/* 241 */       if (this.numTicks++ < 20 && fromStart < 1.25D) {
/* 242 */         MovementHelper.moveTowards(this.ctx, state, fakeDest);
/*     */       } else {
/* 244 */         MovementHelper.moveTowards(this.ctx, state, (class_2338)this.dest);
/*     */       } 
/*     */     }
/* 247 */     return state;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean safeMode() {
/* 253 */     class_2338 into = this.dest.method_10059((class_2382)this.src.down()).method_10081((class_2382)this.dest);
/* 254 */     if (skipToAscend())
/*     */     {
/* 256 */       return true;
/*     */     }
/* 258 */     for (int y = 0; y <= 2; y++) {
/* 259 */       if (MovementHelper.avoidWalkingInto(BlockStateInterface.get(this.ctx, into.method_10086(y)))) {
/* 260 */         return true;
/*     */       }
/*     */     } 
/* 263 */     return false;
/*     */   }
/*     */   
/*     */   public boolean skipToAscend() {
/* 267 */     class_2338 into = this.dest.method_10059((class_2382)this.src.down()).method_10081((class_2382)this.dest); return (
/* 268 */       !MovementHelper.canWalkThrough(this.ctx, new BetterBlockPos(into)) && MovementHelper.canWalkThrough(this.ctx, (new BetterBlockPos(into)).up()) && MovementHelper.canWalkThrough(this.ctx, (new BetterBlockPos(into)).up(2)));
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\pathing\movement\movements\MovementDescend.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */