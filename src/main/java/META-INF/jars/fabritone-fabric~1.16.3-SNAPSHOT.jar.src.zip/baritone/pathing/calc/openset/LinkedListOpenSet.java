/*    */ package baritone.pathing.calc.openset;
/*    */ 
/*    */ import baritone.pathing.calc.PathNode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class LinkedListOpenSet
/*    */   implements IOpenSet
/*    */ {
/* 31 */   private Node first = null;
/*    */ 
/*    */   
/*    */   public boolean isEmpty() {
/* 35 */     return (this.first == null);
/*    */   }
/*    */ 
/*    */   
/*    */   public void insert(PathNode pathNode) {
/* 40 */     Node node = new Node();
/* 41 */     node.val = pathNode;
/* 42 */     node.nextOpen = this.first;
/* 43 */     this.first = node;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void update(PathNode node) {}
/*    */ 
/*    */ 
/*    */   
/*    */   public PathNode removeLowest() {
/* 53 */     if (this.first == null) {
/* 54 */       return null;
/*    */     }
/* 56 */     Node current = this.first.nextOpen;
/* 57 */     if (current == null) {
/* 58 */       Node n = this.first;
/* 59 */       this.first = null;
/* 60 */       return n.val;
/*    */     } 
/* 62 */     Node previous = this.first;
/* 63 */     double bestValue = this.first.val.combinedCost;
/* 64 */     Node bestNode = this.first;
/* 65 */     Node beforeBest = null;
/* 66 */     while (current != null) {
/* 67 */       double comp = current.val.combinedCost;
/* 68 */       if (comp < bestValue) {
/* 69 */         bestValue = comp;
/* 70 */         bestNode = current;
/* 71 */         beforeBest = previous;
/*    */       } 
/* 73 */       previous = current;
/* 74 */       current = current.nextOpen;
/*    */     } 
/* 76 */     if (beforeBest == null) {
/* 77 */       this.first = this.first.nextOpen;
/* 78 */       bestNode.nextOpen = null;
/* 79 */       return bestNode.val;
/*    */     } 
/* 81 */     beforeBest.nextOpen = bestNode.nextOpen;
/* 82 */     bestNode.nextOpen = null;
/* 83 */     return bestNode.val;
/*    */   }
/*    */   
/*    */   public static class Node {
/*    */     private Node nextOpen;
/*    */     private PathNode val;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\pathing\calc\openset\LinkedListOpenSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */