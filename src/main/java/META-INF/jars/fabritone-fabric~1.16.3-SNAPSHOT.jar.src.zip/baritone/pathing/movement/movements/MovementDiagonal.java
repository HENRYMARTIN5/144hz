/*     */ package baritone.pathing.movement.movements;
/*     */ 
/*     */ import baritone.Baritone;
/*     */ import baritone.api.IBaritone;
/*     */ import baritone.api.pathing.movement.MovementStatus;
/*     */ import baritone.api.utils.BetterBlockPos;
/*     */ import baritone.api.utils.input.Input;
/*     */ import baritone.pathing.movement.CalculationContext;
/*     */ import baritone.pathing.movement.Movement;
/*     */ import baritone.pathing.movement.MovementHelper;
/*     */ import baritone.pathing.movement.MovementState;
/*     */ import baritone.utils.BlockStateInterface;
/*     */ import baritone.utils.pathing.MutableMoveResult;
/*     */ import com.google.common.collect.ImmutableSet;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2248;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_746;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MovementDiagonal
/*     */   extends Movement
/*     */ {
/*  45 */   private static final double SQRT_2 = Math.sqrt(2.0D);
/*     */   
/*     */   public MovementDiagonal(IBaritone baritone, BetterBlockPos start, class_2350 dir1, class_2350 dir2, int dy) {
/*  48 */     this(baritone, start, start.offset(dir1), start.offset(dir2), dir2, dy);
/*     */   }
/*     */ 
/*     */   
/*     */   private MovementDiagonal(IBaritone baritone, BetterBlockPos start, BetterBlockPos dir1, BetterBlockPos dir2, class_2350 drr2, int dy) {
/*  53 */     this(baritone, start, dir1.offset(drr2).up(dy), dir1, dir2);
/*     */   }
/*     */   
/*     */   private MovementDiagonal(IBaritone baritone, BetterBlockPos start, BetterBlockPos end, BetterBlockPos dir1, BetterBlockPos dir2) {
/*  57 */     super(baritone, start, end, new BetterBlockPos[] { dir1, dir1.up(), dir2, dir2.up(), end, end.up() });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean safeToCancel(MovementState state) {
/*  64 */     class_746 player = this.ctx.player();
/*  65 */     double offset = 0.25D;
/*  66 */     double x = player.method_23317();
/*  67 */     double y = player.method_23318() - 1.0D;
/*  68 */     double z = player.method_23321();
/*     */     
/*  70 */     if (this.ctx.playerFeet().equals(this.src)) {
/*  71 */       return true;
/*     */     }
/*     */     
/*  74 */     if (MovementHelper.canWalkOn(this.ctx, new class_2338(this.src.x, this.src.y - 1, this.dest.z)) && 
/*  75 */       MovementHelper.canWalkOn(this.ctx, new class_2338(this.dest.x, this.src.y - 1, this.src.z))) {
/*  76 */       return true;
/*     */     }
/*     */     
/*  79 */     if (this.ctx.playerFeet().equals(new BetterBlockPos(this.src.x, this.src.y, this.dest.z)) || this.ctx
/*  80 */       .playerFeet().equals(new BetterBlockPos(this.dest.x, this.src.y, this.src.z))) {
/*  81 */       return (MovementHelper.canWalkOn(this.ctx, new BetterBlockPos(x + offset, y, z + offset)) || 
/*  82 */         MovementHelper.canWalkOn(this.ctx, new BetterBlockPos(x + offset, y, z - offset)) || 
/*  83 */         MovementHelper.canWalkOn(this.ctx, new BetterBlockPos(x - offset, y, z + offset)) || 
/*  84 */         MovementHelper.canWalkOn(this.ctx, new BetterBlockPos(x - offset, y, z - offset)));
/*     */     }
/*  86 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public double calculateCost(CalculationContext context) {
/*  91 */     MutableMoveResult result = new MutableMoveResult();
/*  92 */     cost(context, this.src.x, this.src.y, this.src.z, this.dest.x, this.dest.z, result);
/*  93 */     if (result.y != this.dest.y) {
/*  94 */       return 1000000.0D;
/*     */     }
/*  96 */     return result.cost;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Set<BetterBlockPos> calculateValidPositions() {
/* 101 */     BetterBlockPos diagA = new BetterBlockPos(this.src.x, this.src.y, this.dest.z);
/* 102 */     BetterBlockPos diagB = new BetterBlockPos(this.dest.x, this.src.y, this.src.z);
/* 103 */     if (this.dest.y < this.src.y) {
/* 104 */       return (Set<BetterBlockPos>)ImmutableSet.of(this.src, this.dest.up(), diagA, diagB, this.dest, diagA.down(), (Object[])new BetterBlockPos[] { diagB.down() });
/*     */     }
/* 106 */     if (this.dest.y > this.src.y) {
/* 107 */       return (Set<BetterBlockPos>)ImmutableSet.of(this.src, this.src.up(), diagA, diagB, this.dest, diagA.up(), (Object[])new BetterBlockPos[] { diagB.up() });
/*     */     }
/* 109 */     return (Set<BetterBlockPos>)ImmutableSet.of(this.src, this.dest, diagA, diagB);
/*     */   }
/*     */   public static void cost(CalculationContext context, int x, int y, int z, int destX, int destZ, MutableMoveResult res) {
/*     */     class_2680 destWalkOn;
/* 113 */     if (!MovementHelper.canWalkThrough(context.bsi, destX, y + 1, destZ)) {
/*     */       return;
/*     */     }
/* 116 */     class_2680 destInto = context.get(destX, y, destZ);
/* 117 */     boolean ascend = false;
/*     */     
/* 119 */     boolean descend = false;
/* 120 */     if (!MovementHelper.canWalkThrough(context.bsi, destX, y, destZ, destInto)) {
/* 121 */       ascend = true;
/* 122 */       if (!context.allowDiagonalAscend || !MovementHelper.canWalkThrough(context.bsi, x, y + 2, z) || !MovementHelper.canWalkOn(context.bsi, destX, y, destZ, destInto) || !MovementHelper.canWalkThrough(context.bsi, destX, y + 2, destZ)) {
/*     */         return;
/*     */       }
/* 125 */       destWalkOn = destInto;
/*     */     } else {
/* 127 */       destWalkOn = context.get(destX, y - 1, destZ);
/* 128 */       if (!MovementHelper.canWalkOn(context.bsi, destX, y - 1, destZ, destWalkOn)) {
/* 129 */         descend = true;
/* 130 */         if (!context.allowDiagonalDescend || !MovementHelper.canWalkOn(context.bsi, destX, y - 2, destZ) || !MovementHelper.canWalkThrough(context.bsi, destX, y - 1, destZ, destWalkOn)) {
/*     */           return;
/*     */         }
/*     */       } 
/*     */     } 
/* 135 */     double multiplier = 4.63284688441047D;
/*     */     
/* 137 */     if (destWalkOn.method_26204() == class_2246.field_10114) {
/* 138 */       multiplier += 2.316423442205235D;
/* 139 */     } else if (destWalkOn.method_26204() == class_2246.field_10382) {
/* 140 */       multiplier += context.walkOnWaterOnePenalty * SQRT_2;
/*     */     } 
/* 142 */     class_2248 fromDown = context.get(x, y - 1, z).method_26204();
/* 143 */     if (fromDown == class_2246.field_9983 || fromDown == class_2246.field_10597) {
/*     */       return;
/*     */     }
/* 146 */     if (fromDown == class_2246.field_10114) {
/* 147 */       multiplier += 2.316423442205235D;
/*     */     }
/* 149 */     class_2680 cuttingOver1 = context.get(x, y - 1, destZ);
/* 150 */     if (cuttingOver1.method_26204() == class_2246.field_10092 || MovementHelper.isLava(cuttingOver1)) {
/*     */       return;
/*     */     }
/* 153 */     class_2680 cuttingOver2 = context.get(destX, y - 1, z);
/* 154 */     if (cuttingOver2.method_26204() == class_2246.field_10092 || MovementHelper.isLava(cuttingOver2)) {
/*     */       return;
/*     */     }
/* 157 */     boolean water = false;
/* 158 */     class_2680 startState = context.get(x, y, z);
/* 159 */     class_2248 startIn = startState.method_26204();
/* 160 */     if (MovementHelper.isWater(startState) || MovementHelper.isWater(destInto)) {
/* 161 */       if (ascend) {
/*     */         return;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 167 */       multiplier = context.waterWalkSpeed;
/* 168 */       water = true;
/*     */     } 
/* 170 */     class_2680 pb0 = context.get(x, y, destZ);
/* 171 */     class_2680 pb2 = context.get(destX, y, z);
/* 172 */     if (ascend) {
/* 173 */       boolean ATop = MovementHelper.canWalkThrough(context.bsi, x, y + 2, destZ);
/* 174 */       boolean AMid = MovementHelper.canWalkThrough(context.bsi, x, y + 1, destZ);
/* 175 */       boolean ALow = MovementHelper.canWalkThrough(context.bsi, x, y, destZ, pb0);
/* 176 */       boolean BTop = MovementHelper.canWalkThrough(context.bsi, destX, y + 2, z);
/* 177 */       boolean BMid = MovementHelper.canWalkThrough(context.bsi, destX, y + 1, z);
/* 178 */       boolean BLow = MovementHelper.canWalkThrough(context.bsi, destX, y, z, pb2);
/* 179 */       if (((!ATop || !AMid || !ALow) && (!BTop || !BMid || !BLow)) || 
/* 180 */         MovementHelper.avoidWalkingInto(pb0) || 
/* 181 */         MovementHelper.avoidWalkingInto(pb2) || (ATop && AMid && 
/* 182 */         MovementHelper.canWalkOn(context.bsi, x, y, destZ, pb0)) || (BTop && BMid && 
/* 183 */         MovementHelper.canWalkOn(context.bsi, destX, y, z, pb2)) || (!ATop && AMid && ALow) || (!BTop && BMid && BLow)) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 188 */       res.cost = multiplier * SQRT_2 + JUMP_ONE_BLOCK_COST;
/* 189 */       res.x = destX;
/* 190 */       res.z = destZ;
/* 191 */       res.y = y + 1;
/*     */       return;
/*     */     } 
/* 194 */     double optionA = MovementHelper.getMiningDurationTicks(context, x, y, destZ, pb0, false);
/* 195 */     double optionB = MovementHelper.getMiningDurationTicks(context, destX, y, z, pb2, false);
/* 196 */     if (optionA != 0.0D && optionB != 0.0D) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 201 */     class_2680 pb1 = context.get(x, y + 1, destZ);
/* 202 */     optionA += MovementHelper.getMiningDurationTicks(context, x, y + 1, destZ, pb1, true);
/* 203 */     if (optionA != 0.0D && optionB != 0.0D) {
/*     */       return;
/*     */     }
/*     */     
/* 207 */     class_2680 pb3 = context.get(destX, y + 1, z);
/* 208 */     if (optionA == 0.0D && ((MovementHelper.avoidWalkingInto(pb2) && pb2.method_26204() != class_2246.field_10382) || MovementHelper.avoidWalkingInto(pb3))) {
/*     */       return;
/*     */     }
/*     */     
/* 212 */     optionB += MovementHelper.getMiningDurationTicks(context, destX, y + 1, z, pb3, true);
/* 213 */     if (optionA != 0.0D && optionB != 0.0D) {
/*     */       return;
/*     */     }
/*     */     
/* 217 */     if (optionB == 0.0D && ((MovementHelper.avoidWalkingInto(pb0) && pb0.method_26204() != class_2246.field_10382) || MovementHelper.avoidWalkingInto(pb1))) {
/*     */       return;
/*     */     }
/*     */     
/* 221 */     if (optionA != 0.0D || optionB != 0.0D) {
/* 222 */       multiplier *= SQRT_2 - 0.001D;
/* 223 */       if (startIn == class_2246.field_9983 || startIn == class_2246.field_10597)
/*     */       {
/*     */         return;
/*     */       
/*     */       }
/*     */     }
/* 229 */     else if (context.canSprint && !water) {
/*     */ 
/*     */ 
/*     */       
/* 233 */       multiplier *= 0.7692444761225944D;
/*     */     } 
/*     */     
/* 236 */     res.cost = multiplier * SQRT_2;
/* 237 */     if (descend) {
/* 238 */       res.cost += Math.max(FALL_N_BLOCKS_COST[1], 0.9265693768820937D);
/* 239 */       res.y = y - 1;
/*     */     } else {
/* 241 */       res.y = y;
/*     */     } 
/* 243 */     res.x = destX;
/* 244 */     res.z = destZ;
/*     */   }
/*     */ 
/*     */   
/*     */   public MovementState updateState(MovementState state) {
/* 249 */     super.updateState(state);
/* 250 */     if (state.getStatus() != MovementStatus.RUNNING) {
/* 251 */       return state;
/*     */     }
/*     */     
/* 254 */     if (this.ctx.playerFeet().equals(this.dest))
/* 255 */       return state.setStatus(MovementStatus.SUCCESS); 
/* 256 */     if (!playerInValidPosition() && (!MovementHelper.isLiquid(this.ctx, (class_2338)this.src) || !getValidPositions().contains(this.ctx.playerFeet().up()))) {
/* 257 */       return state.setStatus(MovementStatus.UNREACHABLE);
/*     */     }
/* 259 */     if (this.dest.y > this.src.y && this.ctx.player().method_23318() < this.src.y + 0.1D && (this.ctx.player()).field_5976) {
/* 260 */       state.setInput(Input.JUMP, true);
/*     */     }
/* 262 */     if (sprint()) {
/* 263 */       state.setInput(Input.SPRINT, true);
/*     */     }
/* 265 */     MovementHelper.moveTowards(this.ctx, state, (class_2338)this.dest);
/* 266 */     return state;
/*     */   }
/*     */   
/*     */   private boolean sprint() {
/* 270 */     if (MovementHelper.isLiquid(this.ctx, (class_2338)this.ctx.playerFeet()) && !((Boolean)(Baritone.settings()).sprintInWater.value).booleanValue()) {
/* 271 */       return false;
/*     */     }
/* 273 */     for (int i = 0; i < 4; i++) {
/* 274 */       if (!MovementHelper.canWalkThrough(this.ctx, this.positionsToBreak[i])) {
/* 275 */         return false;
/*     */       }
/*     */     } 
/* 278 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean prepared(MovementState state) {
/* 283 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<class_2338> toBreak(BlockStateInterface bsi) {
/* 288 */     if (this.toBreakCached != null) {
/* 289 */       return this.toBreakCached;
/*     */     }
/* 291 */     List<class_2338> result = new ArrayList<>();
/* 292 */     for (int i = 4; i < 6; i++) {
/* 293 */       if (!MovementHelper.canWalkThrough(bsi, (this.positionsToBreak[i]).x, (this.positionsToBreak[i]).y, (this.positionsToBreak[i]).z)) {
/* 294 */         result.add(this.positionsToBreak[i]);
/*     */       }
/*     */     } 
/* 297 */     this.toBreakCached = result;
/* 298 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<class_2338> toWalkInto(BlockStateInterface bsi) {
/* 303 */     if (this.toWalkIntoCached == null) {
/* 304 */       this.toWalkIntoCached = new ArrayList();
/*     */     }
/* 306 */     List<class_2338> result = new ArrayList<>();
/* 307 */     for (int i = 0; i < 4; i++) {
/* 308 */       if (!MovementHelper.canWalkThrough(bsi, (this.positionsToBreak[i]).x, (this.positionsToBreak[i]).y, (this.positionsToBreak[i]).z)) {
/* 309 */         result.add(this.positionsToBreak[i]);
/*     */       }
/*     */     } 
/* 312 */     this.toWalkIntoCached = result;
/* 313 */     return this.toWalkIntoCached;
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\pathing\movement\movements\MovementDiagonal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */