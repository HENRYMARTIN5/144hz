/*    */ package baritone.pathing.movement.movements;
/*    */ 
/*    */ import baritone.api.IBaritone;
/*    */ import baritone.api.pathing.movement.MovementStatus;
/*    */ import baritone.api.utils.BetterBlockPos;
/*    */ import baritone.pathing.movement.CalculationContext;
/*    */ import baritone.pathing.movement.Movement;
/*    */ import baritone.pathing.movement.MovementHelper;
/*    */ import baritone.pathing.movement.MovementState;
/*    */ import com.google.common.collect.ImmutableSet;
/*    */ import java.util.Set;
/*    */ import net.minecraft.class_2246;
/*    */ import net.minecraft.class_2248;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_2680;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MovementDownward
/*    */   extends Movement
/*    */ {
/* 36 */   private int numTicks = 0;
/*    */   
/*    */   public MovementDownward(IBaritone baritone, BetterBlockPos start, BetterBlockPos end) {
/* 39 */     super(baritone, start, end, new BetterBlockPos[] { end });
/*    */   }
/*    */ 
/*    */   
/*    */   public void reset() {
/* 44 */     super.reset();
/* 45 */     this.numTicks = 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public double calculateCost(CalculationContext context) {
/* 50 */     return cost(context, this.src.x, this.src.y, this.src.z);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Set<BetterBlockPos> calculateValidPositions() {
/* 55 */     return (Set<BetterBlockPos>)ImmutableSet.of(this.src, this.dest);
/*    */   }
/*    */   
/*    */   public static double cost(CalculationContext context, int x, int y, int z) {
/* 59 */     if (!context.allowDownward) {
/* 60 */       return 1000000.0D;
/*    */     }
/* 62 */     if (!MovementHelper.canWalkOn(context.bsi, x, y - 2, z)) {
/* 63 */       return 1000000.0D;
/*    */     }
/* 65 */     class_2680 down = context.get(x, y - 1, z);
/* 66 */     class_2248 downBlock = down.method_26204();
/* 67 */     if (downBlock == class_2246.field_9983 || downBlock == class_2246.field_10597) {
/* 68 */       return 6.666666666666667D;
/*    */     }
/*    */     
/* 71 */     return FALL_N_BLOCKS_COST[1] + MovementHelper.getMiningDurationTicks(context, x, y - 1, z, down, false);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public MovementState updateState(MovementState state) {
/* 77 */     super.updateState(state);
/* 78 */     if (state.getStatus() != MovementStatus.RUNNING) {
/* 79 */       return state;
/*    */     }
/*    */     
/* 82 */     if (this.ctx.playerFeet().equals(this.dest))
/* 83 */       return state.setStatus(MovementStatus.SUCCESS); 
/* 84 */     if (!playerInValidPosition()) {
/* 85 */       return state.setStatus(MovementStatus.UNREACHABLE);
/*    */     }
/* 87 */     double diffX = this.ctx.player().method_23317() - this.dest.method_10263() + 0.5D;
/* 88 */     double diffZ = this.ctx.player().method_23321() - this.dest.method_10260() + 0.5D;
/* 89 */     double ab = Math.sqrt(diffX * diffX + diffZ * diffZ);
/*    */     
/* 91 */     if (this.numTicks++ < 10 && ab < 0.2D) {
/* 92 */       return state;
/*    */     }
/* 94 */     MovementHelper.moveTowards(this.ctx, state, (class_2338)this.positionsToBreak[0]);
/* 95 */     return state;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\pathing\movement\movements\MovementDownward.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */