/*     */ package baritone.pathing.movement;
/*     */ 
/*     */ import baritone.api.utils.BetterBlockPos;
/*     */ import baritone.pathing.movement.movements.MovementAscend;
/*     */ import baritone.pathing.movement.movements.MovementDescend;
/*     */ import baritone.pathing.movement.movements.MovementDiagonal;
/*     */ import baritone.pathing.movement.movements.MovementDownward;
/*     */ import baritone.pathing.movement.movements.MovementFall;
/*     */ import baritone.pathing.movement.movements.MovementParkour;
/*     */ import baritone.pathing.movement.movements.MovementPillar;
/*     */ import baritone.pathing.movement.movements.MovementTraverse;
/*     */ import baritone.utils.pathing.MutableMoveResult;
/*     */ import net.minecraft.class_2350;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum Moves
/*     */ {
/*  31 */   DOWNWARD(0, -1, 0)
/*     */   {
/*     */     public Movement apply0(CalculationContext context, BetterBlockPos src) {
/*  34 */       return (Movement)new MovementDownward(context.getBaritone(), src, src.down());
/*     */     }
/*     */ 
/*     */     
/*     */     public double cost(CalculationContext context, int x, int y, int z) {
/*  39 */       return MovementDownward.cost(context, x, y, z);
/*     */     }
/*     */   },
/*     */   
/*  43 */   PILLAR(0, 1, 0)
/*     */   {
/*     */     public Movement apply0(CalculationContext context, BetterBlockPos src) {
/*  46 */       return (Movement)new MovementPillar(context.getBaritone(), src, src.up());
/*     */     }
/*     */ 
/*     */     
/*     */     public double cost(CalculationContext context, int x, int y, int z) {
/*  51 */       return MovementPillar.cost(context, x, y, z);
/*     */     }
/*     */   },
/*     */   
/*  55 */   TRAVERSE_NORTH(0, 0, -1)
/*     */   {
/*     */     public Movement apply0(CalculationContext context, BetterBlockPos src) {
/*  58 */       return (Movement)new MovementTraverse(context.getBaritone(), src, src.north());
/*     */     }
/*     */ 
/*     */     
/*     */     public double cost(CalculationContext context, int x, int y, int z) {
/*  63 */       return MovementTraverse.cost(context, x, y, z, x, z - 1);
/*     */     }
/*     */   },
/*     */   
/*  67 */   TRAVERSE_SOUTH(0, 0, 1)
/*     */   {
/*     */     public Movement apply0(CalculationContext context, BetterBlockPos src) {
/*  70 */       return (Movement)new MovementTraverse(context.getBaritone(), src, src.south());
/*     */     }
/*     */ 
/*     */     
/*     */     public double cost(CalculationContext context, int x, int y, int z) {
/*  75 */       return MovementTraverse.cost(context, x, y, z, x, z + 1);
/*     */     }
/*     */   },
/*     */   
/*  79 */   TRAVERSE_EAST(1, 0, 0)
/*     */   {
/*     */     public Movement apply0(CalculationContext context, BetterBlockPos src) {
/*  82 */       return (Movement)new MovementTraverse(context.getBaritone(), src, src.east());
/*     */     }
/*     */ 
/*     */     
/*     */     public double cost(CalculationContext context, int x, int y, int z) {
/*  87 */       return MovementTraverse.cost(context, x, y, z, x + 1, z);
/*     */     }
/*     */   },
/*     */   
/*  91 */   TRAVERSE_WEST(-1, 0, 0)
/*     */   {
/*     */     public Movement apply0(CalculationContext context, BetterBlockPos src) {
/*  94 */       return (Movement)new MovementTraverse(context.getBaritone(), src, src.west());
/*     */     }
/*     */ 
/*     */     
/*     */     public double cost(CalculationContext context, int x, int y, int z) {
/*  99 */       return MovementTraverse.cost(context, x, y, z, x - 1, z);
/*     */     }
/*     */   },
/*     */   
/* 103 */   ASCEND_NORTH(0, 1, -1)
/*     */   {
/*     */     public Movement apply0(CalculationContext context, BetterBlockPos src) {
/* 106 */       return (Movement)new MovementAscend(context.getBaritone(), src, new BetterBlockPos(src.x, src.y + 1, src.z - 1));
/*     */     }
/*     */ 
/*     */     
/*     */     public double cost(CalculationContext context, int x, int y, int z) {
/* 111 */       return MovementAscend.cost(context, x, y, z, x, z - 1);
/*     */     }
/*     */   },
/*     */   
/* 115 */   ASCEND_SOUTH(0, 1, 1)
/*     */   {
/*     */     public Movement apply0(CalculationContext context, BetterBlockPos src) {
/* 118 */       return (Movement)new MovementAscend(context.getBaritone(), src, new BetterBlockPos(src.x, src.y + 1, src.z + 1));
/*     */     }
/*     */ 
/*     */     
/*     */     public double cost(CalculationContext context, int x, int y, int z) {
/* 123 */       return MovementAscend.cost(context, x, y, z, x, z + 1);
/*     */     }
/*     */   },
/*     */   
/* 127 */   ASCEND_EAST(1, 1, 0)
/*     */   {
/*     */     public Movement apply0(CalculationContext context, BetterBlockPos src) {
/* 130 */       return (Movement)new MovementAscend(context.getBaritone(), src, new BetterBlockPos(src.x + 1, src.y + 1, src.z));
/*     */     }
/*     */ 
/*     */     
/*     */     public double cost(CalculationContext context, int x, int y, int z) {
/* 135 */       return MovementAscend.cost(context, x, y, z, x + 1, z);
/*     */     }
/*     */   },
/*     */   
/* 139 */   ASCEND_WEST(-1, 1, 0)
/*     */   {
/*     */     public Movement apply0(CalculationContext context, BetterBlockPos src) {
/* 142 */       return (Movement)new MovementAscend(context.getBaritone(), src, new BetterBlockPos(src.x - 1, src.y + 1, src.z));
/*     */     }
/*     */ 
/*     */     
/*     */     public double cost(CalculationContext context, int x, int y, int z) {
/* 147 */       return MovementAscend.cost(context, x, y, z, x - 1, z);
/*     */     }
/*     */   },
/*     */   
/* 151 */   DESCEND_EAST(1, -1, 0, false, true)
/*     */   {
/*     */     public Movement apply0(CalculationContext context, BetterBlockPos src) {
/* 154 */       MutableMoveResult res = new MutableMoveResult();
/* 155 */       apply(context, src.x, src.y, src.z, res);
/* 156 */       if (res.y == src.y - 1) {
/* 157 */         return (Movement)new MovementDescend(context.getBaritone(), src, new BetterBlockPos(res.x, res.y, res.z));
/*     */       }
/* 159 */       return (Movement)new MovementFall(context.getBaritone(), src, new BetterBlockPos(res.x, res.y, res.z));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void apply(CalculationContext context, int x, int y, int z, MutableMoveResult result) {
/* 165 */       MovementDescend.cost(context, x, y, z, x + 1, z, result);
/*     */     }
/*     */   },
/*     */   
/* 169 */   DESCEND_WEST(-1, -1, 0, false, true)
/*     */   {
/*     */     public Movement apply0(CalculationContext context, BetterBlockPos src) {
/* 172 */       MutableMoveResult res = new MutableMoveResult();
/* 173 */       apply(context, src.x, src.y, src.z, res);
/* 174 */       if (res.y == src.y - 1) {
/* 175 */         return (Movement)new MovementDescend(context.getBaritone(), src, new BetterBlockPos(res.x, res.y, res.z));
/*     */       }
/* 177 */       return (Movement)new MovementFall(context.getBaritone(), src, new BetterBlockPos(res.x, res.y, res.z));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void apply(CalculationContext context, int x, int y, int z, MutableMoveResult result) {
/* 183 */       MovementDescend.cost(context, x, y, z, x - 1, z, result);
/*     */     }
/*     */   },
/*     */   
/* 187 */   DESCEND_NORTH(0, -1, -1, false, true)
/*     */   {
/*     */     public Movement apply0(CalculationContext context, BetterBlockPos src) {
/* 190 */       MutableMoveResult res = new MutableMoveResult();
/* 191 */       apply(context, src.x, src.y, src.z, res);
/* 192 */       if (res.y == src.y - 1) {
/* 193 */         return (Movement)new MovementDescend(context.getBaritone(), src, new BetterBlockPos(res.x, res.y, res.z));
/*     */       }
/* 195 */       return (Movement)new MovementFall(context.getBaritone(), src, new BetterBlockPos(res.x, res.y, res.z));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void apply(CalculationContext context, int x, int y, int z, MutableMoveResult result) {
/* 201 */       MovementDescend.cost(context, x, y, z, x, z - 1, result);
/*     */     }
/*     */   },
/*     */   
/* 205 */   DESCEND_SOUTH(0, -1, 1, false, true)
/*     */   {
/*     */     public Movement apply0(CalculationContext context, BetterBlockPos src) {
/* 208 */       MutableMoveResult res = new MutableMoveResult();
/* 209 */       apply(context, src.x, src.y, src.z, res);
/* 210 */       if (res.y == src.y - 1) {
/* 211 */         return (Movement)new MovementDescend(context.getBaritone(), src, new BetterBlockPos(res.x, res.y, res.z));
/*     */       }
/* 213 */       return (Movement)new MovementFall(context.getBaritone(), src, new BetterBlockPos(res.x, res.y, res.z));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void apply(CalculationContext context, int x, int y, int z, MutableMoveResult result) {
/* 219 */       MovementDescend.cost(context, x, y, z, x, z + 1, result);
/*     */     }
/*     */   },
/*     */   
/* 223 */   DIAGONAL_NORTHEAST(1, 0, -1, false, true)
/*     */   {
/*     */     public Movement apply0(CalculationContext context, BetterBlockPos src) {
/* 226 */       MutableMoveResult res = new MutableMoveResult();
/* 227 */       apply(context, src.x, src.y, src.z, res);
/* 228 */       return (Movement)new MovementDiagonal(context.getBaritone(), src, class_2350.field_11043, class_2350.field_11034, res.y - src.y);
/*     */     }
/*     */ 
/*     */     
/*     */     public void apply(CalculationContext context, int x, int y, int z, MutableMoveResult result) {
/* 233 */       MovementDiagonal.cost(context, x, y, z, x + 1, z - 1, result);
/*     */     }
/*     */   },
/*     */   
/* 237 */   DIAGONAL_NORTHWEST(-1, 0, -1, false, true)
/*     */   {
/*     */     public Movement apply0(CalculationContext context, BetterBlockPos src) {
/* 240 */       MutableMoveResult res = new MutableMoveResult();
/* 241 */       apply(context, src.x, src.y, src.z, res);
/* 242 */       return (Movement)new MovementDiagonal(context.getBaritone(), src, class_2350.field_11043, class_2350.field_11039, res.y - src.y);
/*     */     }
/*     */ 
/*     */     
/*     */     public void apply(CalculationContext context, int x, int y, int z, MutableMoveResult result) {
/* 247 */       MovementDiagonal.cost(context, x, y, z, x - 1, z - 1, result);
/*     */     }
/*     */   },
/*     */   
/* 251 */   DIAGONAL_SOUTHEAST(1, 0, 1, false, true)
/*     */   {
/*     */     public Movement apply0(CalculationContext context, BetterBlockPos src) {
/* 254 */       MutableMoveResult res = new MutableMoveResult();
/* 255 */       apply(context, src.x, src.y, src.z, res);
/* 256 */       return (Movement)new MovementDiagonal(context.getBaritone(), src, class_2350.field_11035, class_2350.field_11034, res.y - src.y);
/*     */     }
/*     */ 
/*     */     
/*     */     public void apply(CalculationContext context, int x, int y, int z, MutableMoveResult result) {
/* 261 */       MovementDiagonal.cost(context, x, y, z, x + 1, z + 1, result);
/*     */     }
/*     */   },
/*     */   
/* 265 */   DIAGONAL_SOUTHWEST(-1, 0, 1, false, true)
/*     */   {
/*     */     public Movement apply0(CalculationContext context, BetterBlockPos src) {
/* 268 */       MutableMoveResult res = new MutableMoveResult();
/* 269 */       apply(context, src.x, src.y, src.z, res);
/* 270 */       return (Movement)new MovementDiagonal(context.getBaritone(), src, class_2350.field_11035, class_2350.field_11039, res.y - src.y);
/*     */     }
/*     */ 
/*     */     
/*     */     public void apply(CalculationContext context, int x, int y, int z, MutableMoveResult result) {
/* 275 */       MovementDiagonal.cost(context, x, y, z, x - 1, z + 1, result);
/*     */     }
/*     */   },
/*     */   
/* 279 */   PARKOUR_NORTH(0, 0, -4, true, true)
/*     */   {
/*     */     public Movement apply0(CalculationContext context, BetterBlockPos src) {
/* 282 */       return (Movement)MovementParkour.cost(context, src, class_2350.field_11043);
/*     */     }
/*     */ 
/*     */     
/*     */     public void apply(CalculationContext context, int x, int y, int z, MutableMoveResult result) {
/* 287 */       MovementParkour.cost(context, x, y, z, class_2350.field_11043, result);
/*     */     }
/*     */   },
/*     */   
/* 291 */   PARKOUR_SOUTH(0, 0, 4, true, true)
/*     */   {
/*     */     public Movement apply0(CalculationContext context, BetterBlockPos src) {
/* 294 */       return (Movement)MovementParkour.cost(context, src, class_2350.field_11035);
/*     */     }
/*     */ 
/*     */     
/*     */     public void apply(CalculationContext context, int x, int y, int z, MutableMoveResult result) {
/* 299 */       MovementParkour.cost(context, x, y, z, class_2350.field_11035, result);
/*     */     }
/*     */   },
/*     */   
/* 303 */   PARKOUR_EAST(4, 0, 0, true, true)
/*     */   {
/*     */     public Movement apply0(CalculationContext context, BetterBlockPos src) {
/* 306 */       return (Movement)MovementParkour.cost(context, src, class_2350.field_11034);
/*     */     }
/*     */ 
/*     */     
/*     */     public void apply(CalculationContext context, int x, int y, int z, MutableMoveResult result) {
/* 311 */       MovementParkour.cost(context, x, y, z, class_2350.field_11034, result);
/*     */     }
/*     */   },
/*     */   
/* 315 */   PARKOUR_WEST(-4, 0, 0, true, true)
/*     */   {
/*     */     public Movement apply0(CalculationContext context, BetterBlockPos src) {
/* 318 */       return (Movement)MovementParkour.cost(context, src, class_2350.field_11039);
/*     */     }
/*     */ 
/*     */     
/*     */     public void apply(CalculationContext context, int x, int y, int z, MutableMoveResult result) {
/* 323 */       MovementParkour.cost(context, x, y, z, class_2350.field_11039, result);
/*     */     }
/*     */   };
/*     */ 
/*     */   
/*     */   public final boolean dynamicXZ;
/*     */   public final boolean dynamicY;
/*     */   public final int xOffset;
/*     */   public final int yOffset;
/*     */   public final int zOffset;
/*     */   
/*     */   Moves(int x, int y, int z, boolean dynamicXZ, boolean dynamicY) {
/* 335 */     this.xOffset = x;
/* 336 */     this.yOffset = y;
/* 337 */     this.zOffset = z;
/* 338 */     this.dynamicXZ = dynamicXZ;
/* 339 */     this.dynamicY = dynamicY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void apply(CalculationContext context, int x, int y, int z, MutableMoveResult result) {
/* 349 */     if (this.dynamicXZ || this.dynamicY) {
/* 350 */       throw new UnsupportedOperationException();
/*     */     }
/* 352 */     result.x = x + this.xOffset;
/* 353 */     result.y = y + this.yOffset;
/* 354 */     result.z = z + this.zOffset;
/* 355 */     result.cost = cost(context, x, y, z);
/*     */   }
/*     */   
/*     */   public double cost(CalculationContext context, int x, int y, int z) {
/* 359 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public abstract Movement apply0(CalculationContext paramCalculationContext, BetterBlockPos paramBetterBlockPos);
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\pathing\movement\Moves.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */