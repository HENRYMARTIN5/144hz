/*     */ package baritone.pathing.calc.openset;
/*     */ 
/*     */ import baritone.pathing.calc.PathNode;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BinaryHeapOpenSet
/*     */   implements IOpenSet
/*     */ {
/*     */   private static final int INITIAL_CAPACITY = 1024;
/*     */   private PathNode[] array;
/*     */   private int size;
/*     */   
/*     */   public BinaryHeapOpenSet() {
/*  47 */     this(1024);
/*     */   }
/*     */   
/*     */   public BinaryHeapOpenSet(int size) {
/*  51 */     this.size = 0;
/*  52 */     this.array = new PathNode[size];
/*     */   }
/*     */   
/*     */   public int size() {
/*  56 */     return this.size;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void insert(PathNode value) {
/*  61 */     if (this.size >= this.array.length - 1) {
/*  62 */       this.array = Arrays.<PathNode>copyOf(this.array, this.array.length << 1);
/*     */     }
/*     */     
/*  65 */     value.heapPosition = ++this.size;
/*  66 */     this.array[this.size] = value;
/*  67 */     update(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void update(PathNode val) {
/*  72 */     int index = val.heapPosition;
/*  73 */     int parentInd = index >>> 1;
/*  74 */     double cost = val.combinedCost;
/*  75 */     PathNode parentNode = this.array[parentInd];
/*  76 */     while (index > 1 && parentNode.combinedCost > cost) {
/*  77 */       this.array[index] = parentNode;
/*  78 */       this.array[parentInd] = val;
/*  79 */       val.heapPosition = parentInd;
/*  80 */       parentNode.heapPosition = index;
/*  81 */       index = parentInd;
/*  82 */       parentInd = index >>> 1;
/*  83 */       parentNode = this.array[parentInd];
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isEmpty() {
/*  89 */     return (this.size == 0);
/*     */   }
/*     */   
/*     */   public final PathNode removeLowest() {
/*     */     PathNode smallerChildNode;
/*  94 */     if (this.size == 0) {
/*  95 */       throw new IllegalStateException();
/*     */     }
/*  97 */     PathNode result = this.array[1];
/*  98 */     PathNode val = this.array[this.size];
/*  99 */     this.array[1] = val;
/* 100 */     val.heapPosition = 1;
/* 101 */     this.array[this.size] = null;
/* 102 */     this.size--;
/* 103 */     result.heapPosition = -1;
/* 104 */     if (this.size < 2) {
/* 105 */       return result;
/*     */     }
/* 107 */     int index = 1;
/* 108 */     int smallerChild = 2;
/* 109 */     double cost = val.combinedCost;
/*     */     do {
/* 111 */       smallerChildNode = this.array[smallerChild];
/* 112 */       double smallerChildCost = smallerChildNode.combinedCost;
/* 113 */       if (smallerChild < this.size) {
/* 114 */         PathNode rightChildNode = this.array[smallerChild + 1];
/* 115 */         double rightChildCost = rightChildNode.combinedCost;
/* 116 */         if (smallerChildCost > rightChildCost) {
/* 117 */           smallerChild++;
/* 118 */           smallerChildCost = rightChildCost;
/* 119 */           smallerChildNode = rightChildNode;
/*     */         } 
/*     */       } 
/* 122 */       if (cost <= smallerChildCost) {
/*     */         break;
/*     */       }
/* 125 */       this.array[index] = smallerChildNode;
/* 126 */       this.array[smallerChild] = val;
/* 127 */       val.heapPosition = smallerChild;
/* 128 */       smallerChildNode.heapPosition = index;
/* 129 */       index = smallerChild;
/* 130 */     } while ((smallerChild <<= 1) <= this.size);
/* 131 */     return result;
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\pathing\calc\openset\BinaryHeapOpenSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */