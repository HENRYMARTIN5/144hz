/*     */ package baritone.pathing.path;
/*     */ 
/*     */ import baritone.api.pathing.calc.IPath;
/*     */ import baritone.api.pathing.goals.Goal;
/*     */ import baritone.api.pathing.movement.IMovement;
/*     */ import baritone.api.utils.BetterBlockPos;
/*     */ import baritone.utils.pathing.PathBase;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SplicedPath
/*     */   extends PathBase
/*     */ {
/*     */   private final List<BetterBlockPos> path;
/*     */   private final List<IMovement> movements;
/*     */   private final int numNodes;
/*     */   private final Goal goal;
/*     */   
/*     */   private SplicedPath(List<BetterBlockPos> path, List<IMovement> movements, int numNodesConsidered, Goal goal) {
/*  39 */     this.path = path;
/*  40 */     this.movements = movements;
/*  41 */     this.numNodes = numNodesConsidered;
/*  42 */     this.goal = goal;
/*  43 */     sanityCheck();
/*     */   }
/*     */ 
/*     */   
/*     */   public Goal getGoal() {
/*  48 */     return this.goal;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<IMovement> movements() {
/*  53 */     return Collections.unmodifiableList(this.movements);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<BetterBlockPos> positions() {
/*  58 */     return Collections.unmodifiableList(this.path);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getNumNodesConsidered() {
/*  63 */     return this.numNodes;
/*     */   }
/*     */ 
/*     */   
/*     */   public int length() {
/*  68 */     return this.path.size();
/*     */   }
/*     */   
/*     */   public static Optional<SplicedPath> trySplice(IPath first, IPath second, boolean allowOverlapCutoff) {
/*  72 */     if (second == null || first == null) {
/*  73 */       return Optional.empty();
/*     */     }
/*  75 */     if (!first.getDest().equals(second.getSrc())) {
/*  76 */       return Optional.empty();
/*     */     }
/*  78 */     HashSet<BetterBlockPos> secondPos = new HashSet<>(second.positions());
/*  79 */     int firstPositionInSecond = -1;
/*  80 */     for (int i = 0; i < first.length() - 1; i++) {
/*  81 */       if (secondPos.contains(first.positions().get(i))) {
/*  82 */         firstPositionInSecond = i;
/*     */         break;
/*     */       } 
/*     */     } 
/*  86 */     if (firstPositionInSecond != -1) {
/*  87 */       if (!allowOverlapCutoff) {
/*  88 */         return Optional.empty();
/*     */       }
/*     */     } else {
/*  91 */       firstPositionInSecond = first.length() - 1;
/*     */     } 
/*  93 */     int positionInSecond = second.positions().indexOf(first.positions().get(firstPositionInSecond));
/*  94 */     if (!allowOverlapCutoff && positionInSecond != 0) {
/*  95 */       throw new IllegalStateException();
/*     */     }
/*  97 */     List<BetterBlockPos> positions = new ArrayList<>();
/*  98 */     List<IMovement> movements = new ArrayList<>();
/*  99 */     positions.addAll(first.positions().subList(0, firstPositionInSecond + 1));
/* 100 */     movements.addAll(first.movements().subList(0, firstPositionInSecond));
/*     */     
/* 102 */     positions.addAll(second.positions().subList(positionInSecond + 1, second.length()));
/* 103 */     movements.addAll(second.movements().subList(positionInSecond, second.length() - 1));
/* 104 */     return Optional.of(new SplicedPath(positions, movements, first.getNumNodesConsidered() + second.getNumNodesConsidered(), first.getGoal()));
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\pathing\path\SplicedPath.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */