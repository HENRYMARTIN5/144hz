/*     */ package baritone.pathing.path;
/*     */ 
/*     */ import baritone.Baritone;
/*     */ import baritone.api.IBaritone;
/*     */ import baritone.api.pathing.calc.IPath;
/*     */ import baritone.api.pathing.movement.IMovement;
/*     */ import baritone.api.pathing.movement.MovementStatus;
/*     */ import baritone.api.pathing.path.IPathExecutor;
/*     */ import baritone.api.utils.BetterBlockPos;
/*     */ import baritone.api.utils.Helper;
/*     */ import baritone.api.utils.IPlayerContext;
/*     */ import baritone.api.utils.RotationUtils;
/*     */ import baritone.api.utils.VecUtils;
/*     */ import baritone.api.utils.input.Input;
/*     */ import baritone.behavior.PathingBehavior;
/*     */ import baritone.pathing.calc.AbstractNodeCostSearch;
/*     */ import baritone.pathing.movement.CalculationContext;
/*     */ import baritone.pathing.movement.Movement;
/*     */ import baritone.pathing.movement.MovementHelper;
/*     */ import baritone.pathing.movement.movements.MovementAscend;
/*     */ import baritone.pathing.movement.movements.MovementDescend;
/*     */ import baritone.pathing.movement.movements.MovementFall;
/*     */ import baritone.pathing.movement.movements.MovementTraverse;
/*     */ import baritone.utils.BlockStateInterface;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2382;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_3545;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PathExecutor
/*     */   implements IPathExecutor, Helper
/*     */ {
/*     */   private static final double MAX_MAX_DIST_FROM_PATH = 3.0D;
/*     */   private static final double MAX_DIST_FROM_PATH = 2.0D;
/*     */   private static final double MAX_TICKS_AWAY = 200.0D;
/*     */   private final IPath path;
/*     */   private int pathPosition;
/*     */   private int ticksAway;
/*     */   private int ticksOnCurrent;
/*     */   private Double currentMovementOriginalCostEstimate;
/*     */   private Integer costEstimateIndex;
/*     */   private boolean failed;
/*     */   private boolean recalcBP = true;
/*  72 */   private HashSet<class_2338> toBreak = new HashSet<>();
/*  73 */   private HashSet<class_2338> toPlace = new HashSet<>();
/*  74 */   private HashSet<class_2338> toWalkInto = new HashSet<>();
/*     */   
/*     */   private PathingBehavior behavior;
/*     */   
/*     */   private IPlayerContext ctx;
/*     */   private boolean sprintNextTick;
/*     */   
/*     */   public PathExecutor(PathingBehavior behavior, IPath path) {
/*  82 */     this.behavior = behavior;
/*  83 */     this.ctx = behavior.ctx;
/*  84 */     this.path = path;
/*  85 */     this.pathPosition = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean onTick() {
/*  95 */     if (this.pathPosition == this.path.length() - 1) {
/*  96 */       this.pathPosition++;
/*     */     }
/*  98 */     if (this.pathPosition >= this.path.length()) {
/*  99 */       return true;
/*     */     }
/* 101 */     Movement movement = this.path.movements().get(this.pathPosition);
/* 102 */     BetterBlockPos whereAmI = this.ctx.playerFeet();
/* 103 */     if (!movement.getValidPositions().contains(whereAmI)) {
/* 104 */       int j; for (j = 0; j < this.pathPosition && j < this.path.length(); j++) {
/* 105 */         if (((Movement)this.path.movements().get(j)).getValidPositions().contains(whereAmI)) {
/* 106 */           int previousPos = this.pathPosition;
/* 107 */           this.pathPosition = j;
/* 108 */           for (int k = this.pathPosition; k <= previousPos; k++) {
/* 109 */             ((IMovement)this.path.movements().get(k)).reset();
/*     */           }
/* 111 */           onChangeInPathPosition();
/* 112 */           onTick();
/* 113 */           return false;
/*     */         } 
/*     */       } 
/* 116 */       for (j = this.pathPosition + 3; j < this.path.length() - 1; j++) {
/*     */         
/* 118 */         if (((Movement)this.path.movements().get(j)).getValidPositions().contains(whereAmI)) {
/* 119 */           if (j - this.pathPosition > 2) {
/* 120 */             logDebug("Skipping forward " + (j - this.pathPosition) + " steps, to " + j);
/*     */           }
/*     */           
/* 123 */           this.pathPosition = j - 1;
/* 124 */           onChangeInPathPosition();
/* 125 */           onTick();
/* 126 */           return false;
/*     */         } 
/*     */       } 
/*     */     } 
/* 130 */     class_3545<Double, class_2338> status = closestPathPos(this.path);
/* 131 */     if (possiblyOffPath(status, 2.0D)) {
/* 132 */       this.ticksAway++;
/* 133 */       System.out.println("FAR AWAY FROM PATH FOR " + this.ticksAway + " TICKS. Current distance: " + status.method_15442() + ". Threshold: " + 2.0D);
/* 134 */       if (this.ticksAway > 200.0D) {
/* 135 */         logDebug("Too far away from path for too long, cancelling path");
/* 136 */         cancel();
/* 137 */         return false;
/*     */       } 
/*     */     } else {
/* 140 */       this.ticksAway = 0;
/*     */     } 
/* 142 */     if (possiblyOffPath(status, 3.0D)) {
/* 143 */       logDebug("too far from path");
/* 144 */       cancel();
/* 145 */       return false;
/*     */     } 
/*     */     
/* 148 */     BlockStateInterface bsi = new BlockStateInterface(this.ctx);
/* 149 */     for (int i = this.pathPosition - 10; i < this.pathPosition + 10; i++) {
/* 150 */       if (i >= 0 && i < this.path.movements().size()) {
/*     */ 
/*     */         
/* 153 */         Movement m = this.path.movements().get(i);
/* 154 */         List<class_2338> prevBreak = m.toBreak(bsi);
/* 155 */         List<class_2338> prevPlace = m.toPlace(bsi);
/* 156 */         List<class_2338> prevWalkInto = m.toWalkInto(bsi);
/* 157 */         m.resetBlockCache();
/* 158 */         if (!prevBreak.equals(m.toBreak(bsi))) {
/* 159 */           this.recalcBP = true;
/*     */         }
/* 161 */         if (!prevPlace.equals(m.toPlace(bsi))) {
/* 162 */           this.recalcBP = true;
/*     */         }
/* 164 */         if (!prevWalkInto.equals(m.toWalkInto(bsi)))
/* 165 */           this.recalcBP = true; 
/*     */       } 
/*     */     } 
/* 168 */     if (this.recalcBP) {
/* 169 */       HashSet<class_2338> newBreak = new HashSet<>();
/* 170 */       HashSet<class_2338> newPlace = new HashSet<>();
/* 171 */       HashSet<class_2338> newWalkInto = new HashSet<>();
/* 172 */       for (int j = this.pathPosition; j < this.path.movements().size(); j++) {
/* 173 */         Movement m = this.path.movements().get(j);
/* 174 */         newBreak.addAll(m.toBreak(bsi));
/* 175 */         newPlace.addAll(m.toPlace(bsi));
/* 176 */         newWalkInto.addAll(m.toWalkInto(bsi));
/*     */       } 
/* 178 */       this.toBreak = newBreak;
/* 179 */       this.toPlace = newPlace;
/* 180 */       this.toWalkInto = newWalkInto;
/* 181 */       this.recalcBP = false;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 187 */     if (this.pathPosition < this.path.movements().size() - 1) {
/* 188 */       IMovement next = this.path.movements().get(this.pathPosition + 1);
/* 189 */       if (!this.behavior.baritone.bsi.worldContainsLoadedChunk((next.getDest()).x, (next.getDest()).z)) {
/* 190 */         logDebug("Pausing since destination is at edge of loaded chunks");
/* 191 */         clearKeys();
/* 192 */         return true;
/*     */       } 
/*     */     } 
/* 195 */     boolean canCancel = movement.safeToCancel();
/* 196 */     if (this.costEstimateIndex == null || this.costEstimateIndex.intValue() != this.pathPosition) {
/* 197 */       this.costEstimateIndex = Integer.valueOf(this.pathPosition);
/*     */       
/* 199 */       this.currentMovementOriginalCostEstimate = Double.valueOf(movement.getCost());
/* 200 */       for (int j = 1; j < ((Integer)(Baritone.settings()).costVerificationLookahead.value).intValue() && this.pathPosition + j < this.path.length() - 1; j++) {
/* 201 */         if (((Movement)this.path.movements().get(this.pathPosition + j)).calculateCost(this.behavior.secretInternalGetCalculationContext()) >= 1000000.0D && canCancel) {
/* 202 */           logDebug("Something has changed in the world and a future movement has become impossible. Cancelling.");
/* 203 */           cancel();
/* 204 */           return true;
/*     */         } 
/*     */       } 
/*     */     } 
/* 208 */     double currentCost = movement.recalculateCost(this.behavior.secretInternalGetCalculationContext());
/* 209 */     if (currentCost >= 1000000.0D && canCancel) {
/* 210 */       logDebug("Something has changed in the world and this movement has become impossible. Cancelling.");
/* 211 */       cancel();
/* 212 */       return true;
/*     */     } 
/* 214 */     if (!movement.calculatedWhileLoaded() && currentCost - this.currentMovementOriginalCostEstimate.doubleValue() > ((Double)(Baritone.settings()).maxCostIncrease.value).doubleValue() && canCancel) {
/*     */ 
/*     */       
/* 217 */       logDebug("Original cost " + this.currentMovementOriginalCostEstimate + " current cost " + currentCost + ". Cancelling.");
/* 218 */       cancel();
/* 219 */       return true;
/*     */     } 
/* 221 */     if (shouldPause()) {
/* 222 */       logDebug("Pausing since current best path is a backtrack");
/* 223 */       clearKeys();
/* 224 */       return true;
/*     */     } 
/* 226 */     MovementStatus movementStatus = movement.update();
/* 227 */     if (movementStatus == MovementStatus.UNREACHABLE || movementStatus == MovementStatus.FAILED) {
/* 228 */       logDebug("Movement returns status " + movementStatus);
/* 229 */       cancel();
/* 230 */       return true;
/*     */     } 
/* 232 */     if (movementStatus == MovementStatus.SUCCESS) {
/*     */       
/* 234 */       this.pathPosition++;
/* 235 */       onChangeInPathPosition();
/* 236 */       onTick();
/* 237 */       return true;
/*     */     } 
/* 239 */     this.sprintNextTick = shouldSprintNextTick();
/* 240 */     if (!this.sprintNextTick) {
/* 241 */       this.ctx.player().method_5728(false);
/*     */     }
/* 243 */     this.ticksOnCurrent++;
/* 244 */     if (this.ticksOnCurrent > this.currentMovementOriginalCostEstimate.doubleValue() + ((Integer)(Baritone.settings()).movementTimeoutTicks.value).intValue()) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 249 */       logDebug("This movement has taken too long (" + this.ticksOnCurrent + " ticks, expected " + this.currentMovementOriginalCostEstimate + "). Cancelling.");
/* 250 */       cancel();
/* 251 */       return true;
/*     */     } 
/*     */     
/* 254 */     return canCancel;
/*     */   }
/*     */   
/*     */   private class_3545<Double, class_2338> closestPathPos(IPath path) {
/* 258 */     double best = -1.0D;
/* 259 */     class_2338 bestPos = null;
/* 260 */     for (IMovement movement : path.movements()) {
/* 261 */       for (class_2338 pos : ((Movement)movement).getValidPositions()) {
/* 262 */         double dist = VecUtils.entityDistanceToCenter((class_1297)this.ctx.player(), pos);
/* 263 */         if (dist < best || best == -1.0D) {
/* 264 */           best = dist;
/* 265 */           bestPos = pos;
/*     */         } 
/*     */       } 
/*     */     } 
/* 269 */     return new class_3545(Double.valueOf(best), bestPos);
/*     */   }
/*     */   
/*     */   private boolean shouldPause() {
/* 273 */     Optional<AbstractNodeCostSearch> current = this.behavior.getInProgress();
/* 274 */     if (!current.isPresent()) {
/* 275 */       return false;
/*     */     }
/* 277 */     if (!this.ctx.player().method_24828()) {
/* 278 */       return false;
/*     */     }
/* 280 */     if (!MovementHelper.canWalkOn(this.ctx, this.ctx.playerFeet().down()))
/*     */     {
/* 282 */       return false;
/*     */     }
/* 284 */     if (!MovementHelper.canWalkThrough(this.ctx, this.ctx.playerFeet()) || !MovementHelper.canWalkThrough(this.ctx, this.ctx.playerFeet().up()))
/*     */     {
/* 286 */       return false;
/*     */     }
/* 288 */     if (!((IMovement)this.path.movements().get(this.pathPosition)).safeToCancel()) {
/* 289 */       return false;
/*     */     }
/* 291 */     Optional<IPath> currentBest = ((AbstractNodeCostSearch)current.get()).bestPathSoFar();
/* 292 */     if (!currentBest.isPresent()) {
/* 293 */       return false;
/*     */     }
/* 295 */     List<BetterBlockPos> positions = ((IPath)currentBest.get()).positions();
/* 296 */     if (positions.size() < 3) {
/* 297 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 301 */     positions = positions.subList(1, positions.size());
/* 302 */     return positions.contains(this.ctx.playerFeet());
/*     */   }
/*     */   
/*     */   private boolean possiblyOffPath(class_3545<Double, class_2338> status, double leniency) {
/* 306 */     double distanceFromPath = ((Double)status.method_15442()).doubleValue();
/* 307 */     if (distanceFromPath > leniency) {
/*     */       
/* 309 */       if (this.path.movements().get(this.pathPosition) instanceof MovementFall) {
/* 310 */         class_2338 fallDest = this.path.positions().get(this.pathPosition + 1);
/* 311 */         return (VecUtils.entityFlatDistanceToCenter((class_1297)this.ctx.player(), fallDest) >= leniency);
/*     */       } 
/* 313 */       return true;
/*     */     } 
/*     */     
/* 316 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean snipsnapifpossible() {
/* 326 */     if (!this.ctx.player().method_24828() && this.ctx.world().method_8316((class_2338)this.ctx.playerFeet()).method_15769())
/*     */     {
/* 328 */       return false;
/*     */     }
/*     */     
/* 331 */     if ((this.ctx.player().method_18798()).field_1351 < -0.1D)
/*     */     {
/*     */       
/* 334 */       return false;
/*     */     }
/*     */     
/* 337 */     int index = this.path.positions().indexOf(this.ctx.playerFeet());
/* 338 */     if (index == -1) {
/* 339 */       return false;
/*     */     }
/* 341 */     this.pathPosition = index;
/* 342 */     clearKeys();
/* 343 */     return true;
/*     */   }
/*     */   
/*     */   private boolean shouldSprintNextTick() {
/* 347 */     boolean requested = this.behavior.baritone.getInputOverrideHandler().isInputForcedDown(Input.SPRINT);
/*     */ 
/*     */     
/* 350 */     this.behavior.baritone.getInputOverrideHandler().setInputForceState(Input.SPRINT, false);
/*     */ 
/*     */     
/* 353 */     if (!(new CalculationContext((IBaritone)this.behavior.baritone)).canSprint) {
/* 354 */       return false;
/*     */     }
/* 356 */     IMovement current = this.path.movements().get(this.pathPosition);
/*     */ 
/*     */     
/* 359 */     if (current instanceof MovementTraverse && this.pathPosition < this.path.length() - 3) {
/* 360 */       IMovement next = this.path.movements().get(this.pathPosition + 1);
/* 361 */       if (next instanceof MovementAscend && sprintableAscend(this.ctx, (MovementTraverse)current, (MovementAscend)next, this.path.movements().get(this.pathPosition + 2))) {
/* 362 */         if (skipNow(this.ctx, current)) {
/* 363 */           logDebug("Skipping traverse to straight ascend");
/* 364 */           this.pathPosition++;
/* 365 */           onChangeInPathPosition();
/* 366 */           onTick();
/* 367 */           this.behavior.baritone.getInputOverrideHandler().setInputForceState(Input.JUMP, true);
/* 368 */           return true;
/*     */         } 
/* 370 */         logDebug("Too far to the side to safely sprint ascend");
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 376 */     if (requested) {
/* 377 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 381 */     if (current instanceof MovementDescend) {
/*     */       
/* 383 */       if (((MovementDescend)current).safeMode() && !((MovementDescend)current).skipToAscend()) {
/* 384 */         logDebug("Sprinting would be unsafe");
/* 385 */         return false;
/*     */       } 
/*     */       
/* 388 */       if (this.pathPosition < this.path.length() - 2) {
/* 389 */         IMovement next = this.path.movements().get(this.pathPosition + 1);
/* 390 */         if (next instanceof MovementAscend && current.getDirection().method_10084().equals(next.getDirection().method_10074())) {
/*     */           
/* 392 */           this.pathPosition++;
/* 393 */           onChangeInPathPosition();
/* 394 */           onTick();
/*     */           
/* 396 */           logDebug("Skipping descend to straight ascend");
/* 397 */           return true;
/*     */         } 
/* 399 */         if (canSprintFromDescendInto(this.ctx, current, next)) {
/* 400 */           if (this.ctx.playerFeet().equals(current.getDest())) {
/* 401 */             this.pathPosition++;
/* 402 */             onChangeInPathPosition();
/* 403 */             onTick();
/*     */           } 
/* 405 */           return true;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 410 */     if (current instanceof MovementAscend && this.pathPosition != 0) {
/* 411 */       IMovement prev = this.path.movements().get(this.pathPosition - 1);
/* 412 */       if (prev instanceof MovementDescend && prev.getDirection().method_10084().equals(current.getDirection().method_10074())) {
/* 413 */         BetterBlockPos betterBlockPos = current.getSrc().up();
/*     */ 
/*     */ 
/*     */         
/* 417 */         if (this.ctx.player().method_23318() >= betterBlockPos.method_10264() - 0.07D) {
/* 418 */           this.behavior.baritone.getInputOverrideHandler().setInputForceState(Input.JUMP, false);
/* 419 */           return true;
/*     */         } 
/*     */       } 
/* 422 */       if (this.pathPosition < this.path.length() - 2 && prev instanceof MovementTraverse && sprintableAscend(this.ctx, (MovementTraverse)prev, (MovementAscend)current, this.path.movements().get(this.pathPosition + 1))) {
/* 423 */         return true;
/*     */       }
/*     */     } 
/* 426 */     if (current instanceof MovementFall) {
/* 427 */       class_3545<class_243, class_2338> data = overrideFall((MovementFall)current);
/* 428 */       if (data != null) {
/* 429 */         BetterBlockPos fallDest = new BetterBlockPos((class_2338)data.method_15441());
/* 430 */         if (!this.path.positions().contains(fallDest)) {
/* 431 */           throw new IllegalStateException();
/*     */         }
/* 433 */         if (this.ctx.playerFeet().equals(fallDest)) {
/* 434 */           this.pathPosition = this.path.positions().indexOf(fallDest);
/* 435 */           onChangeInPathPosition();
/* 436 */           onTick();
/* 437 */           return true;
/*     */         } 
/* 439 */         clearKeys();
/* 440 */         this.behavior.baritone.getLookBehavior().updateTarget(RotationUtils.calcRotationFromVec3d(this.ctx.playerHead(), (class_243)data.method_15442(), this.ctx.playerRotations()), false);
/* 441 */         this.behavior.baritone.getInputOverrideHandler().setInputForceState(Input.MOVE_FORWARD, true);
/* 442 */         return true;
/*     */       } 
/*     */     } 
/* 445 */     return false;
/*     */   }
/*     */   
/*     */   private class_3545<class_243, class_2338> overrideFall(MovementFall movement) {
/* 449 */     class_2338 class_2338 = movement.getDirection();
/* 450 */     if (class_2338.method_10264() < -3) {
/* 451 */       return null;
/*     */     }
/* 453 */     if (!movement.toBreakCached.isEmpty()) {
/* 454 */       return null;
/*     */     }
/* 456 */     class_2382 flatDir = new class_2382(class_2338.method_10263(), 0, class_2338.method_10260());
/*     */     
/*     */     int i;
/* 459 */     label31: for (i = this.pathPosition + 1; i < this.path.length() - 1 && i < this.pathPosition + 3; i++) {
/* 460 */       IMovement next = this.path.movements().get(i);
/* 461 */       if (!(next instanceof MovementTraverse)) {
/*     */         break;
/*     */       }
/* 464 */       if (!flatDir.equals(next.getDirection())) {
/*     */         break;
/*     */       }
/* 467 */       for (int y = (next.getDest()).y; y <= (movement.getSrc()).y + 1; y++) {
/* 468 */         class_2338 chk = new class_2338((next.getDest()).x, y, (next.getDest()).z);
/* 469 */         if (!MovementHelper.fullyPassable(this.ctx, chk)) {
/*     */           break label31;
/*     */         }
/*     */       } 
/* 473 */       if (!MovementHelper.canWalkOn(this.ctx, next.getDest().down())) {
/*     */         break;
/*     */       }
/*     */     } 
/* 477 */     i--;
/* 478 */     if (i == this.pathPosition) {
/* 479 */       return null;
/*     */     }
/* 481 */     double len = (i - this.pathPosition) - 0.4D;
/* 482 */     return new class_3545(new class_243(flatDir
/* 483 */           .method_10263() * len + (movement.getDest()).x + 0.5D, (movement.getDest()).y, flatDir.method_10260() * len + (movement.getDest()).z + 0.5D), movement
/* 484 */         .getDest().method_10069(flatDir.method_10263() * (i - this.pathPosition), 0, flatDir.method_10260() * (i - this.pathPosition)));
/*     */   }
/*     */   
/*     */   private static boolean skipNow(IPlayerContext ctx, IMovement current) {
/* 488 */     double offTarget = Math.abs(current.getDirection().method_10263() * ((current.getSrc()).z + 0.5D - ctx.player().method_23321())) + Math.abs(current.getDirection().method_10260() * ((current.getSrc()).x + 0.5D - ctx.player().method_23317()));
/* 489 */     if (offTarget > 0.1D) {
/* 490 */       return false;
/*     */     }
/*     */     
/* 493 */     class_2338 headBonk = current.getSrc().method_10059((class_2382)current.getDirection()).method_10086(2);
/* 494 */     if (MovementHelper.fullyPassable(ctx, headBonk)) {
/* 495 */       return true;
/*     */     }
/*     */     
/* 498 */     double flatDist = Math.abs(current.getDirection().method_10263() * (headBonk.method_10263() + 0.5D - ctx.player().method_23317())) + Math.abs(current.getDirection().method_10260() * (headBonk.method_10260() + 0.5D - ctx.player().method_23321()));
/* 499 */     return (flatDist > 0.8D);
/*     */   }
/*     */   
/*     */   private static boolean sprintableAscend(IPlayerContext ctx, MovementTraverse current, MovementAscend next, IMovement nextnext) {
/* 503 */     if (!((Boolean)(Baritone.settings()).sprintAscends.value).booleanValue()) {
/* 504 */       return false;
/*     */     }
/* 506 */     if (!current.getDirection().equals(next.getDirection().method_10074())) {
/* 507 */       return false;
/*     */     }
/* 509 */     if (nextnext.getDirection().method_10263() != next.getDirection().method_10263() || nextnext.getDirection().method_10260() != next.getDirection().method_10260()) {
/* 510 */       return false;
/*     */     }
/* 512 */     if (!MovementHelper.canWalkOn(ctx, current.getDest().down())) {
/* 513 */       return false;
/*     */     }
/* 515 */     if (!MovementHelper.canWalkOn(ctx, next.getDest().down())) {
/* 516 */       return false;
/*     */     }
/* 518 */     if (!next.toBreakCached.isEmpty()) {
/* 519 */       return false;
/*     */     }
/* 521 */     for (int x = 0; x < 2; x++) {
/* 522 */       for (int y = 0; y < 3; y++) {
/* 523 */         class_2338 class_2338; BetterBlockPos betterBlockPos = current.getSrc().up(y);
/* 524 */         if (x == 1) {
/* 525 */           class_2338 = betterBlockPos.method_10081((class_2382)current.getDirection());
/*     */         }
/* 527 */         if (!MovementHelper.fullyPassable(ctx, class_2338)) {
/* 528 */           return false;
/*     */         }
/*     */       } 
/*     */     } 
/* 532 */     if (MovementHelper.avoidWalkingInto(ctx.world().method_8320((class_2338)current.getSrc().up(3)))) {
/* 533 */       return false;
/*     */     }
/* 535 */     return !MovementHelper.avoidWalkingInto(ctx.world().method_8320((class_2338)next.getDest().up(2)));
/*     */   }
/*     */   
/*     */   private static boolean canSprintFromDescendInto(IPlayerContext ctx, IMovement current, IMovement next) {
/* 539 */     if (next instanceof MovementDescend && next.getDirection().equals(current.getDirection())) {
/* 540 */       return true;
/*     */     }
/* 542 */     if (!MovementHelper.canWalkOn(ctx, current.getDest().method_10081((class_2382)current.getDirection()))) {
/* 543 */       return false;
/*     */     }
/* 545 */     if (next instanceof MovementTraverse && next.getDirection().method_10074().equals(current.getDirection())) {
/* 546 */       return true;
/*     */     }
/* 548 */     return (next instanceof baritone.pathing.movement.movements.MovementDiagonal && ((Boolean)(Baritone.settings()).allowOvershootDiagonalDescend.value).booleanValue());
/*     */   }
/*     */   
/*     */   private void onChangeInPathPosition() {
/* 552 */     clearKeys();
/* 553 */     this.ticksOnCurrent = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   private void clearKeys() {
/* 558 */     this.behavior.baritone.getInputOverrideHandler().clearAllKeys();
/*     */   }
/*     */   
/*     */   private void cancel() {
/* 562 */     clearKeys();
/* 563 */     this.behavior.baritone.getInputOverrideHandler().getBlockBreakHelper().stopBreakingBlock();
/* 564 */     this.pathPosition = this.path.length() + 3;
/* 565 */     this.failed = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPosition() {
/* 570 */     return this.pathPosition;
/*     */   }
/*     */   
/*     */   public PathExecutor trySplice(PathExecutor next) {
/* 574 */     if (next == null) {
/* 575 */       return cutIfTooLong();
/*     */     }
/* 577 */     return SplicedPath.trySplice(this.path, next.path, false).<PathExecutor>map(path -> {
/*     */           if (!path.getDest().equals(next.getPath().getDest())) {
/*     */             throw new IllegalStateException();
/*     */           }
/*     */           PathExecutor ret = new PathExecutor(this.behavior, (IPath)path);
/*     */           ret.pathPosition = this.pathPosition;
/*     */           ret.currentMovementOriginalCostEstimate = this.currentMovementOriginalCostEstimate;
/*     */           ret.costEstimateIndex = this.costEstimateIndex;
/*     */           ret.ticksOnCurrent = this.ticksOnCurrent;
/*     */           return ret;
/* 587 */         }).orElseGet(this::cutIfTooLong);
/*     */   }
/*     */   
/*     */   private PathExecutor cutIfTooLong() {
/* 591 */     if (this.pathPosition > ((Integer)(Baritone.settings()).maxPathHistoryLength.value).intValue()) {
/* 592 */       int cutoffAmt = ((Integer)(Baritone.settings()).pathHistoryCutoffAmount.value).intValue();
/* 593 */       CutoffPath newPath = new CutoffPath(this.path, cutoffAmt, this.path.length() - 1);
/* 594 */       if (!newPath.getDest().equals(this.path.getDest())) {
/* 595 */         throw new IllegalStateException();
/*     */       }
/* 597 */       logDebug("Discarding earliest segment movements, length cut from " + this.path.length() + " to " + newPath.length());
/* 598 */       PathExecutor ret = new PathExecutor(this.behavior, (IPath)newPath);
/* 599 */       this.pathPosition -= cutoffAmt;
/* 600 */       ret.currentMovementOriginalCostEstimate = this.currentMovementOriginalCostEstimate;
/* 601 */       if (this.costEstimateIndex != null) {
/* 602 */         ret.costEstimateIndex = Integer.valueOf(this.costEstimateIndex.intValue() - cutoffAmt);
/*     */       }
/* 604 */       ret.ticksOnCurrent = this.ticksOnCurrent;
/* 605 */       return ret;
/*     */     } 
/* 607 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public IPath getPath() {
/* 612 */     return this.path;
/*     */   }
/*     */   
/*     */   public boolean failed() {
/* 616 */     return this.failed;
/*     */   }
/*     */   
/*     */   public boolean finished() {
/* 620 */     return (this.pathPosition >= this.path.length());
/*     */   }
/*     */   
/*     */   public Set<class_2338> toBreak() {
/* 624 */     return Collections.unmodifiableSet(this.toBreak);
/*     */   }
/*     */   
/*     */   public Set<class_2338> toPlace() {
/* 628 */     return Collections.unmodifiableSet(this.toPlace);
/*     */   }
/*     */   
/*     */   public Set<class_2338> toWalkInto() {
/* 632 */     return Collections.unmodifiableSet(this.toWalkInto);
/*     */   }
/*     */   
/*     */   public boolean isSprinting() {
/* 636 */     return this.sprintNextTick;
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\pathing\path\PathExecutor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */