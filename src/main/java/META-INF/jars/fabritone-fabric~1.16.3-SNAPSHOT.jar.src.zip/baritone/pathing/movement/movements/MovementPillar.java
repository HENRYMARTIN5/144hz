/*     */ package baritone.pathing.movement.movements;
/*     */ 
/*     */ import baritone.Baritone;
/*     */ import baritone.api.IBaritone;
/*     */ import baritone.api.pathing.movement.MovementStatus;
/*     */ import baritone.api.utils.BetterBlockPos;
/*     */ import baritone.api.utils.Rotation;
/*     */ import baritone.api.utils.RotationUtils;
/*     */ import baritone.api.utils.VecUtils;
/*     */ import baritone.api.utils.input.Input;
/*     */ import baritone.pathing.movement.CalculationContext;
/*     */ import baritone.pathing.movement.Movement;
/*     */ import baritone.pathing.movement.MovementHelper;
/*     */ import baritone.pathing.movement.MovementState;
/*     */ import baritone.utils.BlockStateInterface;
/*     */ import com.google.common.collect.ImmutableSet;
/*     */ import java.util.Set;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2248;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_2399;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_2482;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_2769;
/*     */ import net.minecraft.class_2771;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MovementPillar
/*     */   extends Movement
/*     */ {
/*     */   public MovementPillar(IBaritone baritone, BetterBlockPos start, BetterBlockPos end) {
/*  44 */     super(baritone, start, end, new BetterBlockPos[] { start.up(2) }, start);
/*     */   }
/*     */ 
/*     */   
/*     */   public double calculateCost(CalculationContext context) {
/*  49 */     return cost(context, this.src.x, this.src.y, this.src.z);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Set<BetterBlockPos> calculateValidPositions() {
/*  54 */     return (Set<BetterBlockPos>)ImmutableSet.of(this.src, this.dest);
/*     */   }
/*     */   
/*     */   public static double cost(CalculationContext context, int x, int y, int z) {
/*  58 */     class_2680 fromState = context.get(x, y, z);
/*  59 */     class_2248 from = fromState.method_26204();
/*  60 */     boolean ladder = (from == class_2246.field_9983 || from == class_2246.field_10597);
/*  61 */     class_2680 fromDown = context.get(x, y - 1, z);
/*  62 */     if (!ladder) {
/*  63 */       if (fromDown.method_26204() == class_2246.field_9983 || fromDown.method_26204() == class_2246.field_10597) {
/*  64 */         return 1000000.0D;
/*     */       }
/*  66 */       if (fromDown.method_26204() instanceof class_2482 && fromDown.method_11654((class_2769)class_2482.field_11501) == class_2771.field_12681) {
/*  67 */         return 1000000.0D;
/*     */       }
/*     */     } 
/*  70 */     if (from == class_2246.field_10597 && !hasAgainst(context, x, y, z)) {
/*  71 */       return 1000000.0D;
/*     */     }
/*  73 */     class_2680 toBreak = context.get(x, y + 2, z);
/*  74 */     class_2248 toBreakBlock = toBreak.method_26204();
/*  75 */     if (toBreakBlock instanceof net.minecraft.class_2349) {
/*  76 */       return 1000000.0D;
/*     */     }
/*  78 */     class_2680 srcUp = null;
/*  79 */     if (MovementHelper.isWater(toBreak) && MovementHelper.isWater(fromState)) {
/*  80 */       srcUp = context.get(x, y + 1, z);
/*  81 */       if (MovementHelper.isWater(srcUp)) {
/*  82 */         return 8.51063829787234D;
/*     */       }
/*     */     } 
/*  85 */     double placeCost = 0.0D;
/*  86 */     if (!ladder) {
/*     */       
/*  88 */       placeCost = context.costOfPlacingAt(x, y, z, fromState);
/*  89 */       if (placeCost >= 1000000.0D) {
/*  90 */         return 1000000.0D;
/*     */       }
/*  92 */       if (fromDown.method_26204() instanceof net.minecraft.class_2189) {
/*  93 */         placeCost += 0.1D;
/*     */       }
/*     */     } 
/*  96 */     if ((MovementHelper.isLiquid(fromState) && !MovementHelper.canPlaceAgainst(context.bsi, x, y - 1, z, fromDown)) || (MovementHelper.isLiquid(fromDown) && context.assumeWalkOnWater))
/*     */     {
/*     */ 
/*     */       
/* 100 */       return 1000000.0D;
/*     */     }
/* 102 */     double hardness = MovementHelper.getMiningDurationTicks(context, x, y + 2, z, toBreak, true);
/* 103 */     if (hardness >= 1000000.0D) {
/* 104 */       return 1000000.0D;
/*     */     }
/* 106 */     if (hardness != 0.0D) {
/* 107 */       if (toBreakBlock == class_2246.field_9983 || toBreakBlock == class_2246.field_10597) {
/* 108 */         hardness = 0.0D;
/*     */       } else {
/* 110 */         class_2680 check = context.get(x, y + 3, z);
/* 111 */         if (check.method_26204() instanceof net.minecraft.class_2346) {
/*     */           
/* 113 */           if (srcUp == null) {
/* 114 */             srcUp = context.get(x, y + 1, z);
/*     */           }
/* 116 */           if (!(toBreakBlock instanceof net.minecraft.class_2346) || !(srcUp.method_26204() instanceof net.minecraft.class_2346)) {
/* 117 */             return 1000000.0D;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 129 */     if (ladder) {
/* 130 */       return 8.51063829787234D + hardness * 5.0D;
/*     */     }
/* 132 */     return JUMP_ONE_BLOCK_COST + placeCost + context.jumpPenalty + hardness;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean hasAgainst(CalculationContext context, int x, int y, int z) {
/* 137 */     return (MovementHelper.isBlockNormalCube(context.get(x + 1, y, z)) || 
/* 138 */       MovementHelper.isBlockNormalCube(context.get(x - 1, y, z)) || 
/* 139 */       MovementHelper.isBlockNormalCube(context.get(x, y, z + 1)) || 
/* 140 */       MovementHelper.isBlockNormalCube(context.get(x, y, z - 1)));
/*     */   }
/*     */   
/*     */   public static class_2338 getAgainst(CalculationContext context, BetterBlockPos vine) {
/* 144 */     if (MovementHelper.isBlockNormalCube(context.get((class_2338)vine.north()))) {
/* 145 */       return (class_2338)vine.north();
/*     */     }
/* 147 */     if (MovementHelper.isBlockNormalCube(context.get((class_2338)vine.south()))) {
/* 148 */       return (class_2338)vine.south();
/*     */     }
/* 150 */     if (MovementHelper.isBlockNormalCube(context.get((class_2338)vine.east()))) {
/* 151 */       return (class_2338)vine.east();
/*     */     }
/* 153 */     if (MovementHelper.isBlockNormalCube(context.get((class_2338)vine.west()))) {
/* 154 */       return (class_2338)vine.west();
/*     */     }
/* 156 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public MovementState updateState(MovementState state) {
/* 161 */     super.updateState(state);
/* 162 */     if (state.getStatus() != MovementStatus.RUNNING) {
/* 163 */       return state;
/*     */     }
/*     */     
/* 166 */     if ((this.ctx.playerFeet()).y < this.src.y) {
/* 167 */       return state.setStatus(MovementStatus.UNREACHABLE);
/*     */     }
/*     */     
/* 170 */     class_2680 fromDown = BlockStateInterface.get(this.ctx, (class_2338)this.src);
/* 171 */     if (MovementHelper.isWater(fromDown) && MovementHelper.isWater(this.ctx, (class_2338)this.dest)) {
/*     */       
/* 173 */       state.setTarget(new MovementState.MovementTarget(RotationUtils.calcRotationFromVec3d(this.ctx.playerHead(), VecUtils.getBlockPosCenter((class_2338)this.dest), this.ctx.playerRotations()), false));
/* 174 */       class_243 destCenter = VecUtils.getBlockPosCenter((class_2338)this.dest);
/* 175 */       if (Math.abs(this.ctx.player().method_23317() - destCenter.field_1352) > 0.2D || Math.abs(this.ctx.player().method_23321() - destCenter.field_1350) > 0.2D) {
/* 176 */         state.setInput(Input.MOVE_FORWARD, true);
/*     */       }
/* 178 */       if (this.ctx.playerFeet().equals(this.dest)) {
/* 179 */         return state.setStatus(MovementStatus.SUCCESS);
/*     */       }
/* 181 */       return state;
/*     */     } 
/* 183 */     boolean ladder = (fromDown.method_26204() == class_2246.field_9983 || fromDown.method_26204() == class_2246.field_10597);
/* 184 */     boolean vine = (fromDown.method_26204() == class_2246.field_10597);
/* 185 */     Rotation rotation = RotationUtils.calcRotationFromVec3d(this.ctx.playerHead(), 
/* 186 */         VecUtils.getBlockPosCenter((class_2338)this.positionToPlace), new Rotation(
/* 187 */           (this.ctx.player()).field_6031, (this.ctx.player()).field_5965));
/* 188 */     if (!ladder) {
/* 189 */       state.setTarget(new MovementState.MovementTarget(new Rotation((this.ctx.player()).field_6031, rotation.getPitch()), true));
/*     */     }
/*     */     
/* 192 */     boolean blockIsThere = (MovementHelper.canWalkOn(this.ctx, this.src) || ladder);
/* 193 */     if (ladder) {
/* 194 */       class_2338 against = vine ? getAgainst(new CalculationContext(this.baritone), this.src) : (class_2338)this.src.offset(((class_2350)fromDown.method_11654((class_2769)class_2399.field_11253)).method_10153());
/* 195 */       if (against == null) {
/* 196 */         logDirect("Unable to climb vines. Consider disabling allowVines.");
/* 197 */         return state.setStatus(MovementStatus.UNREACHABLE);
/*     */       } 
/*     */       
/* 200 */       if (this.ctx.playerFeet().equals(against.method_10084()) || this.ctx.playerFeet().equals(this.dest)) {
/* 201 */         return state.setStatus(MovementStatus.SUCCESS);
/*     */       }
/* 203 */       if (MovementHelper.isBottomSlab(BlockStateInterface.get(this.ctx, (class_2338)this.src.down()))) {
/* 204 */         state.setInput(Input.JUMP, true);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 212 */       MovementHelper.moveTowards(this.ctx, state, against);
/* 213 */       return state;
/*     */     } 
/*     */     
/* 216 */     if (!((Baritone)this.baritone).getInventoryBehavior().selectThrowawayForLocation(true, this.src.x, this.src.y, this.src.z)) {
/* 217 */       return state.setStatus(MovementStatus.UNREACHABLE);
/*     */     }
/*     */ 
/*     */     
/* 221 */     state.setInput(Input.SNEAK, (this.ctx.player().method_23318() > this.dest.method_10264() || this.ctx.player().method_23318() < this.src.method_10264() + 0.2D));
/*     */ 
/*     */     
/* 224 */     double diffX = this.ctx.player().method_23317() - this.dest.method_10263() + 0.5D;
/* 225 */     double diffZ = this.ctx.player().method_23321() - this.dest.method_10260() + 0.5D;
/* 226 */     double dist = Math.sqrt(diffX * diffX + diffZ * diffZ);
/* 227 */     double flatMotion = Math.sqrt((this.ctx.player().method_18798()).field_1352 * (this.ctx.player().method_18798()).field_1352 + (this.ctx.player().method_18798()).field_1350 * (this.ctx.player().method_18798()).field_1350);
/* 228 */     if (dist > 0.17D) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 233 */       state.setInput(Input.MOVE_FORWARD, true);
/*     */ 
/*     */       
/* 236 */       state.setTarget(new MovementState.MovementTarget(rotation, true));
/* 237 */     } else if (flatMotion < 0.05D) {
/*     */       
/* 239 */       state.setInput(Input.JUMP, (this.ctx.player().method_23318() < this.dest.method_10264()));
/*     */     } 
/*     */ 
/*     */     
/* 243 */     if (!blockIsThere) {
/* 244 */       class_2680 frState = BlockStateInterface.get(this.ctx, (class_2338)this.src);
/* 245 */       class_2248 fr = frState.method_26204();
/*     */       
/* 247 */       if (!(fr instanceof net.minecraft.class_2189) && !frState.method_26207().method_15800()) {
/* 248 */         RotationUtils.reachable(this.ctx.player(), (class_2338)this.src, this.ctx.playerController().getBlockReachDistance())
/* 249 */           .map(rot -> new MovementState.MovementTarget(rot, true))
/* 250 */           .ifPresent(state::setTarget);
/* 251 */         state.setInput(Input.JUMP, false);
/* 252 */         state.setInput(Input.CLICK_LEFT, true);
/* 253 */         blockIsThere = false;
/* 254 */       } else if (this.ctx.player().method_5715() && (this.ctx.isLookingAt((class_2338)this.src.down()) || this.ctx.isLookingAt((class_2338)this.src)) && this.ctx.player().method_23318() > this.dest.method_10264() + 0.1D) {
/* 255 */         state.setInput(Input.CLICK_RIGHT, true);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 261 */     if (this.ctx.playerFeet().equals(this.dest) && blockIsThere) {
/* 262 */       return state.setStatus(MovementStatus.SUCCESS);
/*     */     }
/*     */     
/* 265 */     return state;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean prepared(MovementState state) {
/* 270 */     if (this.ctx.playerFeet().equals(this.src) || this.ctx.playerFeet().equals(this.src.down())) {
/* 271 */       class_2248 block = BlockStateInterface.getBlock(this.ctx, (class_2338)this.src.down());
/* 272 */       if (block == class_2246.field_9983 || block == class_2246.field_10597) {
/* 273 */         state.setInput(Input.SNEAK, true);
/*     */       }
/*     */     } 
/* 276 */     if (MovementHelper.isWater(this.ctx, (class_2338)this.dest.up())) {
/* 277 */       return true;
/*     */     }
/* 279 */     return super.prepared(state);
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\pathing\movement\movements\MovementPillar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */