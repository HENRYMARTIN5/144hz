/*     */ package baritone.pathing.movement;
/*     */ 
/*     */ import baritone.Baritone;
/*     */ import baritone.api.BaritoneAPI;
/*     */ import baritone.api.IBaritone;
/*     */ import baritone.api.pathing.movement.ActionCosts;
/*     */ import baritone.api.pathing.movement.MovementStatus;
/*     */ import baritone.api.utils.BetterBlockPos;
/*     */ import baritone.api.utils.Helper;
/*     */ import baritone.api.utils.IPlayerContext;
/*     */ import baritone.api.utils.RayTraceUtils;
/*     */ import baritone.api.utils.Rotation;
/*     */ import baritone.api.utils.RotationUtils;
/*     */ import baritone.api.utils.VecUtils;
/*     */ import baritone.api.utils.input.Input;
/*     */ import baritone.utils.BlockStateInterface;
/*     */ import baritone.utils.ToolSet;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import net.minecraft.class_10;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1922;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2248;
/*     */ import net.minecraft.class_2323;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2346;
/*     */ import net.minecraft.class_2349;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_2383;
/*     */ import net.minecraft.class_239;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_2482;
/*     */ import net.minecraft.class_2488;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_2746;
/*     */ import net.minecraft.class_2769;
/*     */ import net.minecraft.class_2771;
/*     */ import net.minecraft.class_3610;
/*     */ import net.minecraft.class_3611;
/*     */ import net.minecraft.class_3612;
/*     */ import net.minecraft.class_3965;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface MovementHelper
/*     */   extends ActionCosts, Helper
/*     */ {
/*     */   static boolean avoidBreaking(BlockStateInterface bsi, int x, int y, int z, class_2680 state) {
/*  54 */     class_2248 b = state.method_26204();
/*  55 */     return (b == class_2246.field_10295 || b instanceof net.minecraft.class_2384 || 
/*     */ 
/*     */       
/*  58 */       avoidAdjacentBreaking(bsi, x, y + 1, z, true) || 
/*  59 */       avoidAdjacentBreaking(bsi, x + 1, y, z, false) || 
/*  60 */       avoidAdjacentBreaking(bsi, x - 1, y, z, false) || 
/*  61 */       avoidAdjacentBreaking(bsi, x, y, z + 1, false) || 
/*  62 */       avoidAdjacentBreaking(bsi, x, y, z - 1, false));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean avoidAdjacentBreaking(BlockStateInterface bsi, int x, int y, int z, boolean directlyAbove) {
/*  69 */     class_2680 state = bsi.get0(x, y, z);
/*  70 */     class_2248 block = state.method_26204();
/*  71 */     if (!directlyAbove && block instanceof class_2346)
/*     */     {
/*     */       
/*  74 */       if (((Boolean)(Baritone.settings()).avoidUpdatingFallingBlocks.value).booleanValue() && 
/*  75 */         class_2346.method_10128(bsi.get0(x, y - 1, z)))
/*  76 */         return true; 
/*     */     }
/*  78 */     return !state.method_26227().method_15769();
/*     */   }
/*     */   
/*     */   static boolean canWalkThrough(IPlayerContext ctx, BetterBlockPos pos) {
/*  82 */     return canWalkThrough(new BlockStateInterface(ctx), pos.x, pos.y, pos.z);
/*     */   }
/*     */   
/*     */   static boolean canWalkThrough(BlockStateInterface bsi, int x, int y, int z) {
/*  86 */     return canWalkThrough(bsi, x, y, z, bsi.get0(x, y, z));
/*     */   }
/*     */   
/*     */   static boolean canWalkThrough(BlockStateInterface bsi, int x, int y, int z, class_2680 state) {
/*  90 */     class_2248 block = state.method_26204();
/*  91 */     if (block instanceof net.minecraft.class_2189) {
/*  92 */       return true;
/*     */     }
/*  94 */     if (block == class_2246.field_10036 || block == class_2246.field_10589 || block == class_2246.field_10343 || block == class_2246.field_10027 || block == class_2246.field_10302 || block instanceof net.minecraft.class_2190 || block == class_2246.field_10422 || block instanceof net.minecraft.class_2480 || block instanceof class_2482 || block instanceof net.minecraft.class_2533 || block == class_2246.field_21211 || block == class_2246.field_10455) {
/*  95 */       return false;
/*     */     }
/*  97 */     if (((List)(Baritone.settings()).blocksToAvoid.value).contains(block)) {
/*  98 */       return false;
/*     */     }
/* 100 */     if (block instanceof class_2323 || block instanceof class_2349)
/*     */     {
/*     */ 
/*     */       
/* 104 */       return (block != class_2246.field_9973);
/*     */     }
/* 106 */     if (block instanceof net.minecraft.class_2577) {
/* 107 */       return canWalkOn(bsi, x, y - 1, z);
/*     */     }
/* 109 */     if (block instanceof class_2488) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 114 */       if (!bsi.worldContainsLoadedChunk(x, z)) {
/* 115 */         return true;
/*     */       }
/*     */ 
/*     */       
/* 119 */       if (((Integer)state.method_11654((class_2769)class_2488.field_11518)).intValue() >= 3) {
/* 120 */         return false;
/*     */       }
/*     */       
/* 123 */       return canWalkOn(bsi, x, y - 1, z);
/*     */     } 
/* 125 */     if (isFlowing(x, y, z, state, bsi)) {
/* 126 */       return false;
/*     */     }
/* 128 */     class_3610 fluidState = state.method_26227();
/* 129 */     if (fluidState.method_15772() instanceof net.minecraft.class_3621) {
/* 130 */       if (((Boolean)(Baritone.settings()).assumeWalkOnWater.value).booleanValue()) {
/* 131 */         return false;
/*     */       }
/* 133 */       class_2680 up = bsi.get0(x, y + 1, z);
/* 134 */       if (!up.method_26227().method_15769() || up.method_26204() instanceof net.minecraft.class_2553) {
/* 135 */         return false;
/*     */       }
/* 137 */       return true;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 142 */     return state.method_26171(bsi.access, class_2338.field_10980, class_10.field_50);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean fullyPassable(CalculationContext context, int x, int y, int z) {
/* 156 */     return fullyPassable(context.bsi.access, (class_2338)context.bsi.isPassableBlockPos
/*     */         
/* 158 */         .method_10103(x, y, z), context.bsi
/* 159 */         .get0(x, y, z));
/*     */   }
/*     */ 
/*     */   
/*     */   static boolean fullyPassable(IPlayerContext ctx, class_2338 pos) {
/* 164 */     return fullyPassable((class_1922)ctx.world(), pos, ctx.world().method_8320(pos));
/*     */   }
/*     */   
/*     */   static boolean fullyPassable(class_1922 access, class_2338 pos, class_2680 state) {
/* 168 */     class_2248 block = state.method_26204();
/* 169 */     if (block instanceof net.minecraft.class_2189) {
/* 170 */       return true;
/*     */     }
/*     */     
/* 173 */     if (block == class_2246.field_10036 || block == class_2246.field_10589 || block == class_2246.field_10343 || block == class_2246.field_10597 || block == class_2246.field_9983 || block == class_2246.field_10302 || block instanceof class_2323 || block instanceof class_2349 || block instanceof class_2488 || 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 182 */       !state.method_26227().method_15769() || block instanceof net.minecraft.class_2533 || block instanceof net.minecraft.class_2334 || block instanceof net.minecraft.class_2484 || block instanceof net.minecraft.class_2480)
/*     */     {
/*     */ 
/*     */ 
/*     */       
/* 187 */       return false;
/*     */     }
/*     */     
/* 190 */     return state.method_26171(access, pos, class_10.field_50);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isReplaceable(int x, int y, int z, class_2680 state, BlockStateInterface bsi) {
/* 204 */     class_2248 block = state.method_26204();
/* 205 */     if (block instanceof net.minecraft.class_2189)
/*     */     {
/* 207 */       return true;
/*     */     }
/* 209 */     if (block instanceof class_2488) {
/*     */       
/* 211 */       if (!bsi.worldContainsLoadedChunk(x, z)) {
/* 212 */         return true;
/*     */       }
/* 214 */       return (((Integer)state.method_11654((class_2769)class_2488.field_11518)).intValue() == 1);
/*     */     } 
/* 216 */     if (block == class_2246.field_10313 || block == class_2246.field_10214) {
/* 217 */       return true;
/*     */     }
/* 219 */     return state.method_26207().method_15800();
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   static boolean isReplacable(int x, int y, int z, class_2680 state, BlockStateInterface bsi) {
/* 224 */     return isReplaceable(x, y, z, state, bsi);
/*     */   }
/*     */   
/*     */   static boolean isDoorPassable(IPlayerContext ctx, class_2338 doorPos, class_2338 playerPos) {
/* 228 */     if (playerPos.equals(doorPos)) {
/* 229 */       return false;
/*     */     }
/*     */     
/* 232 */     class_2680 state = BlockStateInterface.get(ctx, doorPos);
/* 233 */     if (!(state.method_26204() instanceof class_2323)) {
/* 234 */       return true;
/*     */     }
/*     */     
/* 237 */     return isHorizontalBlockPassable(doorPos, state, playerPos, class_2323.field_10945);
/*     */   }
/*     */   
/*     */   static boolean isGatePassable(IPlayerContext ctx, class_2338 gatePos, class_2338 playerPos) {
/* 241 */     if (playerPos.equals(gatePos)) {
/* 242 */       return false;
/*     */     }
/*     */     
/* 245 */     class_2680 state = BlockStateInterface.get(ctx, gatePos);
/* 246 */     if (!(state.method_26204() instanceof class_2349)) {
/* 247 */       return true;
/*     */     }
/*     */     
/* 250 */     return ((Boolean)state.method_11654((class_2769)class_2349.field_11026)).booleanValue();
/*     */   }
/*     */   static boolean isHorizontalBlockPassable(class_2338 blockPos, class_2680 blockState, class_2338 playerPos, class_2746 propertyOpen) {
/*     */     class_2350.class_2351 playerFacing;
/* 254 */     if (playerPos.equals(blockPos)) {
/* 255 */       return false;
/*     */     }
/*     */     
/* 258 */     class_2350.class_2351 facing = ((class_2350)blockState.method_11654((class_2769)class_2383.field_11177)).method_10166();
/* 259 */     boolean open = ((Boolean)blockState.method_11654((class_2769)propertyOpen)).booleanValue();
/*     */ 
/*     */     
/* 262 */     if (playerPos.method_10095().equals(blockPos) || playerPos.method_10072().equals(blockPos)) {
/* 263 */       playerFacing = class_2350.class_2351.field_11051;
/* 264 */     } else if (playerPos.method_10078().equals(blockPos) || playerPos.method_10067().equals(blockPos)) {
/* 265 */       playerFacing = class_2350.class_2351.field_11048;
/*     */     } else {
/* 267 */       return true;
/*     */     } 
/*     */     
/* 270 */     return (((facing == playerFacing)) == open);
/*     */   }
/*     */   
/*     */   static boolean avoidWalkingInto(class_2680 state) {
/* 274 */     class_2248 block = state.method_26204();
/* 275 */     return (!state.method_26227().method_15769() || block == class_2246.field_10092 || block == class_2246.field_10029 || block == class_2246.field_10036 || block == class_2246.field_10027 || block == class_2246.field_10343 || block == class_2246.field_10422);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean canWalkOn(BlockStateInterface bsi, int x, int y, int z, class_2680 state) {
/* 297 */     class_2248 block = state.method_26204();
/* 298 */     if (block instanceof net.minecraft.class_2189 || block == class_2246.field_10092 || block == class_2246.field_10422 || block == class_2246.field_21211)
/*     */     {
/*     */       
/* 301 */       return false;
/*     */     }
/* 303 */     if (isBlockNormalCube(state)) {
/* 304 */       return true;
/*     */     }
/* 306 */     if (block == class_2246.field_9983 || (block == class_2246.field_10597 && ((Boolean)(Baritone.settings()).allowVines.value).booleanValue())) {
/* 307 */       return true;
/*     */     }
/* 309 */     if (block == class_2246.field_10362 || block == class_2246.field_10194) {
/* 310 */       return true;
/*     */     }
/* 312 */     if (block == class_2246.field_10443 || block == class_2246.field_10034 || block == class_2246.field_10380) {
/* 313 */       return true;
/*     */     }
/* 315 */     if (isWater(state)) {
/*     */ 
/*     */       
/* 318 */       class_2680 upState = bsi.get0(x, y + 1, z);
/* 319 */       class_2248 up = upState.method_26204();
/* 320 */       if (up == class_2246.field_10588 || up instanceof net.minecraft.class_2577) {
/* 321 */         return true;
/*     */       }
/* 323 */       if (isFlowing(x, y, z, state, bsi) || upState.method_26227().method_15772() == class_3612.field_15909)
/*     */       {
/* 325 */         return (isWater(upState) && !((Boolean)(Baritone.settings()).assumeWalkOnWater.value).booleanValue());
/*     */       }
/*     */ 
/*     */       
/* 329 */       return isWater(upState) ^ ((Boolean)(Baritone.settings()).assumeWalkOnWater.value).booleanValue();
/*     */     } 
/* 331 */     if (((Boolean)(Baritone.settings()).assumeWalkOnLava.value).booleanValue() && isLava(state) && !isFlowing(x, y, z, state, bsi)) {
/* 332 */       return true;
/*     */     }
/* 334 */     if (block == class_2246.field_10033 || block instanceof net.minecraft.class_2506) {
/* 335 */       return true;
/*     */     }
/* 337 */     if (block instanceof class_2482) {
/* 338 */       if (!((Boolean)(Baritone.settings()).allowWalkOnBottomSlab.value).booleanValue()) {
/* 339 */         return (state.method_11654((class_2769)class_2482.field_11501) != class_2771.field_12681);
/*     */       }
/* 341 */       return true;
/*     */     } 
/* 343 */     return block instanceof net.minecraft.class_2510;
/*     */   }
/*     */   
/*     */   static boolean canWalkOn(IPlayerContext ctx, BetterBlockPos pos, class_2680 state) {
/* 347 */     return canWalkOn(new BlockStateInterface(ctx), pos.x, pos.y, pos.z, state);
/*     */   }
/*     */   
/*     */   static boolean canWalkOn(IPlayerContext ctx, class_2338 pos) {
/* 351 */     return canWalkOn(new BlockStateInterface(ctx), pos.method_10263(), pos.method_10264(), pos.method_10260());
/*     */   }
/*     */   
/*     */   static boolean canWalkOn(IPlayerContext ctx, BetterBlockPos pos) {
/* 355 */     return canWalkOn(new BlockStateInterface(ctx), pos.x, pos.y, pos.z);
/*     */   }
/*     */   
/*     */   static boolean canWalkOn(BlockStateInterface bsi, int x, int y, int z) {
/* 359 */     return canWalkOn(bsi, x, y, z, bsi.get0(x, y, z));
/*     */   }
/*     */   
/*     */   static boolean canPlaceAgainst(BlockStateInterface bsi, int x, int y, int z) {
/* 363 */     return canPlaceAgainst(bsi, x, y, z, bsi.get0(x, y, z));
/*     */   }
/*     */   
/*     */   static boolean canPlaceAgainst(BlockStateInterface bsi, class_2338 pos) {
/* 367 */     return canPlaceAgainst(bsi, pos.method_10263(), pos.method_10264(), pos.method_10260());
/*     */   }
/*     */   
/*     */   static boolean canPlaceAgainst(IPlayerContext ctx, class_2338 pos) {
/* 371 */     return canPlaceAgainst(new BlockStateInterface(ctx), pos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean canPlaceAgainst(BlockStateInterface bsi, int x, int y, int z, class_2680 state) {
/* 378 */     return (isBlockNormalCube(state) || state.method_26204() == class_2246.field_10033 || state.method_26204() instanceof net.minecraft.class_2506);
/*     */   }
/*     */   
/*     */   static double getMiningDurationTicks(CalculationContext context, int x, int y, int z, boolean includeFalling) {
/* 382 */     return getMiningDurationTicks(context, x, y, z, context.get(x, y, z), includeFalling);
/*     */   }
/*     */   
/*     */   static double getMiningDurationTicks(CalculationContext context, int x, int y, int z, class_2680 state, boolean includeFalling) {
/* 386 */     class_2248 block = state.method_26204();
/* 387 */     if (!canWalkThrough(context.bsi, x, y, z, state)) {
/* 388 */       if (!state.method_26227().method_15769()) {
/* 389 */         return 1000000.0D;
/*     */       }
/* 391 */       double mult = context.breakCostMultiplierAt(x, y, z, state);
/* 392 */       if (mult >= 1000000.0D) {
/* 393 */         return 1000000.0D;
/*     */       }
/* 395 */       if (avoidBreaking(context.bsi, x, y, z, state)) {
/* 396 */         return 1000000.0D;
/*     */       }
/* 398 */       double strVsBlock = context.toolSet.getStrVsBlock(state);
/* 399 */       if (strVsBlock <= 0.0D) {
/* 400 */         return 1000000.0D;
/*     */       }
/* 402 */       double result = 1.0D / strVsBlock;
/* 403 */       result += context.breakBlockAdditionalCost;
/* 404 */       result *= mult;
/* 405 */       if (includeFalling) {
/* 406 */         class_2680 above = context.get(x, y + 1, z);
/* 407 */         if (above.method_26204() instanceof class_2346) {
/* 408 */           result += getMiningDurationTicks(context, x, y + 1, z, above, true);
/*     */         }
/*     */       } 
/* 411 */       return result;
/*     */     } 
/* 413 */     return 0.0D;
/*     */   }
/*     */   
/*     */   static boolean isBottomSlab(class_2680 state) {
/* 417 */     return (state.method_26204() instanceof class_2482 && state
/* 418 */       .method_11654((class_2769)class_2482.field_11501) == class_2771.field_12681);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void switchToBestToolFor(IPlayerContext ctx, class_2680 b) {
/* 428 */     switchToBestToolFor(ctx, b, new ToolSet(ctx.player()), ((Boolean)(BaritoneAPI.getSettings()).preferSilkTouch.value).booleanValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void switchToBestToolFor(IPlayerContext ctx, class_2680 b, ToolSet ts, boolean preferSilkTouch) {
/* 439 */     if (!((Boolean)(Baritone.settings()).disableAutoTool.value).booleanValue() && !((Boolean)(Baritone.settings()).assumeExternalAutoTool.value).booleanValue()) {
/* 440 */       (ctx.player()).field_7514.field_7545 = ts.getBestSlot(b.method_26204(), preferSilkTouch);
/*     */     }
/*     */   }
/*     */   
/*     */   static void moveTowards(IPlayerContext ctx, MovementState state, class_2338 pos) {
/* 445 */     state.setTarget(new MovementState.MovementTarget(new Rotation(
/* 446 */             RotationUtils.calcRotationFromVec3d(ctx.playerHead(), 
/* 447 */               VecUtils.getBlockPosCenter(pos), ctx
/* 448 */               .playerRotations()).getYaw(), (ctx.player()).field_5965), false))
/*     */       
/* 450 */       .setInput(Input.MOVE_FORWARD, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isWater(class_2680 state) {
/* 461 */     class_3611 f = state.method_26227().method_15772();
/* 462 */     return (f == class_3612.field_15910 || f == class_3612.field_15909);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isWater(IPlayerContext ctx, class_2338 bp) {
/* 474 */     return isWater(BlockStateInterface.get(ctx, bp));
/*     */   }
/*     */   
/*     */   static boolean isLava(class_2680 state) {
/* 478 */     class_3611 f = state.method_26227().method_15772();
/* 479 */     return (f == class_3612.field_15908 || f == class_3612.field_15907);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isLiquid(IPlayerContext ctx, class_2338 p) {
/* 490 */     return isLiquid(BlockStateInterface.get(ctx, p));
/*     */   }
/*     */   
/*     */   static boolean isLiquid(class_2680 blockState) {
/* 494 */     return !blockState.method_26227().method_15769();
/*     */   }
/*     */   
/*     */   static boolean possiblyFlowing(class_2680 state) {
/* 498 */     class_3610 fluidState = state.method_26227();
/* 499 */     return (fluidState.method_15772() instanceof net.minecraft.class_3609 && fluidState
/* 500 */       .method_15772().method_15779(fluidState) != 8);
/*     */   }
/*     */   
/*     */   static boolean isFlowing(int x, int y, int z, class_2680 state, BlockStateInterface bsi) {
/* 504 */     class_3610 fluidState = state.method_26227();
/* 505 */     if (!(fluidState.method_15772() instanceof net.minecraft.class_3609)) {
/* 506 */       return false;
/*     */     }
/* 508 */     if (fluidState.method_15772().method_15779(fluidState) != 8) {
/* 509 */       return true;
/*     */     }
/* 511 */     return (possiblyFlowing(bsi.get0(x + 1, y, z)) || 
/* 512 */       possiblyFlowing(bsi.get0(x - 1, y, z)) || 
/* 513 */       possiblyFlowing(bsi.get0(x, y, z + 1)) || 
/* 514 */       possiblyFlowing(bsi.get0(x, y, z - 1)));
/*     */   }
/*     */   
/*     */   static boolean isBlockNormalCube(class_2680 state) {
/* 518 */     class_2248 block = state.method_26204();
/* 519 */     if (block instanceof net.minecraft.class_2211 || block instanceof net.minecraft.class_2667 || block instanceof net.minecraft.class_3736 || block instanceof net.minecraft.class_2480)
/*     */     {
/*     */ 
/*     */       
/* 523 */       return false;
/*     */     }
/* 525 */     return class_2248.method_9614(state.method_26220(null, null));
/*     */   }
/*     */   
/*     */   static PlaceResult attemptToPlaceABlock(MovementState state, IBaritone baritone, class_2338 placeAt, boolean preferDown, boolean wouldSneak) {
/* 529 */     IPlayerContext ctx = baritone.getPlayerContext();
/* 530 */     Optional<Rotation> direct = RotationUtils.reachable(ctx, placeAt, wouldSneak);
/* 531 */     boolean found = false;
/* 532 */     if (direct.isPresent()) {
/* 533 */       state.setTarget(new MovementState.MovementTarget(direct.get(), true));
/* 534 */       found = true;
/*     */     } 
/* 536 */     for (int i = 0; i < 5; i++) {
/* 537 */       class_2338 against1 = placeAt.method_10093(Movement.HORIZONTALS_BUT_ALSO_DOWN_____SO_EVERY_DIRECTION_EXCEPT_UP[i]);
/* 538 */       if (canPlaceAgainst(ctx, against1)) {
/* 539 */         if (!((Baritone)baritone).getInventoryBehavior().selectThrowawayForLocation(false, placeAt.method_10263(), placeAt.method_10264(), placeAt.method_10260())) {
/* 540 */           Helper.HELPER.logDebug("bb pls get me some blocks. dirt, netherrack, cobble");
/* 541 */           state.setStatus(MovementStatus.UNREACHABLE);
/* 542 */           return PlaceResult.NO_OPTION;
/*     */         } 
/* 544 */         double faceX = ((placeAt.method_10263() + against1.method_10263()) + 1.0D) * 0.5D;
/* 545 */         double faceY = ((placeAt.method_10264() + against1.method_10264()) + 0.5D) * 0.5D;
/* 546 */         double faceZ = ((placeAt.method_10260() + against1.method_10260()) + 1.0D) * 0.5D;
/* 547 */         Rotation place = RotationUtils.calcRotationFromVec3d(wouldSneak ? RayTraceUtils.inferSneakingEyePosition((class_1297)ctx.player()) : ctx.playerHead(), new class_243(faceX, faceY, faceZ), ctx.playerRotations());
/* 548 */         class_239 res = RayTraceUtils.rayTraceTowards((class_1297)ctx.player(), place, ctx.playerController().getBlockReachDistance(), wouldSneak);
/* 549 */         if (res != null && res.method_17783() == class_239.class_240.field_1332 && ((class_3965)res).method_17777().equals(against1) && ((class_3965)res).method_17777().method_10093(((class_3965)res).method_17780()).equals(placeAt)) {
/* 550 */           state.setTarget(new MovementState.MovementTarget(place, true));
/* 551 */           found = true;
/*     */           
/* 553 */           if (!preferDown) {
/*     */             break;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 561 */     if (ctx.getSelectedBlock().isPresent()) {
/* 562 */       class_2338 selectedBlock = ctx.getSelectedBlock().get();
/* 563 */       class_2350 side = ((class_3965)ctx.objectMouseOver()).method_17780();
/*     */       
/* 565 */       if (selectedBlock.equals(placeAt) || (canPlaceAgainst(ctx, selectedBlock) && selectedBlock.method_10093(side).equals(placeAt))) {
/* 566 */         if (wouldSneak) {
/* 567 */           state.setInput(Input.SNEAK, true);
/*     */         }
/* 569 */         ((Baritone)baritone).getInventoryBehavior().selectThrowawayForLocation(true, placeAt.method_10263(), placeAt.method_10264(), placeAt.method_10260());
/* 570 */         return PlaceResult.READY_TO_PLACE;
/*     */       } 
/*     */     } 
/* 573 */     if (found) {
/* 574 */       if (wouldSneak) {
/* 575 */         state.setInput(Input.SNEAK, true);
/*     */       }
/* 577 */       ((Baritone)baritone).getInventoryBehavior().selectThrowawayForLocation(true, placeAt.method_10263(), placeAt.method_10264(), placeAt.method_10260());
/* 578 */       return PlaceResult.ATTEMPTING;
/*     */     } 
/* 580 */     return PlaceResult.NO_OPTION;
/*     */   }
/*     */   
/*     */   public enum PlaceResult {
/* 584 */     READY_TO_PLACE, ATTEMPTING, NO_OPTION;
/*     */   }
/*     */   
/*     */   static boolean isTransparent(class_2248 b) {
/* 588 */     return (b == class_2246.field_10124 || b == class_2246.field_10382);
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\pathing\movement\MovementHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */