/*     */ package baritone.pathing.calc;
/*     */ 
/*     */ import baritone.api.pathing.goals.Goal;
/*     */ import baritone.api.utils.BetterBlockPos;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PathNode
/*     */ {
/*     */   public final int x;
/*     */   public final int y;
/*     */   public final int z;
/*     */   public final double estimatedCostToGoal;
/*     */   public double cost;
/*     */   public double combinedCost;
/*     */   public PathNode previous;
/*     */   public int heapPosition;
/*     */   
/*     */   public PathNode(int x, int y, int z, Goal goal) {
/*  67 */     this.previous = null;
/*  68 */     this.cost = 1000000.0D;
/*  69 */     this.estimatedCostToGoal = goal.heuristic(x, y, z);
/*  70 */     if (Double.isNaN(this.estimatedCostToGoal)) {
/*  71 */       throw new IllegalStateException(goal + " calculated implausible heuristic");
/*     */     }
/*  73 */     this.heapPosition = -1;
/*  74 */     this.x = x;
/*  75 */     this.y = y;
/*  76 */     this.z = z;
/*     */   }
/*     */   
/*     */   public boolean isOpen() {
/*  80 */     return (this.heapPosition != -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  90 */     return (int)BetterBlockPos.longHash(this.x, this.y, this.z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 102 */     PathNode other = (PathNode)obj;
/*     */ 
/*     */     
/* 105 */     return (this.x == other.x && this.y == other.y && this.z == other.z);
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\pathing\calc\PathNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */