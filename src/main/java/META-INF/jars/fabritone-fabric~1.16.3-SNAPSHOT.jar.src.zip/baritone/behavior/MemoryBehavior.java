/*    */ package baritone.behavior;
/*    */ 
/*    */ import baritone.Baritone;
/*    */ import baritone.api.cache.IWaypoint;
/*    */ import baritone.api.cache.Waypoint;
/*    */ import baritone.api.event.events.BlockInteractEvent;
/*    */ import baritone.api.utils.BetterBlockPos;
/*    */ import baritone.cache.ContainerMemory;
/*    */ import baritone.utils.BlockStateInterface;
/*    */ import java.io.IOException;
/*    */ import java.nio.file.Files;
/*    */ import java.nio.file.Path;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.UUID;
/*    */ import java.util.function.Function;
/*    */ import net.minecraft.class_1799;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MemoryBehavior
/*    */   extends Behavior
/*    */ {
/*    */   public MemoryBehavior(Baritone baritone) {
/* 47 */     super(baritone);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onBlockInteract(BlockInteractEvent event) {
/* 52 */     if (event.getType() == BlockInteractEvent.Type.USE && BlockStateInterface.getBlock(this.ctx, event.getPos()) instanceof net.minecraft.class_2244) {
/* 53 */       this.baritone.getWorldProvider().getCurrentWorld().getWaypoints().addWaypoint((IWaypoint)new Waypoint("bed", IWaypoint.Tag.BED, BetterBlockPos.from(event.getPos())));
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void onPlayerDeath() {
/* 59 */     this.baritone.getWorldProvider().getCurrentWorld().getWaypoints().addWaypoint((IWaypoint)new Waypoint("death", IWaypoint.Tag.DEATH, this.ctx.playerFeet()));
/*    */   }
/*    */   
/*    */   public EnderChestMemory getCurrent() {
/* 63 */     Path path = (this.baritone.getWorldProvider().getCurrentWorld()).directory;
/* 64 */     return EnderChestMemory.getByServerAndPlayer(path.getParent(), this.ctx.player().method_5667());
/*    */   }
/*    */   
/*    */   public static class EnderChestMemory
/*    */   {
/* 69 */     private static final Map<Path, EnderChestMemory> memory = new HashMap<>();
/*    */     private final Path enderChest;
/*    */     private List<class_1799> contents;
/*    */     
/*    */     private EnderChestMemory(Path enderChest) {
/* 74 */       this.enderChest = enderChest;
/* 75 */       System.out.println("Echest storing in " + enderChest);
/*    */       try {
/* 77 */         this.contents = ContainerMemory.readItemStacks(Files.readAllBytes(enderChest));
/* 78 */       } catch (IOException e) {
/* 79 */         e.printStackTrace();
/* 80 */         System.out.println("CANNOT read echest =( =(");
/* 81 */         this.contents = null;
/*    */       } 
/*    */     }
/*    */     
/*    */     public synchronized void save() {
/* 86 */       System.out.println("Saving");
/* 87 */       if (this.contents != null) {
/*    */         try {
/* 89 */           this.enderChest.getParent().toFile().mkdir();
/* 90 */           Files.write(this.enderChest, ContainerMemory.writeItemStacks(this.contents), new java.nio.file.OpenOption[0]);
/* 91 */         } catch (IOException e) {
/* 92 */           e.printStackTrace();
/* 93 */           System.out.println("CANNOT save echest =( =(");
/*    */         } 
/*    */       }
/*    */     }
/*    */     
/*    */     private static synchronized EnderChestMemory getByServerAndPlayer(Path serverStorage, UUID player) {
/* 99 */       return memory.computeIfAbsent(serverStorage.resolve("echests").resolve(player.toString()), EnderChestMemory::new);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\behavior\MemoryBehavior.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */