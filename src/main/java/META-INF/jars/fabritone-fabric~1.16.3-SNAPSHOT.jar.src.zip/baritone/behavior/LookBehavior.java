/*     */ package baritone.behavior;
/*     */ 
/*     */ import baritone.Baritone;
/*     */ import baritone.api.behavior.ILookBehavior;
/*     */ import baritone.api.event.events.PlayerUpdateEvent;
/*     */ import baritone.api.event.events.RotationMoveEvent;
/*     */ import baritone.api.event.events.type.EventState;
/*     */ import baritone.api.utils.Rotation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class LookBehavior
/*     */   extends Behavior
/*     */   implements ILookBehavior
/*     */ {
/*     */   private Rotation target;
/*     */   private boolean force;
/*     */   private float lastYaw;
/*     */   
/*     */   public LookBehavior(Baritone baritone) {
/*  47 */     super(baritone);
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateTarget(Rotation target, boolean force) {
/*  52 */     this.target = target;
/*  53 */     if (!force) {
/*  54 */       double rand = Math.random() - 0.5D;
/*  55 */       if (Math.abs(rand) < 0.1D) {
/*  56 */         rand *= 4.0D;
/*     */       }
/*  58 */       this.target = new Rotation(this.target.getYaw() + (float)(rand * ((Double)(Baritone.settings()).randomLooking113.value).doubleValue()), this.target.getPitch());
/*     */     } 
/*  60 */     this.force = (force || !((Boolean)(Baritone.settings()).freeLook.value).booleanValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public void onPlayerUpdate(PlayerUpdateEvent event) {
/*  65 */     if (this.target == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  70 */     boolean silent = (((Boolean)(Baritone.settings()).antiCheatCompatibility.value).booleanValue() && !this.force);
/*     */     
/*  72 */     switch (event.getState()) {
/*     */       case PRE:
/*  74 */         if (this.force) {
/*  75 */           (this.ctx.player()).field_6031 = this.target.getYaw();
/*  76 */           float oldPitch = (this.ctx.player()).field_5965;
/*  77 */           float desiredPitch = this.target.getPitch();
/*  78 */           (this.ctx.player()).field_5965 = desiredPitch;
/*  79 */           (this.ctx.player()).field_6031 = (float)((this.ctx.player()).field_6031 + (Math.random() - 0.5D) * ((Double)(Baritone.settings()).randomLooking.value).doubleValue());
/*  80 */           (this.ctx.player()).field_5965 = (float)((this.ctx.player()).field_5965 + (Math.random() - 0.5D) * ((Double)(Baritone.settings()).randomLooking.value).doubleValue());
/*  81 */           if (desiredPitch == oldPitch && !((Boolean)(Baritone.settings()).freeLook.value).booleanValue()) {
/*  82 */             nudgeToLevel();
/*     */           }
/*  84 */           this.target = null;
/*     */         } 
/*  86 */         if (silent) {
/*  87 */           this.lastYaw = (this.ctx.player()).field_6031;
/*  88 */           (this.ctx.player()).field_6031 = this.target.getYaw();
/*     */         } 
/*     */         break;
/*     */       
/*     */       case POST:
/*  93 */         if (silent) {
/*  94 */           (this.ctx.player()).field_6031 = this.lastYaw;
/*  95 */           this.target = null;
/*     */         } 
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void pig() {
/* 105 */     if (this.target != null) {
/* 106 */       (this.ctx.player()).field_6031 = this.target.getYaw();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void onPlayerRotationMove(RotationMoveEvent event) {
/* 112 */     if (this.target != null) {
/*     */       
/* 114 */       event.setYaw(this.target.getYaw());
/*     */ 
/*     */ 
/*     */       
/* 118 */       if (!((Boolean)(Baritone.settings()).antiCheatCompatibility.value).booleanValue() && event.getType() == RotationMoveEvent.Type.MOTION_UPDATE && !this.force) {
/* 119 */         this.target = null;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void nudgeToLevel() {
/* 128 */     if ((this.ctx.player()).field_5965 < -20.0F) {
/* 129 */       (this.ctx.player()).field_5965++;
/* 130 */     } else if ((this.ctx.player()).field_5965 > 10.0F) {
/* 131 */       (this.ctx.player()).field_5965--;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\behavior\LookBehavior.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */