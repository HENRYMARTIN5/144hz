/*    */ package baritone.behavior;
/*    */ 
/*    */ import baritone.Baritone;
/*    */ import baritone.api.behavior.IBehavior;
/*    */ import baritone.api.utils.IPlayerContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Behavior
/*    */   implements IBehavior
/*    */ {
/*    */   public final Baritone baritone;
/*    */   public final IPlayerContext ctx;
/*    */   
/*    */   protected Behavior(Baritone baritone) {
/* 36 */     this.baritone = baritone;
/* 37 */     this.ctx = baritone.getPlayerContext();
/* 38 */     baritone.registerBehavior(this);
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\behavior\Behavior.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */