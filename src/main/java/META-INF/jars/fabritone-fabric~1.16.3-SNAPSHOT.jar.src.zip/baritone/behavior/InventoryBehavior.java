/*     */ package baritone.behavior;
/*     */ 
/*     */ import baritone.Baritone;
/*     */ import baritone.api.event.events.TickEvent;
/*     */ import baritone.utils.ToolSet;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.OptionalInt;
/*     */ import java.util.Random;
/*     */ import java.util.function.Predicate;
/*     */ import net.minecraft.class_1268;
/*     */ import net.minecraft.class_1657;
/*     */ import net.minecraft.class_1713;
/*     */ import net.minecraft.class_1747;
/*     */ import net.minecraft.class_1750;
/*     */ import net.minecraft.class_1792;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_1810;
/*     */ import net.minecraft.class_1831;
/*     */ import net.minecraft.class_1838;
/*     */ import net.minecraft.class_1937;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2248;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_2371;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_3965;
/*     */ import net.minecraft.class_746;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class InventoryBehavior
/*     */   extends Behavior
/*     */ {
/*     */   public InventoryBehavior(Baritone baritone) {
/*  43 */     super(baritone);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onTick(TickEvent event) {
/*  48 */     if (!((Boolean)(Baritone.settings()).allowInventory.value).booleanValue()) {
/*     */       return;
/*     */     }
/*  51 */     if (event.getType() == TickEvent.Type.OUT) {
/*     */       return;
/*     */     }
/*  54 */     if ((this.ctx.player()).field_7498 != (this.ctx.player()).field_7512) {
/*     */       return;
/*     */     }
/*     */     
/*  58 */     if (firstValidThrowaway() >= 9) {
/*  59 */       swapWithHotBar(firstValidThrowaway(), 8);
/*     */     }
/*  61 */     int pick = bestToolAgainst(class_2246.field_10340, (Class)class_1810.class);
/*  62 */     if (pick >= 9) {
/*  63 */       swapWithHotBar(pick, 0);
/*     */     }
/*     */   }
/*     */   
/*     */   public void attemptToPutOnHotbar(int inMainInvy, Predicate<Integer> disallowedHotbar) {
/*  68 */     OptionalInt destination = getTempHotbarSlot(disallowedHotbar);
/*  69 */     if (destination.isPresent()) {
/*  70 */       swapWithHotBar(inMainInvy, destination.getAsInt());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public OptionalInt getTempHotbarSlot(Predicate<Integer> disallowedHotbar) {
/*  76 */     ArrayList<Integer> candidates = new ArrayList<>(); int i;
/*  77 */     for (i = 1; i < 8; i++) {
/*  78 */       if (((class_1799)(this.ctx.player()).field_7514.field_7547.get(i)).method_7960() && !disallowedHotbar.test(Integer.valueOf(i))) {
/*  79 */         candidates.add(Integer.valueOf(i));
/*     */       }
/*     */     } 
/*  82 */     if (candidates.isEmpty()) {
/*  83 */       for (i = 1; i < 8; i++) {
/*  84 */         if (!disallowedHotbar.test(Integer.valueOf(i))) {
/*  85 */           candidates.add(Integer.valueOf(i));
/*     */         }
/*     */       } 
/*     */     }
/*  89 */     if (candidates.isEmpty()) {
/*  90 */       return OptionalInt.empty();
/*     */     }
/*  92 */     return OptionalInt.of(((Integer)candidates.get((new Random()).nextInt(candidates.size()))).intValue());
/*     */   }
/*     */   
/*     */   private void swapWithHotBar(int inInventory, int inHotbar) {
/*  96 */     this.ctx.playerController().windowClick((this.ctx.player()).field_7512.field_7763, (inInventory < 9) ? (inInventory + 36) : inInventory, inHotbar, class_1713.field_7791, (class_1657)this.ctx.player());
/*     */   }
/*     */   
/*     */   private int firstValidThrowaway() {
/* 100 */     class_2371<class_1799> invy = (this.ctx.player()).field_7514.field_7547;
/* 101 */     for (int i = 0; i < invy.size(); i++) {
/* 102 */       if (((List)(Baritone.settings()).acceptableThrowawayItems.value).contains(((class_1799)invy.get(i)).method_7909())) {
/* 103 */         return i;
/*     */       }
/*     */     } 
/* 106 */     return -1;
/*     */   }
/*     */   
/*     */   private int bestToolAgainst(class_2248 against, Class<? extends class_1831> cla$$) {
/* 110 */     class_2371<class_1799> invy = (this.ctx.player()).field_7514.field_7547;
/* 111 */     int bestInd = -1;
/* 112 */     double bestSpeed = -1.0D;
/* 113 */     for (int i = 0; i < invy.size(); i++) {
/* 114 */       class_1799 stack = (class_1799)invy.get(i);
/* 115 */       if (!stack.method_7960())
/*     */       {
/*     */         
/* 118 */         if (cla$$.isInstance(stack.method_7909())) {
/* 119 */           double speed = ToolSet.calculateSpeedVsBlock(stack, against.method_9564());
/* 120 */           if (speed > bestSpeed) {
/* 121 */             bestSpeed = speed;
/* 122 */             bestInd = i;
/*     */           } 
/*     */         }  } 
/*     */     } 
/* 126 */     return bestInd;
/*     */   }
/*     */   
/*     */   public boolean hasGenericThrowaway() {
/* 130 */     for (Iterator<class_1792> iterator = ((List)(Baritone.settings()).acceptableThrowawayItems.value).iterator(); iterator.hasNext(); ) { class_1792 item = iterator.next();
/* 131 */       if (throwaway(false, stack -> item.equals(stack.method_7909()))) {
/* 132 */         return true;
/*     */       } }
/*     */     
/* 135 */     return false;
/*     */   }
/*     */   
/*     */   public boolean selectThrowawayForLocation(boolean select, int x, int y, int z) {
/* 139 */     class_2680 maybe = this.baritone.getBuilderProcess().placeAt(x, y, z, this.baritone.bsi.get0(x, y, z));
/* 140 */     if (maybe != null && throwaway(select, stack -> (stack.method_7909() instanceof class_1747 && maybe.equals(((class_1747)stack.method_7909()).method_7711().method_9605(new class_1750(new class_1838(this.ctx.world(), (class_1657)this.ctx.player(), class_1268.field_5808, stack, new class_3965(new class_243(this.ctx.player().method_23317(), this.ctx.player().method_23318(), this.ctx.player().method_23321()), class_2350.field_11036, (class_2338)this.ctx.playerFeet(), false)) {  })))))) {
/* 141 */       return true;
/*     */     }
/* 143 */     if (maybe != null && throwaway(select, stack -> (stack.method_7909() instanceof class_1747 && ((class_1747)stack.method_7909()).method_7711().equals(maybe.method_26204())))) {
/* 144 */       return true;
/*     */     }
/* 146 */     for (class_1792 item : (Baritone.settings()).acceptableThrowawayItems.value) {
/* 147 */       if (throwaway(select, stack -> item.equals(stack.method_7909()))) {
/* 148 */         return true;
/*     */       }
/*     */     } 
/* 151 */     return false;
/*     */   }
/*     */   
/*     */   public boolean throwaway(boolean select, Predicate<? super class_1799> desired) {
/* 155 */     class_746 p = this.ctx.player();
/* 156 */     class_2371<class_1799> inv = p.field_7514.field_7547; int i;
/* 157 */     for (i = 0; i < 9; i++) {
/* 158 */       class_1799 item = (class_1799)inv.get(i);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 164 */       if (desired.test(item)) {
/* 165 */         if (select) {
/* 166 */           p.field_7514.field_7545 = i;
/*     */         }
/* 168 */         return true;
/*     */       } 
/*     */     } 
/* 171 */     if (desired.test(p.field_7514.field_7544.get(0)))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 177 */       for (i = 0; i < 9; i++) {
/* 178 */         class_1799 item = (class_1799)inv.get(i);
/* 179 */         if (item.method_7960() || item.method_7909() instanceof class_1810) {
/* 180 */           if (select) {
/* 181 */             p.field_7514.field_7545 = i;
/*     */           }
/* 183 */           return true;
/*     */         } 
/*     */       } 
/*     */     }
/* 187 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\behavior\InventoryBehavior.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */