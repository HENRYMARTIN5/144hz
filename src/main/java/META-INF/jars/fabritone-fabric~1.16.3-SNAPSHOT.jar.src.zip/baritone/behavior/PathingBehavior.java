/*     */ package baritone.behavior;
/*     */ 
/*     */ import baritone.Baritone;
/*     */ import baritone.api.IBaritone;
/*     */ import baritone.api.behavior.IPathingBehavior;
/*     */ import baritone.api.event.events.PathEvent;
/*     */ import baritone.api.event.events.PlayerUpdateEvent;
/*     */ import baritone.api.event.events.RenderEvent;
/*     */ import baritone.api.event.events.SprintStateEvent;
/*     */ import baritone.api.event.events.TickEvent;
/*     */ import baritone.api.event.events.type.EventState;
/*     */ import baritone.api.pathing.calc.IPath;
/*     */ import baritone.api.pathing.goals.Goal;
/*     */ import baritone.api.pathing.goals.GoalXZ;
/*     */ import baritone.api.pathing.path.IPathExecutor;
/*     */ import baritone.api.process.PathingCommand;
/*     */ import baritone.api.utils.BetterBlockPos;
/*     */ import baritone.api.utils.Helper;
/*     */ import baritone.api.utils.PathCalculationResult;
/*     */ import baritone.api.utils.interfaces.IGoalRenderPos;
/*     */ import baritone.pathing.calc.AStarPathFinder;
/*     */ import baritone.pathing.calc.AbstractNodeCostSearch;
/*     */ import baritone.pathing.movement.CalculationContext;
/*     */ import baritone.pathing.movement.MovementHelper;
/*     */ import baritone.pathing.path.PathExecutor;
/*     */ import baritone.utils.PathRenderer;
/*     */ import baritone.utils.PathingCommandContext;
/*     */ import baritone.utils.pathing.Favoring;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.concurrent.LinkedBlockingQueue;
/*     */ import net.minecraft.class_2338;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PathingBehavior
/*     */   extends Behavior
/*     */   implements IPathingBehavior, Helper
/*     */ {
/*     */   private PathExecutor current;
/*     */   private PathExecutor next;
/*     */   private Goal goal;
/*     */   private CalculationContext context;
/*     */   private boolean safeToCancel;
/*     */   private boolean pauseRequestedLastTick;
/*     */   private boolean unpausedLastTick;
/*     */   private boolean pausedThisTick;
/*     */   private boolean cancelRequested;
/*     */   private boolean calcFailedLastTick;
/*     */   private volatile AbstractNodeCostSearch inProgress;
/*  63 */   private final Object pathCalcLock = new Object();
/*     */   
/*  65 */   private final Object pathPlanLock = new Object();
/*     */   
/*     */   private boolean lastAutoJump;
/*     */   
/*     */   private BetterBlockPos expectedSegmentStart;
/*     */   
/*  71 */   private final LinkedBlockingQueue<PathEvent> toDispatch = new LinkedBlockingQueue<>();
/*     */   
/*     */   public PathingBehavior(Baritone baritone) {
/*  74 */     super(baritone);
/*     */   }
/*     */   
/*     */   private void queuePathEvent(PathEvent event) {
/*  78 */     this.toDispatch.add(event);
/*     */   }
/*     */   
/*     */   private void dispatchEvents() {
/*  82 */     ArrayList<PathEvent> curr = new ArrayList<>();
/*  83 */     this.toDispatch.drainTo(curr);
/*  84 */     this.calcFailedLastTick = curr.contains(PathEvent.CALC_FAILED);
/*  85 */     for (PathEvent event : curr) {
/*  86 */       this.baritone.getGameEventHandler().onPathEvent(event);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void onTick(TickEvent event) {
/*  92 */     dispatchEvents();
/*  93 */     if (event.getType() == TickEvent.Type.OUT) {
/*  94 */       secretInternalSegmentCancel();
/*  95 */       this.baritone.getPathingControlManager().cancelEverything();
/*     */       return;
/*     */     } 
/*  98 */     this.expectedSegmentStart = pathStart();
/*  99 */     this.baritone.getPathingControlManager().preTick();
/* 100 */     tickPath();
/* 101 */     dispatchEvents();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onPlayerSprintState(SprintStateEvent event) {
/* 106 */     if (isPathing()) {
/* 107 */       event.setState(this.current.isSprinting());
/*     */     }
/*     */   }
/*     */   
/*     */   private void tickPath() {
/* 112 */     this.pausedThisTick = false;
/* 113 */     if (this.pauseRequestedLastTick && this.safeToCancel) {
/* 114 */       this.pauseRequestedLastTick = false;
/* 115 */       if (this.unpausedLastTick) {
/* 116 */         this.baritone.getInputOverrideHandler().clearAllKeys();
/* 117 */         this.baritone.getInputOverrideHandler().getBlockBreakHelper().stopBreakingBlock();
/*     */       } 
/* 119 */       this.unpausedLastTick = false;
/* 120 */       this.pausedThisTick = true;
/*     */       return;
/*     */     } 
/* 123 */     this.unpausedLastTick = true;
/* 124 */     if (this.cancelRequested) {
/* 125 */       this.cancelRequested = false;
/* 126 */       this.baritone.getInputOverrideHandler().clearAllKeys();
/*     */     } 
/* 128 */     synchronized (this.pathPlanLock) {
/* 129 */       synchronized (this.pathCalcLock) {
/* 130 */         if (this.inProgress != null) {
/*     */ 
/*     */           
/* 133 */           BetterBlockPos calcFrom = this.inProgress.getStart();
/* 134 */           Optional<IPath> currentBest = this.inProgress.bestPathSoFar();
/* 135 */           if ((this.current == null || !this.current.getPath().getDest().equals(calcFrom)) && 
/* 136 */             !calcFrom.equals(this.ctx.playerFeet()) && !calcFrom.equals(this.expectedSegmentStart) && (
/* 137 */             !currentBest.isPresent() || (!((IPath)currentBest.get()).positions().contains(this.ctx.playerFeet()) && !((IPath)currentBest.get()).positions().contains(this.expectedSegmentStart))))
/*     */           {
/*     */             
/* 140 */             this.inProgress.cancel();
/*     */           }
/*     */         } 
/*     */       } 
/* 144 */       if (this.current == null) {
/*     */         return;
/*     */       }
/* 147 */       this.safeToCancel = this.current.onTick();
/* 148 */       if (this.current.failed() || this.current.finished()) {
/* 149 */         this.current = null;
/* 150 */         if (this.goal == null || this.goal.isInGoal((class_2338)this.ctx.playerFeet())) {
/* 151 */           logDebug("All done. At " + this.goal);
/* 152 */           queuePathEvent(PathEvent.AT_GOAL);
/* 153 */           this.next = null;
/* 154 */           if (((Boolean)(Baritone.settings()).disconnectOnArrival.value).booleanValue()) {
/* 155 */             this.ctx.world().method_8525();
/*     */           }
/*     */           return;
/*     */         } 
/* 159 */         if (this.next != null && !this.next.getPath().positions().contains(this.ctx.playerFeet()) && !this.next.getPath().positions().contains(this.expectedSegmentStart)) {
/*     */           
/* 161 */           logDebug("Discarding next path as it does not contain current position");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 167 */           queuePathEvent(PathEvent.DISCARD_NEXT);
/* 168 */           this.next = null;
/*     */         } 
/* 170 */         if (this.next != null) {
/* 171 */           logDebug("Continuing on to planned next path");
/* 172 */           queuePathEvent(PathEvent.CONTINUING_ONTO_PLANNED_NEXT);
/* 173 */           this.current = this.next;
/* 174 */           this.next = null;
/* 175 */           this.current.onTick();
/*     */           
/*     */           return;
/*     */         } 
/* 179 */         synchronized (this.pathCalcLock) {
/* 180 */           if (this.inProgress != null) {
/* 181 */             queuePathEvent(PathEvent.PATH_FINISHED_NEXT_STILL_CALCULATING);
/*     */             
/*     */             return;
/*     */           } 
/* 185 */           queuePathEvent(PathEvent.CALC_STARTED);
/* 186 */           findPathInNewThread((class_2338)this.expectedSegmentStart, true, this.context);
/*     */         } 
/*     */         
/*     */         return;
/*     */       } 
/* 191 */       if (this.safeToCancel && this.next != null && this.next.snipsnapifpossible()) {
/*     */         
/* 193 */         logDebug("Splicing into planned next path early...");
/* 194 */         queuePathEvent(PathEvent.SPLICING_ONTO_NEXT_EARLY);
/* 195 */         this.current = this.next;
/* 196 */         this.next = null;
/* 197 */         this.current.onTick();
/*     */         return;
/*     */       } 
/* 200 */       if (((Boolean)(Baritone.settings()).splicePath.value).booleanValue()) {
/* 201 */         this.current = this.current.trySplice(this.next);
/*     */       }
/* 203 */       if (this.next != null && this.current.getPath().getDest().equals(this.next.getPath().getDest())) {
/* 204 */         this.next = null;
/*     */       }
/* 206 */       synchronized (this.pathCalcLock) {
/* 207 */         if (this.inProgress != null) {
/*     */           return;
/*     */         }
/*     */         
/* 211 */         if (this.next != null) {
/*     */           return;
/*     */         }
/*     */         
/* 215 */         if (this.goal == null || this.goal.isInGoal((class_2338)this.current.getPath().getDest())) {
/*     */           return;
/*     */         }
/*     */         
/* 219 */         if (((Double)ticksRemainingInSegment(false).get()).doubleValue() < ((Integer)(Baritone.settings()).planningTickLookahead.value).intValue()) {
/*     */ 
/*     */ 
/*     */           
/* 223 */           logDebug("Path almost over. Planning ahead...");
/* 224 */           queuePathEvent(PathEvent.NEXT_SEGMENT_CALC_STARTED);
/* 225 */           findPathInNewThread((class_2338)this.current.getPath().getDest(), false, this.context);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void onPlayerUpdate(PlayerUpdateEvent event) {
/* 233 */     if (this.current != null) {
/* 234 */       switch (event.getState()) {
/*     */         case PRE:
/* 236 */           this.lastAutoJump = mc.field_1690.field_1848;
/* 237 */           mc.field_1690.field_1848 = false;
/*     */           break;
/*     */         case POST:
/* 240 */           mc.field_1690.field_1848 = this.lastAutoJump;
/*     */           break;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void secretInternalSetGoal(Goal goal) {
/* 249 */     this.goal = goal;
/*     */   }
/*     */   
/*     */   public boolean secretInternalSetGoalAndPath(PathingCommand command) {
/* 253 */     secretInternalSetGoal(command.goal);
/* 254 */     if (command instanceof PathingCommandContext) {
/* 255 */       this.context = ((PathingCommandContext)command).desiredCalcContext;
/*     */     } else {
/* 257 */       this.context = new CalculationContext((IBaritone)this.baritone, true);
/*     */     } 
/* 259 */     if (this.goal == null) {
/* 260 */       return false;
/*     */     }
/* 262 */     if (this.goal.isInGoal((class_2338)this.ctx.playerFeet()) || this.goal.isInGoal((class_2338)this.expectedSegmentStart)) {
/* 263 */       return false;
/*     */     }
/* 265 */     synchronized (this.pathPlanLock) {
/* 266 */       if (this.current != null) {
/* 267 */         return false;
/*     */       }
/* 269 */       synchronized (this.pathCalcLock) {
/* 270 */         if (this.inProgress != null) {
/* 271 */           return false;
/*     */         }
/* 273 */         queuePathEvent(PathEvent.CALC_STARTED);
/* 274 */         findPathInNewThread((class_2338)this.expectedSegmentStart, true, this.context);
/* 275 */         return true;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Goal getGoal() {
/* 282 */     return this.goal;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPathing() {
/* 287 */     return (hasPath() && !this.pausedThisTick);
/*     */   }
/*     */ 
/*     */   
/*     */   public PathExecutor getCurrent() {
/* 292 */     return this.current;
/*     */   }
/*     */ 
/*     */   
/*     */   public PathExecutor getNext() {
/* 297 */     return this.next;
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<AbstractNodeCostSearch> getInProgress() {
/* 302 */     return Optional.ofNullable(this.inProgress);
/*     */   }
/*     */   
/*     */   public boolean isSafeToCancel() {
/* 306 */     return (this.current == null || this.safeToCancel);
/*     */   }
/*     */   
/*     */   public void requestPause() {
/* 310 */     this.pauseRequestedLastTick = true;
/*     */   }
/*     */   
/*     */   public boolean cancelSegmentIfSafe() {
/* 314 */     if (isSafeToCancel()) {
/* 315 */       secretInternalSegmentCancel();
/* 316 */       return true;
/*     */     } 
/* 318 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean cancelEverything() {
/* 323 */     boolean doIt = isSafeToCancel();
/* 324 */     if (doIt) {
/* 325 */       secretInternalSegmentCancel();
/*     */     }
/* 327 */     this.baritone.getPathingControlManager().cancelEverything();
/* 328 */     return doIt;
/*     */   }
/*     */   
/*     */   public boolean calcFailedLastTick() {
/* 332 */     return this.calcFailedLastTick;
/*     */   }
/*     */   
/*     */   public void softCancelIfSafe() {
/* 336 */     synchronized (this.pathPlanLock) {
/* 337 */       getInProgress().ifPresent(AbstractNodeCostSearch::cancel);
/* 338 */       if (!isSafeToCancel()) {
/*     */         return;
/*     */       }
/* 341 */       this.current = null;
/* 342 */       this.next = null;
/*     */     } 
/* 344 */     this.cancelRequested = true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void secretInternalSegmentCancel() {
/* 350 */     queuePathEvent(PathEvent.CANCELED);
/* 351 */     synchronized (this.pathPlanLock) {
/* 352 */       getInProgress().ifPresent(AbstractNodeCostSearch::cancel);
/* 353 */       if (this.current != null) {
/* 354 */         this.current = null;
/* 355 */         this.next = null;
/* 356 */         this.baritone.getInputOverrideHandler().clearAllKeys();
/* 357 */         this.baritone.getInputOverrideHandler().getBlockBreakHelper().stopBreakingBlock();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void forceCancel() {
/* 364 */     cancelEverything();
/* 365 */     secretInternalSegmentCancel();
/* 366 */     synchronized (this.pathCalcLock) {
/* 367 */       this.inProgress = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public CalculationContext secretInternalGetCalculationContext() {
/* 372 */     return this.context;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BetterBlockPos pathStart() {
/* 381 */     BetterBlockPos feet = this.ctx.playerFeet();
/* 382 */     if (!MovementHelper.canWalkOn(this.ctx, feet.down())) {
/* 383 */       if (this.ctx.player().method_24828()) {
/* 384 */         double playerX = this.ctx.player().method_23317();
/* 385 */         double playerZ = this.ctx.player().method_23321();
/* 386 */         ArrayList<BetterBlockPos> closest = new ArrayList<>();
/* 387 */         for (int dx = -1; dx <= 1; dx++) {
/* 388 */           for (int dz = -1; dz <= 1; dz++) {
/* 389 */             closest.add(new BetterBlockPos(feet.x + dx, feet.y, feet.z + dz));
/*     */           }
/*     */         } 
/* 392 */         closest.sort(Comparator.comparingDouble(pos -> (pos.x + 0.5D - playerX) * (pos.x + 0.5D - playerX) + (pos.z + 0.5D - playerZ) * (pos.z + 0.5D - playerZ)));
/* 393 */         for (int i = 0; i < 4; i++) {
/* 394 */           BetterBlockPos possibleSupport = closest.get(i);
/* 395 */           double xDist = Math.abs(possibleSupport.x + 0.5D - playerX);
/* 396 */           double zDist = Math.abs(possibleSupport.z + 0.5D - playerZ);
/* 397 */           if (xDist <= 0.8D || zDist <= 0.8D)
/*     */           {
/*     */ 
/*     */             
/* 401 */             if (MovementHelper.canWalkOn(this.ctx, possibleSupport.down()) && MovementHelper.canWalkThrough(this.ctx, possibleSupport) && MovementHelper.canWalkThrough(this.ctx, possibleSupport.up()))
/*     */             {
/*     */               
/* 404 */               return possibleSupport;
/*     */             
/*     */             }
/*     */           }
/*     */         }
/*     */       
/*     */       }
/* 411 */       else if (MovementHelper.canWalkOn(this.ctx, feet.down().down())) {
/*     */         
/* 413 */         return feet.down();
/*     */       } 
/*     */     }
/*     */     
/* 417 */     return feet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void findPathInNewThread(class_2338 start, boolean talkAboutIt, CalculationContext context) {
/*     */     long primaryTimeout, failureTimeout;
/* 429 */     if (!Thread.holdsLock(this.pathCalcLock)) {
/* 430 */       throw new IllegalStateException("Must be called with synchronization on pathCalcLock");
/*     */     }
/*     */     
/* 433 */     if (this.inProgress != null) {
/* 434 */       throw new IllegalStateException("Already doing it");
/*     */     }
/* 436 */     if (!context.safeForThreadedUse) {
/* 437 */       throw new IllegalStateException("Improper context thread safety level");
/*     */     }
/* 439 */     Goal goal = this.goal;
/* 440 */     if (goal == null) {
/* 441 */       logDebug("no goal");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 446 */     if (this.current == null) {
/* 447 */       primaryTimeout = ((Long)(Baritone.settings()).primaryTimeoutMS.value).longValue();
/* 448 */       failureTimeout = ((Long)(Baritone.settings()).failureTimeoutMS.value).longValue();
/*     */     } else {
/* 450 */       primaryTimeout = ((Long)(Baritone.settings()).planAheadPrimaryTimeoutMS.value).longValue();
/* 451 */       failureTimeout = ((Long)(Baritone.settings()).planAheadFailureTimeoutMS.value).longValue();
/*     */     } 
/* 453 */     AbstractNodeCostSearch pathfinder = createPathfinder(start, goal, (this.current == null) ? null : this.current.getPath(), context);
/* 454 */     if (!Objects.equals(pathfinder.getGoal(), goal)) {
/* 455 */       logDebug("Simplifying " + goal.getClass() + " to GoalXZ due to distance");
/*     */     }
/* 457 */     this.inProgress = pathfinder;
/* 458 */     Baritone.getExecutor().execute(() -> {
/*     */           if (talkAboutIt) {
/*     */             logDebug("Starting to search for path from " + start + " to " + goal);
/*     */           }
/*     */           PathCalculationResult calcResult = pathfinder.calculate(primaryTimeout, failureTimeout);
/*     */           synchronized (this.pathPlanLock) {
/*     */             Optional<PathExecutor> executor = calcResult.getPath().map(());
/*     */             if (this.current == null) {
/*     */               if (executor.isPresent()) {
/*     */                 if (((PathExecutor)executor.get()).getPath().positions().contains(this.expectedSegmentStart)) {
/*     */                   queuePathEvent(PathEvent.CALC_FINISHED_NOW_EXECUTING);
/*     */                   this.current = executor.get();
/*     */                 } else {
/*     */                   logDebug("Warning: discarding orphan path segment with incorrect start");
/*     */                 } 
/*     */               } else if (calcResult.getType() != PathCalculationResult.Type.CANCELLATION && calcResult.getType() != PathCalculationResult.Type.EXCEPTION) {
/*     */                 queuePathEvent(PathEvent.CALC_FAILED);
/*     */               } 
/*     */             } else if (this.next == null) {
/*     */               if (executor.isPresent()) {
/*     */                 if (((PathExecutor)executor.get()).getPath().getSrc().equals(this.current.getPath().getDest())) {
/*     */                   queuePathEvent(PathEvent.NEXT_SEGMENT_CALC_FINISHED);
/*     */                   this.next = executor.get();
/*     */                 } else {
/*     */                   logDebug("Warning: discarding orphan next segment with incorrect start");
/*     */                 } 
/*     */               } else {
/*     */                 queuePathEvent(PathEvent.NEXT_CALC_FAILED);
/*     */               } 
/*     */             } else {
/*     */               logDirect("Warning: PathingBehaivor illegal state! Discarding invalid path!");
/*     */             } 
/*     */             if (talkAboutIt && this.current != null && this.current.getPath() != null) {
/*     */               if (goal.isInGoal((class_2338)this.current.getPath().getDest())) {
/*     */                 logDebug("Finished finding a path from " + start + " to " + goal + ". " + this.current.getPath().getNumNodesConsidered() + " nodes considered");
/*     */               } else {
/*     */                 logDebug("Found path segment from " + start + " towards " + goal + ". " + this.current.getPath().getNumNodesConsidered() + " nodes considered");
/*     */               } 
/*     */             }
/*     */             synchronized (this.pathCalcLock) {
/*     */               this.inProgress = null;
/*     */             } 
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static AbstractNodeCostSearch createPathfinder(class_2338 start, Goal goal, IPath previous, CalculationContext context) {
/*     */     GoalXZ goalXZ;
/* 513 */     Goal transformed = goal;
/* 514 */     if (((Boolean)(Baritone.settings()).simplifyUnloadedYCoord.value).booleanValue() && goal instanceof IGoalRenderPos) {
/* 515 */       class_2338 pos = ((IGoalRenderPos)goal).getGoalPos();
/* 516 */       if (!context.bsi.worldContainsLoadedChunk(pos.method_10263(), pos.method_10260())) {
/* 517 */         goalXZ = new GoalXZ(pos.method_10263(), pos.method_10260());
/*     */       }
/*     */     } 
/* 520 */     Favoring favoring = new Favoring(context.getBaritone().getPlayerContext(), previous, context);
/* 521 */     return (AbstractNodeCostSearch)new AStarPathFinder(start.method_10263(), start.method_10264(), start.method_10260(), (Goal)goalXZ, favoring, context);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onRenderPass(RenderEvent event) {
/* 526 */     PathRenderer.render(event, this);
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\behavior\PathingBehavior.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */