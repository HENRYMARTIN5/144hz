/*    */ package baritone.utils.schematic.schematica;
/*    */ 
/*    */ import baritone.api.schematic.IStaticSchematic;
/*    */ import com.github.lunatrius.schematica.Schematica;
/*    */ import com.github.lunatrius.schematica.client.world.SchematicWorld;
/*    */ import com.github.lunatrius.schematica.proxy.ClientProxy;
/*    */ import java.util.Optional;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_3545;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum SchematicaHelper
/*    */ {
/*    */   public static boolean isSchematicaPresent() {
/*    */     try {
/* 33 */       Class.forName(Schematica.class.getName());
/* 34 */       return true;
/* 35 */     } catch (ClassNotFoundException|NoClassDefFoundError ex) {
/* 36 */       return false;
/*    */     } 
/*    */   }
/*    */   
/*    */   public static Optional<class_3545<IStaticSchematic, class_2338>> getOpenSchematic() {
/* 41 */     return Optional.<SchematicWorld>ofNullable(ClientProxy.schematic)
/* 42 */       .map(world -> new class_3545(new SchematicAdapter(world), world.position));
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\bariton\\utils\schematic\schematica\SchematicaHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */