/*    */ package baritone.utils.schematic.format.defaults;
/*    */ 
/*    */ import baritone.utils.schematic.StaticSchematic;
/*    */ import net.minecraft.class_1181;
/*    */ import net.minecraft.class_2248;
/*    */ import net.minecraft.class_2378;
/*    */ import net.minecraft.class_2487;
/*    */ import net.minecraft.class_2960;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MCEditSchematic
/*    */   extends StaticSchematic
/*    */ {
/*    */   public MCEditSchematic(class_2487 schematic) {
/* 35 */     String type = schematic.method_10558("Materials");
/* 36 */     if (!type.equals("Alpha")) {
/* 37 */       throw new IllegalStateException("bad schematic " + type);
/*    */     }
/* 39 */     this.x = schematic.method_10550("Width");
/* 40 */     this.y = schematic.method_10550("Height");
/* 41 */     this.z = schematic.method_10550("Length");
/* 42 */     byte[] blocks = schematic.method_10547("Blocks");
/*    */ 
/*    */     
/* 45 */     byte[] additional = null;
/* 46 */     if (schematic.method_10545("AddBlocks")) {
/* 47 */       byte[] addBlocks = schematic.method_10547("AddBlocks");
/* 48 */       additional = new byte[addBlocks.length * 2];
/* 49 */       for (int i = 0; i < addBlocks.length; i++) {
/* 50 */         additional[i * 2 + 0] = (byte)(addBlocks[i] >> 4 & 0xF);
/* 51 */         additional[i * 2 + 1] = (byte)(addBlocks[i] >> 0 & 0xF);
/*    */       } 
/*    */     } 
/* 54 */     this.states = new net.minecraft.class_2680[this.x][this.z][this.y];
/* 55 */     for (int y = 0; y < this.y; y++) {
/* 56 */       for (int z = 0; z < this.z; z++) {
/* 57 */         for (int x = 0; x < this.x; x++) {
/* 58 */           int blockInd = (y * this.z + z) * this.x + x;
/*    */           
/* 60 */           int blockID = blocks[blockInd] & 0xFF;
/* 61 */           if (additional != null)
/*    */           {
/* 63 */             blockID |= additional[blockInd] << 8;
/*    */           }
/* 65 */           class_2248 block = (class_2248)class_2378.field_11146.method_10223(class_2960.method_12829(class_1181.method_5018(blockID)));
/*    */ 
/*    */           
/* 68 */           this.states[x][z][y] = block.method_9564();
/*    */         } 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\bariton\\utils\schematic\format\defaults\MCEditSchematic.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */