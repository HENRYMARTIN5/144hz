/*    */ package baritone.utils.pathing;
/*    */ 
/*    */ import baritone.Baritone;
/*    */ import baritone.api.utils.BetterBlockPos;
/*    */ import baritone.api.utils.IPlayerContext;
/*    */ import it.unimi.dsi.fastutil.longs.Long2DoubleOpenHashMap;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import net.minecraft.class_1297;
/*    */ import net.minecraft.class_1560;
/*    */ import net.minecraft.class_1590;
/*    */ import net.minecraft.class_2338;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Avoidance
/*    */ {
/*    */   private final int centerX;
/*    */   private final int centerY;
/*    */   private final int centerZ;
/*    */   private final double coefficient;
/*    */   private final int radius;
/*    */   private final int radiusSq;
/*    */   
/*    */   public Avoidance(class_2338 center, double coefficient, int radius) {
/* 44 */     this(center.method_10263(), center.method_10264(), center.method_10260(), coefficient, radius);
/*    */   }
/*    */   
/*    */   public Avoidance(int centerX, int centerY, int centerZ, double coefficient, int radius) {
/* 48 */     this.centerX = centerX;
/* 49 */     this.centerY = centerY;
/* 50 */     this.centerZ = centerZ;
/* 51 */     this.coefficient = coefficient;
/* 52 */     this.radius = radius;
/* 53 */     this.radiusSq = radius * radius;
/*    */   }
/*    */   
/*    */   public double coefficient(int x, int y, int z) {
/* 57 */     int xDiff = x - this.centerX;
/* 58 */     int yDiff = y - this.centerY;
/* 59 */     int zDiff = z - this.centerZ;
/* 60 */     return (xDiff * xDiff + yDiff * yDiff + zDiff * zDiff <= this.radiusSq) ? this.coefficient : 1.0D;
/*    */   }
/*    */   
/*    */   public static List<Avoidance> create(IPlayerContext ctx) {
/* 64 */     if (!((Boolean)(Baritone.settings()).avoidance.value).booleanValue()) {
/* 65 */       return Collections.emptyList();
/*    */     }
/* 67 */     List<Avoidance> res = new ArrayList<>();
/* 68 */     double mobSpawnerCoeff = ((Double)(Baritone.settings()).mobSpawnerAvoidanceCoefficient.value).doubleValue();
/* 69 */     double mobCoeff = ((Double)(Baritone.settings()).mobAvoidanceCoefficient.value).doubleValue();
/* 70 */     if (mobSpawnerCoeff != 1.0D) {
/* 71 */       ctx.worldData().getCachedWorld().getLocationsOf("mob_spawner", 1, (ctx.playerFeet()).x, (ctx.playerFeet()).z, 2)
/* 72 */         .forEach(mobspawner -> res.add(new Avoidance(mobspawner, mobSpawnerCoeff, ((Integer)(Baritone.settings()).mobSpawnerAvoidanceRadius.value).intValue())));
/*    */     }
/* 74 */     if (mobCoeff != 1.0D) {
/* 75 */       ctx.entitiesStream()
/* 76 */         .filter(entity -> entity instanceof net.minecraft.class_1308)
/* 77 */         .filter(entity -> (!(entity instanceof net.minecraft.class_1628) || ctx.player().method_5718() < 0.5D))
/* 78 */         .filter(entity -> (!(entity instanceof class_1590) || ((class_1590)entity).method_6065() != null))
/* 79 */         .filter(entity -> (!(entity instanceof class_1560) || ((class_1560)entity).method_7028()))
/* 80 */         .forEach(entity -> res.add(new Avoidance(entity.method_24515(), mobCoeff, ((Integer)(Baritone.settings()).mobAvoidanceRadius.value).intValue())));
/*    */     }
/* 82 */     return res;
/*    */   }
/*    */   
/*    */   public void applySpherical(Long2DoubleOpenHashMap map) {
/* 86 */     for (int x = -this.radius; x <= this.radius; x++) {
/* 87 */       for (int y = -this.radius; y <= this.radius; y++) {
/* 88 */         for (int z = -this.radius; z <= this.radius; z++) {
/* 89 */           if (x * x + y * y + z * z <= this.radius * this.radius) {
/* 90 */             long hash = BetterBlockPos.longHash(this.centerX + x, this.centerY + y, this.centerZ + z);
/* 91 */             map.put(hash, map.get(hash) * this.coefficient);
/*    */           } 
/*    */         } 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\bariton\\utils\pathing\Avoidance.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */