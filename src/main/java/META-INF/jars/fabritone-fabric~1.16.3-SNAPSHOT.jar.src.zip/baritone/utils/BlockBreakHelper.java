/*    */ package baritone.utils;
/*    */ 
/*    */ import baritone.api.utils.Helper;
/*    */ import baritone.api.utils.IPlayerContext;
/*    */ import net.minecraft.class_1268;
/*    */ import net.minecraft.class_239;
/*    */ import net.minecraft.class_3965;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BlockBreakHelper
/*    */   implements Helper
/*    */ {
/*    */   private final IPlayerContext ctx;
/*    */   private boolean didBreakLastTick;
/*    */   
/*    */   BlockBreakHelper(IPlayerContext ctx) {
/* 36 */     this.ctx = ctx;
/*    */   }
/*    */ 
/*    */   
/*    */   public void stopBreakingBlock() {
/* 41 */     if (this.ctx.player() != null && this.didBreakLastTick) {
/* 42 */       if (!this.ctx.playerController().hasBrokenBlock())
/*    */       {
/* 44 */         this.ctx.playerController().setHittingBlock(true);
/*    */       }
/* 46 */       this.ctx.playerController().resetBlockRemoving();
/* 47 */       this.didBreakLastTick = false;
/*    */     } 
/*    */   }
/*    */   
/*    */   public void tick(boolean isLeftClick) {
/* 52 */     class_239 trace = this.ctx.objectMouseOver();
/* 53 */     boolean isBlockTrace = (trace != null && trace.method_17783() == class_239.class_240.field_1332);
/*    */     
/* 55 */     if (isLeftClick && isBlockTrace) {
/* 56 */       if (!this.didBreakLastTick) {
/* 57 */         this.ctx.playerController().syncHeldItem();
/* 58 */         this.ctx.playerController().clickBlock(((class_3965)trace).method_17777(), ((class_3965)trace).method_17780());
/* 59 */         this.ctx.player().method_6104(class_1268.field_5808);
/*    */       } 
/*    */ 
/*    */       
/* 63 */       if (this.ctx.playerController().onPlayerDamageBlock(((class_3965)trace).method_17777(), ((class_3965)trace).method_17780())) {
/* 64 */         this.ctx.player().method_6104(class_1268.field_5808);
/*    */       }
/*    */       
/* 67 */       this.ctx.playerController().setHittingBlock(false);
/*    */       
/* 69 */       this.didBreakLastTick = true;
/* 70 */     } else if (this.didBreakLastTick) {
/* 71 */       stopBreakingBlock();
/* 72 */       this.didBreakLastTick = false;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\bariton\\utils\BlockBreakHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */