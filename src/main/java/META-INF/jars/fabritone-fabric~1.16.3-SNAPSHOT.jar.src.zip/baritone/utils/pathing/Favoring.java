/*    */ package baritone.utils.pathing;
/*    */ 
/*    */ import baritone.api.pathing.calc.IPath;
/*    */ import baritone.api.utils.BetterBlockPos;
/*    */ import baritone.api.utils.Helper;
/*    */ import baritone.api.utils.IPlayerContext;
/*    */ import baritone.pathing.movement.CalculationContext;
/*    */ import it.unimi.dsi.fastutil.longs.Long2DoubleOpenHashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Favoring
/*    */ {
/*    */   private final Long2DoubleOpenHashMap favorings;
/*    */   
/*    */   public Favoring(IPlayerContext ctx, IPath previous, CalculationContext context) {
/* 32 */     this(previous, context);
/* 33 */     for (Avoidance avoid : Avoidance.create(ctx)) {
/* 34 */       avoid.applySpherical(this.favorings);
/*    */     }
/* 36 */     Helper.HELPER.logDebug("Favoring size: " + this.favorings.size());
/*    */   }
/*    */   
/*    */   public Favoring(IPath previous, CalculationContext context) {
/* 40 */     this.favorings = new Long2DoubleOpenHashMap();
/* 41 */     this.favorings.defaultReturnValue(1.0D);
/* 42 */     double coeff = context.backtrackCostFavoringCoefficient;
/* 43 */     if (coeff != 1.0D && previous != null) {
/* 44 */       previous.positions().forEach(pos -> this.favorings.put(BetterBlockPos.longHash(pos), coeff));
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean isEmpty() {
/* 49 */     return this.favorings.isEmpty();
/*    */   }
/*    */   
/*    */   public double calculate(long hash) {
/* 53 */     return this.favorings.get(hash);
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\bariton\\utils\pathing\Favoring.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */