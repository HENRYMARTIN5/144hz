/*    */ package baritone.utils;
/*    */ 
/*    */ import javax.annotation.Nullable;
/*    */ import net.minecraft.class_1922;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_2586;
/*    */ import net.minecraft.class_2680;
/*    */ import net.minecraft.class_3610;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BlockStateInterfaceAccessWrapper
/*    */   implements class_1922
/*    */ {
/*    */   private final BlockStateInterface bsi;
/*    */   
/*    */   BlockStateInterfaceAccessWrapper(BlockStateInterface bsi) {
/* 38 */     this.bsi = bsi;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public class_2586 method_8321(class_2338 pos) {
/* 44 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public class_2680 method_8320(class_2338 pos) {
/* 50 */     return this.bsi.get0(pos.method_10263(), pos.method_10264(), pos.method_10260());
/*    */   }
/*    */ 
/*    */   
/*    */   public class_3610 method_8316(class_2338 blockPos) {
/* 55 */     return method_8320(blockPos).method_26227();
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\bariton\\utils\BlockStateInterfaceAccessWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */