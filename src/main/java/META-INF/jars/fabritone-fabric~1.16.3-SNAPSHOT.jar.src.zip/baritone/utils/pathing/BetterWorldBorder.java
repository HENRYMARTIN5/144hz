/*    */ package baritone.utils.pathing;
/*    */ 
/*    */ import net.minecraft.class_2784;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BetterWorldBorder
/*    */ {
/*    */   private final double minX;
/*    */   private final double maxX;
/*    */   private final double minZ;
/*    */   private final double maxZ;
/*    */   
/*    */   public BetterWorldBorder(class_2784 border) {
/* 34 */     this.minX = border.method_11976();
/* 35 */     this.maxX = border.method_11963();
/* 36 */     this.minZ = border.method_11958();
/* 37 */     this.maxZ = border.method_11977();
/*    */   }
/*    */   
/*    */   public boolean entirelyContains(int x, int z) {
/* 41 */     return ((x + 1) > this.minX && x < this.maxX && (z + 1) > this.minZ && z < this.maxZ);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean canPlaceAt(int x, int z) {
/* 48 */     return (x > this.minX && (x + 1) < this.maxX && z > this.minZ && (z + 1) < this.maxZ);
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\bariton\\utils\pathing\BetterWorldBorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */