/*     */ package baritone.utils;
/*     */ 
/*     */ import baritone.Baritone;
/*     */ import baritone.api.utils.IPlayerContext;
/*     */ import baritone.cache.CachedRegion;
/*     */ import baritone.cache.WorldData;
/*     */ import baritone.utils.accessor.IClientChunkProvider;
/*     */ import net.minecraft.class_1922;
/*     */ import net.minecraft.class_1937;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2248;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_2791;
/*     */ import net.minecraft.class_2806;
/*     */ import net.minecraft.class_2818;
/*     */ import net.minecraft.class_2826;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_631;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BlockStateInterface
/*     */ {
/*     */   private final class_631 provider;
/*     */   private final WorldData worldData;
/*     */   protected final class_1922 world;
/*     */   public final class_2338.class_2339 isPassableBlockPos;
/*     */   public final class_1922 access;
/*  51 */   private class_2818 prev = null;
/*  52 */   private CachedRegion prevCached = null;
/*     */   
/*     */   private final boolean useTheRealWorld;
/*     */   
/*  56 */   private static final class_2680 AIR = class_2246.field_10124.method_9564();
/*     */   
/*     */   public BlockStateInterface(IPlayerContext ctx) {
/*  59 */     this(ctx, false);
/*     */   }
/*     */   
/*     */   public BlockStateInterface(IPlayerContext ctx, boolean copyLoadedChunks) {
/*  63 */     this(ctx.world(), (WorldData)ctx.worldData(), copyLoadedChunks);
/*     */   }
/*     */   
/*     */   public BlockStateInterface(class_1937 world, WorldData worldData, boolean copyLoadedChunks) {
/*  67 */     this.world = (class_1922)world;
/*  68 */     this.worldData = worldData;
/*  69 */     if (copyLoadedChunks) {
/*  70 */       this.provider = ((IClientChunkProvider)world.method_8398()).createThreadSafeCopy();
/*     */     } else {
/*  72 */       this.provider = (class_631)world.method_8398();
/*     */     } 
/*  74 */     this.useTheRealWorld = !((Boolean)(Baritone.settings()).pathThroughCachedOnly.value).booleanValue();
/*  75 */     if (!class_310.method_1551().method_18854()) {
/*  76 */       throw new IllegalStateException();
/*     */     }
/*  78 */     this.isPassableBlockPos = new class_2338.class_2339();
/*  79 */     this.access = new BlockStateInterfaceAccessWrapper(this);
/*     */   }
/*     */   
/*     */   public boolean worldContainsLoadedChunk(int blockX, int blockZ) {
/*  83 */     return this.provider.method_12123(blockX >> 4, blockZ >> 4);
/*     */   }
/*     */   
/*     */   public static class_2248 getBlock(IPlayerContext ctx, class_2338 pos) {
/*  87 */     return get(ctx, pos).method_26204();
/*     */   }
/*     */   
/*     */   public static class_2680 get(IPlayerContext ctx, class_2338 pos) {
/*  91 */     return (new BlockStateInterface(ctx)).get0(pos.method_10263(), pos.method_10264(), pos.method_10260());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public class_2680 get0(class_2338 pos) {
/*  97 */     return get0(pos.method_10263(), pos.method_10264(), pos.method_10260());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public class_2680 get0(int x, int y, int z) {
/* 103 */     if (y < 0 || y >= 256) {
/* 104 */       return AIR;
/*     */     }
/*     */     
/* 107 */     if (this.useTheRealWorld) {
/* 108 */       class_2818 class_28181 = this.prev;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 115 */       if (class_28181 != null && (class_28181.method_12004()).field_9181 == x >> 4 && (class_28181.method_12004()).field_9180 == z >> 4) {
/* 116 */         return getFromChunk((class_2791)class_28181, x, y, z);
/*     */       }
/* 118 */       class_2818 chunk = this.provider.method_2857(x >> 4, z >> 4, class_2806.field_12803, false);
/* 119 */       if (chunk != null && !chunk.method_12223()) {
/* 120 */         this.prev = chunk;
/* 121 */         return getFromChunk((class_2791)chunk, x, y, z);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 126 */     CachedRegion cached = this.prevCached;
/* 127 */     if (cached == null || cached.getX() != x >> 9 || cached.getZ() != z >> 9) {
/* 128 */       if (this.worldData == null) {
/* 129 */         return AIR;
/*     */       }
/* 131 */       CachedRegion region = this.worldData.cache.getRegion(x >> 9, z >> 9);
/* 132 */       if (region == null) {
/* 133 */         return AIR;
/*     */       }
/* 135 */       this.prevCached = region;
/* 136 */       cached = region;
/*     */     } 
/* 138 */     class_2680 type = cached.getBlock(x & 0x1FF, y, z & 0x1FF);
/* 139 */     if (type == null) {
/* 140 */       return AIR;
/*     */     }
/* 142 */     return type;
/*     */   }
/*     */   
/*     */   public boolean isLoaded(int x, int z) {
/* 146 */     class_2818 prevChunk = this.prev;
/* 147 */     if (prevChunk != null && (prevChunk.method_12004()).field_9181 == x >> 4 && (prevChunk.method_12004()).field_9180 == z >> 4) {
/* 148 */       return true;
/*     */     }
/* 150 */     prevChunk = this.provider.method_2857(x >> 4, z >> 4, class_2806.field_12803, false);
/* 151 */     if (prevChunk != null && !prevChunk.method_12223()) {
/* 152 */       this.prev = prevChunk;
/* 153 */       return true;
/*     */     } 
/* 155 */     CachedRegion prevRegion = this.prevCached;
/* 156 */     if (prevRegion != null && prevRegion.getX() == x >> 9 && prevRegion.getZ() == z >> 9) {
/* 157 */       return prevRegion.isCached(x & 0x1FF, z & 0x1FF);
/*     */     }
/* 159 */     if (this.worldData == null) {
/* 160 */       return false;
/*     */     }
/* 162 */     prevRegion = this.worldData.cache.getRegion(x >> 9, z >> 9);
/* 163 */     if (prevRegion == null) {
/* 164 */       return false;
/*     */     }
/* 166 */     this.prevCached = prevRegion;
/* 167 */     return prevRegion.isCached(x & 0x1FF, z & 0x1FF);
/*     */   }
/*     */ 
/*     */   
/*     */   public static class_2680 getFromChunk(class_2791 chunk, int x, int y, int z) {
/* 172 */     class_2826 section = chunk.method_12006()[y >> 4];
/* 173 */     if (class_2826.method_18090(section)) {
/* 174 */       return AIR;
/*     */     }
/* 176 */     return section.method_12254(x & 0xF, y & 0xF, z & 0xF);
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\bariton\\utils\BlockStateInterface.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */