/*    */ package baritone.utils.schematic;
/*    */ 
/*    */ import baritone.api.schematic.AbstractSchematic;
/*    */ import baritone.api.schematic.IStaticSchematic;
/*    */ import java.util.List;
/*    */ import net.minecraft.class_2680;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StaticSchematic
/*    */   extends AbstractSchematic
/*    */   implements IStaticSchematic
/*    */ {
/*    */   protected class_2680[][][] states;
/*    */   
/*    */   public class_2680 desiredState(int x, int y, int z, class_2680 current, List<class_2680> approxPlaceable) {
/* 38 */     return this.states[x][z][y];
/*    */   }
/*    */ 
/*    */   
/*    */   public class_2680 getDirect(int x, int y, int z) {
/* 43 */     return this.states[x][z][y];
/*    */   }
/*    */ 
/*    */   
/*    */   public class_2680[] getColumn(int x, int z) {
/* 48 */     return this.states[x][z];
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\bariton\\utils\schematic\StaticSchematic.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */