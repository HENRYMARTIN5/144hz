/*    */ package baritone.utils.schematic;
/*    */ 
/*    */ import baritone.api.command.registry.Registry;
/*    */ import baritone.api.schematic.ISchematicSystem;
/*    */ import baritone.api.schematic.format.ISchematicFormat;
/*    */ import baritone.utils.schematic.format.DefaultSchematicFormats;
/*    */ import java.io.File;
/*    */ import java.util.Arrays;
/*    */ import java.util.Optional;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum SchematicSystem
/*    */   implements ISchematicSystem
/*    */ {
/* 34 */   INSTANCE;
/*    */   
/* 36 */   private final Registry<ISchematicFormat> registry = new Registry();
/*    */   
/*    */   SchematicSystem() {
/* 39 */     Arrays.<DefaultSchematicFormats>stream(DefaultSchematicFormats.values()).forEach(this.registry::register);
/*    */   }
/*    */ 
/*    */   
/*    */   public Registry<ISchematicFormat> getRegistry() {
/* 44 */     return this.registry;
/*    */   }
/*    */ 
/*    */   
/*    */   public Optional<ISchematicFormat> getByFile(File file) {
/* 49 */     return this.registry.stream().filter(format -> format.isFileType(file)).findFirst();
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\bariton\\utils\schematic\SchematicSystem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */