/*    */ package baritone.utils.pathing;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum PathingBlockType
/*    */ {
/* 26 */   AIR(0),
/* 27 */   WATER(1),
/* 28 */   AVOID(2),
/* 29 */   SOLID(3);
/*    */   
/*    */   private final boolean[] bits;
/*    */   
/*    */   PathingBlockType(int bits) {
/* 34 */     this.bits = new boolean[] { ((bits & 0x2) != 0), ((bits & 0x1) != 0) };
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final boolean[] getBits() {
/* 41 */     return this.bits;
/*    */   }
/*    */   
/*    */   public static PathingBlockType fromBits(boolean b1, boolean b2) {
/* 45 */     return b1 ? (b2 ? SOLID : AVOID) : (b2 ? WATER : AIR);
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\bariton\\utils\pathing\PathingBlockType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */