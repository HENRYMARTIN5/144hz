/*    */ package baritone.utils.pathing;
/*    */ 
/*    */ import baritone.Baritone;
/*    */ import baritone.api.BaritoneAPI;
/*    */ import baritone.api.pathing.calc.IPath;
/*    */ import baritone.api.pathing.goals.Goal;
/*    */ import baritone.pathing.path.CutoffPath;
/*    */ import baritone.utils.BlockStateInterface;
/*    */ import net.minecraft.class_2338;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class PathBase
/*    */   implements IPath
/*    */ {
/*    */   public PathBase cutoffAtLoadedChunks(Object bsi0) {
/* 32 */     if (!((Boolean)(Baritone.settings()).cutoffAtLoadBoundary.value).booleanValue()) {
/* 33 */       return this;
/*    */     }
/* 35 */     BlockStateInterface bsi = (BlockStateInterface)bsi0;
/* 36 */     for (int i = 0; i < positions().size(); i++) {
/* 37 */       class_2338 pos = positions().get(i);
/* 38 */       if (!bsi.worldContainsLoadedChunk(pos.method_10263(), pos.method_10260())) {
/* 39 */         return (PathBase)new CutoffPath(this, i);
/*    */       }
/*    */     } 
/* 42 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public PathBase staticCutoff(Goal destination) {
/* 47 */     int min = ((Integer)(BaritoneAPI.getSettings()).pathCutoffMinimumLength.value).intValue();
/* 48 */     if (length() < min) {
/* 49 */       return this;
/*    */     }
/* 51 */     if (destination == null || destination.isInGoal((class_2338)getDest())) {
/* 52 */       return this;
/*    */     }
/* 54 */     double factor = ((Double)(BaritoneAPI.getSettings()).pathCutoffFactor.value).doubleValue();
/* 55 */     int newLength = (int)((length() - min) * factor) + min - 1;
/* 56 */     return (PathBase)new CutoffPath(this, newLength);
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\bariton\\utils\pathing\PathBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */