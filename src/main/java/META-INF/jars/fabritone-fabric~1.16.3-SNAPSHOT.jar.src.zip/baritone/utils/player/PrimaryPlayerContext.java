/*    */ package baritone.utils.player;
/*    */ 
/*    */ import baritone.api.BaritoneAPI;
/*    */ import baritone.api.cache.IWorldData;
/*    */ import baritone.api.utils.Helper;
/*    */ import baritone.api.utils.IPlayerContext;
/*    */ import baritone.api.utils.IPlayerController;
/*    */ import baritone.api.utils.RayTraceUtils;
/*    */ import net.minecraft.class_1297;
/*    */ import net.minecraft.class_1937;
/*    */ import net.minecraft.class_239;
/*    */ import net.minecraft.class_746;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum PrimaryPlayerContext
/*    */   implements IPlayerContext, Helper
/*    */ {
/* 38 */   INSTANCE;
/*    */ 
/*    */   
/*    */   public class_746 player() {
/* 42 */     return mc.field_1724;
/*    */   }
/*    */ 
/*    */   
/*    */   public IPlayerController playerController() {
/* 47 */     return PrimaryPlayerController.INSTANCE;
/*    */   }
/*    */ 
/*    */   
/*    */   public class_1937 world() {
/* 52 */     return (class_1937)mc.field_1687;
/*    */   }
/*    */ 
/*    */   
/*    */   public IWorldData worldData() {
/* 57 */     return BaritoneAPI.getProvider().getPrimaryBaritone().getWorldProvider().getCurrentWorld();
/*    */   }
/*    */ 
/*    */   
/*    */   public class_239 objectMouseOver() {
/* 62 */     return RayTraceUtils.rayTraceTowards((class_1297)player(), playerRotations(), playerController().getBlockReachDistance());
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\bariton\\utils\player\PrimaryPlayerContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */