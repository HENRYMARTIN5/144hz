/*    */ package baritone.utils;
/*    */ 
/*    */ import baritone.api.utils.input.Input;
/*    */ import net.minecraft.class_744;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlayerMovementInput
/*    */   extends class_744
/*    */ {
/*    */   private final InputOverrideHandler handler;
/*    */   
/*    */   PlayerMovementInput(InputOverrideHandler handler) {
/* 27 */     this.handler = handler;
/*    */   }
/*    */ 
/*    */   
/*    */   public void method_3129(boolean p_225607_1_) {
/* 32 */     this.field_3907 = 0.0F;
/* 33 */     this.field_3905 = 0.0F;
/*    */     
/* 35 */     this.field_3904 = this.handler.isInputForcedDown(Input.JUMP);
/*    */     
/* 37 */     if (this.field_3910 = this.handler.isInputForcedDown(Input.MOVE_FORWARD)) {
/* 38 */       this.field_3905++;
/*    */     }
/*    */     
/* 41 */     if (this.field_3909 = this.handler.isInputForcedDown(Input.MOVE_BACK)) {
/* 42 */       this.field_3905--;
/*    */     }
/*    */     
/* 45 */     if (this.field_3908 = this.handler.isInputForcedDown(Input.MOVE_LEFT)) {
/* 46 */       this.field_3907++;
/*    */     }
/*    */     
/* 49 */     if (this.field_3906 = this.handler.isInputForcedDown(Input.MOVE_RIGHT)) {
/* 50 */       this.field_3907--;
/*    */     }
/*    */     
/* 53 */     if (this.field_3903 = this.handler.isInputForcedDown(Input.SNEAK)) {
/* 54 */       this.field_3907 = (float)(this.field_3907 * 0.3D);
/* 55 */       this.field_3905 = (float)(this.field_3905 * 0.3D);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\bariton\\utils\PlayerMovementInput.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */