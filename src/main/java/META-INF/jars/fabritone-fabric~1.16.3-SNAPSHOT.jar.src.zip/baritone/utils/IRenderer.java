/*     */ package baritone.utils;
/*     */ 
/*     */ import baritone.api.BaritoneAPI;
/*     */ import baritone.api.Settings;
/*     */ import baritone.api.utils.Helper;
/*     */ import baritone.utils.accessor.IEntityRenderManager;
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import java.awt.Color;
/*     */ import net.minecraft.class_1159;
/*     */ import net.minecraft.class_238;
/*     */ import net.minecraft.class_287;
/*     */ import net.minecraft.class_289;
/*     */ import net.minecraft.class_290;
/*     */ import net.minecraft.class_4587;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface IRenderer
/*     */ {
/*  38 */   public static final class_289 tessellator = class_289.method_1348();
/*  39 */   public static final class_287 buffer = tessellator.method_1349();
/*  40 */   public static final IEntityRenderManager renderManager = (IEntityRenderManager)Helper.mc.method_1561();
/*  41 */   public static final Settings settings = BaritoneAPI.getSettings();
/*     */   
/*     */   static void glColor(Color color, float alpha) {
/*  44 */     float[] colorComponents = color.getColorComponents(null);
/*  45 */     RenderSystem.color4f(colorComponents[0], colorComponents[1], colorComponents[2], alpha);
/*     */   }
/*     */   
/*     */   static void startLines(Color color, float alpha, float lineWidth, boolean ignoreDepth) {
/*  49 */     RenderSystem.enableBlend();
/*  50 */     RenderSystem.blendFuncSeparate(770, 771, 1, 0);
/*  51 */     glColor(color, alpha);
/*  52 */     RenderSystem.lineWidth(lineWidth);
/*  53 */     RenderSystem.disableTexture();
/*  54 */     RenderSystem.depthMask(false);
/*     */     
/*  56 */     if (ignoreDepth) {
/*  57 */       RenderSystem.disableDepthTest();
/*     */     }
/*     */   }
/*     */   
/*     */   static void startLines(Color color, float lineWidth, boolean ignoreDepth) {
/*  62 */     startLines(color, 0.4F, lineWidth, ignoreDepth);
/*     */   }
/*     */   
/*     */   static void endLines(boolean ignoredDepth) {
/*  66 */     if (ignoredDepth) {
/*  67 */       RenderSystem.enableDepthTest();
/*     */     }
/*     */     
/*  70 */     RenderSystem.depthMask(true);
/*  71 */     RenderSystem.enableTexture();
/*  72 */     RenderSystem.disableBlend();
/*     */   }
/*     */   
/*     */   static void drawAABB(class_4587 stack, class_238 aabb) {
/*  76 */     class_238 toDraw = aabb.method_989(-renderManager.renderPosX(), -renderManager.renderPosY(), -renderManager.renderPosZ());
/*     */     
/*  78 */     class_1159 matrix4f = stack.method_23760().method_23761();
/*  79 */     buffer.method_1328(1, class_290.field_1592);
/*     */     
/*  81 */     buffer.method_22918(matrix4f, (float)toDraw.field_1323, (float)toDraw.field_1322, (float)toDraw.field_1321).method_1344();
/*  82 */     buffer.method_22918(matrix4f, (float)toDraw.field_1320, (float)toDraw.field_1322, (float)toDraw.field_1321).method_1344();
/*  83 */     buffer.method_22918(matrix4f, (float)toDraw.field_1320, (float)toDraw.field_1322, (float)toDraw.field_1321).method_1344();
/*  84 */     buffer.method_22918(matrix4f, (float)toDraw.field_1320, (float)toDraw.field_1322, (float)toDraw.field_1324).method_1344();
/*  85 */     buffer.method_22918(matrix4f, (float)toDraw.field_1320, (float)toDraw.field_1322, (float)toDraw.field_1324).method_1344();
/*  86 */     buffer.method_22918(matrix4f, (float)toDraw.field_1323, (float)toDraw.field_1322, (float)toDraw.field_1324).method_1344();
/*  87 */     buffer.method_22918(matrix4f, (float)toDraw.field_1323, (float)toDraw.field_1322, (float)toDraw.field_1324).method_1344();
/*  88 */     buffer.method_22918(matrix4f, (float)toDraw.field_1323, (float)toDraw.field_1322, (float)toDraw.field_1321).method_1344();
/*     */     
/*  90 */     buffer.method_22918(matrix4f, (float)toDraw.field_1323, (float)toDraw.field_1325, (float)toDraw.field_1321).method_1344();
/*  91 */     buffer.method_22918(matrix4f, (float)toDraw.field_1320, (float)toDraw.field_1325, (float)toDraw.field_1321).method_1344();
/*  92 */     buffer.method_22918(matrix4f, (float)toDraw.field_1320, (float)toDraw.field_1325, (float)toDraw.field_1321).method_1344();
/*  93 */     buffer.method_22918(matrix4f, (float)toDraw.field_1320, (float)toDraw.field_1325, (float)toDraw.field_1324).method_1344();
/*  94 */     buffer.method_22918(matrix4f, (float)toDraw.field_1320, (float)toDraw.field_1325, (float)toDraw.field_1324).method_1344();
/*  95 */     buffer.method_22918(matrix4f, (float)toDraw.field_1323, (float)toDraw.field_1325, (float)toDraw.field_1324).method_1344();
/*  96 */     buffer.method_22918(matrix4f, (float)toDraw.field_1323, (float)toDraw.field_1325, (float)toDraw.field_1324).method_1344();
/*  97 */     buffer.method_22918(matrix4f, (float)toDraw.field_1323, (float)toDraw.field_1325, (float)toDraw.field_1321).method_1344();
/*     */     
/*  99 */     buffer.method_22918(matrix4f, (float)toDraw.field_1323, (float)toDraw.field_1322, (float)toDraw.field_1321).method_1344();
/* 100 */     buffer.method_22918(matrix4f, (float)toDraw.field_1323, (float)toDraw.field_1325, (float)toDraw.field_1321).method_1344();
/* 101 */     buffer.method_22918(matrix4f, (float)toDraw.field_1320, (float)toDraw.field_1322, (float)toDraw.field_1321).method_1344();
/* 102 */     buffer.method_22918(matrix4f, (float)toDraw.field_1320, (float)toDraw.field_1325, (float)toDraw.field_1321).method_1344();
/* 103 */     buffer.method_22918(matrix4f, (float)toDraw.field_1320, (float)toDraw.field_1322, (float)toDraw.field_1324).method_1344();
/* 104 */     buffer.method_22918(matrix4f, (float)toDraw.field_1320, (float)toDraw.field_1325, (float)toDraw.field_1324).method_1344();
/* 105 */     buffer.method_22918(matrix4f, (float)toDraw.field_1323, (float)toDraw.field_1322, (float)toDraw.field_1324).method_1344();
/* 106 */     buffer.method_22918(matrix4f, (float)toDraw.field_1323, (float)toDraw.field_1325, (float)toDraw.field_1324).method_1344();
/* 107 */     tessellator.method_1350();
/*     */   }
/*     */   
/*     */   static void drawAABB(class_4587 stack, class_238 aabb, double expand) {
/* 111 */     drawAABB(stack, aabb.method_1009(expand, expand, expand));
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\bariton\\utils\IRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */