/*     */ package baritone.utils;
/*     */ 
/*     */ import baritone.Baritone;
/*     */ import baritone.api.BaritoneAPI;
/*     */ import baritone.api.event.events.TickEvent;
/*     */ import baritone.api.utils.IInputOverrideHandler;
/*     */ import baritone.api.utils.input.Input;
/*     */ import baritone.behavior.Behavior;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_743;
/*     */ import net.minecraft.class_744;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class InputOverrideHandler
/*     */   extends Behavior
/*     */   implements IInputOverrideHandler
/*     */ {
/*  45 */   private final Map<Input, Boolean> inputForceStateMap = new HashMap<>();
/*     */   
/*     */   private final BlockBreakHelper blockBreakHelper;
/*     */   private final BlockPlaceHelper blockPlaceHelper;
/*     */   
/*     */   public InputOverrideHandler(Baritone baritone) {
/*  51 */     super(baritone);
/*  52 */     this.blockBreakHelper = new BlockBreakHelper(baritone.getPlayerContext());
/*  53 */     this.blockPlaceHelper = new BlockPlaceHelper(baritone.getPlayerContext());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isInputForcedDown(Input input) {
/*  64 */     return (input == null) ? false : ((Boolean)this.inputForceStateMap.getOrDefault(input, Boolean.valueOf(false))).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setInputForceState(Input input, boolean forced) {
/*  75 */     this.inputForceStateMap.put(input, Boolean.valueOf(forced));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void clearAllKeys() {
/*  83 */     this.inputForceStateMap.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public final void onTick(TickEvent event) {
/*  88 */     if (event.getType() == TickEvent.Type.OUT) {
/*     */       return;
/*     */     }
/*  91 */     if (isInputForcedDown(Input.CLICK_LEFT)) {
/*  92 */       setInputForceState(Input.CLICK_RIGHT, false);
/*     */     }
/*  94 */     this.blockBreakHelper.tick(isInputForcedDown(Input.CLICK_LEFT));
/*  95 */     this.blockPlaceHelper.tick(isInputForcedDown(Input.CLICK_RIGHT));
/*     */     
/*  97 */     if (inControl()) {
/*  98 */       if ((this.ctx.player()).field_3913.getClass() != PlayerMovementInput.class) {
/*  99 */         (this.ctx.player()).field_3913 = new PlayerMovementInput(this);
/*     */       }
/*     */     }
/* 102 */     else if ((this.ctx.player()).field_3913.getClass() == PlayerMovementInput.class) {
/* 103 */       (this.ctx.player()).field_3913 = (class_744)new class_743((class_310.method_1551()).field_1690);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean inControl() {
/* 111 */     for (Input input : new Input[] { Input.MOVE_FORWARD, Input.MOVE_BACK, Input.MOVE_LEFT, Input.MOVE_RIGHT, Input.SNEAK }) {
/* 112 */       if (isInputForcedDown(input)) {
/* 113 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 117 */     return (this.baritone.getPathingBehavior().isPathing() || this.baritone != BaritoneAPI.getProvider().getPrimaryBaritone());
/*     */   }
/*     */   
/*     */   public BlockBreakHelper getBlockBreakHelper() {
/* 121 */     return this.blockBreakHelper;
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\bariton\\utils\InputOverrideHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */