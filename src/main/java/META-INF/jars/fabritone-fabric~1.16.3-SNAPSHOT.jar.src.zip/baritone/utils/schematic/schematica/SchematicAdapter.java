/*    */ package baritone.utils.schematic.schematica;
/*    */ 
/*    */ import baritone.api.schematic.IStaticSchematic;
/*    */ import com.github.lunatrius.schematica.client.world.SchematicWorld;
/*    */ import java.util.List;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_2680;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SchematicAdapter
/*    */   implements IStaticSchematic
/*    */ {
/*    */   private final SchematicWorld schematic;
/*    */   
/*    */   public SchematicAdapter(SchematicWorld schematicWorld) {
/* 32 */     this.schematic = schematicWorld;
/*    */   }
/*    */ 
/*    */   
/*    */   public class_2680 desiredState(int x, int y, int z, class_2680 current, List<class_2680> approxPlaceable) {
/* 37 */     return getDirect(x, y, z);
/*    */   }
/*    */ 
/*    */   
/*    */   public class_2680 getDirect(int x, int y, int z) {
/* 42 */     return this.schematic.getSchematic().getBlockState(new class_2338(x, y, z));
/*    */   }
/*    */ 
/*    */   
/*    */   public int widthX() {
/* 47 */     return this.schematic.getSchematic().getWidth();
/*    */   }
/*    */ 
/*    */   
/*    */   public int heightY() {
/* 52 */     return this.schematic.getSchematic().getHeight();
/*    */   }
/*    */ 
/*    */   
/*    */   public int lengthZ() {
/* 57 */     return this.schematic.getSchematic().getLength();
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\bariton\\utils\schematic\schematica\SchematicAdapter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */