/*    */ package baritone.utils.pathing;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MutableMoveResult
/*    */ {
/*    */   public int x;
/*    */   public int y;
/*    */   public int z;
/*    */   public double cost;
/*    */   
/*    */   public MutableMoveResult() {
/* 35 */     reset();
/*    */   }
/*    */   
/*    */   public final void reset() {
/* 39 */     this.x = 0;
/* 40 */     this.y = 0;
/* 41 */     this.z = 0;
/* 42 */     this.cost = 1000000.0D;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\bariton\\utils\pathing\MutableMoveResult.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */