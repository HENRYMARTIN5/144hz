/*     */ package baritone.utils;
/*     */ 
/*     */ import baritone.api.BaritoneAPI;
/*     */ import baritone.api.event.events.RenderEvent;
/*     */ import baritone.api.pathing.calc.IPath;
/*     */ import baritone.api.pathing.goals.Goal;
/*     */ import baritone.api.pathing.goals.GoalComposite;
/*     */ import baritone.api.pathing.goals.GoalInverted;
/*     */ import baritone.api.pathing.goals.GoalXZ;
/*     */ import baritone.api.pathing.goals.GoalYLevel;
/*     */ import baritone.api.utils.BetterBlockPos;
/*     */ import baritone.api.utils.Helper;
/*     */ import baritone.api.utils.interfaces.IGoalRenderPos;
/*     */ import baritone.behavior.PathingBehavior;
/*     */ import baritone.pathing.calc.AbstractNodeCostSearch;
/*     */ import baritone.pathing.path.PathExecutor;
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import java.awt.Color;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import net.minecraft.class_1159;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1922;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_238;
/*     */ import net.minecraft.class_259;
/*     */ import net.minecraft.class_265;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_2874;
/*     */ import net.minecraft.class_290;
/*     */ import net.minecraft.class_2960;
/*     */ import net.minecraft.class_3532;
/*     */ import net.minecraft.class_4587;
/*     */ import net.minecraft.class_4597;
/*     */ import net.minecraft.class_822;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PathRenderer
/*     */   implements IRenderer, Helper
/*     */ {
/*  57 */   private static final class_2960 TEXTURE_BEACON_BEAM = new class_2960("textures/entity/beacon_beam.png");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double posX() {
/*  63 */     return renderManager.renderPosX();
/*     */   }
/*     */   
/*     */   public static double posY() {
/*  67 */     return renderManager.renderPosY();
/*     */   }
/*     */   
/*     */   public static double posZ() {
/*  71 */     return renderManager.renderPosZ();
/*     */   }
/*     */   
/*     */   public static void render(RenderEvent event, PathingBehavior behavior) {
/*  75 */     float partialTicks = event.getPartialTicks();
/*  76 */     Goal goal = behavior.getGoal();
/*  77 */     if (Helper.mc.field_1755 instanceof GuiClick) {
/*  78 */       ((GuiClick)Helper.mc.field_1755).onRender(event.getModelViewStack(), event.getProjectionMatrix());
/*     */     }
/*     */     
/*  81 */     class_2874 thisPlayerDimension = behavior.baritone.getPlayerContext().world().method_8597();
/*  82 */     class_2874 currentRenderViewDimension = BaritoneAPI.getProvider().getPrimaryBaritone().getPlayerContext().world().method_8597();
/*     */     
/*  84 */     if (thisPlayerDimension != currentRenderViewDimension) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  89 */     class_1297 renderView = Helper.mc.method_1560();
/*     */     
/*  91 */     if (renderView.field_6002 != BaritoneAPI.getProvider().getPrimaryBaritone().getPlayerContext().world()) {
/*  92 */       System.out.println("I have no idea what's going on");
/*  93 */       System.out.println("The primary baritone is in a different world than the render view entity");
/*  94 */       System.out.println("Not rendering the path");
/*     */       
/*     */       return;
/*     */     } 
/*  98 */     if (goal != null && ((Boolean)settings.renderGoal.value).booleanValue()) {
/*  99 */       drawDankLitGoalBox(event.getModelViewStack(), renderView, goal, partialTicks, (Color)settings.colorGoalBox.value);
/*     */     }
/*     */     
/* 102 */     if (!((Boolean)settings.renderPath.value).booleanValue()) {
/*     */       return;
/*     */     }
/*     */     
/* 106 */     PathExecutor current = behavior.getCurrent();
/* 107 */     PathExecutor next = behavior.getNext();
/* 108 */     if (current != null && ((Boolean)settings.renderSelectionBoxes.value).booleanValue()) {
/* 109 */       drawManySelectionBoxes(event.getModelViewStack(), renderView, current.toBreak(), (Color)settings.colorBlocksToBreak.value);
/* 110 */       drawManySelectionBoxes(event.getModelViewStack(), renderView, current.toPlace(), (Color)settings.colorBlocksToPlace.value);
/* 111 */       drawManySelectionBoxes(event.getModelViewStack(), renderView, current.toWalkInto(), (Color)settings.colorBlocksToWalkInto.value);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 117 */     if (current != null && current.getPath() != null) {
/* 118 */       int renderBegin = Math.max(current.getPosition() - 3, 0);
/* 119 */       drawPath(event.getModelViewStack(), current.getPath(), renderBegin, (Color)settings.colorCurrentPath.value, ((Boolean)settings.fadePath.value).booleanValue(), 10, 20);
/*     */     } 
/*     */     
/* 122 */     if (next != null && next.getPath() != null) {
/* 123 */       drawPath(event.getModelViewStack(), next.getPath(), 0, (Color)settings.colorNextPath.value, ((Boolean)settings.fadePath.value).booleanValue(), 10, 20);
/*     */     }
/*     */ 
/*     */     
/* 127 */     behavior.getInProgress().ifPresent(currentlyRunning -> {
/*     */           currentlyRunning.bestPathSoFar().ifPresent(());
/*     */           currentlyRunning.pathToMostRecentNodeConsidered().ifPresent(());
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void drawPath(class_4587 stack, IPath path, int startIndex, Color color, boolean fadeOut, int fadeStart0, int fadeEnd0) {
/* 140 */     IRenderer.startLines(color, ((Float)settings.pathRenderLineWidthPixels.value).floatValue(), ((Boolean)settings.renderPathIgnoreDepth.value).booleanValue());
/*     */     
/* 142 */     int fadeStart = fadeStart0 + startIndex;
/* 143 */     int fadeEnd = fadeEnd0 + startIndex;
/*     */     
/* 145 */     List<BetterBlockPos> positions = path.positions(); int i;
/* 146 */     for (i = startIndex; i < positions.size() - 1; i = next) {
/* 147 */       BetterBlockPos start = positions.get(i); int next;
/* 148 */       BetterBlockPos end = positions.get(next = i + 1);
/*     */       
/* 150 */       int dirX = end.x - start.x;
/* 151 */       int dirY = end.y - start.y;
/* 152 */       int dirZ = end.z - start.z;
/*     */       
/* 154 */       while (next + 1 < positions.size() && (!fadeOut || next + 1 < fadeStart) && dirX == ((BetterBlockPos)positions
/* 155 */         .get(next + 1)).x - end.x && dirY == ((BetterBlockPos)positions
/* 156 */         .get(next + 1)).y - end.y && dirZ == ((BetterBlockPos)positions
/* 157 */         .get(next + 1)).z - end.z) {
/* 158 */         end = positions.get(++next);
/*     */       }
/*     */       
/* 161 */       if (fadeOut) {
/*     */         float alpha;
/*     */         
/* 164 */         if (i <= fadeStart) {
/* 165 */           alpha = 0.4F;
/*     */         } else {
/* 167 */           if (i > fadeEnd) {
/*     */             break;
/*     */           }
/* 170 */           alpha = 0.4F * (1.0F - (i - fadeStart) / (fadeEnd - fadeStart));
/*     */         } 
/* 172 */         IRenderer.glColor(color, alpha);
/*     */       } 
/*     */       
/* 175 */       drawLine(stack, start.x, start.y, start.z, end.x, end.y, end.z);
/*     */       
/* 177 */       tessellator.method_1350();
/*     */     } 
/*     */     
/* 180 */     IRenderer.endLines(((Boolean)settings.renderPathIgnoreDepth.value).booleanValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public static void drawLine(class_4587 stack, double x1, double y1, double z1, double x2, double y2, double z2) {
/* 185 */     class_1159 matrix4f = stack.method_23760().method_23761();
/*     */     
/* 187 */     double vpX = posX();
/* 188 */     double vpY = posY();
/* 189 */     double vpZ = posZ();
/* 190 */     boolean renderPathAsFrickinThingy = !((Boolean)settings.renderPathAsLine.value).booleanValue();
/*     */     
/* 192 */     buffer.method_1328(renderPathAsFrickinThingy ? 3 : 1, class_290.field_1592);
/* 193 */     buffer.method_22918(matrix4f, (float)(x1 + 0.5D - vpX), (float)(y1 + 0.5D - vpY), (float)(z1 + 0.5D - vpZ)).method_1344();
/* 194 */     buffer.method_22918(matrix4f, (float)(x2 + 0.5D - vpX), (float)(y2 + 0.5D - vpY), (float)(z2 + 0.5D - vpZ)).method_1344();
/*     */     
/* 196 */     if (renderPathAsFrickinThingy) {
/* 197 */       buffer.method_22918(matrix4f, (float)(x2 + 0.5D - vpX), (float)(y2 + 0.53D - vpY), (float)(z2 + 0.5D - vpZ)).method_1344();
/* 198 */       buffer.method_22918(matrix4f, (float)(x1 + 0.5D - vpX), (float)(y1 + 0.53D - vpY), (float)(z1 + 0.5D - vpZ)).method_1344();
/* 199 */       buffer.method_22918(matrix4f, (float)(x1 + 0.5D - vpX), (float)(y1 + 0.5D - vpY), (float)(z1 + 0.5D - vpZ)).method_1344();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void drawManySelectionBoxes(class_4587 stack, class_1297 player, Collection<class_2338> positions, Color color) {
/* 204 */     IRenderer.startLines(color, ((Float)settings.pathRenderLineWidthPixels.value).floatValue(), ((Boolean)settings.renderSelectionBoxesIgnoreDepth.value).booleanValue());
/*     */ 
/*     */     
/* 207 */     BlockStateInterface bsi = new BlockStateInterface(BaritoneAPI.getProvider().getPrimaryBaritone().getPlayerContext());
/*     */     
/* 209 */     positions.forEach(pos -> {
/*     */           class_2680 state = bsi.get0(pos);
/*     */           
/*     */           class_265 shape = state.method_26218((class_1922)player.field_6002, pos);
/*     */           class_238 toDraw = shape.method_1110() ? class_259.method_1077().method_1107() : shape.method_1107();
/*     */           toDraw = toDraw.method_996(pos);
/*     */           IRenderer.drawAABB(stack, toDraw, 0.002D);
/*     */         });
/* 217 */     IRenderer.endLines(((Boolean)settings.renderSelectionBoxesIgnoreDepth.value).booleanValue());
/*     */   }
/*     */   
/*     */   public static void drawDankLitGoalBox(class_4587 stack, class_1297 player, Goal goal, float partialTicks, Color color) {
/* 221 */     double minX, maxX, minZ, maxZ, minY, maxY, y1, y2, renderPosX = posX();
/* 222 */     double renderPosY = posY();
/* 223 */     double renderPosZ = posZ();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 228 */     double y = class_3532.method_15362((float)(((float)(System.nanoTime() / 100000L % 20000L) / 20000.0F) * Math.PI * 2.0D));
/* 229 */     if (goal instanceof IGoalRenderPos)
/* 230 */     { class_2338 goalPos = ((IGoalRenderPos)goal).getGoalPos();
/* 231 */       minX = goalPos.method_10263() + 0.002D - renderPosX;
/* 232 */       maxX = (goalPos.method_10263() + 1) - 0.002D - renderPosX;
/* 233 */       minZ = goalPos.method_10260() + 0.002D - renderPosZ;
/* 234 */       maxZ = (goalPos.method_10260() + 1) - 0.002D - renderPosZ;
/* 235 */       if (goal instanceof baritone.api.pathing.goals.GoalGetToBlock || goal instanceof baritone.api.pathing.goals.GoalTwoBlocks) {
/* 236 */         y /= 2.0D;
/*     */       }
/* 238 */       y1 = 1.0D + y + goalPos.method_10264() - renderPosY;
/* 239 */       y2 = 1.0D - y + goalPos.method_10264() - renderPosY;
/* 240 */       minY = goalPos.method_10264() - renderPosY;
/* 241 */       maxY = minY + 2.0D;
/* 242 */       if (goal instanceof baritone.api.pathing.goals.GoalGetToBlock || goal instanceof baritone.api.pathing.goals.GoalTwoBlocks) {
/* 243 */         y1 -= 0.5D;
/* 244 */         y2 -= 0.5D;
/* 245 */         maxY--;
/*     */       }  }
/* 247 */     else if (goal instanceof GoalXZ)
/* 248 */     { GoalXZ goalPos = (GoalXZ)goal;
/*     */       
/* 250 */       if (((Boolean)settings.renderGoalXZBeacon.value).booleanValue()) {
/* 251 */         GL11.glPushAttrib(64);
/*     */         
/* 253 */         Helper.mc.method_1531().method_22813(TEXTURE_BEACON_BEAM);
/* 254 */         if (((Boolean)settings.renderGoalIgnoreDepth.value).booleanValue()) {
/* 255 */           RenderSystem.disableDepthTest();
/*     */         }
/*     */         
/* 258 */         stack.method_22903();
/* 259 */         stack.method_22904(goalPos.getX() - renderPosX, -renderPosY, goalPos.getZ() - renderPosZ);
/*     */         
/* 261 */         class_822.method_3545(stack, (class_4597)mc
/*     */             
/* 263 */             .method_22940().method_23000(), TEXTURE_BEACON_BEAM, partialTicks, 1.0F, player.field_6002
/*     */ 
/*     */ 
/*     */             
/* 267 */             .method_8510(), 0, 256, color
/*     */ 
/*     */             
/* 270 */             .getColorComponents(null), 0.2F, 0.25F);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 277 */         stack.method_22909();
/*     */         
/* 279 */         if (((Boolean)settings.renderGoalIgnoreDepth.value).booleanValue()) {
/* 280 */           RenderSystem.enableDepthTest();
/*     */         }
/*     */         
/* 283 */         GL11.glPopAttrib();
/*     */         
/*     */         return;
/*     */       } 
/* 287 */       minX = goalPos.getX() + 0.002D - renderPosX;
/* 288 */       maxX = (goalPos.getX() + 1) - 0.002D - renderPosX;
/* 289 */       minZ = goalPos.getZ() + 0.002D - renderPosZ;
/* 290 */       maxZ = (goalPos.getZ() + 1) - 0.002D - renderPosZ;
/*     */       
/* 292 */       y1 = 0.0D;
/* 293 */       y2 = 0.0D;
/* 294 */       minY = 0.0D - renderPosY;
/* 295 */       maxY = 256.0D - renderPosY; }
/* 296 */     else { if (goal instanceof GoalComposite) {
/* 297 */         for (Goal g : ((GoalComposite)goal).goals())
/* 298 */           drawDankLitGoalBox(stack, player, g, partialTicks, color); 
/*     */         return;
/*     */       } 
/* 301 */       if (goal instanceof GoalInverted) {
/* 302 */         drawDankLitGoalBox(stack, player, ((GoalInverted)goal).origin, partialTicks, (Color)settings.colorInvertedGoalBox.value); return;
/*     */       } 
/* 304 */       if (goal instanceof GoalYLevel) {
/* 305 */         GoalYLevel goalpos = (GoalYLevel)goal;
/* 306 */         minX = player.method_23317() - ((Double)settings.yLevelBoxSize.value).doubleValue() - renderPosX;
/* 307 */         minZ = player.method_23321() - ((Double)settings.yLevelBoxSize.value).doubleValue() - renderPosZ;
/* 308 */         maxX = player.method_23317() + ((Double)settings.yLevelBoxSize.value).doubleValue() - renderPosX;
/* 309 */         maxZ = player.method_23321() + ((Double)settings.yLevelBoxSize.value).doubleValue() - renderPosZ;
/* 310 */         minY = ((GoalYLevel)goal).level - renderPosY;
/* 311 */         maxY = minY + 2.0D;
/* 312 */         y1 = 1.0D + y + goalpos.level - renderPosY;
/* 313 */         y2 = 1.0D - y + goalpos.level - renderPosY;
/*     */       } else {
/*     */         return;
/*     */       }  }
/*     */     
/* 318 */     IRenderer.startLines(color, ((Float)settings.goalRenderLineWidthPixels.value).floatValue(), ((Boolean)settings.renderGoalIgnoreDepth.value).booleanValue());
/*     */     
/* 320 */     renderHorizontalQuad(stack, minX, maxX, minZ, maxZ, y1);
/* 321 */     renderHorizontalQuad(stack, minX, maxX, minZ, maxZ, y2);
/*     */     
/* 323 */     class_1159 matrix4f = stack.method_23760().method_23761();
/* 324 */     buffer.method_1328(1, class_290.field_1592);
/* 325 */     buffer.method_22918(matrix4f, (float)minX, (float)minY, (float)minZ).method_1344();
/* 326 */     buffer.method_22918(matrix4f, (float)minX, (float)maxY, (float)minZ).method_1344();
/* 327 */     buffer.method_22918(matrix4f, (float)maxX, (float)minY, (float)minZ).method_1344();
/* 328 */     buffer.method_22918(matrix4f, (float)maxX, (float)maxY, (float)minZ).method_1344();
/* 329 */     buffer.method_22918(matrix4f, (float)maxX, (float)minY, (float)maxZ).method_1344();
/* 330 */     buffer.method_22918(matrix4f, (float)maxX, (float)maxY, (float)maxZ).method_1344();
/* 331 */     buffer.method_22918(matrix4f, (float)minX, (float)minY, (float)maxZ).method_1344();
/* 332 */     buffer.method_22918(matrix4f, (float)minX, (float)maxY, (float)maxZ).method_1344();
/* 333 */     tessellator.method_1350();
/*     */     
/* 335 */     IRenderer.endLines(((Boolean)settings.renderGoalIgnoreDepth.value).booleanValue());
/*     */   }
/*     */   
/*     */   private static void renderHorizontalQuad(class_4587 stack, double minX, double maxX, double minZ, double maxZ, double y) {
/* 339 */     if (y != 0.0D) {
/* 340 */       class_1159 matrix4f = stack.method_23760().method_23761();
/* 341 */       buffer.method_1328(2, class_290.field_1592);
/* 342 */       buffer.method_22918(matrix4f, (float)minX, (float)y, (float)minZ).method_1344();
/* 343 */       buffer.method_22918(matrix4f, (float)maxX, (float)y, (float)minZ).method_1344();
/* 344 */       buffer.method_22918(matrix4f, (float)maxX, (float)y, (float)maxZ).method_1344();
/* 345 */       buffer.method_22918(matrix4f, (float)minX, (float)y, (float)maxZ).method_1344();
/* 346 */       tessellator.method_1350();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\bariton\\utils\PathRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */