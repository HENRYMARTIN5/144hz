/*     */ package baritone.utils;
/*     */ 
/*     */ import baritone.Baritone;
/*     */ import baritone.api.event.events.TickEvent;
/*     */ import baritone.api.event.listener.AbstractGameEventListener;
/*     */ import baritone.api.event.listener.IGameEventListener;
/*     */ import baritone.api.pathing.calc.IPathingControlManager;
/*     */ import baritone.api.pathing.goals.Goal;
/*     */ import baritone.api.process.IBaritoneProcess;
/*     */ import baritone.api.process.PathingCommand;
/*     */ import baritone.api.process.PathingCommandType;
/*     */ import baritone.api.utils.BetterBlockPos;
/*     */ import baritone.behavior.PathingBehavior;
/*     */ import baritone.pathing.path.PathExecutor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import net.minecraft.class_2338;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PathingControlManager
/*     */   implements IPathingControlManager
/*     */ {
/*     */   private final Baritone baritone;
/*     */   private final HashSet<IBaritoneProcess> processes;
/*     */   private final List<IBaritoneProcess> active;
/*     */   private IBaritoneProcess inControlLastTick;
/*     */   private IBaritoneProcess inControlThisTick;
/*     */   private PathingCommand command;
/*     */   
/*     */   public PathingControlManager(Baritone baritone) {
/*  44 */     this.baritone = baritone;
/*  45 */     this.processes = new HashSet<>();
/*  46 */     this.active = new ArrayList<>();
/*  47 */     baritone.getGameEventHandler().registerEventListener((IGameEventListener)new AbstractGameEventListener()
/*     */         {
/*     */           public void onTick(TickEvent event) {
/*  50 */             if (event.getType() == TickEvent.Type.IN) {
/*  51 */               PathingControlManager.this.postTick();
/*     */             }
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public void registerProcess(IBaritoneProcess process) {
/*  59 */     process.onLostControl();
/*  60 */     this.processes.add(process);
/*     */   }
/*     */   
/*     */   public void cancelEverything() {
/*  64 */     this.inControlLastTick = null;
/*  65 */     this.inControlThisTick = null;
/*  66 */     this.command = null;
/*  67 */     this.active.clear();
/*  68 */     for (IBaritoneProcess proc : this.processes) {
/*  69 */       proc.onLostControl();
/*  70 */       if (proc.isActive() && !proc.isTemporary()) {
/*  71 */         throw new IllegalStateException(proc.displayName());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<IBaritoneProcess> mostRecentInControl() {
/*  78 */     return Optional.ofNullable(this.inControlThisTick);
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<PathingCommand> mostRecentCommand() {
/*  83 */     return Optional.ofNullable(this.command);
/*     */   }
/*     */   
/*     */   public void preTick() {
/*  87 */     this.inControlLastTick = this.inControlThisTick;
/*  88 */     this.inControlThisTick = null;
/*  89 */     PathingBehavior p = this.baritone.getPathingBehavior();
/*  90 */     this.command = executeProcesses();
/*  91 */     if (this.command == null) {
/*  92 */       p.cancelSegmentIfSafe();
/*  93 */       p.secretInternalSetGoal(null);
/*     */       return;
/*     */     } 
/*  96 */     if (!Objects.equals(this.inControlThisTick, this.inControlLastTick) && this.command.commandType != PathingCommandType.REQUEST_PAUSE && this.inControlLastTick != null && !this.inControlLastTick.isTemporary())
/*     */     {
/*  98 */       p.cancelSegmentIfSafe();
/*     */     }
/*     */     
/* 101 */     switch (this.command.commandType) {
/*     */       case REQUEST_PAUSE:
/* 103 */         p.requestPause();
/*     */         return;
/*     */       case CANCEL_AND_SET_GOAL:
/* 106 */         p.secretInternalSetGoal(this.command.goal);
/* 107 */         p.cancelSegmentIfSafe();
/*     */         return;
/*     */       case FORCE_REVALIDATE_GOAL_AND_PATH:
/* 110 */         if (!p.isPathing() && !p.getInProgress().isPresent()) {
/* 111 */           p.secretInternalSetGoalAndPath(this.command);
/*     */         }
/*     */         return;
/*     */       case REVALIDATE_GOAL_AND_PATH:
/* 115 */         if (!p.isPathing() && !p.getInProgress().isPresent()) {
/* 116 */           p.secretInternalSetGoalAndPath(this.command);
/*     */         }
/*     */         return;
/*     */       
/*     */       case SET_GOAL_AND_PATH:
/* 121 */         if (this.command.goal != null) {
/* 122 */           this.baritone.getPathingBehavior().secretInternalSetGoalAndPath(this.command);
/*     */         }
/*     */         return;
/*     */     } 
/* 126 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void postTick() {
/* 135 */     if (this.command == null) {
/*     */       return;
/*     */     }
/* 138 */     PathingBehavior p = this.baritone.getPathingBehavior();
/* 139 */     switch (this.command.commandType) {
/*     */       case FORCE_REVALIDATE_GOAL_AND_PATH:
/* 141 */         if (this.command.goal == null || forceRevalidate(this.command.goal) || revalidateGoal(this.command.goal))
/*     */         {
/* 143 */           p.softCancelIfSafe();
/*     */         }
/* 145 */         p.secretInternalSetGoalAndPath(this.command);
/*     */         break;
/*     */       case REVALIDATE_GOAL_AND_PATH:
/* 148 */         if (((Boolean)(Baritone.settings()).cancelOnGoalInvalidation.value).booleanValue() && (this.command.goal == null || revalidateGoal(this.command.goal))) {
/* 149 */           p.softCancelIfSafe();
/*     */         }
/* 151 */         p.secretInternalSetGoalAndPath(this.command);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean forceRevalidate(Goal newGoal) {
/* 158 */     PathExecutor current = this.baritone.getPathingBehavior().getCurrent();
/* 159 */     if (current != null) {
/* 160 */       if (newGoal.isInGoal((class_2338)current.getPath().getDest())) {
/* 161 */         return false;
/*     */       }
/* 163 */       return !newGoal.toString().equals(current.getPath().getGoal().toString());
/*     */     } 
/* 165 */     return false;
/*     */   }
/*     */   
/*     */   public boolean revalidateGoal(Goal newGoal) {
/* 169 */     PathExecutor current = this.baritone.getPathingBehavior().getCurrent();
/* 170 */     if (current != null) {
/* 171 */       Goal intended = current.getPath().getGoal();
/* 172 */       BetterBlockPos betterBlockPos = current.getPath().getDest();
/* 173 */       if (intended.isInGoal((class_2338)betterBlockPos) && !newGoal.isInGoal((class_2338)betterBlockPos))
/*     */       {
/*     */         
/* 176 */         return true;
/*     */       }
/*     */     } 
/* 179 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public PathingCommand executeProcesses() {
/* 184 */     for (IBaritoneProcess process : this.processes) {
/* 185 */       if (process.isActive()) {
/* 186 */         if (!this.active.contains(process))
/*     */         {
/* 188 */           this.active.add(0, process); } 
/*     */         continue;
/*     */       } 
/* 191 */       this.active.remove(process);
/*     */     } 
/*     */ 
/*     */     
/* 195 */     this.active.sort(Comparator.<IBaritoneProcess>comparingDouble(IBaritoneProcess::priority).reversed());
/*     */     
/* 197 */     Iterator<IBaritoneProcess> iterator = this.active.iterator();
/* 198 */     while (iterator.hasNext()) {
/* 199 */       IBaritoneProcess proc = iterator.next();
/*     */       
/* 201 */       PathingCommand exec = proc.onTick((Objects.equals(proc, this.inControlLastTick) && this.baritone.getPathingBehavior().calcFailedLastTick()), this.baritone.getPathingBehavior().isSafeToCancel());
/* 202 */       if (exec == null) {
/* 203 */         if (proc.isActive())
/* 204 */           throw new IllegalStateException(proc.displayName() + " actively returned null PathingCommand"); 
/*     */         continue;
/*     */       } 
/* 207 */       if (exec.commandType != PathingCommandType.DEFER) {
/* 208 */         this.inControlThisTick = proc;
/* 209 */         if (!proc.isTemporary()) {
/* 210 */           iterator.forEachRemaining(IBaritoneProcess::onLostControl);
/*     */         }
/* 212 */         return exec;
/*     */       } 
/*     */     } 
/* 215 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\bariton\\utils\PathingControlManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */