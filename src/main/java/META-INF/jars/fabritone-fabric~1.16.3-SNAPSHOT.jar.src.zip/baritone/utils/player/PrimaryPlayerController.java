/*    */ package baritone.utils.player;
/*    */ 
/*    */ import baritone.api.utils.Helper;
/*    */ import baritone.api.utils.IPlayerController;
/*    */ import baritone.utils.accessor.IPlayerControllerMP;
/*    */ import net.minecraft.class_1268;
/*    */ import net.minecraft.class_1269;
/*    */ import net.minecraft.class_1657;
/*    */ import net.minecraft.class_1713;
/*    */ import net.minecraft.class_1799;
/*    */ import net.minecraft.class_1934;
/*    */ import net.minecraft.class_1937;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_2350;
/*    */ import net.minecraft.class_3965;
/*    */ import net.minecraft.class_638;
/*    */ import net.minecraft.class_746;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum PrimaryPlayerController
/*    */   implements IPlayerController, Helper
/*    */ {
/* 45 */   INSTANCE;
/*    */ 
/*    */   
/*    */   public void syncHeldItem() {
/* 49 */     ((IPlayerControllerMP)mc.field_1761).callSyncSelectedSlot();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasBrokenBlock() {
/* 54 */     return (((IPlayerControllerMP)mc.field_1761).getCurrentBreakingPos().method_10264() == -1);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean onPlayerDamageBlock(class_2338 pos, class_2350 side) {
/* 59 */     return mc.field_1761.method_2902(pos, side);
/*    */   }
/*    */ 
/*    */   
/*    */   public void resetBlockRemoving() {
/* 64 */     mc.field_1761.method_2925();
/*    */   }
/*    */ 
/*    */   
/*    */   public class_1799 windowClick(int windowId, int slotId, int mouseButton, class_1713 type, class_1657 player) {
/* 69 */     return mc.field_1761.method_2906(windowId, slotId, mouseButton, type, player);
/*    */   }
/*    */ 
/*    */   
/*    */   public class_1934 getGameType() {
/* 74 */     return mc.field_1761.method_2920();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public class_1269 processRightClickBlock(class_746 player, class_1937 world, class_1268 hand, class_3965 result) {
/* 80 */     return mc.field_1761.method_2896(player, (class_638)world, hand, result);
/*    */   }
/*    */ 
/*    */   
/*    */   public class_1269 processRightClick(class_746 player, class_1937 world, class_1268 hand) {
/* 85 */     return mc.field_1761.method_2919((class_1657)player, world, hand);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean clickBlock(class_2338 loc, class_2350 face) {
/* 90 */     return mc.field_1761.method_2910(loc, face);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setHittingBlock(boolean hittingBlock) {
/* 95 */     ((IPlayerControllerMP)mc.field_1761).setBreakingBlock(hittingBlock);
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\bariton\\utils\player\PrimaryPlayerController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */