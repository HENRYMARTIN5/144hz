/*     */ package baritone.utils;
/*     */ 
/*     */ import baritone.Baritone;
/*     */ import baritone.api.BaritoneAPI;
/*     */ import baritone.api.command.IBaritoneChatControl;
/*     */ import baritone.api.pathing.goals.Goal;
/*     */ import baritone.api.pathing.goals.GoalBlock;
/*     */ import baritone.api.utils.BetterBlockPos;
/*     */ import baritone.api.utils.Helper;
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import java.awt.Color;
/*     */ import java.util.Collections;
/*     */ import net.minecraft.class_1159;
/*     */ import net.minecraft.class_1162;
/*     */ import net.minecraft.class_124;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_238;
/*     */ import net.minecraft.class_239;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_2558;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_2585;
/*     */ import net.minecraft.class_3959;
/*     */ import net.minecraft.class_3965;
/*     */ import net.minecraft.class_437;
/*     */ import net.minecraft.class_4587;
/*     */ import net.minecraft.class_746;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GuiClick
/*     */   extends class_437
/*     */   implements Helper
/*     */ {
/*     */   private class_1159 projectionViewMatrix;
/*     */   private class_2338 clickStart;
/*     */   private class_2338 currentMouseOver;
/*     */   
/*     */   public GuiClick() {
/*  54 */     super((class_2561)new class_2585("CLICK"));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean method_25421() {
/*  59 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void method_25394(class_4587 stack, int mouseX, int mouseY, float partialTicks) {
/*  64 */     double mx = mc.field_1729.method_1603();
/*  65 */     double my = mc.field_1729.method_1604();
/*     */     
/*  67 */     my = mc.method_22683().method_4507() - my;
/*  68 */     my *= mc.method_22683().method_4506() / mc.method_22683().method_4507();
/*  69 */     mx *= mc.method_22683().method_4489() / mc.method_22683().method_4480();
/*  70 */     class_243 near = toWorld(mx, my, 0.0D);
/*  71 */     class_243 far = toWorld(mx, my, 1.0D);
/*     */     
/*  73 */     if (near != null && far != null) {
/*     */       
/*  75 */       class_243 viewerPos = new class_243(PathRenderer.posX(), PathRenderer.posY(), PathRenderer.posZ());
/*  76 */       class_746 player = BaritoneAPI.getProvider().getPrimaryBaritone().getPlayerContext().player();
/*  77 */       class_3965 class_3965 = player.field_6002.method_17742(new class_3959(near.method_1019(viewerPos), far.method_1019(viewerPos), class_3959.class_3960.field_17559, class_3959.class_242.field_1348, (class_1297)player));
/*  78 */       if (class_3965 != null && class_3965.method_17783() == class_239.class_240.field_1332) {
/*  79 */         this.currentMouseOver = class_3965.method_17777();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean method_25406(double mouseX, double mouseY, int mouseButton) {
/*  86 */     if (this.currentMouseOver != null) {
/*  87 */       if (mouseButton == 0) {
/*  88 */         if (this.clickStart != null && !this.clickStart.equals(this.currentMouseOver)) {
/*  89 */           BaritoneAPI.getProvider().getPrimaryBaritone().getSelectionManager().removeAllSelections();
/*  90 */           BaritoneAPI.getProvider().getPrimaryBaritone().getSelectionManager().addSelection(BetterBlockPos.from(this.clickStart), BetterBlockPos.from(this.currentMouseOver));
/*  91 */           class_2585 class_2585 = new class_2585("Selection made! For usage: " + (String)(Baritone.settings()).prefix.value + "help sel");
/*  92 */           class_2585.method_10862(class_2585.method_10866()
/*  93 */               .method_27706(class_124.field_1068)
/*  94 */               .method_10958(new class_2558(class_2558.class_2559.field_11750, IBaritoneChatControl.FORCE_COMMAND_PREFIX + "help sel")));
/*     */ 
/*     */ 
/*     */           
/*  98 */           Helper.HELPER.logDirect(new class_2561[] { (class_2561)class_2585 });
/*  99 */           this.clickStart = null;
/*     */         } else {
/* 101 */           BaritoneAPI.getProvider().getPrimaryBaritone().getCustomGoalProcess().setGoalAndPath((Goal)new GoalBlock(this.currentMouseOver));
/*     */         } 
/* 103 */       } else if (mouseButton == 1) {
/* 104 */         BaritoneAPI.getProvider().getPrimaryBaritone().getCustomGoalProcess().setGoalAndPath((Goal)new GoalBlock(this.currentMouseOver.method_10084()));
/*     */       } 
/*     */     }
/* 107 */     this.clickStart = null;
/* 108 */     return super.method_25406(mouseX, mouseY, mouseButton);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean method_25402(double mouseX, double mouseY, int mouseButton) {
/* 113 */     this.clickStart = this.currentMouseOver;
/* 114 */     return super.method_25402(mouseX, mouseY, mouseButton);
/*     */   }
/*     */   
/*     */   public void onRender(class_4587 modelViewStack, class_1159 projectionMatrix) {
/* 118 */     this.projectionViewMatrix = projectionMatrix.method_22673();
/* 119 */     this.projectionViewMatrix.method_22672(modelViewStack.method_23760().method_23761());
/* 120 */     this.projectionViewMatrix.method_22870();
/*     */     
/* 122 */     if (this.currentMouseOver != null) {
/* 123 */       class_1297 e = mc.method_1560();
/*     */       
/* 125 */       PathRenderer.drawManySelectionBoxes(modelViewStack, e, Collections.singletonList(this.currentMouseOver), Color.CYAN);
/* 126 */       if (this.clickStart != null && !this.clickStart.equals(this.currentMouseOver)) {
/* 127 */         RenderSystem.enableBlend();
/* 128 */         RenderSystem.blendFuncSeparate(770, 771, 1, 0);
/* 129 */         RenderSystem.color4f(Color.RED.getColorComponents(null)[0], Color.RED.getColorComponents(null)[1], Color.RED.getColorComponents(null)[2], 0.4F);
/* 130 */         RenderSystem.lineWidth(((Float)(Baritone.settings()).pathRenderLineWidthPixels.value).floatValue());
/* 131 */         RenderSystem.disableTexture();
/* 132 */         RenderSystem.depthMask(false);
/* 133 */         RenderSystem.disableDepthTest();
/* 134 */         BetterBlockPos a = new BetterBlockPos(this.currentMouseOver);
/* 135 */         BetterBlockPos b = new BetterBlockPos(this.clickStart);
/* 136 */         IRenderer.drawAABB(modelViewStack, new class_238(Math.min(a.x, b.x), Math.min(a.y, b.y), Math.min(a.z, b.z), (Math.max(a.x, b.x) + 1), (Math.max(a.y, b.y) + 1), (Math.max(a.z, b.z) + 1)));
/* 137 */         RenderSystem.enableDepthTest();
/*     */         
/* 139 */         RenderSystem.depthMask(true);
/* 140 */         RenderSystem.enableTexture();
/* 141 */         RenderSystem.disableBlend();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private class_243 toWorld(double x, double y, double z) {
/* 147 */     if (this.projectionViewMatrix == null) {
/* 148 */       return null;
/*     */     }
/*     */     
/* 151 */     x /= mc.method_22683().method_4489();
/* 152 */     y /= mc.method_22683().method_4506();
/* 153 */     x = x * 2.0D - 1.0D;
/* 154 */     y = y * 2.0D - 1.0D;
/*     */     
/* 156 */     class_1162 pos = new class_1162((float)x, (float)y, (float)z, 1.0F);
/* 157 */     pos.method_22674(this.projectionViewMatrix);
/* 158 */     if (pos.method_23853() == 0.0F) {
/* 159 */       return null;
/*     */     }
/*     */     
/* 162 */     pos.method_23219();
/* 163 */     return new class_243(pos.method_4953(), pos.method_4956(), pos.method_4957());
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\bariton\\utils\GuiClick.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */