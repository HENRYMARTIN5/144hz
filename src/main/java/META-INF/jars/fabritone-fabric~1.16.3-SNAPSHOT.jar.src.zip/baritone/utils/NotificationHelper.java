/*    */ package baritone.utils;
/*    */ 
/*    */ import java.awt.Image;
/*    */ import java.awt.SystemTray;
/*    */ import java.awt.Toolkit;
/*    */ import java.awt.TrayIcon;
/*    */ import java.io.IOException;
/*    */ import org.apache.commons.lang3.SystemUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NotificationHelper
/*    */ {
/*    */   private static TrayIcon trayIcon;
/*    */   
/*    */   public static void notify(String text, boolean error) {
/* 36 */     if (SystemUtils.IS_OS_WINDOWS) {
/* 37 */       windows(text, error);
/* 38 */     } else if (SystemUtils.IS_OS_MAC_OSX) {
/* 39 */       mac(text);
/* 40 */     } else if (SystemUtils.IS_OS_LINUX) {
/* 41 */       linux(text);
/*    */     } 
/*    */   }
/*    */   
/*    */   private static void windows(String text, boolean error) {
/* 46 */     if (SystemTray.isSupported()) {
/*    */       try {
/* 48 */         if (trayIcon == null) {
/* 49 */           SystemTray tray = SystemTray.getSystemTray();
/* 50 */           Image image = Toolkit.getDefaultToolkit().createImage("");
/*    */           
/* 52 */           trayIcon = new TrayIcon(image, "Baritone");
/* 53 */           trayIcon.setImageAutoSize(true);
/* 54 */           trayIcon.setToolTip("Baritone");
/* 55 */           tray.add(trayIcon);
/*    */         } 
/*    */         
/* 58 */         trayIcon.displayMessage("Baritone", text, error ? TrayIcon.MessageType.ERROR : TrayIcon.MessageType.INFO);
/* 59 */       } catch (Exception e) {
/* 60 */         e.printStackTrace();
/*    */       } 
/*    */     } else {
/* 63 */       System.out.println("SystemTray is not supported");
/*    */     } 
/*    */   }
/*    */   
/*    */   private static void mac(String text) {
/* 68 */     ProcessBuilder processBuilder = new ProcessBuilder(new String[0]);
/* 69 */     processBuilder.command(new String[] { "osascript", "-e", "display notification \"" + text + "\" with title \"Baritone\"" });
/*    */     try {
/* 71 */       processBuilder.start();
/* 72 */     } catch (IOException e) {
/* 73 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static void linux(String text) {
/* 81 */     ProcessBuilder processBuilder = new ProcessBuilder(new String[0]);
/* 82 */     processBuilder.command(new String[] { "notify-send", "-a", "Baritone", text });
/*    */     try {
/* 84 */       processBuilder.start();
/* 85 */     } catch (IOException e) {
/* 86 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\bariton\\utils\NotificationHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */