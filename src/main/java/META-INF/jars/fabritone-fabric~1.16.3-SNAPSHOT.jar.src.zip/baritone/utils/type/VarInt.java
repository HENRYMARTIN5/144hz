/*    */ package baritone.utils.type;
/*    */ 
/*    */ import it.unimi.dsi.fastutil.bytes.ByteArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class VarInt
/*    */ {
/*    */   private final int value;
/*    */   private final byte[] serialized;
/*    */   private final int size;
/*    */   
/*    */   public VarInt(int value) {
/* 34 */     this.value = value;
/* 35 */     this.serialized = serialize0(this.value);
/* 36 */     this.size = this.serialized.length;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final int getValue() {
/* 43 */     return this.value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final int getSize() {
/* 50 */     return this.size;
/*    */   }
/*    */   
/*    */   public final byte[] serialize() {
/* 54 */     return this.serialized;
/*    */   }
/*    */   
/*    */   private static byte[] serialize0(int valueIn) {
/* 58 */     ByteArrayList byteArrayList = new ByteArrayList();
/*    */     
/* 60 */     int value = valueIn;
/* 61 */     while ((value & 0x80) != 0) {
/* 62 */       byteArrayList.add((byte)(value & 0x7F | 0x80));
/* 63 */       value >>>= 7;
/*    */     } 
/* 65 */     byteArrayList.add((byte)(value & 0xFF));
/*    */     
/* 67 */     return byteArrayList.toByteArray();
/*    */   }
/*    */   
/*    */   public static VarInt read(byte[] bytes) {
/* 71 */     return read(bytes, 0);
/*    */   }
/*    */   public static VarInt read(byte[] bytes, int start) {
/*    */     byte b;
/* 75 */     int value = 0;
/* 76 */     int size = 0;
/* 77 */     int index = start;
/*    */     
/*    */     do {
/* 80 */       b = bytes[index++];
/* 81 */       value |= (b & Byte.MAX_VALUE) << size++ * 7;
/*    */       
/* 83 */       if (size > 5) {
/* 84 */         throw new IllegalArgumentException("VarInt size cannot exceed 5 bytes");
/*    */       
/*    */       }
/*    */     }
/* 88 */     while ((b & 0x80) != 0);
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 93 */     return new VarInt(value);
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\bariton\\utils\type\VarInt.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */