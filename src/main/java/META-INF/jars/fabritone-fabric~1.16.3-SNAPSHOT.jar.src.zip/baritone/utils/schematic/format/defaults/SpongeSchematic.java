/*     */ package baritone.utils.schematic.format.defaults;
/*     */ 
/*     */ import baritone.utils.schematic.StaticSchematic;
/*     */ import baritone.utils.type.VarInt;
/*     */ import it.unimi.dsi.fastutil.ints.Int2ObjectArrayMap;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import net.minecraft.class_2248;
/*     */ import net.minecraft.class_2378;
/*     */ import net.minecraft.class_2487;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_2769;
/*     */ import net.minecraft.class_2960;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SpongeSchematic
/*     */   extends StaticSchematic
/*     */ {
/*     */   public SpongeSchematic(class_2487 nbt) {
/*  43 */     this.x = nbt.method_10550("Width");
/*  44 */     this.y = nbt.method_10550("Height");
/*  45 */     this.z = nbt.method_10550("Length");
/*  46 */     this.states = new class_2680[this.x][this.z][this.y];
/*     */     
/*  48 */     Int2ObjectArrayMap<class_2680> palette = new Int2ObjectArrayMap();
/*  49 */     class_2487 paletteTag = nbt.method_10562("Palette");
/*  50 */     for (String tag : paletteTag.method_10541()) {
/*  51 */       int index = paletteTag.method_10550(tag);
/*     */       
/*  53 */       SerializedBlockState serializedState = SerializedBlockState.getFromString(tag);
/*  54 */       if (serializedState == null) {
/*  55 */         throw new IllegalArgumentException("Unable to parse palette tag");
/*     */       }
/*     */       
/*  58 */       class_2680 state = serializedState.deserialize();
/*  59 */       if (state == null) {
/*  60 */         throw new IllegalArgumentException("Unable to deserialize palette tag");
/*     */       }
/*     */       
/*  63 */       palette.put(index, state);
/*     */     } 
/*     */ 
/*     */     
/*  67 */     byte[] rawBlockData = nbt.method_10547("BlockData");
/*  68 */     int[] blockData = new int[this.x * this.y * this.z];
/*  69 */     int offset = 0;
/*  70 */     for (int i = 0; i < blockData.length; i++) {
/*  71 */       if (offset >= rawBlockData.length) {
/*  72 */         throw new IllegalArgumentException("No remaining bytes in BlockData for complete schematic");
/*     */       }
/*     */       
/*  75 */       VarInt varInt = VarInt.read(rawBlockData, offset);
/*  76 */       blockData[i] = varInt.getValue();
/*  77 */       offset += varInt.getSize();
/*     */     } 
/*     */     
/*  80 */     for (int y = 0; y < this.y; y++) {
/*  81 */       for (int z = 0; z < this.z; z++) {
/*  82 */         for (int x = 0; x < this.x; x++) {
/*  83 */           int index = (y * this.z + z) * this.x + x;
/*  84 */           class_2680 state = (class_2680)palette.get(blockData[index]);
/*  85 */           if (state == null) {
/*  86 */             throw new IllegalArgumentException("Invalid Palette Index " + index);
/*     */           }
/*     */           
/*  89 */           this.states[x][z][y] = state;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static final class SerializedBlockState
/*     */   {
/*  97 */     private static final Pattern REGEX = Pattern.compile("(?<location>(\\w+:)?\\w+)(\\[(?<properties>(\\w+=\\w+,?)+)])?");
/*     */     
/*     */     private final class_2960 resourceLocation;
/*     */     private final Map<String, String> properties;
/*     */     private class_2680 blockState;
/*     */     
/*     */     private SerializedBlockState(class_2960 resourceLocation, Map<String, String> properties) {
/* 104 */       this.resourceLocation = resourceLocation;
/* 105 */       this.properties = properties;
/*     */     }
/*     */     
/*     */     private class_2680 deserialize() {
/* 109 */       if (this.blockState == null) {
/* 110 */         class_2248 block = (class_2248)class_2378.field_11146.method_10223(this.resourceLocation);
/* 111 */         this.blockState = block.method_9564();
/*     */         
/* 113 */         this.properties.keySet().stream().sorted(String::compareTo).forEachOrdered(key -> {
/*     */               class_2769<?> property = block.method_9595().method_11663(key);
/*     */               if (property != null) {
/*     */                 this.blockState = setPropertyValue(this.blockState, property, this.properties.get(key));
/*     */               }
/*     */             });
/*     */       } 
/* 120 */       return this.blockState;
/*     */     }
/*     */     
/*     */     private static SerializedBlockState getFromString(String s) {
/* 124 */       Matcher m = REGEX.matcher(s);
/* 125 */       if (!m.matches()) {
/* 126 */         return null;
/*     */       }
/*     */       
/*     */       try {
/* 130 */         String location = m.group("location");
/* 131 */         String properties = m.group("properties");
/*     */         
/* 133 */         class_2960 resourceLocation = new class_2960(location);
/* 134 */         Map<String, String> propertiesMap = new HashMap<>();
/* 135 */         if (properties != null) {
/* 136 */           for (String property : properties.split(",")) {
/* 137 */             String[] split = property.split("=");
/* 138 */             propertiesMap.put(split[0], split[1]);
/*     */           } 
/*     */         }
/*     */         
/* 142 */         return new SerializedBlockState(resourceLocation, propertiesMap);
/* 143 */       } catch (Exception e) {
/* 144 */         e.printStackTrace();
/* 145 */         return null;
/*     */       } 
/*     */     }
/*     */     
/*     */     private static <T extends Comparable<T>> class_2680 setPropertyValue(class_2680 state, class_2769<T> property, String value) {
/* 150 */       Optional<T> parsed = property.method_11900(value);
/* 151 */       if (parsed.isPresent()) {
/* 152 */         return (class_2680)state.method_11657(property, (Comparable)parsed.get());
/*     */       }
/* 154 */       throw new IllegalArgumentException("Invalid value for property " + property);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\bariton\\utils\schematic\format\defaults\SpongeSchematic.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */