/*    */ package baritone.utils;
/*    */ 
/*    */ import baritone.Baritone;
/*    */ import baritone.api.utils.Helper;
/*    */ import baritone.api.utils.IPlayerContext;
/*    */ import net.minecraft.class_1268;
/*    */ import net.minecraft.class_1269;
/*    */ import net.minecraft.class_239;
/*    */ import net.minecraft.class_3965;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlockPlaceHelper
/*    */   implements Helper
/*    */ {
/*    */   private final IPlayerContext ctx;
/*    */   private int rightClickTimer;
/*    */   
/*    */   BlockPlaceHelper(IPlayerContext playerContext) {
/* 35 */     this.ctx = playerContext;
/*    */   }
/*    */   
/*    */   public void tick(boolean rightClickRequested) {
/* 39 */     if (this.rightClickTimer > 0) {
/* 40 */       this.rightClickTimer--;
/*    */       return;
/*    */     } 
/* 43 */     class_239 mouseOver = this.ctx.objectMouseOver();
/* 44 */     boolean isRowingBoat = (this.ctx.player().method_5854() != null && this.ctx.player().method_5854() instanceof net.minecraft.class_1690);
/* 45 */     if (!rightClickRequested || isRowingBoat || mouseOver == null || mouseOver.method_17783() != class_239.class_240.field_1332) {
/*    */       return;
/*    */     }
/* 48 */     this.rightClickTimer = ((Integer)(Baritone.settings()).rightClickSpeed.value).intValue();
/* 49 */     for (class_1268 hand : class_1268.values()) {
/* 50 */       if (this.ctx.playerController().processRightClickBlock(this.ctx.player(), this.ctx.world(), hand, (class_3965)mouseOver) == class_1269.field_5812) {
/* 51 */         this.ctx.player().method_6104(hand);
/*    */         return;
/*    */       } 
/* 54 */       if (!this.ctx.player().method_5998(hand).method_7960() && this.ctx.playerController().processRightClick(this.ctx.player(), this.ctx.world(), hand) == class_1269.field_5812)
/*    */         return; 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\bariton\\utils\BlockPlaceHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */