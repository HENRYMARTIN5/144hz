/*     */ package baritone.utils;
/*     */ 
/*     */ import baritone.Baritone;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.function.Function;
/*     */ import net.minecraft.class_1294;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_1890;
/*     */ import net.minecraft.class_1893;
/*     */ import net.minecraft.class_2248;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_746;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ToolSet
/*     */ {
/*     */   private final Map<class_2248, Double> breakStrengthCache;
/*     */   private final Function<class_2248, Double> backendCalculation;
/*     */   private final class_746 player;
/*     */   
/*     */   public ToolSet(class_746 player) {
/*  55 */     this.breakStrengthCache = new HashMap<>();
/*  56 */     this.player = player;
/*     */     
/*  58 */     if (((Boolean)(Baritone.settings()).considerPotionEffects.value).booleanValue()) {
/*  59 */       double amplifier = potionAmplifier();
/*  60 */       Function<Double, Double> amplify = x -> Double.valueOf(amplifier * x.doubleValue());
/*  61 */       this.backendCalculation = amplify.compose(this::getBestDestructionTime);
/*     */     } else {
/*  63 */       this.backendCalculation = this::getBestDestructionTime;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getStrVsBlock(class_2680 state) {
/*  74 */     return ((Double)this.breakStrengthCache.computeIfAbsent(state.method_26204(), this.backendCalculation)).doubleValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getMaterialCost(class_1799 itemStack) {
/*  84 */     return (itemStack.method_7909() instanceof net.minecraft.class_1831) ? 1 : -1;
/*     */   }
/*     */   
/*     */   public boolean hasSilkTouch(class_1799 stack) {
/*  88 */     return (class_1890.method_8225(class_1893.field_9099, stack) > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBestSlot(class_2248 b, boolean preferSilkTouch) {
/* 100 */     return getBestSlot(b, preferSilkTouch, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBestSlot(class_2248 b, boolean preferSilkTouch, boolean pathingCalculation) {
/* 109 */     if (((Boolean)(Baritone.settings()).disableAutoTool.value).booleanValue() && pathingCalculation) {
/* 110 */       return this.player.field_7514.field_7545;
/*     */     }
/*     */     
/* 113 */     int best = 0;
/* 114 */     double highestSpeed = Double.NEGATIVE_INFINITY;
/* 115 */     int lowestCost = Integer.MIN_VALUE;
/* 116 */     boolean bestSilkTouch = false;
/* 117 */     class_2680 blockState = b.method_9564();
/* 118 */     for (int i = 0; i < 9; i++) {
/* 119 */       class_1799 itemStack = this.player.field_7514.method_5438(i);
/* 120 */       double speed = calculateSpeedVsBlock(itemStack, blockState);
/* 121 */       boolean silkTouch = hasSilkTouch(itemStack);
/* 122 */       if (speed > highestSpeed) {
/* 123 */         highestSpeed = speed;
/* 124 */         best = i;
/* 125 */         lowestCost = getMaterialCost(itemStack);
/* 126 */         bestSilkTouch = silkTouch;
/* 127 */       } else if (speed == highestSpeed) {
/* 128 */         int cost = getMaterialCost(itemStack);
/* 129 */         if ((cost < lowestCost && (silkTouch || !bestSilkTouch)) || (preferSilkTouch && !bestSilkTouch && silkTouch)) {
/*     */           
/* 131 */           highestSpeed = speed;
/* 132 */           best = i;
/* 133 */           lowestCost = cost;
/* 134 */           bestSilkTouch = silkTouch;
/*     */         } 
/*     */       } 
/*     */     } 
/* 138 */     return best;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double getBestDestructionTime(class_2248 b) {
/* 148 */     class_1799 stack = this.player.field_7514.method_5438(getBestSlot(b, false, true));
/* 149 */     return calculateSpeedVsBlock(stack, b.method_9564()) * avoidanceMultiplier(b);
/*     */   }
/*     */   
/*     */   private double avoidanceMultiplier(class_2248 b) {
/* 153 */     return ((List)(Baritone.settings()).blocksToAvoidBreaking.value).contains(b) ? 0.1D : 1.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double calculateSpeedVsBlock(class_1799 item, class_2680 state) {
/* 165 */     float hardness = state.method_26214(null, null);
/* 166 */     if (hardness < 0.0F) {
/* 167 */       return -1.0D;
/*     */     }
/*     */     
/* 170 */     float speed = item.method_7924(state);
/* 171 */     if (speed > 1.0F) {
/* 172 */       int effLevel = class_1890.method_8225(class_1893.field_9131, item);
/* 173 */       if (effLevel > 0 && !item.method_7960()) {
/* 174 */         speed += (effLevel * effLevel + 1);
/*     */       }
/*     */     } 
/*     */     
/* 178 */     speed /= hardness;
/* 179 */     if (!state.method_29291() || (!item.method_7960() && item.method_7951(state))) {
/* 180 */       return (speed / 30.0F);
/*     */     }
/* 182 */     return (speed / 100.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double potionAmplifier() {
/* 192 */     double speed = 1.0D;
/* 193 */     if (this.player.method_6059(class_1294.field_5917)) {
/* 194 */       speed *= 1.0D + (this.player.method_6112(class_1294.field_5917).method_5578() + 1) * 0.2D;
/*     */     }
/* 196 */     if (this.player.method_6059(class_1294.field_5901))
/* 197 */     { switch (this.player.method_6112(class_1294.field_5901).method_5578())
/*     */       { case 0:
/* 199 */           speed *= 0.3D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 212 */           return speed;case 1: speed *= 0.09D; return speed;case 2: speed *= 0.0027D; return speed; }  speed *= 8.1E-4D; }  return speed;
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\bariton\\utils\ToolSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */