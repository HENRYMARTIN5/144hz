/*     */ package baritone.utils;
/*     */ 
/*     */ import baritone.api.BaritoneAPI;
/*     */ import baritone.api.event.events.TickEvent;
/*     */ import baritone.api.event.listener.AbstractGameEventListener;
/*     */ import baritone.api.pathing.goals.Goal;
/*     */ import baritone.api.pathing.goals.GoalBlock;
/*     */ import baritone.api.utils.Helper;
/*     */ import baritone.api.utils.IPlayerContext;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.nio.file.Files;
/*     */ import java.util.OptionalLong;
/*     */ import net.minecraft.class_1132;
/*     */ import net.minecraft.class_1157;
/*     */ import net.minecraft.class_1267;
/*     */ import net.minecraft.class_1928;
/*     */ import net.minecraft.class_1934;
/*     */ import net.minecraft.class_1937;
/*     */ import net.minecraft.class_1940;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_315;
/*     */ import net.minecraft.class_3218;
/*     */ import net.minecraft.class_3521;
/*     */ import net.minecraft.class_4060;
/*     */ import net.minecraft.class_4063;
/*     */ import net.minecraft.class_4066;
/*     */ import net.minecraft.class_5285;
/*     */ import net.minecraft.class_5359;
/*     */ import net.minecraft.class_5365;
/*     */ import net.minecraft.class_5455;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BaritoneAutoTest
/*     */   implements AbstractGameEventListener, Helper
/*     */ {
/*  57 */   public static final BaritoneAutoTest INSTANCE = new BaritoneAutoTest();
/*     */   
/*  59 */   public static final boolean ENABLE_AUTO_TEST = "true".equals(System.getenv("BARITONE_AUTO_TEST"));
/*     */   private static final long TEST_SEED = -928872506371745L;
/*  61 */   private static final class_2338 STARTING_POSITION = new class_2338(0, 65, 0);
/*  62 */   private static final Goal GOAL = (Goal)new GoalBlock(69, 69, 420);
/*     */ 
/*     */   
/*     */   private static final int MAX_TICKS = 3300;
/*     */ 
/*     */   
/*     */   public void onPreInit() {
/*  69 */     if (!ENABLE_AUTO_TEST) {
/*     */       return;
/*     */     }
/*  72 */     System.out.println("Optimizing Game Settings");
/*     */     
/*  74 */     class_315 s = mc.field_1690;
/*  75 */     s.field_1909 = 20;
/*  76 */     s.field_1856 = 0;
/*  77 */     s.field_1882 = class_4066.field_18199;
/*  78 */     s.field_1872 = 128;
/*  79 */     s.field_1885 = 128;
/*  80 */     s.field_1905 = false;
/*  81 */     s.field_1888 = false;
/*  82 */     s.field_1908 = 0.0D;
/*  83 */     s.field_1841 = class_4060.field_18144;
/*  84 */     s.field_1814 = class_4063.field_18162;
/*  85 */     s.field_25444 = class_5365.field_25427;
/*  86 */     s.field_1875 = class_1157.field_5653;
/*  87 */     s.field_1842 = true;
/*  88 */     s.field_1826 = 30.0D;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onTick(TickEvent event) {
/*  93 */     IPlayerContext ctx = BaritoneAPI.getProvider().getPrimaryBaritone().getPlayerContext();
/*     */     
/*  95 */     if (mc.field_1755 instanceof net.minecraft.class_442) {
/*  96 */       System.out.println("Beginning Baritone automatic test routine");
/*  97 */       mc.method_1507(null);
/*  98 */       class_1940 worldsettings = new class_1940("BaritoneAutoTest", class_1934.field_9215, false, class_1267.field_5802, true, new class_1928(), class_5359.field_25393);
/*  99 */       class_5455.class_5457 impl = class_5455.method_30528();
/* 100 */       mc.method_29607("BaritoneAutoTest", worldsettings, impl, class_5285.method_31112((class_5455)impl).method_28024(false, OptionalLong.of(-928872506371745L)));
/*     */     } 
/*     */     
/* 103 */     class_1132 server = mc.method_1576();
/*     */ 
/*     */ 
/*     */     
/* 107 */     if (server != null && server.method_3847(class_1937.field_25179) != null) {
/* 108 */       server.method_3776(class_1267.field_5801, true);
/* 109 */       if (mc.field_1724 == null) {
/* 110 */         server.execute(() -> {
/*     */               server.method_3847(class_1937.field_25179).method_8554(STARTING_POSITION, 0.0F);
/*     */               server.method_3734().method_9249(server.method_3739(), "/difficulty peaceful");
/*     */               int result = server.method_3734().method_9249(server.method_3739(), "/gamerule spawnRadius 0");
/*     */               if (result != 0) {
/*     */                 throw new IllegalStateException(result + "");
/*     */               }
/*     */             });
/* 118 */         for (class_3218 world : mc.method_1576().method_3738()) {
/*     */           
/* 120 */           if (world != null) {
/* 121 */             ((class_1928.class_4312)world.method_8450().method_20746(class_1928.field_19403)).method_27332("0");
/* 122 */             world.method_8554(STARTING_POSITION, 0.0F);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 128 */     if (event.getType() == TickEvent.Type.IN) {
/*     */ 
/*     */ 
/*     */       
/* 132 */       if (mc.method_1542() && !mc.method_1576().method_3860()) {
/* 133 */         mc.method_1576().method_3763(class_1934.field_9215, false, class_3521.method_15302());
/*     */       }
/*     */ 
/*     */       
/* 137 */       if (event.getCount() < 200) {
/* 138 */         System.out.println("Waiting for world to generate... " + event.getCount());
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 143 */       if (event.getCount() % 100 == 0) {
/* 144 */         System.out.println(ctx.playerFeet() + " " + event.getCount());
/*     */       }
/*     */ 
/*     */       
/* 148 */       if (!BaritoneAPI.getProvider().getPrimaryBaritone().getCustomGoalProcess().isActive()) {
/* 149 */         BaritoneAPI.getProvider().getPrimaryBaritone().getCustomGoalProcess().setGoalAndPath(GOAL);
/*     */       }
/*     */ 
/*     */       
/* 153 */       if (GOAL.isInGoal((class_2338)ctx.playerFeet())) {
/* 154 */         System.out.println("Successfully pathed to " + ctx.playerFeet() + " in " + event.getCount() + " ticks");
/*     */         try {
/* 156 */           File file = new File("success");
/* 157 */           System.out.println("Writing success to " + file.getAbsolutePath());
/* 158 */           Files.write(file.getAbsoluteFile().toPath(), "Success!".getBytes(), new java.nio.file.OpenOption[0]);
/* 159 */         } catch (IOException e) {
/* 160 */           e.printStackTrace();
/*     */         } 
/* 162 */         mc.method_1592();
/* 163 */         mc.method_1490();
/* 164 */         System.exit(0);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 169 */       if (event.getCount() > 3300)
/* 170 */         throw new IllegalStateException("took too long"); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\bariton\\utils\BaritoneAutoTest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */