package baritone.utils.accessor;

import java.util.concurrent.atomic.AtomicReferenceArray;
import net.minecraft.class_2818;

public interface IChunkArray {
  void copyFrom(IChunkArray paramIChunkArray);
  
  AtomicReferenceArray<class_2818> getChunks();
  
  int centerX();
  
  int centerZ();
  
  int viewDistance();
}


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\bariton\\utils\accessor\IChunkArray.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */