/*    */ package baritone.utils;
/*    */ 
/*    */ import baritone.Baritone;
/*    */ import baritone.api.process.IBaritoneProcess;
/*    */ import baritone.api.utils.Helper;
/*    */ import baritone.api.utils.IPlayerContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class BaritoneProcessHelper
/*    */   implements IBaritoneProcess, Helper
/*    */ {
/*    */   protected final Baritone baritone;
/*    */   protected final IPlayerContext ctx;
/*    */   
/*    */   public BaritoneProcessHelper(Baritone baritone) {
/* 31 */     this.baritone = baritone;
/* 32 */     this.ctx = baritone.getPlayerContext();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isTemporary() {
/* 37 */     return false;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\bariton\\utils\BaritoneProcessHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */