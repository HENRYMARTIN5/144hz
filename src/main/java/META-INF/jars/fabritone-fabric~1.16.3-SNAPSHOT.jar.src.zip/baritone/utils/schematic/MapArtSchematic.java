/*    */ package baritone.utils.schematic;
/*    */ 
/*    */ import baritone.api.schematic.ISchematic;
/*    */ import baritone.api.schematic.IStaticSchematic;
/*    */ import baritone.api.schematic.MaskSchematic;
/*    */ import java.util.OptionalInt;
/*    */ import java.util.function.Predicate;
/*    */ import net.minecraft.class_2680;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MapArtSchematic
/*    */   extends MaskSchematic
/*    */ {
/*    */   private final int[][] heightMap;
/*    */   
/*    */   public MapArtSchematic(IStaticSchematic schematic) {
/* 33 */     super((ISchematic)schematic);
/* 34 */     this.heightMap = generateHeightMap(schematic);
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean partOfMask(int x, int y, int z, class_2680 currentState) {
/* 39 */     return (y >= this.heightMap[x][z]);
/*    */   }
/*    */   
/*    */   private static int[][] generateHeightMap(IStaticSchematic schematic) {
/* 43 */     int[][] heightMap = new int[schematic.widthX()][schematic.lengthZ()];
/*    */     
/* 45 */     for (int x = 0; x < schematic.widthX(); x++) {
/* 46 */       for (int z = 0; z < schematic.lengthZ(); z++) {
/* 47 */         class_2680[] column = schematic.getColumn(x, z);
/* 48 */         OptionalInt lowestBlockY = lastIndexMatching(column, state -> !(state.method_26204() instanceof net.minecraft.class_2189));
/* 49 */         if (lowestBlockY.isPresent()) {
/* 50 */           heightMap[x][z] = lowestBlockY.getAsInt();
/*    */         } else {
/* 52 */           System.out.println("Column " + x + "," + z + " has no blocks, but it's apparently map art? wtf");
/* 53 */           System.out.println("Letting it be whatever");
/* 54 */           heightMap[x][z] = 256;
/*    */         } 
/*    */       } 
/*    */     } 
/* 58 */     return heightMap;
/*    */   }
/*    */   
/*    */   private static <T> OptionalInt lastIndexMatching(T[] arr, Predicate<? super T> predicate) {
/* 62 */     for (int y = arr.length - 1; y >= 0; y--) {
/* 63 */       if (predicate.test(arr[y])) {
/* 64 */         return OptionalInt.of(y);
/*    */       }
/*    */     } 
/* 67 */     return OptionalInt.empty();
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\bariton\\utils\schematic\MapArtSchematic.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */