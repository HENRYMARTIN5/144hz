/*    */ package baritone.utils.schematic.format;
/*    */ 
/*    */ import baritone.api.schematic.IStaticSchematic;
/*    */ import baritone.api.schematic.format.ISchematicFormat;
/*    */ import baritone.utils.schematic.format.defaults.MCEditSchematic;
/*    */ import baritone.utils.schematic.format.defaults.SpongeSchematic;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import net.minecraft.class_2487;
/*    */ import net.minecraft.class_2507;
/*    */ import org.apache.commons.io.FilenameUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum DefaultSchematicFormats
/*    */   implements ISchematicFormat
/*    */ {
/* 43 */   MCEDIT("schematic")
/*    */   {
/*    */     public IStaticSchematic parse(InputStream input) throws IOException
/*    */     {
/* 47 */       return (IStaticSchematic)new MCEditSchematic(class_2507.method_10629(input));
/*    */     }
/*    */   },
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 56 */   SPONGE("schem")
/*    */   {
/*    */     public IStaticSchematic parse(InputStream input) throws IOException
/*    */     {
/* 60 */       class_2487 nbt = class_2507.method_10629(input);
/* 61 */       int version = nbt.method_10550("Version");
/* 62 */       switch (version) {
/*    */         case 1:
/*    */         case 2:
/* 65 */           return (IStaticSchematic)new SpongeSchematic(nbt);
/*    */       } 
/* 67 */       throw new UnsupportedOperationException("Unsupported Version of a Sponge Schematic");
/*    */     }
/*    */   };
/*    */ 
/*    */   
/*    */   private final String extension;
/*    */   
/*    */   DefaultSchematicFormats(String extension) {
/* 75 */     this.extension = extension;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isFileType(File file) {
/* 80 */     return this.extension.equalsIgnoreCase(FilenameUtils.getExtension(file.getAbsolutePath()));
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\bariton\\utils\schematic\format\DefaultSchematicFormats.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */