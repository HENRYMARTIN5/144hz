/*    */ package baritone.utils;
/*    */ 
/*    */ import baritone.api.pathing.goals.Goal;
/*    */ import baritone.api.process.PathingCommand;
/*    */ import baritone.api.process.PathingCommandType;
/*    */ import baritone.pathing.movement.CalculationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PathingCommandContext
/*    */   extends PathingCommand
/*    */ {
/*    */   public final CalculationContext desiredCalcContext;
/*    */   
/*    */   public PathingCommandContext(Goal goal, PathingCommandType commandType, CalculationContext context) {
/* 30 */     super(goal, commandType);
/* 31 */     this.desiredCalcContext = context;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\bariton\\utils\PathingCommandContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */