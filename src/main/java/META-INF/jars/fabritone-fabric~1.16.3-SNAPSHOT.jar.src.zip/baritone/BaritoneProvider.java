/*    */ package baritone;
/*    */ 
/*    */ import baritone.api.IBaritone;
/*    */ import baritone.api.IBaritoneProvider;
/*    */ import baritone.api.cache.IWorldScanner;
/*    */ import baritone.api.command.ICommandSystem;
/*    */ import baritone.api.schematic.ISchematicSystem;
/*    */ import baritone.cache.WorldScanner;
/*    */ import baritone.command.CommandSystem;
/*    */ import baritone.command.ExampleBaritoneControl;
/*    */ import baritone.utils.schematic.SchematicSystem;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BaritoneProvider
/*    */   implements IBaritoneProvider
/*    */ {
/*    */   private final Baritone primary;
/*    */   private final List<IBaritone> all;
/*    */   
/*    */   public BaritoneProvider() {
/* 43 */     this.primary = new Baritone();
/* 44 */     this.all = Collections.singletonList(this.primary);
/*    */ 
/*    */     
/* 47 */     new ExampleBaritoneControl(this.primary);
/*    */   }
/*    */ 
/*    */   
/*    */   public IBaritone getPrimaryBaritone() {
/* 52 */     return this.primary;
/*    */   }
/*    */ 
/*    */   
/*    */   public List<IBaritone> getAllBaritones() {
/* 57 */     return this.all;
/*    */   }
/*    */ 
/*    */   
/*    */   public IWorldScanner getWorldScanner() {
/* 62 */     return (IWorldScanner)WorldScanner.INSTANCE;
/*    */   }
/*    */ 
/*    */   
/*    */   public ICommandSystem getCommandSystem() {
/* 67 */     return (ICommandSystem)CommandSystem.INSTANCE;
/*    */   }
/*    */ 
/*    */   
/*    */   public ISchematicSystem getSchematicSystem() {
/* 72 */     return (ISchematicSystem)SchematicSystem.INSTANCE;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\BaritoneProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */