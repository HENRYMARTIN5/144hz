/*     */ package baritone.event;
/*     */ 
/*     */ import baritone.Baritone;
/*     */ import baritone.api.event.events.BlockInteractEvent;
/*     */ import baritone.api.event.events.ChatEvent;
/*     */ import baritone.api.event.events.ChunkEvent;
/*     */ import baritone.api.event.events.PacketEvent;
/*     */ import baritone.api.event.events.PathEvent;
/*     */ import baritone.api.event.events.PlayerUpdateEvent;
/*     */ import baritone.api.event.events.RenderEvent;
/*     */ import baritone.api.event.events.RotationMoveEvent;
/*     */ import baritone.api.event.events.SprintStateEvent;
/*     */ import baritone.api.event.events.TabCompleteEvent;
/*     */ import baritone.api.event.events.TickEvent;
/*     */ import baritone.api.event.events.WorldEvent;
/*     */ import baritone.api.event.events.type.EventState;
/*     */ import baritone.api.event.listener.IEventBus;
/*     */ import baritone.api.event.listener.IGameEventListener;
/*     */ import baritone.api.utils.Helper;
/*     */ import baritone.cache.WorldData;
/*     */ import baritone.cache.WorldProvider;
/*     */ import baritone.utils.BlockStateInterface;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import net.minecraft.class_1937;
/*     */ import net.minecraft.class_2818;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class GameEventHandler
/*     */   implements IEventBus, Helper
/*     */ {
/*     */   private final Baritone baritone;
/*  43 */   private final List<IGameEventListener> listeners = new CopyOnWriteArrayList<>();
/*     */   
/*     */   public GameEventHandler(Baritone baritone) {
/*  46 */     this.baritone = baritone;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void onTick(TickEvent event) {
/*  51 */     if (event.getType() == TickEvent.Type.IN) {
/*     */       try {
/*  53 */         this.baritone.bsi = new BlockStateInterface(this.baritone.getPlayerContext(), true);
/*  54 */       } catch (Exception ex) {
/*  55 */         ex.printStackTrace();
/*  56 */         this.baritone.bsi = null;
/*     */       } 
/*     */     } else {
/*  59 */       this.baritone.bsi = null;
/*     */     } 
/*  61 */     this.listeners.forEach(l -> l.onTick(event));
/*     */   }
/*     */ 
/*     */   
/*     */   public final void onPlayerUpdate(PlayerUpdateEvent event) {
/*  66 */     this.listeners.forEach(l -> l.onPlayerUpdate(event));
/*     */   }
/*     */ 
/*     */   
/*     */   public final void onSendChatMessage(ChatEvent event) {
/*  71 */     this.listeners.forEach(l -> l.onSendChatMessage(event));
/*     */   }
/*     */ 
/*     */   
/*     */   public void onPreTabComplete(TabCompleteEvent event) {
/*  76 */     this.listeners.forEach(l -> l.onPreTabComplete(event));
/*     */   }
/*     */ 
/*     */   
/*     */   public final void onChunkEvent(ChunkEvent event) {
/*  81 */     EventState state = event.getState();
/*  82 */     ChunkEvent.Type type = event.getType();
/*     */     
/*  84 */     boolean isPostPopulate = (state == EventState.POST && (type == ChunkEvent.Type.POPULATE_FULL || type == ChunkEvent.Type.POPULATE_PARTIAL));
/*     */ 
/*     */     
/*  87 */     class_1937 world = this.baritone.getPlayerContext().world();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  94 */     boolean isPreUnload = (state == EventState.PRE && type == ChunkEvent.Type.UNLOAD && world.method_8398().method_12121(event.getX(), event.getZ(), null, false) != null);
/*     */     
/*  96 */     if (isPostPopulate || isPreUnload) {
/*  97 */       this.baritone.getWorldProvider().ifWorldLoaded(worldData -> {
/*     */             class_2818 chunk = world.method_8497(event.getX(), event.getZ());
/*     */             
/*     */             worldData.getCachedWorld().queueForPacking(chunk);
/*     */           });
/*     */     }
/*     */     
/* 104 */     this.listeners.forEach(l -> l.onChunkEvent(event));
/*     */   }
/*     */ 
/*     */   
/*     */   public final void onRenderPass(RenderEvent event) {
/* 109 */     this.listeners.forEach(l -> l.onRenderPass(event));
/*     */   }
/*     */ 
/*     */   
/*     */   public final void onWorldEvent(WorldEvent event) {
/* 114 */     WorldProvider cache = this.baritone.getWorldProvider();
/*     */     
/* 116 */     if (event.getState() == EventState.POST) {
/* 117 */       cache.closeWorld();
/* 118 */       if (event.getWorld() != null) {
/* 119 */         cache.initWorld(event.getWorld().method_27983());
/*     */       }
/*     */     } 
/*     */     
/* 123 */     this.listeners.forEach(l -> l.onWorldEvent(event));
/*     */   }
/*     */ 
/*     */   
/*     */   public final void onSendPacket(PacketEvent event) {
/* 128 */     this.listeners.forEach(l -> l.onSendPacket(event));
/*     */   }
/*     */ 
/*     */   
/*     */   public final void onReceivePacket(PacketEvent event) {
/* 133 */     this.listeners.forEach(l -> l.onReceivePacket(event));
/*     */   }
/*     */ 
/*     */   
/*     */   public void onPlayerRotationMove(RotationMoveEvent event) {
/* 138 */     this.listeners.forEach(l -> l.onPlayerRotationMove(event));
/*     */   }
/*     */ 
/*     */   
/*     */   public void onPlayerSprintState(SprintStateEvent event) {
/* 143 */     this.listeners.forEach(l -> l.onPlayerSprintState(event));
/*     */   }
/*     */ 
/*     */   
/*     */   public void onBlockInteract(BlockInteractEvent event) {
/* 148 */     this.listeners.forEach(l -> l.onBlockInteract(event));
/*     */   }
/*     */ 
/*     */   
/*     */   public void onPlayerDeath() {
/* 153 */     this.listeners.forEach(IGameEventListener::onPlayerDeath);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onPathEvent(PathEvent event) {
/* 158 */     this.listeners.forEach(l -> l.onPathEvent(event));
/*     */   }
/*     */ 
/*     */   
/*     */   public final void registerEventListener(IGameEventListener listener) {
/* 163 */     this.listeners.add(listener);
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\event\GameEventHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */