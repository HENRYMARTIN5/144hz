/*     */ package baritone.command.defaults;
/*     */ 
/*     */ import baritone.api.IBaritone;
/*     */ import baritone.api.cache.IWaypoint;
/*     */ import baritone.api.cache.Waypoint;
/*     */ import baritone.api.command.Command;
/*     */ import baritone.api.command.IBaritoneChatControl;
/*     */ import baritone.api.command.argument.IArgConsumer;
/*     */ import baritone.api.command.datatypes.ForWaypoints;
/*     */ import baritone.api.command.datatypes.IDatatype;
/*     */ import baritone.api.command.datatypes.IDatatypeFor;
/*     */ import baritone.api.command.datatypes.IDatatypePost;
/*     */ import baritone.api.command.datatypes.RelativeBlockPos;
/*     */ import baritone.api.command.exception.CommandException;
/*     */ import baritone.api.command.exception.CommandInvalidStateException;
/*     */ import baritone.api.command.exception.CommandInvalidTypeException;
/*     */ import baritone.api.command.helpers.Paginator;
/*     */ import baritone.api.command.helpers.TabCompleteHelper;
/*     */ import baritone.api.pathing.goals.Goal;
/*     */ import baritone.api.pathing.goals.GoalBlock;
/*     */ import baritone.api.utils.BetterBlockPos;
/*     */ import java.util.Arrays;
/*     */ import java.util.Date;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Function;
/*     */ import java.util.stream.Stream;
/*     */ import net.minecraft.class_124;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2558;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_2568;
/*     */ import net.minecraft.class_2585;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WaypointsCommand
/*     */   extends Command
/*     */ {
/*     */   public WaypointsCommand(IBaritone baritone) {
/*  48 */     super(baritone, new String[] { "waypoints", "waypoint", "wp" });
/*     */   }
/*     */ 
/*     */   
/*     */   public void execute(String label, IArgConsumer args) throws CommandException {
/*  53 */     Action action = args.hasAny() ? Action.getByName(args.getString()) : Action.LIST;
/*  54 */     if (action == null) {
/*  55 */       throw new CommandInvalidTypeException(args.consumed(), "an action");
/*     */     }
/*  57 */     BiFunction<IWaypoint, Action, class_2561> toComponent = (waypoint, _action) -> {
/*     */         class_2585 class_25851 = new class_2585("");
/*     */ 
/*     */         
/*     */         class_2585 class_25852 = new class_2585(waypoint.getTag().name() + " ");
/*     */ 
/*     */         
/*     */         class_25852.method_10862(class_25852.method_10866().method_27706(class_124.field_1080));
/*     */         
/*     */         String name = waypoint.getName();
/*     */         
/*     */         class_2585 class_25853 = new class_2585(!name.isEmpty() ? name : "<empty>");
/*     */         
/*     */         class_25853.method_10862(class_25853.method_10866().method_27706(!name.isEmpty() ? class_124.field_1080 : class_124.field_1063));
/*     */         
/*     */         class_2585 class_25854 = new class_2585(" @ " + new Date(waypoint.getCreationTimestamp()));
/*     */         
/*     */         class_25854.method_10862(class_25854.method_10866().method_27706(class_124.field_1063));
/*     */         
/*     */         class_25851.method_10852((class_2561)class_25852);
/*     */         
/*     */         class_25851.method_10852((class_2561)class_25853);
/*     */         
/*     */         class_25851.method_10852((class_2561)class_25854);
/*     */         
/*     */         class_25851.method_10862(class_25851.method_10866().method_10949(new class_2568(class_2568.class_5247.field_24342, new class_2585("Click to select"))).method_10958(new class_2558(class_2558.class_2559.field_11750, String.format("%s%s %s %s @ %d", new Object[] { IBaritoneChatControl.FORCE_COMMAND_PREFIX, label, Action.access$000(_action)[0], waypoint.getTag().getName(), Long.valueOf(waypoint.getCreationTimestamp()) }))));
/*     */         
/*     */         return (class_2561)class_25851;
/*     */       };
/*     */     
/*  87 */     Function<IWaypoint, class_2561> transform = waypoint -> (class_2561)toComponent.apply(waypoint, (action == Action.LIST) ? Action.INFO : action);
/*     */     
/*  89 */     if (action == Action.LIST) {
/*  90 */       IWaypoint.Tag tag = args.hasAny() ? IWaypoint.Tag.getByName(args.peekString()) : null;
/*  91 */       if (tag != null) {
/*  92 */         args.get();
/*     */       }
/*     */ 
/*     */       
/*  96 */       IWaypoint[] waypoints = (tag != null) ? ForWaypoints.getWaypointsByTag(this.baritone, tag) : ForWaypoints.getWaypoints(this.baritone);
/*  97 */       if (waypoints.length > 0) {
/*  98 */         args.requireMax(1);
/*  99 */         Paginator.paginate(args, (Object[])waypoints, () -> logDirect((tag != null) ? String.format("All waypoints by tag %s:", new Object[] { tag.name() }) : "All waypoints:"), transform, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 108 */             String.format("%s%s %s%s", new Object[] {
/*     */ 
/*     */ 
/*     */                 
/* 112 */                 IBaritoneChatControl.FORCE_COMMAND_PREFIX, label, Action.access$000(action)[0], (tag != null) ? (" " + tag
/* 113 */                 .getName()) : ""
/*     */               }));
/*     */       } else {
/*     */         
/* 117 */         args.requireMax(0);
/* 118 */         throw new CommandInvalidStateException((tag != null) ? "No waypoints found by that tag" : "No waypoints found");
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/* 124 */     else if (action == Action.SAVE) {
/* 125 */       IWaypoint.Tag tag = IWaypoint.Tag.getByName(args.getString());
/* 126 */       if (tag == null) {
/* 127 */         throw new CommandInvalidStateException(String.format("'%s' is not a tag ", new Object[] { args.consumedString() }));
/*     */       }
/* 129 */       String name = args.hasAny() ? args.getString() : "";
/*     */ 
/*     */       
/* 132 */       BetterBlockPos pos = args.hasAny() ? (BetterBlockPos)args.getDatatypePost((IDatatypePost)RelativeBlockPos.INSTANCE, this.ctx.playerFeet()) : this.ctx.playerFeet();
/* 133 */       args.requireMax(0);
/* 134 */       Waypoint waypoint = new Waypoint(name, tag, pos);
/* 135 */       ForWaypoints.waypoints(this.baritone).addWaypoint((IWaypoint)waypoint);
/* 136 */       class_2585 class_2585 = new class_2585("Waypoint added: ");
/* 137 */       class_2585.method_10862(class_2585.method_10866().method_27706(class_124.field_1080));
/* 138 */       class_2585.method_10852(toComponent.apply(waypoint, Action.INFO));
/* 139 */       logDirect(new class_2561[] { (class_2561)class_2585 });
/* 140 */     } else if (action == Action.CLEAR) {
/* 141 */       args.requireMax(1);
/* 142 */       IWaypoint.Tag tag = IWaypoint.Tag.getByName(args.getString());
/* 143 */       IWaypoint[] waypoints = ForWaypoints.getWaypointsByTag(this.baritone, tag);
/* 144 */       for (IWaypoint waypoint : waypoints) {
/* 145 */         ForWaypoints.waypoints(this.baritone).removeWaypoint(waypoint);
/*     */       }
/* 147 */       logDirect(String.format("Cleared %d waypoints", new Object[] { Integer.valueOf(waypoints.length) }));
/*     */     } else {
/* 149 */       IWaypoint[] waypoints = (IWaypoint[])args.getDatatypeFor((IDatatypeFor)ForWaypoints.INSTANCE);
/* 150 */       IWaypoint waypoint = null;
/* 151 */       if (args.hasAny() && args.peekString().equals("@")) {
/* 152 */         args.requireExactly(2);
/* 153 */         args.get();
/* 154 */         long timestamp = ((Long)args.getAs(Long.class)).longValue();
/* 155 */         for (IWaypoint iWaypoint : waypoints) {
/* 156 */           if (iWaypoint.getCreationTimestamp() == timestamp) {
/* 157 */             waypoint = iWaypoint;
/*     */             break;
/*     */           } 
/*     */         } 
/* 161 */         if (waypoint == null) {
/* 162 */           throw new CommandInvalidStateException("Timestamp was specified but no waypoint was found");
/*     */         }
/*     */       } else {
/* 165 */         switch (waypoints.length) {
/*     */           case 0:
/* 167 */             throw new CommandInvalidStateException("No waypoints found");
/*     */           case 1:
/* 169 */             waypoint = waypoints[0];
/*     */             break;
/*     */         } 
/*     */ 
/*     */       
/*     */       } 
/* 175 */       if (waypoint == null) {
/* 176 */         args.requireMax(1);
/* 177 */         Paginator.paginate(args, (Object[])waypoints, () -> logDirect("Multiple waypoints were found:"), transform, 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 182 */             String.format("%s%s %s %s", new Object[] {
/*     */ 
/*     */ 
/*     */                 
/* 186 */                 IBaritoneChatControl.FORCE_COMMAND_PREFIX, label, Action.access$000(action)[0], args
/* 187 */                 .consumedString()
/*     */               }));
/*     */       
/*     */       }
/* 191 */       else if (action == Action.INFO) {
/* 192 */         logDirect(new class_2561[] { transform.apply(waypoint) });
/* 193 */         logDirect(String.format("Position: %s", new Object[] { waypoint.getLocation() }));
/* 194 */         class_2585 class_25851 = new class_2585("Click to delete this waypoint");
/* 195 */         class_25851.method_10862(class_25851.method_10866().method_10958(new class_2558(class_2558.class_2559.field_11750, 
/*     */                 
/* 197 */                 String.format("%s%s delete %s @ %d", new Object[] {
/*     */ 
/*     */ 
/*     */                     
/* 201 */                     IBaritoneChatControl.FORCE_COMMAND_PREFIX, label, waypoint.getTag().getName(), 
/* 202 */                     Long.valueOf(waypoint.getCreationTimestamp())
/*     */                   }))));
/*     */         
/* 205 */         class_2585 class_25852 = new class_2585("Click to set goal to this waypoint");
/* 206 */         class_25852.method_10862(class_25852.method_10866().method_10958(new class_2558(class_2558.class_2559.field_11750, 
/*     */                 
/* 208 */                 String.format("%s%s goal %s @ %d", new Object[] {
/*     */ 
/*     */ 
/*     */                     
/* 212 */                     IBaritoneChatControl.FORCE_COMMAND_PREFIX, label, waypoint.getTag().getName(), 
/* 213 */                     Long.valueOf(waypoint.getCreationTimestamp())
/*     */                   }))));
/*     */         
/* 216 */         class_2585 class_25853 = new class_2585("Click to return to the waypoints list");
/* 217 */         class_25853.method_10862(class_25853.method_10866().method_10958(new class_2558(class_2558.class_2559.field_11750, 
/*     */                 
/* 219 */                 String.format("%s%s list", new Object[] { IBaritoneChatControl.FORCE_COMMAND_PREFIX, label }))));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 225 */         logDirect(new class_2561[] { (class_2561)class_25851 });
/* 226 */         logDirect(new class_2561[] { (class_2561)class_25852 });
/* 227 */         logDirect(new class_2561[] { (class_2561)class_25853 });
/* 228 */       } else if (action == Action.DELETE) {
/* 229 */         ForWaypoints.waypoints(this.baritone).removeWaypoint(waypoint);
/* 230 */         logDirect("That waypoint has successfully been deleted");
/* 231 */       } else if (action == Action.GOAL) {
/* 232 */         GoalBlock goalBlock = new GoalBlock((class_2338)waypoint.getLocation());
/* 233 */         this.baritone.getCustomGoalProcess().setGoal((Goal)goalBlock);
/* 234 */         logDirect(String.format("Goal: %s", new Object[] { goalBlock }));
/* 235 */       } else if (action == Action.GOTO) {
/* 236 */         GoalBlock goalBlock = new GoalBlock((class_2338)waypoint.getLocation());
/* 237 */         this.baritone.getCustomGoalProcess().setGoalAndPath((Goal)goalBlock);
/* 238 */         logDirect(String.format("Going to: %s", new Object[] { goalBlock }));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Stream<String> tabComplete(String label, IArgConsumer args) throws CommandException {
/* 246 */     if (args.hasAny()) {
/* 247 */       if (args.hasExactlyOne()) {
/* 248 */         return (new TabCompleteHelper())
/* 249 */           .append(Action.getAllNames())
/* 250 */           .sortAlphabetically()
/* 251 */           .filterPrefix(args.getString())
/* 252 */           .stream();
/*     */       }
/* 254 */       Action action = Action.getByName(args.getString());
/* 255 */       if (args.hasExactlyOne()) {
/* 256 */         if (action == Action.LIST || action == Action.SAVE || action == Action.CLEAR) {
/* 257 */           return (new TabCompleteHelper())
/* 258 */             .append(IWaypoint.Tag.getAllNames())
/* 259 */             .sortAlphabetically()
/* 260 */             .filterPrefix(args.getString())
/* 261 */             .stream();
/*     */         }
/* 263 */         return args.tabCompleteDatatype((IDatatype)ForWaypoints.INSTANCE);
/*     */       } 
/* 265 */       if (args.has(3) && action == Action.SAVE) {
/* 266 */         args.get();
/* 267 */         args.get();
/* 268 */         return args.tabCompleteDatatype((IDatatype)RelativeBlockPos.INSTANCE);
/*     */       } 
/*     */     } 
/*     */     
/* 272 */     return Stream.empty();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getShortDesc() {
/* 277 */     return "Manage waypoints";
/*     */   }
/*     */ 
/*     */   
/*     */   public List<String> getLongDesc() {
/* 282 */     return Arrays.asList(new String[] { "The waypoint command allows you to manage Baritone's waypoints.", "", "Waypoints can be used to mark positions for later. Waypoints are each given a tag and an optional name.", "", "Note that the info, delete, and goal commands let you specify a waypoint by tag. If there is more than one waypoint with a certain tag, then they will let you select which waypoint you mean.", "", "Usage:", "> wp [l/list] - List all waypoints.", "> wp <s/save> <tag> - Save your current position as an unnamed waypoint with the specified tag.", "> wp <s/save> <tag> <name> - Save the waypoint with the specified name.", "> wp <s/save> <tag> <name> <pos> - Save the waypoint with the specified name and position.", "> wp <i/info/show> <tag> - Show info on a waypoint by tag.", "> wp <d/delete> <tag> - Delete a waypoint by tag.", "> wp <g/goal> <tag> - Set a goal to a waypoint by tag.", "> wp <goto> <tag> - Set a goal to a waypoint by tag and start pathing." });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private enum Action
/*     */   {
/* 302 */     LIST((String)new String[] { "list", "get", "l" }),
/* 303 */     CLEAR((String)new String[] { "clear", "c" }),
/* 304 */     SAVE((String)new String[] { "save", "s" }),
/* 305 */     INFO((String)new String[] { "info", "show", "i" }),
/* 306 */     DELETE((String)new String[] { "delete", "d" }),
/* 307 */     GOAL((String)new String[] { "goal", "g" }),
/* 308 */     GOTO((String)new String[] { "goto" });
/*     */     private final String[] names;
/*     */     
/*     */     Action(String... names) {
/* 312 */       this.names = names;
/*     */     }
/*     */     
/*     */     public static Action getByName(String name) {
/* 316 */       for (Action action : values()) {
/* 317 */         for (String alias : action.names) {
/* 318 */           if (alias.equalsIgnoreCase(name)) {
/* 319 */             return action;
/*     */           }
/*     */         } 
/*     */       } 
/* 323 */       return null;
/*     */     }
/*     */     
/*     */     public static String[] getAllNames() {
/* 327 */       Set<String> names = new HashSet<>();
/* 328 */       for (Action action : values()) {
/* 329 */         names.addAll(Arrays.asList(action.names));
/*     */       }
/* 331 */       return names.<String>toArray(new String[0]);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\command\defaults\WaypointsCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */