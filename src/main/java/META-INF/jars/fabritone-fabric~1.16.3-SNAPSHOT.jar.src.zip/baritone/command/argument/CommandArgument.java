/*    */ package baritone.command.argument;
/*    */ 
/*    */ import baritone.api.command.argument.ICommandArgument;
/*    */ import baritone.api.command.exception.CommandInvalidTypeException;
/*    */ import baritone.command.argparser.ArgParserManager;
/*    */ import java.util.stream.Stream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CommandArgument
/*    */   implements ICommandArgument
/*    */ {
/*    */   private final int index;
/*    */   private final String value;
/*    */   private final String rawRest;
/*    */   
/*    */   CommandArgument(int index, String value, String rawRest) {
/* 38 */     this.index = index;
/* 39 */     this.value = value;
/* 40 */     this.rawRest = rawRest;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getIndex() {
/* 45 */     return this.index;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getValue() {
/* 50 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getRawRest() {
/* 55 */     return this.rawRest;
/*    */   }
/*    */ 
/*    */   
/*    */   public <E extends Enum<?>> E getEnum(Class<E> enumClass) throws CommandInvalidTypeException {
/* 60 */     return (E)Stream.of((Object[])enumClass.getEnumConstants())
/* 61 */       .filter(e -> e.name().equalsIgnoreCase(this.value))
/* 62 */       .findFirst()
/* 63 */       .orElseThrow(() -> new CommandInvalidTypeException(this, enumClass.getSimpleName()));
/*    */   }
/*    */ 
/*    */   
/*    */   public <T> T getAs(Class<T> type) throws CommandInvalidTypeException {
/* 68 */     return (T)ArgParserManager.INSTANCE.parseStateless(type, this);
/*    */   }
/*    */ 
/*    */   
/*    */   public <T> boolean is(Class<T> type) {
/*    */     try {
/* 74 */       getAs(type);
/* 75 */       return true;
/* 76 */     } catch (Throwable t) {
/* 77 */       return false;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public <T, S> T getAs(Class<T> type, Class<S> stateType, S state) throws CommandInvalidTypeException {
/* 84 */     return (T)ArgParserManager.INSTANCE.parseStated(type, stateType, this, state);
/*    */   }
/*    */ 
/*    */   
/*    */   public <T, S> boolean is(Class<T> type, Class<S> stateType, S state) {
/*    */     try {
/* 90 */       getAs(type, stateType, state);
/* 91 */       return true;
/* 92 */     } catch (Throwable t) {
/* 93 */       return false;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\command\argument\CommandArgument.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */