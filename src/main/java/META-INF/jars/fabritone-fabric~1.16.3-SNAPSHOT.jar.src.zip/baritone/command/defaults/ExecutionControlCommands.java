/*     */ package baritone.command.defaults;
/*     */ 
/*     */ import baritone.api.IBaritone;
/*     */ import baritone.api.command.Command;
/*     */ import baritone.api.command.argument.IArgConsumer;
/*     */ import baritone.api.command.exception.CommandException;
/*     */ import baritone.api.command.exception.CommandInvalidStateException;
/*     */ import baritone.api.process.IBaritoneProcess;
/*     */ import baritone.api.process.PathingCommand;
/*     */ import baritone.api.process.PathingCommandType;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.stream.Stream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExecutionControlCommands
/*     */ {
/*     */   Command pauseCommand;
/*     */   Command resumeCommand;
/*     */   Command pausedCommand;
/*     */   Command cancelCommand;
/*     */   
/*     */   public ExecutionControlCommands(IBaritone baritone) {
/*  49 */     final boolean[] paused = { false };
/*  50 */     baritone.getPathingControlManager().registerProcess(new IBaritoneProcess()
/*     */         {
/*     */           public boolean isActive()
/*     */           {
/*  54 */             return paused[0];
/*     */           }
/*     */ 
/*     */           
/*     */           public PathingCommand onTick(boolean calcFailed, boolean isSafeToCancel) {
/*  59 */             return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
/*     */           }
/*     */ 
/*     */           
/*     */           public boolean isTemporary() {
/*  64 */             return true;
/*     */           }
/*     */ 
/*     */ 
/*     */           
/*     */           public void onLostControl() {}
/*     */ 
/*     */           
/*     */           public double priority() {
/*  73 */             return 0.0D;
/*     */           }
/*     */ 
/*     */           
/*     */           public String displayName0() {
/*  78 */             return "Pause/Resume Commands";
/*     */           }
/*     */         });
/*     */     
/*  82 */     this.pauseCommand = new Command(baritone, new String[] { "pause", "p" })
/*     */       {
/*     */         public void execute(String label, IArgConsumer args) throws CommandException {
/*  85 */           args.requireMax(0);
/*  86 */           if (paused[0]) {
/*  87 */             throw new CommandInvalidStateException("Already paused");
/*     */           }
/*  89 */           paused[0] = true;
/*  90 */           logDirect("Paused");
/*     */         }
/*     */ 
/*     */         
/*     */         public Stream<String> tabComplete(String label, IArgConsumer args) {
/*  95 */           return Stream.empty();
/*     */         }
/*     */ 
/*     */         
/*     */         public String getShortDesc() {
/* 100 */           return "Pauses Baritone until you use resume";
/*     */         }
/*     */ 
/*     */         
/*     */         public List<String> getLongDesc() {
/* 105 */           return Arrays.asList(new String[] { "The pause command tells Baritone to temporarily stop whatever it's doing.", "", "This can be used to pause pathing, building, following, whatever. A single use of the resume command will start it right back up again!", "", "Usage:", "> pause" });
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 115 */     this.resumeCommand = new Command(baritone, new String[] { "resume", "r" })
/*     */       {
/*     */         public void execute(String label, IArgConsumer args) throws CommandException {
/* 118 */           args.requireMax(0);
/* 119 */           this.baritone.getBuilderProcess().resume();
/* 120 */           if (!paused[0]) {
/* 121 */             throw new CommandInvalidStateException("Not paused");
/*     */           }
/* 123 */           paused[0] = false;
/* 124 */           logDirect("Resumed");
/*     */         }
/*     */ 
/*     */         
/*     */         public Stream<String> tabComplete(String label, IArgConsumer args) {
/* 129 */           return Stream.empty();
/*     */         }
/*     */ 
/*     */         
/*     */         public String getShortDesc() {
/* 134 */           return "Resumes Baritone after a pause";
/*     */         }
/*     */ 
/*     */         
/*     */         public List<String> getLongDesc() {
/* 139 */           return Arrays.asList(new String[] { "The resume command tells Baritone to resume whatever it was doing when you last used pause.", "", "Usage:", "> resume" });
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 147 */     this.pausedCommand = new Command(baritone, new String[] { "paused" })
/*     */       {
/*     */         public void execute(String label, IArgConsumer args) throws CommandException {
/* 150 */           args.requireMax(0);
/* 151 */           logDirect(String.format("Baritone is %spaused", new Object[] { this.val$paused[0] ? "" : "not " }));
/*     */         }
/*     */ 
/*     */         
/*     */         public Stream<String> tabComplete(String label, IArgConsumer args) {
/* 156 */           return Stream.empty();
/*     */         }
/*     */ 
/*     */         
/*     */         public String getShortDesc() {
/* 161 */           return "Tells you if Baritone is paused";
/*     */         }
/*     */ 
/*     */         
/*     */         public List<String> getLongDesc() {
/* 166 */           return Arrays.asList(new String[] { "The paused command tells you if Baritone is currently paused by use of the pause command.", "", "Usage:", "> paused" });
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 174 */     this.cancelCommand = new Command(baritone, new String[] { "cancel", "c", "stop" })
/*     */       {
/*     */         public void execute(String label, IArgConsumer args) throws CommandException {
/* 177 */           args.requireMax(0);
/* 178 */           if (paused[0]) {
/* 179 */             paused[0] = false;
/*     */           }
/* 181 */           this.baritone.getPathingBehavior().cancelEverything();
/* 182 */           logDirect("ok canceled");
/*     */         }
/*     */ 
/*     */         
/*     */         public Stream<String> tabComplete(String label, IArgConsumer args) {
/* 187 */           return Stream.empty();
/*     */         }
/*     */ 
/*     */         
/*     */         public String getShortDesc() {
/* 192 */           return "Cancel what Baritone is currently doing";
/*     */         }
/*     */ 
/*     */         
/*     */         public List<String> getLongDesc() {
/* 197 */           return Arrays.asList(new String[] { "The cancel command tells Baritone to stop whatever it's currently doing.", "", "Usage:", "> cancel" });
/*     */         }
/*     */       };
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\command\defaults\ExecutionControlCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */