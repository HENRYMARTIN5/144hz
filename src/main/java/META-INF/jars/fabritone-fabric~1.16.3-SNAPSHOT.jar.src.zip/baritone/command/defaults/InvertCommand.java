/*    */ package baritone.command.defaults;
/*    */ 
/*    */ import baritone.api.IBaritone;
/*    */ import baritone.api.command.Command;
/*    */ import baritone.api.command.argument.IArgConsumer;
/*    */ import baritone.api.command.exception.CommandException;
/*    */ import baritone.api.command.exception.CommandInvalidStateException;
/*    */ import baritone.api.pathing.goals.Goal;
/*    */ import baritone.api.pathing.goals.GoalInverted;
/*    */ import baritone.api.process.ICustomGoalProcess;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import java.util.stream.Stream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvertCommand
/*    */   extends Command
/*    */ {
/*    */   public InvertCommand(IBaritone baritone) {
/* 36 */     super(baritone, new String[] { "invert" });
/*    */   }
/*    */   
/*    */   public void execute(String label, IArgConsumer args) throws CommandException {
/*    */     GoalInverted goalInverted;
/* 41 */     args.requireMax(0);
/* 42 */     ICustomGoalProcess customGoalProcess = this.baritone.getCustomGoalProcess();
/*    */     Goal goal;
/* 44 */     if ((goal = customGoalProcess.getGoal()) == null) {
/* 45 */       throw new CommandInvalidStateException("No goal");
/*    */     }
/* 47 */     if (goal instanceof GoalInverted) {
/* 48 */       goal = ((GoalInverted)goal).origin;
/*    */     } else {
/* 50 */       goalInverted = new GoalInverted(goal);
/*    */     } 
/* 52 */     customGoalProcess.setGoalAndPath((Goal)goalInverted);
/* 53 */     logDirect(String.format("Goal: %s", new Object[] { goalInverted.toString() }));
/*    */   }
/*    */ 
/*    */   
/*    */   public Stream<String> tabComplete(String label, IArgConsumer args) {
/* 58 */     return Stream.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShortDesc() {
/* 63 */     return "Run away from the current goal";
/*    */   }
/*    */ 
/*    */   
/*    */   public List<String> getLongDesc() {
/* 68 */     return Arrays.asList(new String[] { "The invert command tells Baritone to head away from the current goal rather than towards it.", "", "Usage:", "> invert - Invert the current goal." });
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\command\defaults\InvertCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */