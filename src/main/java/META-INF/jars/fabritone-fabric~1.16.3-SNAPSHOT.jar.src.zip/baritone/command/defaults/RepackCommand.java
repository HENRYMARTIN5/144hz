/*    */ package baritone.command.defaults;
/*    */ 
/*    */ import baritone.api.IBaritone;
/*    */ import baritone.api.command.Command;
/*    */ import baritone.api.command.argument.IArgConsumer;
/*    */ import baritone.api.command.exception.CommandException;
/*    */ import baritone.cache.WorldScanner;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import java.util.stream.Stream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RepackCommand
/*    */   extends Command
/*    */ {
/*    */   public RepackCommand(IBaritone baritone) {
/* 33 */     super(baritone, new String[] { "repack", "rescan" });
/*    */   }
/*    */ 
/*    */   
/*    */   public void execute(String label, IArgConsumer args) throws CommandException {
/* 38 */     args.requireMax(0);
/* 39 */     logDirect(String.format("Queued %d chunks for repacking", new Object[] { Integer.valueOf(WorldScanner.INSTANCE.repack(this.ctx)) }));
/*    */   }
/*    */ 
/*    */   
/*    */   public Stream<String> tabComplete(String label, IArgConsumer args) {
/* 44 */     return Stream.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShortDesc() {
/* 49 */     return "Re-cache chunks";
/*    */   }
/*    */ 
/*    */   
/*    */   public List<String> getLongDesc() {
/* 54 */     return Arrays.asList(new String[] { "Repack chunks around you. This basically re-caches them.", "", "Usage:", "> repack - Repack chunks." });
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\command\defaults\RepackCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */