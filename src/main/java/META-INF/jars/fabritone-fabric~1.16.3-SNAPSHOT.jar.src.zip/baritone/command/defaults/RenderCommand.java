/*    */ package baritone.command.defaults;
/*    */ 
/*    */ import baritone.api.IBaritone;
/*    */ import baritone.api.command.Command;
/*    */ import baritone.api.command.argument.IArgConsumer;
/*    */ import baritone.api.command.exception.CommandException;
/*    */ import baritone.api.utils.BetterBlockPos;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import java.util.stream.Stream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RenderCommand
/*    */   extends Command
/*    */ {
/*    */   public RenderCommand(IBaritone baritone) {
/* 33 */     super(baritone, new String[] { "render" });
/*    */   }
/*    */ 
/*    */   
/*    */   public void execute(String label, IArgConsumer args) throws CommandException {
/* 38 */     args.requireMax(0);
/* 39 */     BetterBlockPos origin = this.ctx.playerFeet();
/* 40 */     int renderDistance = (mc.field_1690.field_1870 + 1) * 16;
/* 41 */     mc.field_1769.method_18146(origin.x - renderDistance, 0, origin.z - renderDistance, origin.x + renderDistance, 255, origin.z + renderDistance);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 49 */     logDirect("Done");
/*    */   }
/*    */ 
/*    */   
/*    */   public Stream<String> tabComplete(String label, IArgConsumer args) {
/* 54 */     return Stream.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShortDesc() {
/* 59 */     return "Fix glitched chunks";
/*    */   }
/*    */ 
/*    */   
/*    */   public List<String> getLongDesc() {
/* 64 */     return Arrays.asList(new String[] { "The render command fixes glitched chunk rendering without having to reload all of them.", "", "Usage:", "> render" });
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\command\defaults\RenderCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */