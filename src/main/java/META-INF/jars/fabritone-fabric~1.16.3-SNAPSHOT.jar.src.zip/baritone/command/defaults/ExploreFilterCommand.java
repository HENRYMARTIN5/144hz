/*    */ package baritone.command.defaults;
/*    */ 
/*    */ import baritone.api.IBaritone;
/*    */ import baritone.api.command.Command;
/*    */ import baritone.api.command.argument.IArgConsumer;
/*    */ import baritone.api.command.datatypes.IDatatypePost;
/*    */ import baritone.api.command.datatypes.RelativeFile;
/*    */ import baritone.api.command.exception.CommandException;
/*    */ import baritone.api.command.exception.CommandInvalidStateException;
/*    */ import baritone.api.command.exception.CommandInvalidTypeException;
/*    */ import com.google.gson.JsonSyntaxException;
/*    */ import java.io.File;
/*    */ import java.nio.file.NoSuchFileException;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import java.util.stream.Stream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExploreFilterCommand
/*    */   extends Command
/*    */ {
/*    */   public ExploreFilterCommand(IBaritone baritone) {
/* 38 */     super(baritone, new String[] { "explorefilter" });
/*    */   }
/*    */ 
/*    */   
/*    */   public void execute(String label, IArgConsumer args) throws CommandException {
/* 43 */     args.requireMax(2);
/* 44 */     File file = (File)args.getDatatypePost((IDatatypePost)RelativeFile.INSTANCE, mc.field_1697.getAbsoluteFile().getParentFile());
/* 45 */     boolean invert = false;
/* 46 */     if (args.hasAny()) {
/* 47 */       if (args.getString().equalsIgnoreCase("invert")) {
/* 48 */         invert = true;
/*    */       } else {
/* 50 */         throw new CommandInvalidTypeException(args.consumed(), "either \"invert\" or nothing");
/*    */       } 
/*    */     }
/*    */     try {
/* 54 */       this.baritone.getExploreProcess().applyJsonFilter(file.toPath().toAbsolutePath(), invert);
/* 55 */     } catch (NoSuchFileException e) {
/* 56 */       throw new CommandInvalidStateException("File not found");
/* 57 */     } catch (JsonSyntaxException e) {
/* 58 */       throw new CommandInvalidStateException("Invalid JSON syntax");
/* 59 */     } catch (Exception e) {
/* 60 */       throw new IllegalStateException(e);
/*    */     } 
/* 62 */     logDirect(String.format("Explore filter applied. Inverted: %s", new Object[] { Boolean.toString(invert) }));
/*    */   }
/*    */ 
/*    */   
/*    */   public Stream<String> tabComplete(String label, IArgConsumer args) throws CommandException {
/* 67 */     if (args.hasExactlyOne()) {
/* 68 */       return RelativeFile.tabComplete(args, RelativeFile.gameDir());
/*    */     }
/* 70 */     return Stream.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShortDesc() {
/* 75 */     return "Explore chunks from a json";
/*    */   }
/*    */ 
/*    */   
/*    */   public List<String> getLongDesc() {
/* 80 */     return Arrays.asList(new String[] { "Apply an explore filter before using explore, which tells the explore process which chunks have been explored/not explored.", "", "The JSON file will follow this format: [{\"x\":0,\"z\":0},...]", "", "If 'invert' is specified, the chunks listed will be considered NOT explored, rather than explored.", "", "Usage:", "> explorefilter <path> [invert] - Load the JSON file referenced by the specified path. If invert is specified, it must be the literal word 'invert'." });
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\command\defaults\ExploreFilterCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */