/*    */ package baritone.command.defaults;
/*    */ 
/*    */ import baritone.api.IBaritone;
/*    */ import baritone.api.command.Command;
/*    */ import baritone.api.command.argument.IArgConsumer;
/*    */ import baritone.api.command.datatypes.IDatatypePost;
/*    */ import baritone.api.command.datatypes.RelativeCoordinate;
/*    */ import baritone.api.command.datatypes.RelativeGoal;
/*    */ import baritone.api.command.exception.CommandException;
/*    */ import baritone.api.command.helpers.TabCompleteHelper;
/*    */ import baritone.api.pathing.goals.Goal;
/*    */ import baritone.api.process.ICustomGoalProcess;
/*    */ import baritone.api.utils.BetterBlockPos;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import java.util.stream.Stream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GoalCommand
/*    */   extends Command
/*    */ {
/*    */   public GoalCommand(IBaritone baritone) {
/* 38 */     super(baritone, new String[] { "goal" });
/*    */   }
/*    */ 
/*    */   
/*    */   public void execute(String label, IArgConsumer args) throws CommandException {
/* 43 */     ICustomGoalProcess goalProcess = this.baritone.getCustomGoalProcess();
/* 44 */     if (args.hasAny() && Arrays.<String>asList(new String[] { "reset", "clear", "none" }).contains(args.peekString())) {
/* 45 */       args.requireMax(1);
/* 46 */       if (goalProcess.getGoal() != null) {
/* 47 */         goalProcess.setGoal(null);
/* 48 */         logDirect("Cleared goal");
/*    */       } else {
/* 50 */         logDirect("There was no goal to clear");
/*    */       } 
/*    */     } else {
/* 53 */       args.requireMax(3);
/* 54 */       BetterBlockPos origin = this.baritone.getPlayerContext().playerFeet();
/* 55 */       Goal goal = (Goal)args.getDatatypePost((IDatatypePost)RelativeGoal.INSTANCE, origin);
/* 56 */       goalProcess.setGoal(goal);
/* 57 */       logDirect(String.format("Goal: %s", new Object[] { goal.toString() }));
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public Stream<String> tabComplete(String label, IArgConsumer args) throws CommandException {
/* 63 */     TabCompleteHelper helper = new TabCompleteHelper();
/* 64 */     if (args.hasExactlyOne()) {
/* 65 */       helper.append(new String[] { "reset", "clear", "none", "~" });
/*    */     }
/* 67 */     else if (args.hasAtMost(3)) {
/* 68 */       while (args.has(2) && 
/* 69 */         args.peekDatatypeOrNull((IDatatypePost)RelativeCoordinate.INSTANCE) != null) {
/*    */ 
/*    */         
/* 72 */         args.get();
/* 73 */         if (!args.has(2)) {
/* 74 */           helper.append(new String[] { "~" });
/*    */         }
/*    */       } 
/*    */     } 
/*    */     
/* 79 */     return helper.filterPrefix(args.getString()).stream();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShortDesc() {
/* 84 */     return "Set or clear the goal";
/*    */   }
/*    */ 
/*    */   
/*    */   public List<String> getLongDesc() {
/* 89 */     return Arrays.asList(new String[] { "The goal command allows you to set or clear Baritone's goal.", "", "Wherever a coordinate is expected, you can use ~ just like in regular Minecraft commands. Or, you can just use regular numbers.", "", "Usage:", "> goal - Set the goal to your current position", "> goal <reset/clear/none> - Erase the goal", "> goal <y> - Set the goal to a Y level", "> goal <x> <z> - Set the goal to an X,Z position", "> goal <x> <y> <z> - Set the goal to an X,Y,Z position" });
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\command\defaults\GoalCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */