/*    */ package baritone.command.defaults;
/*    */ 
/*    */ import baritone.api.IBaritone;
/*    */ import baritone.api.command.Command;
/*    */ import baritone.api.command.ICommand;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DefaultCommands
/*    */ {
/*    */   public static List<ICommand> createAll(IBaritone baritone) {
/* 31 */     Objects.requireNonNull(baritone);
/* 32 */     List<ICommand> commands = new ArrayList<>((Collection)Arrays.asList((Object[])new Command[] { new HelpCommand(baritone), new SetCommand(baritone), new CommandAlias(baritone, 
/*    */ 
/*    */               
/* 35 */               Arrays.asList(new String[] { "modified", "mod", "baritone", "modifiedsettings" }, ), "List modified settings", "set modified"), new CommandAlias(baritone, "reset", "Reset all settings or just one", "set reset"), new GoalCommand(baritone), new GotoCommand(baritone), new PathCommand(baritone), new ProcCommand(baritone), new VersionCommand(baritone), new RepackCommand(baritone), new BuildCommand(baritone), new SchematicaCommand(baritone), new ComeCommand(baritone), new AxisCommand(baritone), new ForceCancelCommand(baritone), new GcCommand(baritone), new InvertCommand(baritone), new TunnelCommand(baritone), new RenderCommand(baritone), new FarmCommand(baritone), new ChestsCommand(baritone), new FollowCommand(baritone), new ExploreFilterCommand(baritone), new ReloadAllCommand(baritone), new SaveAllCommand(baritone), new ExploreCommand(baritone), new BlacklistCommand(baritone), new FindCommand(baritone), new MineCommand(baritone), new ClickCommand(baritone), new SurfaceCommand(baritone), new ThisWayCommand(baritone), new WaypointsCommand(baritone), new CommandAlias(baritone, "sethome", "Sets your home waypoint", "waypoints save home"), new CommandAlias(baritone, "home", "Path to your home waypoint", "waypoints goto home"), new SelCommand(baritone) }));
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 70 */     ExecutionControlCommands prc = new ExecutionControlCommands(baritone);
/* 71 */     commands.add(prc.pauseCommand);
/* 72 */     commands.add(prc.resumeCommand);
/* 73 */     commands.add(prc.pausedCommand);
/* 74 */     commands.add(prc.cancelCommand);
/* 75 */     return Collections.unmodifiableList(commands);
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\command\defaults\DefaultCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */