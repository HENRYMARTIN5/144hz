/*    */ package baritone.command.defaults;
/*    */ 
/*    */ import baritone.api.IBaritone;
/*    */ import baritone.api.command.Command;
/*    */ import baritone.api.command.argument.IArgConsumer;
/*    */ import baritone.api.command.exception.CommandException;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import java.util.stream.Stream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SaveAllCommand
/*    */   extends Command
/*    */ {
/*    */   public SaveAllCommand(IBaritone baritone) {
/* 32 */     super(baritone, new String[] { "saveall" });
/*    */   }
/*    */ 
/*    */   
/*    */   public void execute(String label, IArgConsumer args) throws CommandException {
/* 37 */     args.requireMax(0);
/* 38 */     this.ctx.worldData().getCachedWorld().save();
/* 39 */     logDirect("Saved");
/*    */   }
/*    */ 
/*    */   
/*    */   public Stream<String> tabComplete(String label, IArgConsumer args) {
/* 44 */     return Stream.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShortDesc() {
/* 49 */     return "Saves Baritone's cache for this world";
/*    */   }
/*    */ 
/*    */   
/*    */   public List<String> getLongDesc() {
/* 54 */     return Arrays.asList(new String[] { "The saveall command saves Baritone's world cache.", "", "Usage:", "> saveall" });
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\command\defaults\SaveAllCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */