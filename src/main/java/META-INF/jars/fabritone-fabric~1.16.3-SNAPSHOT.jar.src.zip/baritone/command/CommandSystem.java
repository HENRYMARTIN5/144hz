/*    */ package baritone.command;
/*    */ 
/*    */ import baritone.api.command.ICommandSystem;
/*    */ import baritone.api.command.argparser.IArgParserManager;
/*    */ import baritone.command.argparser.ArgParserManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum CommandSystem
/*    */   implements ICommandSystem
/*    */ {
/* 29 */   INSTANCE;
/*    */ 
/*    */   
/*    */   public IArgParserManager getParserManager() {
/* 33 */     return (IArgParserManager)ArgParserManager.INSTANCE;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\command\CommandSystem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */