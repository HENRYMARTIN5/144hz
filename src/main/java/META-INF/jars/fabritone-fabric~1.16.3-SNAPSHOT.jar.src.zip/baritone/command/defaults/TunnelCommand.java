/*     */ package baritone.command.defaults;
/*     */ 
/*     */ import baritone.api.IBaritone;
/*     */ import baritone.api.command.Command;
/*     */ import baritone.api.command.argument.IArgConsumer;
/*     */ import baritone.api.command.argument.ICommandArgument;
/*     */ import baritone.api.command.exception.CommandException;
/*     */ import baritone.api.pathing.goals.Goal;
/*     */ import baritone.api.pathing.goals.GoalStrictDirection;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.stream.Stream;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2350;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TunnelCommand
/*     */   extends Command
/*     */ {
/*     */   public TunnelCommand(IBaritone baritone) {
/*  36 */     super(baritone, new String[] { "tunnel" });
/*     */   }
/*     */ 
/*     */   
/*     */   public void execute(String label, IArgConsumer args) throws CommandException {
/*  41 */     args.requireMax(3);
/*  42 */     if (args.hasExactly(3)) {
/*  43 */       boolean cont = true;
/*  44 */       int height = Integer.parseInt(((ICommandArgument)args.getArgs().get(0)).getValue());
/*  45 */       int width = Integer.parseInt(((ICommandArgument)args.getArgs().get(1)).getValue());
/*  46 */       int depth = Integer.parseInt(((ICommandArgument)args.getArgs().get(2)).getValue());
/*     */       
/*  48 */       if (width < 1 || height < 2 || depth < 1 || height > 255) {
/*  49 */         logDirect("Width and depth must at least be 1 block; Height must at least be 2 blocks, and cannot be greater than the build limit.");
/*  50 */         cont = false;
/*     */       } 
/*     */       
/*  53 */       if (cont) {
/*  54 */         class_2338 corner1, corner2; height--;
/*  55 */         width--;
/*     */ 
/*     */         
/*  58 */         class_2350 enumFacing = this.ctx.player().method_5735();
/*  59 */         int addition = (width % 2 == 0) ? 0 : 1;
/*  60 */         switch (enumFacing) {
/*     */           case field_11034:
/*  62 */             corner1 = new class_2338((this.ctx.playerFeet()).x, (this.ctx.playerFeet()).y, (this.ctx.playerFeet()).z - width / 2);
/*  63 */             corner2 = new class_2338((this.ctx.playerFeet()).x + depth, (this.ctx.playerFeet()).y + height, (this.ctx.playerFeet()).z + width / 2 + addition);
/*     */             break;
/*     */           case field_11039:
/*  66 */             corner1 = new class_2338((this.ctx.playerFeet()).x, (this.ctx.playerFeet()).y, (this.ctx.playerFeet()).z + width / 2 + addition);
/*  67 */             corner2 = new class_2338((this.ctx.playerFeet()).x - depth, (this.ctx.playerFeet()).y + height, (this.ctx.playerFeet()).z - width / 2);
/*     */             break;
/*     */           case field_11043:
/*  70 */             corner1 = new class_2338((this.ctx.playerFeet()).x - width / 2, (this.ctx.playerFeet()).y, (this.ctx.playerFeet()).z);
/*  71 */             corner2 = new class_2338((this.ctx.playerFeet()).x + width / 2 + addition, (this.ctx.playerFeet()).y + height, (this.ctx.playerFeet()).z - depth);
/*     */             break;
/*     */           case field_11035:
/*  74 */             corner1 = new class_2338((this.ctx.playerFeet()).x + width / 2 + addition, (this.ctx.playerFeet()).y, (this.ctx.playerFeet()).z);
/*  75 */             corner2 = new class_2338((this.ctx.playerFeet()).x - width / 2, (this.ctx.playerFeet()).y + height, (this.ctx.playerFeet()).z + depth);
/*     */             break;
/*     */           default:
/*  78 */             throw new IllegalStateException("Unexpected value: " + enumFacing);
/*     */         } 
/*  80 */         logDirect(String.format("Creating a tunnel %s block(s) high, %s block(s) wide, and %s block(s) deep", new Object[] { Integer.valueOf(height + 1), Integer.valueOf(width + 1), Integer.valueOf(depth) }));
/*  81 */         this.baritone.getBuilderProcess().clearArea(corner1, corner2);
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/*  86 */       GoalStrictDirection goalStrictDirection = new GoalStrictDirection((class_2338)this.ctx.playerFeet(), this.ctx.player().method_5735());
/*     */       
/*  88 */       this.baritone.getCustomGoalProcess().setGoalAndPath((Goal)goalStrictDirection);
/*  89 */       logDirect(String.format("Goal: %s", new Object[] { goalStrictDirection.toString() }));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Stream<String> tabComplete(String label, IArgConsumer args) {
/*  95 */     return Stream.empty();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getShortDesc() {
/* 100 */     return "Set a goal to tunnel in your current direction";
/*     */   }
/*     */ 
/*     */   
/*     */   public List<String> getLongDesc() {
/* 105 */     return Arrays.asList(new String[] { "The tunnel command sets a goal that tells Baritone to mine completely straight in the direction that you're facing.", "", "Usage:", "> tunnel - No arguments, mines in a 1x2 radius.", "> tunnel <height> <width> <depth> - Tunnels in a user defined height, width and depth." });
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\command\defaults\TunnelCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */