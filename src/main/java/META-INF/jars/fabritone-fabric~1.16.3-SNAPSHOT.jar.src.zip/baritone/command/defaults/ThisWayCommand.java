/*    */ package baritone.command.defaults;
/*    */ 
/*    */ import baritone.api.IBaritone;
/*    */ import baritone.api.command.Command;
/*    */ import baritone.api.command.argument.IArgConsumer;
/*    */ import baritone.api.command.exception.CommandException;
/*    */ import baritone.api.pathing.goals.Goal;
/*    */ import baritone.api.pathing.goals.GoalXZ;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import java.util.stream.Stream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ThisWayCommand
/*    */   extends Command
/*    */ {
/*    */   public ThisWayCommand(IBaritone baritone) {
/* 33 */     super(baritone, new String[] { "thisway", "forward" });
/*    */   }
/*    */ 
/*    */   
/*    */   public void execute(String label, IArgConsumer args) throws CommandException {
/* 38 */     args.requireExactly(1);
/* 39 */     GoalXZ goal = GoalXZ.fromDirection(this.ctx
/* 40 */         .playerFeetAsVec(), 
/* 41 */         (this.ctx.player()).field_6241, ((Double)args
/* 42 */         .getAs(Double.class)).doubleValue());
/*    */     
/* 44 */     this.baritone.getCustomGoalProcess().setGoal((Goal)goal);
/* 45 */     logDirect(String.format("Goal: %s", new Object[] { goal }));
/*    */   }
/*    */ 
/*    */   
/*    */   public Stream<String> tabComplete(String label, IArgConsumer args) {
/* 50 */     return Stream.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShortDesc() {
/* 55 */     return "Travel in your current direction";
/*    */   }
/*    */ 
/*    */   
/*    */   public List<String> getLongDesc() {
/* 60 */     return Arrays.asList(new String[] { "Creates a GoalXZ some amount of blocks in the direction you're currently looking", "", "Usage:", "> thisway <distance> - makes a GoalXZ distance blocks in front of you" });
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\command\defaults\ThisWayCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */