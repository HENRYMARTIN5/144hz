/*     */ package baritone.command.defaults;
/*     */ 
/*     */ import baritone.Baritone;
/*     */ import baritone.api.IBaritone;
/*     */ import baritone.api.Settings;
/*     */ import baritone.api.command.Command;
/*     */ import baritone.api.command.IBaritoneChatControl;
/*     */ import baritone.api.command.argument.IArgConsumer;
/*     */ import baritone.api.command.exception.CommandException;
/*     */ import baritone.api.command.exception.CommandInvalidTypeException;
/*     */ import baritone.api.command.helpers.Paginator;
/*     */ import baritone.api.command.helpers.TabCompleteHelper;
/*     */ import baritone.api.utils.SettingsUtil;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ import net.minecraft.class_124;
/*     */ import net.minecraft.class_2558;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_2568;
/*     */ import net.minecraft.class_2585;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SetCommand
/*     */   extends Command
/*     */ {
/*     */   public SetCommand(IBaritone baritone) {
/*  49 */     super(baritone, new String[] { "set", "setting", "settings" });
/*     */   }
/*     */ 
/*     */   
/*     */   public void execute(String label, IArgConsumer args) throws CommandException {
/*  54 */     String arg = args.hasAny() ? args.getString().toLowerCase(Locale.US) : "list";
/*  55 */     if (Arrays.<String>asList(new String[] { "s", "save" }).contains(arg)) {
/*  56 */       SettingsUtil.save(Baritone.settings());
/*  57 */       logDirect("Settings saved");
/*     */       return;
/*     */     } 
/*  60 */     boolean viewModified = Arrays.<String>asList(new String[] { "m", "mod", "modified" }).contains(arg);
/*  61 */     boolean viewAll = Arrays.<String>asList(new String[] { "all", "l", "list" }).contains(arg);
/*  62 */     boolean paginate = (viewModified || viewAll);
/*  63 */     if (paginate) {
/*  64 */       String search = (args.hasAny() && args.peekAsOrNull(Integer.class) == null) ? args.getString() : "";
/*  65 */       args.requireMax(1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  71 */       List<? extends Settings.Setting> toPaginate = (List<? extends Settings.Setting>)(viewModified ? SettingsUtil.modifiedSettings(Baritone.settings()) : (Baritone.settings()).allSettings).stream().filter(s -> !s.getName().equals("logger")).filter(s -> s.getName().toLowerCase(Locale.US).contains(search.toLowerCase(Locale.US))).sorted((s1, s2) -> String.CASE_INSENSITIVE_ORDER.compare(s1.getName(), s2.getName())).collect(Collectors.toList());
/*  72 */       Paginator.paginate(args, new Paginator(toPaginate), () -> logDirect(!search.isEmpty() ? String.format("All %ssettings containing the string '%s':", new Object[] { viewModified ? "modified " : "", search }) : String.format("All %ssettings:", new Object[] { viewModified ? "modified " : "" })), setting -> { class_2585 class_25851 = new class_2585(String.format(" (%s)", new Object[] { SettingsUtil.settingTypeToString(setting) })); class_25851.method_10862(class_25851.method_10866().method_27706(class_124.field_1063)); class_2585 class_25852 = new class_2585(""); class_25852.method_10862(class_25852.method_10866().method_27706(class_124.field_1080)); class_25852.method_27693(setting.getName()); class_25852.method_27693(String.format("\nType: %s", new Object[] { SettingsUtil.settingTypeToString(setting) })); class_25852.method_27693(String.format("\n\nValue:\n%s", new Object[] { SettingsUtil.settingValueToString(setting) })); String commandSuggestion = (String)(Baritone.settings()).prefix.value + String.format("set %s ", new Object[] { setting.getName() }); class_2585 class_25853 = new class_2585(setting.getName()); class_25853.method_10862(class_25853.method_10866().method_27706(class_124.field_1080)); class_25853.method_10852((class_2561)class_25851); class_25853.method_10862(class_25853.method_10866().method_10949(new class_2568(class_2568.class_5247.field_24342, class_25852)).method_10958(new class_2558(class_2558.class_2559.field_11745, commandSuggestion))); return (class_2561)class_25853; }IBaritoneChatControl.FORCE_COMMAND_PREFIX + "set " + arg + " " + search);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 104 */     args.requireMax(1);
/* 105 */     boolean resetting = arg.equalsIgnoreCase("reset");
/* 106 */     boolean toggling = arg.equalsIgnoreCase("toggle");
/* 107 */     boolean doingSomething = (resetting || toggling);
/* 108 */     if (resetting) {
/* 109 */       if (!args.hasAny()) {
/* 110 */         logDirect("Please specify 'all' as an argument to reset to confirm you'd really like to do this");
/* 111 */         logDirect("ALL settings will be reset. Use the 'set modified' or 'modified' commands to see what will be reset.");
/* 112 */         logDirect("Specify a setting name instead of 'all' to only reset one setting");
/* 113 */       } else if (args.peekString().equalsIgnoreCase("all")) {
/* 114 */         SettingsUtil.modifiedSettings(Baritone.settings()).forEach(Settings.Setting::reset);
/* 115 */         logDirect("All settings have been reset to their default values");
/* 116 */         SettingsUtil.save(Baritone.settings());
/*     */         return;
/*     */       } 
/*     */     }
/* 120 */     if (toggling) {
/* 121 */       args.requireMin(1);
/*     */     }
/* 123 */     String settingName = doingSomething ? args.getString() : arg;
/*     */ 
/*     */ 
/*     */     
/* 127 */     Settings.Setting<?> setting = (Baritone.settings()).allSettings.stream().filter(s -> s.getName().equalsIgnoreCase(settingName)).findFirst().orElse(null);
/* 128 */     if (setting == null) {
/* 129 */       throw new CommandInvalidTypeException(args.consumed(), "a valid setting");
/*     */     }
/* 131 */     if (!doingSomething && !args.hasAny()) {
/* 132 */       logDirect(String.format("Value of setting %s:", new Object[] { setting.getName() }));
/* 133 */       logDirect(SettingsUtil.settingValueToString(setting));
/*     */     } else {
/* 135 */       String oldValue = SettingsUtil.settingValueToString(setting);
/* 136 */       if (resetting) {
/* 137 */         setting.reset();
/* 138 */       } else if (toggling) {
/* 139 */         if (setting.getValueClass() != Boolean.class) {
/* 140 */           throw new CommandInvalidTypeException(args.consumed(), "a toggleable setting", "some other setting");
/*     */         }
/*     */         
/* 143 */         Settings.Setting<?> setting1 = setting; setting1.value = Boolean.valueOf(((Boolean)setting1.value).booleanValue() ^ true);
/* 144 */         logDirect(String.format("Toggled setting %s to %s", new Object[] { setting
/*     */                 
/* 146 */                 .getName(), 
/* 147 */                 Boolean.toString(((Boolean)setting.value).booleanValue()) }));
/*     */       } else {
/*     */         
/* 150 */         String newValue = args.getString();
/*     */         try {
/* 152 */           SettingsUtil.parseAndApply(Baritone.settings(), arg, newValue);
/* 153 */         } catch (Throwable t) {
/* 154 */           t.printStackTrace();
/* 155 */           throw new CommandInvalidTypeException(args.consumed(), "a valid value", t);
/*     */         } 
/*     */       } 
/* 158 */       if (!toggling) {
/* 159 */         logDirect(String.format("Successfully %s %s to %s", new Object[] { resetting ? "reset" : "set", setting
/*     */ 
/*     */                 
/* 162 */                 .getName(), 
/* 163 */                 SettingsUtil.settingValueToString(setting) }));
/*     */       }
/*     */       
/* 166 */       class_2585 class_2585 = new class_2585(String.format("Old value: %s", new Object[] { oldValue }));
/* 167 */       class_2585.method_10862(class_2585.method_10866()
/* 168 */           .method_27706(class_124.field_1080)
/* 169 */           .method_10949(new class_2568(class_2568.class_5247.field_24342, new class_2585("Click to set the setting back to this value")))
/*     */ 
/*     */ 
/*     */           
/* 173 */           .method_10958(new class_2558(class_2558.class_2559.field_11750, IBaritoneChatControl.FORCE_COMMAND_PREFIX + 
/*     */               
/* 175 */               String.format("set %s %s", new Object[] { setting.getName(), oldValue }))));
/*     */       
/* 177 */       logDirect(new class_2561[] { (class_2561)class_2585 });
/* 178 */       if ((setting.getName().equals("chatControl") && !((Boolean)setting.value).booleanValue() && !((Boolean)(Baritone.settings()).chatControlAnyway.value).booleanValue()) || (setting
/* 179 */         .getName().equals("chatControlAnyway") && !((Boolean)setting.value).booleanValue() && !((Boolean)(Baritone.settings()).chatControl.value).booleanValue())) {
/* 180 */         logDirect("Warning: Chat commands will no longer work. If you want to revert this change, use prefix control (if enabled) or click the old value listed above.", class_124.field_1061);
/* 181 */       } else if (setting.getName().equals("prefixControl") && !((Boolean)setting.value).booleanValue()) {
/* 182 */         logDirect("Warning: Prefixed commands will no longer work. If you want to revert this change, use chat control (if enabled) or click the old value listed above.", class_124.field_1061);
/*     */       } 
/*     */     } 
/* 185 */     SettingsUtil.save(Baritone.settings());
/*     */   }
/*     */ 
/*     */   
/*     */   public Stream<String> tabComplete(String label, IArgConsumer args) throws CommandException {
/* 190 */     if (args.hasAny()) {
/* 191 */       String arg = args.getString();
/* 192 */       if (args.hasExactlyOne() && !Arrays.<String>asList(new String[] { "s", "save" }).contains(args.peekString().toLowerCase(Locale.US))) {
/* 193 */         if (arg.equalsIgnoreCase("reset"))
/* 194 */           return (new TabCompleteHelper())
/* 195 */             .addModifiedSettings()
/* 196 */             .prepend(new String[] { "all"
/* 197 */               }).filterPrefix(args.getString())
/* 198 */             .stream(); 
/* 199 */         if (arg.equalsIgnoreCase("toggle")) {
/* 200 */           return (new TabCompleteHelper())
/* 201 */             .addToggleableSettings()
/* 202 */             .filterPrefix(args.getString())
/* 203 */             .stream();
/*     */         }
/* 205 */         Settings.Setting setting = (Settings.Setting)(Baritone.settings()).byLowerName.get(arg.toLowerCase(Locale.US));
/* 206 */         if (setting != null) {
/* 207 */           if (setting.getType() == Boolean.class) {
/* 208 */             TabCompleteHelper helper = new TabCompleteHelper();
/* 209 */             if (((Boolean)setting.value).booleanValue()) {
/* 210 */               helper.append(new String[] { "true", "false" });
/*     */             } else {
/* 212 */               helper.append(new String[] { "false", "true" });
/*     */             } 
/* 214 */             return helper.filterPrefix(args.getString()).stream();
/*     */           } 
/* 216 */           return Stream.of(SettingsUtil.settingValueToString(setting));
/*     */         }
/*     */       
/* 219 */       } else if (!args.hasAny()) {
/* 220 */         return (new TabCompleteHelper())
/* 221 */           .addSettings()
/* 222 */           .sortAlphabetically()
/* 223 */           .prepend(new String[] { "list", "modified", "reset", "toggle", "save"
/* 224 */             }).filterPrefix(arg)
/* 225 */           .stream();
/*     */       } 
/*     */     } 
/* 228 */     return Stream.empty();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getShortDesc() {
/* 233 */     return "View or change settings";
/*     */   }
/*     */ 
/*     */   
/*     */   public List<String> getLongDesc() {
/* 238 */     return Arrays.asList(new String[] { "Using the set command, you can manage all of Baritone's settings. Almost every aspect is controlled by these settings - go wild!", "", "Usage:", "> set - Same as `set list`", "> set list [page] - View all settings", "> set modified [page] - View modified settings", "> set <setting> - View the current value of a setting", "> set <setting> <value> - Set the value of a setting", "> set reset all - Reset ALL SETTINGS to their defaults", "> set reset <setting> - Reset a setting to its default", "> set toggle <setting> - Toggle a boolean setting", "> set save - Save all settings (this is automatic tho)" });
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\command\defaults\SetCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */