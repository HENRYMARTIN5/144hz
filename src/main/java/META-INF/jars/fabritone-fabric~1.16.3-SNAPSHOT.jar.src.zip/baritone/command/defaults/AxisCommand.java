/*    */ package baritone.command.defaults;
/*    */ 
/*    */ import baritone.api.IBaritone;
/*    */ import baritone.api.command.Command;
/*    */ import baritone.api.command.argument.IArgConsumer;
/*    */ import baritone.api.command.exception.CommandException;
/*    */ import baritone.api.pathing.goals.Goal;
/*    */ import baritone.api.pathing.goals.GoalAxis;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import java.util.stream.Stream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AxisCommand
/*    */   extends Command
/*    */ {
/*    */   public AxisCommand(IBaritone baritone) {
/* 34 */     super(baritone, new String[] { "axis", "highway" });
/*    */   }
/*    */ 
/*    */   
/*    */   public void execute(String label, IArgConsumer args) throws CommandException {
/* 39 */     args.requireMax(0);
/* 40 */     GoalAxis goalAxis = new GoalAxis();
/* 41 */     this.baritone.getCustomGoalProcess().setGoal((Goal)goalAxis);
/* 42 */     logDirect(String.format("Goal: %s", new Object[] { goalAxis.toString() }));
/*    */   }
/*    */ 
/*    */   
/*    */   public Stream<String> tabComplete(String label, IArgConsumer args) {
/* 47 */     return Stream.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShortDesc() {
/* 52 */     return "Set a goal to the axes";
/*    */   }
/*    */ 
/*    */   
/*    */   public List<String> getLongDesc() {
/* 57 */     return Arrays.asList(new String[] { "The axis command sets a goal that tells Baritone to head towards the nearest axis. That is, X=0 or Z=0.", "", "Usage:", "> axis" });
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\command\defaults\AxisCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */