/*    */ package baritone.command.defaults;
/*    */ 
/*    */ import baritone.api.IBaritone;
/*    */ import baritone.api.command.Command;
/*    */ import baritone.api.command.argument.IArgConsumer;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.stream.Stream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CommandAlias
/*    */   extends Command
/*    */ {
/*    */   private final String shortDesc;
/*    */   public final String target;
/*    */   
/*    */   public CommandAlias(IBaritone baritone, List<String> names, String shortDesc, String target) {
/* 34 */     super(baritone, names.<String>toArray(new String[0]));
/* 35 */     this.shortDesc = shortDesc;
/* 36 */     this.target = target;
/*    */   }
/*    */   
/*    */   public CommandAlias(IBaritone baritone, String name, String shortDesc, String target) {
/* 40 */     super(baritone, new String[] { name });
/* 41 */     this.shortDesc = shortDesc;
/* 42 */     this.target = target;
/*    */   }
/*    */ 
/*    */   
/*    */   public void execute(String label, IArgConsumer args) {
/* 47 */     this.baritone.getCommandManager().execute(String.format("%s %s", new Object[] { this.target, args.rawRest() }));
/*    */   }
/*    */ 
/*    */   
/*    */   public Stream<String> tabComplete(String label, IArgConsumer args) {
/* 52 */     return this.baritone.getCommandManager().tabComplete(String.format("%s %s", new Object[] { this.target, args.rawRest() }));
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShortDesc() {
/* 57 */     return this.shortDesc;
/*    */   }
/*    */ 
/*    */   
/*    */   public List<String> getLongDesc() {
/* 62 */     return Collections.singletonList(String.format("This command is an alias, for: %s ...", new Object[] { this.target }));
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\command\defaults\CommandAlias.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */