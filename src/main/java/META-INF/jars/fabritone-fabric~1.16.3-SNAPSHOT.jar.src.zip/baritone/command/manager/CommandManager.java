/*     */ package baritone.command.manager;
/*     */ 
/*     */ import baritone.Baritone;
/*     */ import baritone.api.IBaritone;
/*     */ import baritone.api.command.ICommand;
/*     */ import baritone.api.command.argument.IArgConsumer;
/*     */ import baritone.api.command.argument.ICommandArgument;
/*     */ import baritone.api.command.exception.CommandUnhandledException;
/*     */ import baritone.api.command.exception.ICommandException;
/*     */ import baritone.api.command.helpers.TabCompleteHelper;
/*     */ import baritone.api.command.manager.ICommandManager;
/*     */ import baritone.api.command.registry.Registry;
/*     */ import baritone.command.argument.ArgConsumer;
/*     */ import baritone.command.argument.CommandArguments;
/*     */ import baritone.command.defaults.DefaultCommands;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.stream.Stream;
/*     */ import net.minecraft.class_3545;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CommandManager
/*     */   implements ICommandManager
/*     */ {
/*  47 */   private final Registry<ICommand> registry = new Registry();
/*     */   private final Baritone baritone;
/*     */   
/*     */   public CommandManager(Baritone baritone) {
/*  51 */     this.baritone = baritone;
/*  52 */     DefaultCommands.createAll((IBaritone)baritone).forEach(this.registry::register);
/*     */   }
/*     */ 
/*     */   
/*     */   public IBaritone getBaritone() {
/*  57 */     return (IBaritone)this.baritone;
/*     */   }
/*     */ 
/*     */   
/*     */   public Registry<ICommand> getRegistry() {
/*  62 */     return this.registry;
/*     */   }
/*     */ 
/*     */   
/*     */   public ICommand getCommand(String name) {
/*  67 */     for (ICommand command : this.registry.entries) {
/*  68 */       if (command.getNames().contains(name.toLowerCase(Locale.US))) {
/*  69 */         return command;
/*     */       }
/*     */     } 
/*  72 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean execute(String string) {
/*  77 */     return execute(expand(string));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean execute(class_3545<String, List<ICommandArgument>> expanded) {
/*  82 */     ExecutionWrapper execution = from(expanded);
/*  83 */     if (execution != null) {
/*  84 */       execution.execute();
/*     */     }
/*  86 */     return (execution != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public Stream<String> tabComplete(class_3545<String, List<ICommandArgument>> expanded) {
/*  91 */     ExecutionWrapper execution = from(expanded);
/*  92 */     return (execution == null) ? Stream.<String>empty() : execution.tabComplete();
/*     */   }
/*     */ 
/*     */   
/*     */   public Stream<String> tabComplete(String prefix) {
/*  97 */     class_3545<String, List<ICommandArgument>> pair = expand(prefix, true);
/*  98 */     String label = (String)pair.method_15442();
/*  99 */     List<ICommandArgument> args = (List<ICommandArgument>)pair.method_15441();
/* 100 */     if (args.isEmpty()) {
/* 101 */       return (new TabCompleteHelper())
/* 102 */         .addCommands(this.baritone.getCommandManager())
/* 103 */         .filterPrefix(label)
/* 104 */         .stream();
/*     */     }
/* 106 */     return tabComplete(pair);
/*     */   }
/*     */ 
/*     */   
/*     */   private ExecutionWrapper from(class_3545<String, List<ICommandArgument>> expanded) {
/* 111 */     String label = (String)expanded.method_15442();
/* 112 */     ArgConsumer args = new ArgConsumer(this, (List)expanded.method_15441());
/*     */     
/* 114 */     ICommand command = getCommand(label);
/* 115 */     return (command == null) ? null : new ExecutionWrapper(command, label, args);
/*     */   }
/*     */   
/*     */   private static class_3545<String, List<ICommandArgument>> expand(String string, boolean preserveEmptyLast) {
/* 119 */     String label = string.split("\\s", 2)[0];
/* 120 */     List<ICommandArgument> args = CommandArguments.from(string.substring(label.length()), preserveEmptyLast);
/* 121 */     return new class_3545(label, args);
/*     */   }
/*     */   
/*     */   public static class_3545<String, List<ICommandArgument>> expand(String string) {
/* 125 */     return expand(string, false);
/*     */   }
/*     */   
/*     */   private static final class ExecutionWrapper
/*     */   {
/*     */     private ICommand command;
/*     */     private String label;
/*     */     private ArgConsumer args;
/*     */     
/*     */     private ExecutionWrapper(ICommand command, String label, ArgConsumer args) {
/* 135 */       this.command = command;
/* 136 */       this.label = label;
/* 137 */       this.args = args;
/*     */     }
/*     */     
/*     */     private void execute() {
/*     */       try {
/* 142 */         this.command.execute(this.label, (IArgConsumer)this.args);
/* 143 */       } catch (Throwable t) {
/*     */         
/* 145 */         ICommandException exception = (t instanceof ICommandException) ? (ICommandException)t : (ICommandException)new CommandUnhandledException(t);
/*     */ 
/*     */ 
/*     */         
/* 149 */         exception.handle(this.command, this.args.getArgs());
/*     */       } 
/*     */     }
/*     */     
/*     */     private Stream<String> tabComplete() {
/*     */       try {
/* 155 */         return this.command.tabComplete(this.label, (IArgConsumer)this.args);
/* 156 */       } catch (Throwable t) {
/* 157 */         return Stream.empty();
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\command\manager\CommandManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */