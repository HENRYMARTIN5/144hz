/*    */ package baritone.command.argument;
/*    */ 
/*    */ import baritone.api.command.argument.ICommandArgument;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.regex.Matcher;
/*    */ import java.util.regex.Pattern;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CommandArguments
/*    */ {
/* 35 */   private static final Pattern ARG_PATTERN = Pattern.compile("\\S+");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static List<ICommandArgument> from(String string, boolean preserveEmptyLast) {
/* 46 */     List<ICommandArgument> args = new ArrayList<>();
/* 47 */     Matcher argMatcher = ARG_PATTERN.matcher(string);
/* 48 */     int lastEnd = -1;
/* 49 */     while (argMatcher.find()) {
/* 50 */       args.add(new CommandArgument(args
/* 51 */             .size(), argMatcher
/* 52 */             .group(), string
/* 53 */             .substring(argMatcher.start())));
/*    */       
/* 55 */       lastEnd = argMatcher.end();
/*    */     } 
/* 57 */     if (preserveEmptyLast && lastEnd < string.length()) {
/* 58 */       args.add(new CommandArgument(args.size(), "", ""));
/*    */     }
/* 60 */     return args;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static List<ICommandArgument> from(String string) {
/* 67 */     return from(string, false);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static CommandArgument unknown() {
/* 77 */     return new CommandArgument(-1, "<unknown>", "");
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\command\argument\CommandArguments.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */