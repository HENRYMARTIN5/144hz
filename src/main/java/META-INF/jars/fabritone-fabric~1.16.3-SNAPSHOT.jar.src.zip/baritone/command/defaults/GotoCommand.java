/*    */ package baritone.command.defaults;
/*    */ 
/*    */ import baritone.api.IBaritone;
/*    */ import baritone.api.command.Command;
/*    */ import baritone.api.command.argument.IArgConsumer;
/*    */ import baritone.api.command.datatypes.BlockById;
/*    */ import baritone.api.command.datatypes.ForBlockOptionalMeta;
/*    */ import baritone.api.command.datatypes.IDatatype;
/*    */ import baritone.api.command.datatypes.IDatatypeFor;
/*    */ import baritone.api.command.datatypes.IDatatypePost;
/*    */ import baritone.api.command.datatypes.RelativeCoordinate;
/*    */ import baritone.api.command.datatypes.RelativeGoal;
/*    */ import baritone.api.command.exception.CommandException;
/*    */ import baritone.api.pathing.goals.Goal;
/*    */ import baritone.api.utils.BetterBlockPos;
/*    */ import baritone.api.utils.BlockOptionalMeta;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import java.util.stream.Stream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GotoCommand
/*    */   extends Command
/*    */ {
/*    */   protected GotoCommand(IBaritone baritone) {
/* 39 */     super(baritone, new String[] { "goto" });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void execute(String label, IArgConsumer args) throws CommandException {
/* 47 */     if (args.peekDatatypeOrNull((IDatatypePost)RelativeCoordinate.INSTANCE) != null) {
/* 48 */       args.requireMax(3);
/* 49 */       BetterBlockPos origin = this.baritone.getPlayerContext().playerFeet();
/* 50 */       Goal goal = (Goal)args.getDatatypePost((IDatatypePost)RelativeGoal.INSTANCE, origin);
/* 51 */       logDirect(String.format("Going to: %s", new Object[] { goal.toString() }));
/* 52 */       this.baritone.getCustomGoalProcess().setGoalAndPath(goal);
/*    */       return;
/*    */     } 
/* 55 */     args.requireMax(1);
/* 56 */     BlockOptionalMeta destination = (BlockOptionalMeta)args.getDatatypeFor((IDatatypeFor)ForBlockOptionalMeta.INSTANCE);
/* 57 */     this.baritone.getGetToBlockProcess().getToBlock(destination);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Stream<String> tabComplete(String label, IArgConsumer args) throws CommandException {
/* 64 */     return args.tabCompleteDatatype((IDatatype)BlockById.INSTANCE);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShortDesc() {
/* 69 */     return "Go to a coordinate or block";
/*    */   }
/*    */ 
/*    */   
/*    */   public List<String> getLongDesc() {
/* 74 */     return Arrays.asList(new String[] { "The goto command tells Baritone to head towards a given goal or block.", "", "Wherever a coordinate is expected, you can use ~ just like in regular Minecraft commands. Or, you can just use regular numbers.", "", "Usage:", "> goto <block> - Go to a block, wherever it is in the world", "> goto <y> - Go to a Y level", "> goto <x> <z> - Go to an X,Z position", "> goto <x> <y> <z> - Go to an X,Y,Z position" });
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\command\defaults\GotoCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */