/*    */ package baritone.command.argparser;
/*    */ 
/*    */ import baritone.api.command.argparser.IArgParser;
/*    */ import baritone.api.command.argparser.IArgParserManager;
/*    */ import baritone.api.command.argument.ICommandArgument;
/*    */ import baritone.api.command.exception.CommandInvalidTypeException;
/*    */ import baritone.api.command.exception.CommandNoParserForTypeException;
/*    */ import baritone.api.command.registry.Registry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ArgParserManager
/*    */   implements IArgParserManager
/*    */ {
/* 28 */   INSTANCE;
/*    */   
/* 30 */   public final Registry<IArgParser> registry = new Registry();
/*    */   
/*    */   ArgParserManager() {
/* 33 */     DefaultArgParsers.ALL.forEach(this.registry::register);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public <T> IArgParser.Stateless<T> getParserStateless(Class<T> type) {
/* 39 */     return this.registry.descendingStream()
/* 40 */       .filter(IArgParser.Stateless.class::isInstance)
/* 41 */       .map(IArgParser.Stateless.class::cast)
/* 42 */       .filter(parser -> parser.getTarget().isAssignableFrom(type))
/* 43 */       .findFirst()
/* 44 */       .orElse(null);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public <T, S> IArgParser.Stated<T, S> getParserStated(Class<T> type, Class<S> stateKlass) {
/* 50 */     return this.registry.descendingStream()
/* 51 */       .filter(IArgParser.Stated.class::isInstance)
/* 52 */       .map(IArgParser.Stated.class::cast)
/* 53 */       .filter(parser -> parser.getTarget().isAssignableFrom(type))
/* 54 */       .filter(parser -> parser.getStateType().isAssignableFrom(stateKlass))
/* 55 */       .map(IArgParser.Stated.class::cast)
/* 56 */       .findFirst()
/* 57 */       .orElse(null);
/*    */   }
/*    */ 
/*    */   
/*    */   public <T> T parseStateless(Class<T> type, ICommandArgument arg) throws CommandInvalidTypeException {
/* 62 */     IArgParser.Stateless<T> parser = getParserStateless(type);
/* 63 */     if (parser == null) {
/* 64 */       throw new CommandNoParserForTypeException(type);
/*    */     }
/*    */     try {
/* 67 */       return (T)parser.parseArg(arg);
/* 68 */     } catch (Exception exc) {
/* 69 */       throw new CommandInvalidTypeException(arg, type.getSimpleName());
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public <T, S> T parseStated(Class<T> type, Class<S> stateKlass, ICommandArgument arg, S state) throws CommandInvalidTypeException {
/* 75 */     IArgParser.Stated<T, S> parser = getParserStated(type, stateKlass);
/* 76 */     if (parser == null) {
/* 77 */       throw new CommandNoParserForTypeException(type);
/*    */     }
/*    */     try {
/* 80 */       return (T)parser.parseArg(arg, state);
/* 81 */     } catch (Exception exc) {
/* 82 */       throw new CommandInvalidTypeException(arg, type.getSimpleName());
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public Registry<IArgParser> getRegistry() {
/* 88 */     return this.registry;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\command\argparser\ArgParserManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */