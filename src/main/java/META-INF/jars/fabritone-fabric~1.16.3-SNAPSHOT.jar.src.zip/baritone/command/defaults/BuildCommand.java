/*    */ package baritone.command.defaults;
/*    */ 
/*    */ import baritone.Baritone;
/*    */ import baritone.api.IBaritone;
/*    */ import baritone.api.command.Command;
/*    */ import baritone.api.command.argument.IArgConsumer;
/*    */ import baritone.api.command.datatypes.IDatatype;
/*    */ import baritone.api.command.datatypes.IDatatypePost;
/*    */ import baritone.api.command.datatypes.RelativeBlockPos;
/*    */ import baritone.api.command.datatypes.RelativeFile;
/*    */ import baritone.api.command.exception.CommandException;
/*    */ import baritone.api.command.exception.CommandInvalidStateException;
/*    */ import baritone.api.utils.BetterBlockPos;
/*    */ import java.io.File;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import java.util.stream.Stream;
/*    */ import net.minecraft.class_2382;
/*    */ import org.apache.commons.io.FilenameUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BuildCommand
/*    */   extends Command
/*    */ {
/* 39 */   private static final File schematicsDir = new File(mc.field_1697, "schematics");
/*    */   
/*    */   public BuildCommand(IBaritone baritone) {
/* 42 */     super(baritone, new String[] { "build" });
/*    */   }
/*    */   
/*    */   public void execute(String label, IArgConsumer args) throws CommandException {
/*    */     BetterBlockPos buildOrigin;
/* 47 */     File file = ((File)args.getDatatypePost((IDatatypePost)RelativeFile.INSTANCE, schematicsDir)).getAbsoluteFile();
/* 48 */     if (FilenameUtils.getExtension(file.getAbsolutePath()).isEmpty()) {
/* 49 */       file = new File(file.getAbsolutePath() + "." + (String)(Baritone.settings()).schematicFallbackExtension.value);
/*    */     }
/* 51 */     BetterBlockPos origin = this.ctx.playerFeet();
/*    */     
/* 53 */     if (args.hasAny()) {
/* 54 */       args.requireMax(3);
/* 55 */       buildOrigin = (BetterBlockPos)args.getDatatypePost((IDatatypePost)RelativeBlockPos.INSTANCE, origin);
/*    */     } else {
/* 57 */       args.requireMax(0);
/* 58 */       buildOrigin = origin;
/*    */     } 
/* 60 */     boolean success = this.baritone.getBuilderProcess().build(file.getName(), file, (class_2382)buildOrigin);
/* 61 */     if (!success) {
/* 62 */       throw new CommandInvalidStateException("Couldn't load the schematic. Make sure to use the FULL file name, including the extension (e.g. blah.schematic).");
/*    */     }
/* 64 */     logDirect(String.format("Successfully loaded schematic for building\nOrigin: %s", new Object[] { buildOrigin }));
/*    */   }
/*    */ 
/*    */   
/*    */   public Stream<String> tabComplete(String label, IArgConsumer args) throws CommandException {
/* 69 */     if (args.hasExactlyOne())
/* 70 */       return RelativeFile.tabComplete(args, schematicsDir); 
/* 71 */     if (args.has(2)) {
/* 72 */       args.get();
/* 73 */       return args.tabCompleteDatatype((IDatatype)RelativeBlockPos.INSTANCE);
/*    */     } 
/* 75 */     return Stream.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShortDesc() {
/* 80 */     return "Build a schematic";
/*    */   }
/*    */ 
/*    */   
/*    */   public List<String> getLongDesc() {
/* 85 */     return Arrays.asList(new String[] { "Build a schematic from a file.", "", "Usage:", "> build <filename> - Loads and builds '<filename>.schematic'", "> build <filename> <x> <y> <z> - Custom position" });
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\command\defaults\BuildCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */