/*    */ package baritone.command.defaults;
/*    */ 
/*    */ import baritone.api.IBaritone;
/*    */ import baritone.api.command.Command;
/*    */ import baritone.api.command.argument.IArgConsumer;
/*    */ import baritone.api.command.datatypes.BlockById;
/*    */ import baritone.api.command.datatypes.IDatatype;
/*    */ import baritone.api.command.datatypes.IDatatypeFor;
/*    */ import baritone.api.command.exception.CommandException;
/*    */ import baritone.api.utils.BetterBlockPos;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import java.util.function.Function;
/*    */ import java.util.stream.Stream;
/*    */ import net.minecraft.class_2248;
/*    */ import net.minecraft.class_2378;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FindCommand
/*    */   extends Command
/*    */ {
/*    */   public FindCommand(IBaritone baritone) {
/* 37 */     super(baritone, new String[] { "find" });
/*    */   }
/*    */ 
/*    */   
/*    */   public void execute(String label, IArgConsumer args) throws CommandException {
/* 42 */     List<class_2248> toFind = new ArrayList<>();
/* 43 */     while (args.hasAny()) {
/* 44 */       toFind.add(args.getDatatypeFor((IDatatypeFor)BlockById.INSTANCE));
/*    */     }
/* 46 */     BetterBlockPos origin = this.ctx.playerFeet();
/* 47 */     toFind.stream()
/* 48 */       .flatMap(block -> this.ctx.worldData().getCachedWorld().getLocationsOf(class_2378.field_11146.method_10221(block).method_12832(), 2147483647, origin.x, origin.y, 4).stream())
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 57 */       .map(BetterBlockPos::new)
/* 58 */       .map(BetterBlockPos::toString)
/* 59 */       .forEach(this::logDirect);
/*    */   }
/*    */ 
/*    */   
/*    */   public Stream<String> tabComplete(String label, IArgConsumer args) {
/* 64 */     return args.tabCompleteDatatype((IDatatype)BlockById.INSTANCE);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShortDesc() {
/* 69 */     return "Find positions of a certain block";
/*    */   }
/*    */ 
/*    */   
/*    */   public List<String> getLongDesc() {
/* 74 */     return Arrays.asList(new String[] { "", "", "Usage:", "> " });
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\command\defaults\FindCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */