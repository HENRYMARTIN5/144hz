/*    */ package baritone.command.defaults;
/*    */ 
/*    */ import baritone.api.IBaritone;
/*    */ import baritone.api.command.Command;
/*    */ import baritone.api.command.argument.IArgConsumer;
/*    */ import baritone.api.command.exception.CommandException;
/*    */ import baritone.api.command.exception.CommandInvalidStateException;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import java.util.stream.Stream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VersionCommand
/*    */   extends Command
/*    */ {
/*    */   public VersionCommand(IBaritone baritone) {
/* 33 */     super(baritone, new String[] { "version" });
/*    */   }
/*    */ 
/*    */   
/*    */   public void execute(String label, IArgConsumer args) throws CommandException {
/* 38 */     args.requireMax(0);
/* 39 */     String version = getClass().getPackage().getImplementationVersion();
/* 40 */     if (version == null) {
/* 41 */       throw new CommandInvalidStateException("Null version (this is normal in a dev environment)");
/*    */     }
/* 43 */     logDirect(String.format("You are running Baritone v%s", new Object[] { version }));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Stream<String> tabComplete(String label, IArgConsumer args) {
/* 49 */     return Stream.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShortDesc() {
/* 54 */     return "View the Baritone version";
/*    */   }
/*    */ 
/*    */   
/*    */   public List<String> getLongDesc() {
/* 59 */     return Arrays.asList(new String[] { "The version command prints the version of Baritone you're currently running.", "", "Usage:", "> version - View version information, if present" });
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\command\defaults\VersionCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */