/*    */ package baritone.command.defaults;
/*    */ 
/*    */ import baritone.api.IBaritone;
/*    */ import baritone.api.command.Command;
/*    */ import baritone.api.command.argument.IArgConsumer;
/*    */ import baritone.api.command.exception.CommandException;
/*    */ import baritone.api.process.ICustomGoalProcess;
/*    */ import baritone.cache.WorldScanner;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import java.util.stream.Stream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PathCommand
/*    */   extends Command
/*    */ {
/*    */   public PathCommand(IBaritone baritone) {
/* 34 */     super(baritone, new String[] { "path" });
/*    */   }
/*    */ 
/*    */   
/*    */   public void execute(String label, IArgConsumer args) throws CommandException {
/* 39 */     ICustomGoalProcess customGoalProcess = this.baritone.getCustomGoalProcess();
/* 40 */     args.requireMax(0);
/* 41 */     WorldScanner.INSTANCE.repack(this.ctx);
/* 42 */     customGoalProcess.path();
/* 43 */     logDirect("Now pathing");
/*    */   }
/*    */ 
/*    */   
/*    */   public Stream<String> tabComplete(String label, IArgConsumer args) throws CommandException {
/* 48 */     return Stream.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShortDesc() {
/* 53 */     return "Start heading towards the goal";
/*    */   }
/*    */ 
/*    */   
/*    */   public List<String> getLongDesc() {
/* 58 */     return Arrays.asList(new String[] { "The path command tells Baritone to head towards the current goal.", "", "Usage:", "> path - Start the pathing." });
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\command\defaults\PathCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */