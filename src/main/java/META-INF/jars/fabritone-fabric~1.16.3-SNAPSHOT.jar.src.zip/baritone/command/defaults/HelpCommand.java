/*     */ package baritone.command.defaults;
/*     */ 
/*     */ import baritone.api.IBaritone;
/*     */ import baritone.api.command.Command;
/*     */ import baritone.api.command.IBaritoneChatControl;
/*     */ import baritone.api.command.ICommand;
/*     */ import baritone.api.command.argument.IArgConsumer;
/*     */ import baritone.api.command.exception.CommandException;
/*     */ import baritone.api.command.exception.CommandNotFoundException;
/*     */ import baritone.api.command.helpers.Paginator;
/*     */ import baritone.api.command.helpers.TabCompleteHelper;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ import net.minecraft.class_124;
/*     */ import net.minecraft.class_2558;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_2568;
/*     */ import net.minecraft.class_2585;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HelpCommand
/*     */   extends Command
/*     */ {
/*     */   public HelpCommand(IBaritone baritone) {
/*  44 */     super(baritone, new String[] { "help", "?" });
/*     */   }
/*     */ 
/*     */   
/*     */   public void execute(String label, IArgConsumer args) throws CommandException {
/*  49 */     args.requireMax(1);
/*  50 */     if (!args.hasAny() || args.is(Integer.class)) {
/*  51 */       Paginator.paginate(args, new Paginator((List)this.baritone
/*     */             
/*  53 */             .getCommandManager().getRegistry().descendingStream()
/*  54 */             .filter(command -> !command.hiddenFromHelp())
/*  55 */             .collect(Collectors.toList())), () -> logDirect("All Baritone commands (clickable):"), command -> { String names = String.join("/", command.getNames()); String name = command.getNames().get(0); class_2585 class_25851 = new class_2585(" - " + command.getShortDesc()); class_25851.method_10862(class_25851.method_10866().method_27706(class_124.field_1063)); class_2585 class_25852 = new class_2585(names); class_25852.method_10862(class_25852.method_10866().method_27706(class_124.field_1068)); class_2585 class_25853 = new class_2585(""); class_25853.method_10862(class_25853.method_10866().method_27706(class_124.field_1080)); class_25853.method_10852((class_2561)class_25852); class_25853.method_27693("\n" + command.getShortDesc()); class_25853.method_27693("\n\nClick to view full help"); String clickCommand = IBaritoneChatControl.FORCE_COMMAND_PREFIX + String.format("%s %s", new Object[] { label, command.getNames().get(0) }); class_2585 class_25854 = new class_2585(name); class_25854.method_10862(class_25854.method_10866().method_27706(class_124.field_1080)); class_25854.method_10852((class_2561)class_25851); class_25854.method_10862(class_25854.method_10866().method_10949(new class_2568(class_2568.class_5247.field_24342, class_25853)).method_10958(new class_2558(class_2558.class_2559.field_11750, clickCommand))); return (class_2561)class_25854; }IBaritoneChatControl.FORCE_COMMAND_PREFIX + label);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  82 */       String commandName = args.getString().toLowerCase();
/*  83 */       ICommand command = this.baritone.getCommandManager().getCommand(commandName);
/*  84 */       if (command == null) {
/*  85 */         throw new CommandNotFoundException(commandName);
/*     */       }
/*  87 */       logDirect(String.format("%s - %s", new Object[] { String.join(" / ", command.getNames()), command.getShortDesc() }));
/*  88 */       logDirect("");
/*  89 */       command.getLongDesc().forEach(this::logDirect);
/*  90 */       logDirect("");
/*  91 */       class_2585 class_2585 = new class_2585("Click to return to the help menu");
/*  92 */       class_2585.method_10862(class_2585.method_10866().method_10958(new class_2558(class_2558.class_2559.field_11750, IBaritoneChatControl.FORCE_COMMAND_PREFIX + label)));
/*     */ 
/*     */ 
/*     */       
/*  96 */       logDirect(new class_2561[] { (class_2561)class_2585 });
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Stream<String> tabComplete(String label, IArgConsumer args) throws CommandException {
/* 102 */     if (args.hasExactlyOne()) {
/* 103 */       return (new TabCompleteHelper())
/* 104 */         .addCommands(this.baritone.getCommandManager())
/* 105 */         .filterPrefix(args.getString())
/* 106 */         .stream();
/*     */     }
/* 108 */     return Stream.empty();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getShortDesc() {
/* 113 */     return "View all commands or help on specific ones";
/*     */   }
/*     */ 
/*     */   
/*     */   public List<String> getLongDesc() {
/* 118 */     return Arrays.asList(new String[] { "Using this command, you can view detailed help information on how to use certain commands of Baritone.", "", "Usage:", "> help - Lists all commands and their short descriptions.", "> help <command> - Displays help information on a specific command." });
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\command\defaults\HelpCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */