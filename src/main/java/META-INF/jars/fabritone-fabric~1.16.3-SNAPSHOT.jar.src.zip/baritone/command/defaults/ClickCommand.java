/*    */ package baritone.command.defaults;
/*    */ 
/*    */ import baritone.api.IBaritone;
/*    */ import baritone.api.command.Command;
/*    */ import baritone.api.command.argument.IArgConsumer;
/*    */ import baritone.api.command.exception.CommandException;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import java.util.stream.Stream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClickCommand
/*    */   extends Command
/*    */ {
/*    */   public ClickCommand(IBaritone baritone) {
/* 32 */     super(baritone, new String[] { "click" });
/*    */   }
/*    */ 
/*    */   
/*    */   public void execute(String label, IArgConsumer args) throws CommandException {
/* 37 */     args.requireMax(0);
/* 38 */     this.baritone.openClick();
/* 39 */     logDirect("aight dude");
/*    */   }
/*    */ 
/*    */   
/*    */   public Stream<String> tabComplete(String label, IArgConsumer args) {
/* 44 */     return Stream.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShortDesc() {
/* 49 */     return "Open click";
/*    */   }
/*    */ 
/*    */   
/*    */   public List<String> getLongDesc() {
/* 54 */     return Arrays.asList(new String[] { "Opens click dude", "", "Usage:", "> click" });
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\command\defaults\ClickCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */