/*     */ package baritone.command.defaults;
/*     */ 
/*     */ import baritone.KeepName;
/*     */ import baritone.api.IBaritone;
/*     */ import baritone.api.command.Command;
/*     */ import baritone.api.command.argument.IArgConsumer;
/*     */ import baritone.api.command.datatypes.EntityClassById;
/*     */ import baritone.api.command.datatypes.IDatatype;
/*     */ import baritone.api.command.datatypes.IDatatypeFor;
/*     */ import baritone.api.command.datatypes.NearbyPlayer;
/*     */ import baritone.api.command.exception.CommandException;
/*     */ import baritone.api.command.helpers.TabCompleteHelper;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.stream.Stream;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1299;
/*     */ import net.minecraft.class_1309;
/*     */ import net.minecraft.class_1657;
/*     */ import net.minecraft.class_2378;
/*     */ import net.minecraft.class_2960;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FollowCommand
/*     */   extends Command
/*     */ {
/*     */   public FollowCommand(IBaritone baritone) {
/*  43 */     super(baritone, new String[] { "follow" });
/*     */   }
/*     */   
/*     */   public void execute(String label, IArgConsumer args) throws CommandException {
/*     */     FollowGroup group;
/*  48 */     args.requireMin(1);
/*     */ 
/*     */     
/*  51 */     List<class_1297> entities = new ArrayList<>();
/*  52 */     List<class_1299> classes = new ArrayList<>();
/*  53 */     if (args.hasExactlyOne()) {
/*  54 */       this.baritone.getFollowProcess().follow((group = (FollowGroup)args.getEnum(FollowGroup.class)).filter);
/*     */     } else {
/*  56 */       args.requireMin(2);
/*  57 */       group = null;
/*  58 */       FollowList list = (FollowList)args.getEnum(FollowList.class);
/*  59 */       while (args.hasAny()) {
/*  60 */         Object gotten = args.getDatatypeFor(list.datatype);
/*  61 */         if (gotten instanceof class_1299) {
/*     */           
/*  63 */           classes.add((class_1299)gotten); continue;
/*     */         } 
/*  65 */         entities.add((class_1297)gotten);
/*     */       } 
/*     */ 
/*     */       
/*  69 */       this.baritone.getFollowProcess().follow(
/*  70 */           classes.isEmpty() ? entities::contains : (e -> classes.stream().anyMatch(())));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  75 */     if (group != null) {
/*  76 */       logDirect(String.format("Following all %s", new Object[] { group.name().toLowerCase(Locale.US) }));
/*     */     } else {
/*  78 */       logDirect("Following these types of entities:");
/*  79 */       if (classes.isEmpty()) {
/*  80 */         entities.stream()
/*  81 */           .map(class_1297::toString)
/*  82 */           .forEach(this::logDirect);
/*     */       } else {
/*  84 */         classes.stream()
/*  85 */           .map(class_2378.field_11145::method_10221)
/*  86 */           .map(Objects::requireNonNull)
/*  87 */           .map(class_2960::toString)
/*  88 */           .forEach(this::logDirect);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public Stream<String> tabComplete(String label, IArgConsumer args) throws CommandException {
/*     */     IDatatypeFor followType;
/*  95 */     if (args.hasExactlyOne()) {
/*  96 */       return (new TabCompleteHelper())
/*  97 */         .append(FollowGroup.class)
/*  98 */         .append(FollowList.class)
/*  99 */         .filterPrefix(args.getString())
/* 100 */         .stream();
/*     */     }
/*     */     
/*     */     try {
/* 104 */       followType = ((FollowList)args.getEnum(FollowList.class)).datatype;
/* 105 */     } catch (NullPointerException e) {
/* 106 */       return Stream.empty();
/*     */     } 
/* 108 */     while (args.has(2)) {
/* 109 */       if (args.peekDatatypeOrNull(followType) == null) {
/* 110 */         return Stream.empty();
/*     */       }
/* 112 */       args.get();
/*     */     } 
/* 114 */     return args.tabCompleteDatatype((IDatatype)followType);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getShortDesc() {
/* 120 */     return "Follow entity things";
/*     */   }
/*     */ 
/*     */   
/*     */   public List<String> getLongDesc() {
/* 125 */     return Arrays.asList(new String[] { "The follow command tells Baritone to follow certain kinds of entities.", "", "Usage:", "> follow entities - Follows all entities.", "> follow entity <entity1> <entity2> <...> - Follow certain entities (for example 'skeleton', 'horse' etc.)", "> follow players - Follow players", "> follow player <username1> <username2> <...> - Follow certain players" });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @KeepName
/*     */   private enum FollowGroup
/*     */   {
/* 138 */     ENTITIES((String)class_1309.class::isInstance),
/* 139 */     PLAYERS((String)class_1657.class::isInstance);
/*     */     
/*     */     final Predicate<class_1297> filter;
/*     */ 
/*     */     
/*     */     FollowGroup(Predicate<class_1297> filter) {
/* 145 */       this.filter = filter;
/*     */     }
/*     */   }
/*     */   
/*     */   @KeepName
/*     */   private enum FollowList {
/* 151 */     ENTITY((String)EntityClassById.INSTANCE),
/* 152 */     PLAYER((String)NearbyPlayer.INSTANCE);
/*     */     
/*     */     final IDatatypeFor datatype;
/*     */     
/*     */     FollowList(IDatatypeFor datatype) {
/* 157 */       this.datatype = datatype;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\command\defaults\FollowCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */