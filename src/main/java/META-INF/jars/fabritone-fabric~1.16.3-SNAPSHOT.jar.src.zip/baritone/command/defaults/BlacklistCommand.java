/*    */ package baritone.command.defaults;
/*    */ 
/*    */ import baritone.api.IBaritone;
/*    */ import baritone.api.command.Command;
/*    */ import baritone.api.command.argument.IArgConsumer;
/*    */ import baritone.api.command.exception.CommandException;
/*    */ import baritone.api.command.exception.CommandInvalidStateException;
/*    */ import baritone.api.process.IGetToBlockProcess;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import java.util.stream.Stream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlacklistCommand
/*    */   extends Command
/*    */ {
/*    */   public BlacklistCommand(IBaritone baritone) {
/* 34 */     super(baritone, new String[] { "blacklist" });
/*    */   }
/*    */ 
/*    */   
/*    */   public void execute(String label, IArgConsumer args) throws CommandException {
/* 39 */     args.requireMax(0);
/* 40 */     IGetToBlockProcess proc = this.baritone.getGetToBlockProcess();
/* 41 */     if (!proc.isActive()) {
/* 42 */       throw new CommandInvalidStateException("GetToBlockProcess is not currently active");
/*    */     }
/* 44 */     if (proc.blacklistClosest()) {
/* 45 */       logDirect("Blacklisted closest instances");
/*    */     } else {
/* 47 */       throw new CommandInvalidStateException("No known locations, unable to blacklist");
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public Stream<String> tabComplete(String label, IArgConsumer args) {
/* 53 */     return Stream.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShortDesc() {
/* 58 */     return "Blacklist closest block";
/*    */   }
/*    */ 
/*    */   
/*    */   public List<String> getLongDesc() {
/* 63 */     return Arrays.asList(new String[] { "While going to a block this command blacklists the closest block so that Baritone won't attempt to get to it.", "", "Usage:", "> blacklist" });
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\command\defaults\BlacklistCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */