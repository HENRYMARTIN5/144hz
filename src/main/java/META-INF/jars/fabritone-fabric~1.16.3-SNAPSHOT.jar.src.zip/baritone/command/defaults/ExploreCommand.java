/*    */ package baritone.command.defaults;
/*    */ 
/*    */ import baritone.api.IBaritone;
/*    */ import baritone.api.command.Command;
/*    */ import baritone.api.command.argument.IArgConsumer;
/*    */ import baritone.api.command.datatypes.IDatatype;
/*    */ import baritone.api.command.datatypes.IDatatypePost;
/*    */ import baritone.api.command.datatypes.RelativeGoalXZ;
/*    */ import baritone.api.command.exception.CommandException;
/*    */ import baritone.api.pathing.goals.GoalXZ;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import java.util.stream.Stream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExploreCommand
/*    */   extends Command
/*    */ {
/*    */   public ExploreCommand(IBaritone baritone) {
/* 34 */     super(baritone, new String[] { "explore" });
/*    */   }
/*    */ 
/*    */   
/*    */   public void execute(String label, IArgConsumer args) throws CommandException {
/* 39 */     if (args.hasAny()) {
/* 40 */       args.requireExactly(2);
/*    */     } else {
/* 42 */       args.requireMax(0);
/*    */     } 
/*    */ 
/*    */     
/* 46 */     GoalXZ goal = args.hasAny() ? (GoalXZ)args.getDatatypePost((IDatatypePost)RelativeGoalXZ.INSTANCE, this.ctx.playerFeet()) : new GoalXZ(this.ctx.playerFeet());
/* 47 */     this.baritone.getExploreProcess().explore(goal.getX(), goal.getZ());
/* 48 */     logDirect(String.format("Exploring from %s", new Object[] { goal.toString() }));
/*    */   }
/*    */ 
/*    */   
/*    */   public Stream<String> tabComplete(String label, IArgConsumer args) {
/* 53 */     if (args.hasAtMost(2)) {
/* 54 */       return args.tabCompleteDatatype((IDatatype)RelativeGoalXZ.INSTANCE);
/*    */     }
/* 56 */     return Stream.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShortDesc() {
/* 61 */     return "Explore things";
/*    */   }
/*    */ 
/*    */   
/*    */   public List<String> getLongDesc() {
/* 66 */     return Arrays.asList(new String[] { "Tell Baritone to explore randomly. If you used explorefilter before this, it will be applied.", "", "Usage:", "> explore - Explore from your current position.", "> explore <x> <z> - Explore from the specified X and Z position." });
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\command\defaults\ExploreCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */