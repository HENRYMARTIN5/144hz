/*     */ package baritone.command.defaults;
/*     */ 
/*     */ import baritone.Baritone;
/*     */ import baritone.api.IBaritone;
/*     */ import baritone.api.command.Command;
/*     */ import baritone.api.command.argument.IArgConsumer;
/*     */ import baritone.api.command.datatypes.ForBlockOptionalMeta;
/*     */ import baritone.api.command.datatypes.ForDirection;
/*     */ import baritone.api.command.datatypes.IDatatype;
/*     */ import baritone.api.command.datatypes.IDatatypeFor;
/*     */ import baritone.api.command.datatypes.IDatatypePost;
/*     */ import baritone.api.command.datatypes.RelativeBlockPos;
/*     */ import baritone.api.command.exception.CommandException;
/*     */ import baritone.api.command.exception.CommandInvalidStateException;
/*     */ import baritone.api.command.exception.CommandInvalidTypeException;
/*     */ import baritone.api.command.helpers.TabCompleteHelper;
/*     */ import baritone.api.event.events.RenderEvent;
/*     */ import baritone.api.event.listener.AbstractGameEventListener;
/*     */ import baritone.api.event.listener.IGameEventListener;
/*     */ import baritone.api.schematic.CompositeSchematic;
/*     */ import baritone.api.schematic.FillSchematic;
/*     */ import baritone.api.schematic.ISchematic;
/*     */ import baritone.api.schematic.ReplaceSchematic;
/*     */ import baritone.api.schematic.ShellSchematic;
/*     */ import baritone.api.schematic.WallsSchematic;
/*     */ import baritone.api.selection.ISelection;
/*     */ import baritone.api.selection.ISelectionManager;
/*     */ import baritone.api.utils.BetterBlockPos;
/*     */ import baritone.api.utils.BlockOptionalMeta;
/*     */ import baritone.api.utils.BlockOptionalMetaLookup;
/*     */ import baritone.utils.IRenderer;
/*     */ import java.awt.Color;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.function.Function;
/*     */ import java.util.stream.Stream;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_238;
/*     */ import net.minecraft.class_2382;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SelCommand
/*     */   extends Command
/*     */ {
/*  54 */   private ISelectionManager manager = this.baritone.getSelectionManager();
/*  55 */   private BetterBlockPos pos1 = null;
/*     */   
/*     */   public SelCommand(IBaritone baritone) {
/*  58 */     super(baritone, new String[] { "sel", "selection", "s" });
/*  59 */     baritone.getGameEventHandler().registerEventListener((IGameEventListener)new AbstractGameEventListener()
/*     */         {
/*     */           public void onRenderPass(RenderEvent event) {
/*  62 */             if (!((Boolean)(Baritone.settings()).renderSelectionCorners.value).booleanValue() || SelCommand.this.pos1 == null) {
/*     */               return;
/*     */             }
/*  65 */             Color color = (Color)(Baritone.settings()).colorSelectionPos1.value;
/*  66 */             float opacity = ((Float)(Baritone.settings()).selectionOpacity.value).floatValue();
/*  67 */             float lineWidth = ((Float)(Baritone.settings()).selectionLineWidth.value).floatValue();
/*  68 */             boolean ignoreDepth = ((Boolean)(Baritone.settings()).renderSelectionIgnoreDepth.value).booleanValue();
/*  69 */             IRenderer.startLines(color, opacity, lineWidth, ignoreDepth);
/*  70 */             IRenderer.drawAABB(event.getModelViewStack(), new class_238((class_2338)SelCommand.this.pos1, SelCommand.this.pos1.method_10069(1, 1, 1)));
/*  71 */             IRenderer.endLines(ignoreDepth);
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public void execute(String label, IArgConsumer args) throws CommandException {
/*  78 */     Action action = Action.getByName(args.getString());
/*  79 */     if (action == null) {
/*  80 */       throw new CommandInvalidTypeException(args.consumed(), "an action");
/*     */     }
/*  82 */     if (action == Action.POS1 || action == Action.POS2) {
/*  83 */       if (action == Action.POS2 && this.pos1 == null) {
/*  84 */         throw new CommandInvalidStateException("Set pos1 first before using pos2");
/*     */       }
/*  86 */       BetterBlockPos playerPos = (mc.method_1560() != null) ? BetterBlockPos.from(mc.method_1560().method_24515()) : this.ctx.playerFeet();
/*  87 */       BetterBlockPos pos = args.hasAny() ? (BetterBlockPos)args.getDatatypePost((IDatatypePost)RelativeBlockPos.INSTANCE, playerPos) : playerPos;
/*  88 */       args.requireMax(0);
/*  89 */       if (action == Action.POS1) {
/*  90 */         this.pos1 = pos;
/*  91 */         logDirect("Position 1 has been set");
/*     */       } else {
/*  93 */         this.manager.addSelection(this.pos1, pos);
/*  94 */         this.pos1 = null;
/*  95 */         logDirect("Selection added");
/*     */       } 
/*  97 */     } else if (action == Action.CLEAR) {
/*  98 */       args.requireMax(0);
/*  99 */       this.pos1 = null;
/* 100 */       logDirect(String.format("Removed %d selections", new Object[] { Integer.valueOf((this.manager.removeAllSelections()).length) }));
/* 101 */     } else if (action == Action.UNDO) {
/* 102 */       args.requireMax(0);
/* 103 */       if (this.pos1 != null) {
/* 104 */         this.pos1 = null;
/* 105 */         logDirect("Undid pos1");
/*     */       } else {
/* 107 */         ISelection[] selections = this.manager.getSelections();
/* 108 */         if (selections.length < 1) {
/* 109 */           throw new CommandInvalidStateException("Nothing to undo!");
/*     */         }
/* 111 */         this.pos1 = this.manager.removeSelection(selections[selections.length - 1]).pos1();
/* 112 */         logDirect("Undid pos2");
/*     */       }
/*     */     
/* 115 */     } else if (action == Action.SET || action == Action.WALLS || action == Action.SHELL || action == Action.CLEARAREA || action == Action.REPLACE) {
/*     */ 
/*     */       
/* 118 */       BlockOptionalMeta type = (action == Action.CLEARAREA) ? new BlockOptionalMeta(class_2246.field_10124) : (BlockOptionalMeta)args.getDatatypeFor((IDatatypeFor)ForBlockOptionalMeta.INSTANCE);
/* 119 */       BlockOptionalMetaLookup replaces = null;
/* 120 */       if (action == Action.REPLACE) {
/* 121 */         args.requireMin(1);
/* 122 */         List<BlockOptionalMeta> replacesList = new ArrayList<>();
/* 123 */         replacesList.add(type);
/* 124 */         while (args.has(2)) {
/* 125 */           replacesList.add(args.getDatatypeFor((IDatatypeFor)ForBlockOptionalMeta.INSTANCE));
/*     */         }
/* 127 */         type = (BlockOptionalMeta)args.getDatatypeFor((IDatatypeFor)ForBlockOptionalMeta.INSTANCE);
/* 128 */         replaces = new BlockOptionalMetaLookup(replacesList.<BlockOptionalMeta>toArray(new BlockOptionalMeta[0]));
/*     */       } else {
/* 130 */         args.requireMax(0);
/*     */       } 
/* 132 */       ISelection[] selections = this.manager.getSelections();
/* 133 */       if (selections.length == 0) {
/* 134 */         throw new CommandInvalidStateException("No selections");
/*     */       }
/* 136 */       BetterBlockPos origin = selections[0].min();
/* 137 */       CompositeSchematic composite = new CompositeSchematic(0, 0, 0);
/* 138 */       for (ISelection selection : selections) {
/* 139 */         BetterBlockPos min = selection.min();
/*     */ 
/*     */ 
/*     */         
/* 143 */         origin = new BetterBlockPos(Math.min(origin.x, min.x), Math.min(origin.y, min.y), Math.min(origin.z, min.z));
/*     */       } 
/*     */       
/* 146 */       for (ISelection selection : selections) {
/* 147 */         WallsSchematic wallsSchematic; ReplaceSchematic replaceSchematic; class_2382 size = selection.size();
/* 148 */         BetterBlockPos min = selection.min();
/* 149 */         FillSchematic fillSchematic = new FillSchematic(size.method_10263(), size.method_10264(), size.method_10260(), type);
/* 150 */         if (action == Action.WALLS)
/* 151 */         { wallsSchematic = new WallsSchematic((ISchematic)fillSchematic); }
/* 152 */         else { ShellSchematic shellSchematic; if (action == Action.SHELL) {
/* 153 */             shellSchematic = new ShellSchematic((ISchematic)wallsSchematic);
/* 154 */           } else if (action == Action.REPLACE) {
/* 155 */             replaceSchematic = new ReplaceSchematic((ISchematic)shellSchematic, replaces);
/*     */           }  }
/* 157 */          composite.put((ISchematic)replaceSchematic, min.x - origin.x, min.y - origin.y, min.z - origin.z);
/*     */       } 
/* 159 */       this.baritone.getBuilderProcess().build("Fill", (ISchematic)composite, (class_2382)origin);
/* 160 */       logDirect("Filling now");
/* 161 */     } else if (action == Action.EXPAND || action == Action.CONTRACT || action == Action.SHIFT) {
/* 162 */       args.requireExactly(3);
/* 163 */       TransformTarget transformTarget = TransformTarget.getByName(args.getString());
/* 164 */       if (transformTarget == null) {
/* 165 */         throw new CommandInvalidStateException("Invalid transform type");
/*     */       }
/* 167 */       class_2350 direction = (class_2350)args.getDatatypeFor((IDatatypeFor)ForDirection.INSTANCE);
/* 168 */       int blocks = ((Integer)args.getAs(Integer.class)).intValue();
/* 169 */       ISelection[] selections = this.manager.getSelections();
/* 170 */       if (selections.length < 1) {
/* 171 */         throw new CommandInvalidStateException("No selections found");
/*     */       }
/* 173 */       selections = transformTarget.transform(selections);
/* 174 */       for (ISelection selection : selections) {
/* 175 */         if (action == Action.EXPAND) {
/* 176 */           this.manager.expand(selection, direction, blocks);
/* 177 */         } else if (action == Action.CONTRACT) {
/* 178 */           this.manager.contract(selection, direction, blocks);
/*     */         } else {
/* 180 */           this.manager.shift(selection, direction, blocks);
/*     */         } 
/*     */       } 
/* 183 */       logDirect(String.format("Transformed %d selections", new Object[] { Integer.valueOf(selections.length) }));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Stream<String> tabComplete(String label, IArgConsumer args) throws CommandException {
/* 189 */     if (args.hasExactlyOne()) {
/* 190 */       return (new TabCompleteHelper())
/* 191 */         .append(Action.getAllNames())
/* 192 */         .filterPrefix(args.getString())
/* 193 */         .sortAlphabetically()
/* 194 */         .stream();
/*     */     }
/* 196 */     Action action = Action.getByName(args.getString());
/* 197 */     if (action != null) {
/* 198 */       if (action == Action.POS1 || action == Action.POS2) {
/* 199 */         if (args.hasAtMost(3)) {
/* 200 */           return args.tabCompleteDatatype((IDatatype)RelativeBlockPos.INSTANCE);
/*     */         }
/* 202 */       } else if (action == Action.SET || action == Action.WALLS || action == Action.CLEARAREA || action == Action.REPLACE) {
/* 203 */         if (args.hasExactlyOne() || action == Action.REPLACE) {
/* 204 */           while (args.has(2)) {
/* 205 */             args.get();
/*     */           }
/* 207 */           return args.tabCompleteDatatype((IDatatype)ForBlockOptionalMeta.INSTANCE);
/*     */         } 
/* 209 */       } else if (action == Action.EXPAND || action == Action.CONTRACT || action == Action.SHIFT) {
/* 210 */         if (args.hasExactlyOne()) {
/* 211 */           return (new TabCompleteHelper())
/* 212 */             .append(TransformTarget.getAllNames())
/* 213 */             .filterPrefix(args.getString())
/* 214 */             .sortAlphabetically()
/* 215 */             .stream();
/*     */         }
/* 217 */         TransformTarget target = TransformTarget.getByName(args.getString());
/* 218 */         if (target != null && args.hasExactlyOne()) {
/* 219 */           return args.tabCompleteDatatype((IDatatype)ForDirection.INSTANCE);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 225 */     return Stream.empty();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getShortDesc() {
/* 230 */     return "WorldEdit-like commands";
/*     */   }
/*     */ 
/*     */   
/*     */   public List<String> getLongDesc() {
/* 235 */     return Arrays.asList(new String[] { "The sel command allows you to manipulate Baritone's selections, similarly to WorldEdit.", "", "Using these selections, you can clear areas, fill them with blocks, or something else.", "", "The expand/contract/shift commands use a kind of selector to choose which selections to target. Supported ones are a/all, n/newest, and o/oldest.", "", "Usage:", "> sel pos1/p1/1 - Set position 1 to your current position.", "> sel pos1/p1/1 <x> <y> <z> - Set position 1 to a relative position.", "> sel pos2/p2/2 - Set position 2 to your current position.", "> sel pos2/p2/2 <x> <y> <z> - Set position 2 to a relative position.", "", "> sel clear/c - Clear the selection.", "> sel undo/u - Undo the last action (setting positions, creating selections, etc.)", "> sel set/fill/s/f [block] - Completely fill all selections with a block.", "> sel walls/w [block] - Fill in the walls of the selection with a specified block.", "> sel shell/shl [block] - The same as walls, but fills in a ceiling and floor too.", "> sel cleararea/ca - Basically 'set air'.", "> sel replace/r <blocks...> <with> - Replaces blocks with another block.", "", "> sel expand <target> <direction> <blocks> - Expand the targets.", "> sel contract <target> <direction> <blocks> - Contract the targets.", "> sel shift <target> <direction> <blocks> - Shift the targets (does not resize)." });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   enum Action
/*     */   {
/* 263 */     POS1((String)new String[] { "pos1", "p1", "1" }),
/* 264 */     POS2((String)new String[] { "pos2", "p2", "2" }),
/* 265 */     CLEAR((String)new String[] { "clear", "c" }),
/* 266 */     UNDO((String)new String[] { "undo", "u" }),
/* 267 */     SET((String)new String[] { "set", "fill", "s", "f" }),
/* 268 */     WALLS((String)new String[] { "walls", "w" }),
/* 269 */     SHELL((String)new String[] { "shell", "shl" }),
/* 270 */     CLEARAREA((String)new String[] { "cleararea", "ca" }),
/* 271 */     REPLACE((String)new String[] { "replace", "r" }),
/* 272 */     EXPAND((String)new String[] { "expand", "ex" }),
/* 273 */     CONTRACT((String)new String[] { "contract", "ct" }),
/* 274 */     SHIFT((String)new String[] { "shift", "sh" });
/*     */     private final String[] names;
/*     */     
/*     */     Action(String... names) {
/* 278 */       this.names = names;
/*     */     }
/*     */     
/*     */     public static Action getByName(String name) {
/* 282 */       for (Action action : values()) {
/* 283 */         for (String alias : action.names) {
/* 284 */           if (alias.equalsIgnoreCase(name)) {
/* 285 */             return action;
/*     */           }
/*     */         } 
/*     */       } 
/* 289 */       return null;
/*     */     }
/*     */     
/*     */     public static String[] getAllNames() {
/* 293 */       Set<String> names = new HashSet<>();
/* 294 */       for (Action action : values()) {
/* 295 */         names.addAll(Arrays.asList(action.names));
/*     */       }
/* 297 */       return names.<String>toArray(new String[0]);
/*     */     } }
/*     */   enum TransformTarget { ALL, NEWEST, OLDEST;
/*     */     
/*     */     static {
/* 302 */       ALL = new TransformTarget("ALL", 0, sels -> sels, new String[] { "all", "a" });
/* 303 */       NEWEST = new TransformTarget("NEWEST", 1, sels -> new ISelection[] { sels[sels.length - 1] }, new String[] { "newest", "n" });
/* 304 */       OLDEST = new TransformTarget("OLDEST", 2, sels -> new ISelection[] { sels[0] }, new String[] { "oldest", "o" });
/*     */     }
/*     */     private final Function<ISelection[], ISelection[]> transform; private final String[] names;
/*     */     
/*     */     TransformTarget(Function<ISelection[], ISelection[]> transform, String... names) {
/* 309 */       this.transform = transform;
/* 310 */       this.names = names;
/*     */     }
/*     */     
/*     */     public ISelection[] transform(ISelection[] selections) {
/* 314 */       return this.transform.apply(selections);
/*     */     }
/*     */     
/*     */     public static TransformTarget getByName(String name) {
/* 318 */       for (TransformTarget target : values()) {
/* 319 */         for (String alias : target.names) {
/* 320 */           if (alias.equalsIgnoreCase(name)) {
/* 321 */             return target;
/*     */           }
/*     */         } 
/*     */       } 
/* 325 */       return null;
/*     */     }
/*     */     
/*     */     public static String[] getAllNames() {
/* 329 */       Set<String> names = new HashSet<>();
/* 330 */       for (TransformTarget target : values()) {
/* 331 */         names.addAll(Arrays.asList(target.names));
/*     */       }
/* 333 */       return names.<String>toArray(new String[0]);
/*     */     } }
/*     */ 
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\command\defaults\SelCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */