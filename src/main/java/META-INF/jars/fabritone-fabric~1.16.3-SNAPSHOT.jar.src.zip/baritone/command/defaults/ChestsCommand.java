/*    */ package baritone.command.defaults;
/*    */ 
/*    */ import baritone.api.IBaritone;
/*    */ import baritone.api.cache.IRememberedInventory;
/*    */ import baritone.api.command.Command;
/*    */ import baritone.api.command.argument.IArgConsumer;
/*    */ import baritone.api.command.exception.CommandException;
/*    */ import baritone.api.command.exception.CommandInvalidStateException;
/*    */ import baritone.api.utils.BetterBlockPos;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import java.util.stream.Stream;
/*    */ import net.minecraft.class_1799;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_2561;
/*    */ import net.minecraft.class_5250;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ChestsCommand
/*    */   extends Command
/*    */ {
/*    */   public ChestsCommand(IBaritone baritone) {
/* 40 */     super(baritone, new String[] { "chests" });
/*    */   }
/*    */ 
/*    */   
/*    */   public void execute(String label, IArgConsumer args) throws CommandException {
/* 45 */     args.requireMax(0);
/*    */     
/* 47 */     Set<Map.Entry<class_2338, IRememberedInventory>> entries = this.ctx.worldData().getContainerMemory().getRememberedInventories().entrySet();
/* 48 */     if (entries.isEmpty()) {
/* 49 */       throw new CommandInvalidStateException("No remembered inventories");
/*    */     }
/* 51 */     for (Map.Entry<class_2338, IRememberedInventory> entry : entries) {
/*    */       
/* 53 */       BetterBlockPos pos = new BetterBlockPos(entry.getKey());
/* 54 */       IRememberedInventory inv = entry.getValue();
/* 55 */       logDirect(pos.toString());
/* 56 */       for (class_1799 item : inv.getContents()) {
/* 57 */         class_5250 component = (class_5250)item.method_7964();
/* 58 */         component.method_27693(String.format(" x %d", new Object[] { Integer.valueOf(item.method_7947()) }));
/* 59 */         logDirect(new class_2561[] { (class_2561)component });
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public Stream<String> tabComplete(String label, IArgConsumer args) {
/* 66 */     return Stream.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShortDesc() {
/* 71 */     return "Display remembered inventories";
/*    */   }
/*    */ 
/*    */   
/*    */   public List<String> getLongDesc() {
/* 76 */     return Arrays.asList(new String[] { "The chests command lists remembered inventories, I guess?", "", "Usage:", "> chests" });
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\command\defaults\ChestsCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */