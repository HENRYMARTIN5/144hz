/*    */ package baritone.command.defaults;
/*    */ 
/*    */ import baritone.api.IBaritone;
/*    */ import baritone.api.behavior.IPathingBehavior;
/*    */ import baritone.api.command.Command;
/*    */ import baritone.api.command.argument.IArgConsumer;
/*    */ import baritone.api.command.exception.CommandException;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import java.util.stream.Stream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ForceCancelCommand
/*    */   extends Command
/*    */ {
/*    */   public ForceCancelCommand(IBaritone baritone) {
/* 33 */     super(baritone, new String[] { "forcecancel" });
/*    */   }
/*    */ 
/*    */   
/*    */   public void execute(String label, IArgConsumer args) throws CommandException {
/* 38 */     args.requireMax(0);
/* 39 */     IPathingBehavior pathingBehavior = this.baritone.getPathingBehavior();
/* 40 */     pathingBehavior.cancelEverything();
/* 41 */     pathingBehavior.forceCancel();
/* 42 */     logDirect("ok force canceled");
/*    */   }
/*    */ 
/*    */   
/*    */   public Stream<String> tabComplete(String label, IArgConsumer args) {
/* 47 */     return Stream.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShortDesc() {
/* 52 */     return "Force cancel";
/*    */   }
/*    */ 
/*    */   
/*    */   public List<String> getLongDesc() {
/* 57 */     return Arrays.asList(new String[] { "Like cancel, but more forceful.", "", "Usage:", "> forcecancel" });
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\command\defaults\ForceCancelCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */