/*     */ package baritone.command.argument;
/*     */ 
/*     */ import baritone.Baritone;
/*     */ import baritone.api.IBaritone;
/*     */ import baritone.api.command.argument.IArgConsumer;
/*     */ import baritone.api.command.argument.ICommandArgument;
/*     */ import baritone.api.command.datatypes.IDatatypeContext;
/*     */ import baritone.api.command.datatypes.IDatatypeFor;
/*     */ import baritone.api.command.datatypes.IDatatypePost;
/*     */ import baritone.api.command.exception.CommandException;
/*     */ import baritone.api.command.exception.CommandInvalidTypeException;
/*     */ import baritone.api.command.exception.CommandNotEnoughArgumentsException;
/*     */ import baritone.api.command.exception.CommandTooManyArgumentsException;
/*     */ import baritone.api.command.manager.ICommandManager;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Deque;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.stream.Stream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArgConsumer
/*     */   implements IArgConsumer
/*     */ {
/*     */   private final ICommandManager manager;
/*     */   private final IDatatypeContext context;
/*     */   private final LinkedList<ICommandArgument> args;
/*     */   private final Deque<ICommandArgument> consumed;
/*     */   
/*     */   private ArgConsumer(ICommandManager manager, Deque<ICommandArgument> args, Deque<ICommandArgument> consumed) {
/*  67 */     this.manager = manager;
/*  68 */     this.context = new Context();
/*  69 */     this.args = new LinkedList<>(args);
/*  70 */     this.consumed = new LinkedList<>(consumed);
/*     */   }
/*     */   
/*     */   public ArgConsumer(ICommandManager manager, List<ICommandArgument> args) {
/*  74 */     this(manager, new LinkedList<>(args), new LinkedList<>());
/*     */   }
/*     */ 
/*     */   
/*     */   public LinkedList<ICommandArgument> getArgs() {
/*  79 */     return this.args;
/*     */   }
/*     */ 
/*     */   
/*     */   public Deque<ICommandArgument> getConsumed() {
/*  84 */     return this.consumed;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean has(int num) {
/*  89 */     return (this.args.size() >= num);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasAny() {
/*  94 */     return has(1);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasAtMost(int num) {
/*  99 */     return (this.args.size() <= num);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasAtMostOne() {
/* 104 */     return hasAtMost(1);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasExactly(int num) {
/* 109 */     return (this.args.size() == num);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasExactlyOne() {
/* 114 */     return hasExactly(1);
/*     */   }
/*     */ 
/*     */   
/*     */   public ICommandArgument peek(int index) throws CommandNotEnoughArgumentsException {
/* 119 */     requireMin(index + 1);
/* 120 */     return this.args.get(index);
/*     */   }
/*     */ 
/*     */   
/*     */   public ICommandArgument peek() throws CommandNotEnoughArgumentsException {
/* 125 */     return peek(0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean is(Class<?> type, int index) throws CommandNotEnoughArgumentsException {
/* 130 */     return peek(index).is(type);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean is(Class<?> type) throws CommandNotEnoughArgumentsException {
/* 135 */     return is(type, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public String peekString(int index) throws CommandNotEnoughArgumentsException {
/* 140 */     return peek(index).getValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public String peekString() throws CommandNotEnoughArgumentsException {
/* 145 */     return peekString(0);
/*     */   }
/*     */ 
/*     */   
/*     */   public <E extends Enum<?>> E peekEnum(Class<E> enumClass, int index) throws CommandInvalidTypeException, CommandNotEnoughArgumentsException {
/* 150 */     return (E)peek(index).getEnum(enumClass);
/*     */   }
/*     */ 
/*     */   
/*     */   public <E extends Enum<?>> E peekEnum(Class<E> enumClass) throws CommandInvalidTypeException, CommandNotEnoughArgumentsException {
/* 155 */     return peekEnum(enumClass, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public <E extends Enum<?>> E peekEnumOrNull(Class<E> enumClass, int index) throws CommandNotEnoughArgumentsException {
/*     */     try {
/* 161 */       return peekEnum(enumClass, index);
/* 162 */     } catch (CommandInvalidTypeException e) {
/* 163 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public <E extends Enum<?>> E peekEnumOrNull(Class<E> enumClass) throws CommandNotEnoughArgumentsException {
/* 169 */     return peekEnumOrNull(enumClass, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T peekAs(Class<T> type, int index) throws CommandInvalidTypeException, CommandNotEnoughArgumentsException {
/* 174 */     return (T)peek(index).getAs(type);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T peekAs(Class<T> type) throws CommandInvalidTypeException, CommandNotEnoughArgumentsException {
/* 179 */     return peekAs(type, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T peekAsOrDefault(Class<T> type, T def, int index) throws CommandNotEnoughArgumentsException {
/*     */     try {
/* 185 */       return peekAs(type, index);
/* 186 */     } catch (CommandInvalidTypeException e) {
/* 187 */       return def;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T peekAsOrDefault(Class<T> type, T def) throws CommandNotEnoughArgumentsException {
/* 193 */     return peekAsOrDefault(type, def, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T peekAsOrNull(Class<T> type, int index) throws CommandNotEnoughArgumentsException {
/* 198 */     return peekAsOrDefault(type, null, index);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T peekAsOrNull(Class<T> type) throws CommandNotEnoughArgumentsException {
/* 203 */     return peekAsOrNull(type, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T peekDatatype(IDatatypeFor<T> datatype) throws CommandInvalidTypeException, CommandNotEnoughArgumentsException {
/* 208 */     return copy().getDatatypeFor(datatype);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T, O> T peekDatatype(IDatatypePost<T, O> datatype) throws CommandInvalidTypeException, CommandNotEnoughArgumentsException {
/* 213 */     return peekDatatype(datatype, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T, O> T peekDatatype(IDatatypePost<T, O> datatype, O original) throws CommandInvalidTypeException, CommandNotEnoughArgumentsException {
/* 218 */     return copy().getDatatypePost(datatype, original);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T peekDatatypeOrNull(IDatatypeFor<T> datatype) {
/* 223 */     return copy().getDatatypeForOrNull(datatype);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T, O> T peekDatatypeOrNull(IDatatypePost<T, O> datatype) {
/* 228 */     return copy().getDatatypePostOrNull(datatype, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T, O, D extends IDatatypePost<T, O>> T peekDatatypePost(D datatype, O original) throws CommandInvalidTypeException, CommandNotEnoughArgumentsException {
/* 233 */     return copy().getDatatypePost(datatype, original);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T, O, D extends IDatatypePost<T, O>> T peekDatatypePostOrDefault(D datatype, O original, T def) {
/* 238 */     return copy().getDatatypePostOrDefault(datatype, original, def);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T, O, D extends IDatatypePost<T, O>> T peekDatatypePostOrNull(D datatype, O original) {
/* 243 */     return peekDatatypePostOrDefault(datatype, original, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T, D extends IDatatypeFor<T>> T peekDatatypeFor(Class<D> datatype) {
/* 248 */     return copy().peekDatatypeFor(datatype);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T, D extends IDatatypeFor<T>> T peekDatatypeForOrDefault(Class<D> datatype, T def) {
/* 253 */     return copy().peekDatatypeForOrDefault(datatype, def);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T, D extends IDatatypeFor<T>> T peekDatatypeForOrNull(Class<D> datatype) {
/* 258 */     return peekDatatypeForOrDefault(datatype, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public ICommandArgument get() throws CommandNotEnoughArgumentsException {
/* 263 */     requireMin(1);
/* 264 */     ICommandArgument arg = this.args.removeFirst();
/* 265 */     this.consumed.add(arg);
/* 266 */     return arg;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getString() throws CommandNotEnoughArgumentsException {
/* 271 */     return get().getValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public <E extends Enum<?>> E getEnum(Class<E> enumClass) throws CommandInvalidTypeException, CommandNotEnoughArgumentsException {
/* 276 */     return (E)get().getEnum(enumClass);
/*     */   }
/*     */ 
/*     */   
/*     */   public <E extends Enum<?>> E getEnumOrDefault(Class<E> enumClass, E def) throws CommandNotEnoughArgumentsException {
/*     */     try {
/* 282 */       peekEnum(enumClass);
/* 283 */       return getEnum(enumClass);
/* 284 */     } catch (CommandInvalidTypeException e) {
/* 285 */       return def;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public <E extends Enum<?>> E getEnumOrNull(Class<E> enumClass) throws CommandNotEnoughArgumentsException {
/* 291 */     return getEnumOrDefault(enumClass, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T getAs(Class<T> type) throws CommandInvalidTypeException, CommandNotEnoughArgumentsException {
/* 296 */     return (T)get().getAs(type);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T getAsOrDefault(Class<T> type, T def) throws CommandNotEnoughArgumentsException {
/*     */     try {
/* 302 */       T val = (T)peek().getAs(type);
/* 303 */       get();
/* 304 */       return val;
/* 305 */     } catch (CommandInvalidTypeException e) {
/* 306 */       return def;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T getAsOrNull(Class<T> type) throws CommandNotEnoughArgumentsException {
/* 312 */     return getAsOrDefault(type, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T, O, D extends IDatatypePost<T, O>> T getDatatypePost(D datatype, O original) throws CommandInvalidTypeException, CommandNotEnoughArgumentsException {
/*     */     try {
/* 318 */       return (T)datatype.apply(this.context, original);
/* 319 */     } catch (Exception e) {
/* 320 */       if (((Boolean)(Baritone.settings()).verboseCommandExceptions.value).booleanValue()) {
/* 321 */         e.printStackTrace();
/*     */       }
/* 323 */       throw new CommandInvalidTypeException(hasAny() ? peek() : consumed(), datatype.getClass().getSimpleName(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public <T, O, D extends IDatatypePost<T, O>> T getDatatypePostOrDefault(D datatype, O original, T _default) {
/* 329 */     List<ICommandArgument> argsSnapshot = new ArrayList<>(this.args);
/* 330 */     List<ICommandArgument> consumedSnapshot = new ArrayList<>(this.consumed);
/*     */     try {
/* 332 */       return getDatatypePost(datatype, original);
/* 333 */     } catch (Exception e) {
/* 334 */       this.args.clear();
/* 335 */       this.args.addAll(argsSnapshot);
/* 336 */       this.consumed.clear();
/* 337 */       this.consumed.addAll(consumedSnapshot);
/* 338 */       return _default;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public <T, O, D extends IDatatypePost<T, O>> T getDatatypePostOrNull(D datatype, O original) {
/* 344 */     return getDatatypePostOrDefault(datatype, original, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T, D extends IDatatypeFor<T>> T getDatatypeFor(D datatype) throws CommandInvalidTypeException, CommandNotEnoughArgumentsException {
/*     */     try {
/* 350 */       return (T)datatype.get(this.context);
/* 351 */     } catch (Exception e) {
/* 352 */       if (((Boolean)(Baritone.settings()).verboseCommandExceptions.value).booleanValue()) {
/* 353 */         e.printStackTrace();
/*     */       }
/* 355 */       throw new CommandInvalidTypeException(hasAny() ? peek() : consumed(), datatype.getClass().getSimpleName(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public <T, D extends IDatatypeFor<T>> T getDatatypeForOrDefault(D datatype, T def) {
/* 361 */     List<ICommandArgument> argsSnapshot = new ArrayList<>(this.args);
/* 362 */     List<ICommandArgument> consumedSnapshot = new ArrayList<>(this.consumed);
/*     */     try {
/* 364 */       return getDatatypeFor(datatype);
/* 365 */     } catch (Exception e) {
/* 366 */       this.args.clear();
/* 367 */       this.args.addAll(argsSnapshot);
/* 368 */       this.consumed.clear();
/* 369 */       this.consumed.addAll(consumedSnapshot);
/* 370 */       return def;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public <T, D extends IDatatypeFor<T>> T getDatatypeForOrNull(D datatype) {
/* 376 */     return getDatatypeForOrDefault(datatype, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T extends baritone.api.command.datatypes.IDatatype> Stream<String> tabCompleteDatatype(T datatype) {
/*     */     try {
/* 382 */       return datatype.tabComplete(this.context);
/* 383 */     } catch (Exception e) {
/* 384 */       e.printStackTrace();
/*     */       
/* 386 */       return Stream.empty();
/*     */     } 
/*     */   }
/*     */   
/*     */   public String rawRest() {
/* 391 */     return (this.args.size() > 0) ? ((ICommandArgument)this.args.getFirst()).getRawRest() : "";
/*     */   }
/*     */ 
/*     */   
/*     */   public void requireMin(int min) throws CommandNotEnoughArgumentsException {
/* 396 */     if (this.args.size() < min) {
/* 397 */       throw new CommandNotEnoughArgumentsException(min + this.consumed.size());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void requireMax(int max) throws CommandTooManyArgumentsException {
/* 403 */     if (this.args.size() > max) {
/* 404 */       throw new CommandTooManyArgumentsException(max + this.consumed.size());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void requireExactly(int args) throws CommandException {
/* 410 */     requireMin(args);
/* 411 */     requireMax(args);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasConsumed() {
/* 416 */     return !this.consumed.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public ICommandArgument consumed() {
/* 421 */     return (this.consumed.size() > 0) ? this.consumed.getLast() : CommandArguments.unknown();
/*     */   }
/*     */ 
/*     */   
/*     */   public String consumedString() {
/* 426 */     return consumed().getValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public ArgConsumer copy() {
/* 431 */     return new ArgConsumer(this.manager, this.args, this.consumed);
/*     */   }
/*     */ 
/*     */   
/*     */   private final class Context
/*     */     implements IDatatypeContext
/*     */   {
/*     */     private Context() {}
/*     */     
/*     */     public final IBaritone getBaritone() {
/* 441 */       return ArgConsumer.this.manager.getBaritone();
/*     */     }
/*     */ 
/*     */     
/*     */     public final ArgConsumer getConsumer() {
/* 446 */       return ArgConsumer.this;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\command\argument\ArgConsumer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */