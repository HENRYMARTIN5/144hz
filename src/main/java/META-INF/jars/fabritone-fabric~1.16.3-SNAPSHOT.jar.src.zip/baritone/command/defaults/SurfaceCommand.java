/*    */ package baritone.command.defaults;
/*    */ 
/*    */ import baritone.api.IBaritone;
/*    */ import baritone.api.command.Command;
/*    */ import baritone.api.command.argument.IArgConsumer;
/*    */ import baritone.api.command.exception.CommandException;
/*    */ import baritone.api.pathing.goals.Goal;
/*    */ import baritone.api.pathing.goals.GoalBlock;
/*    */ import baritone.api.utils.BetterBlockPos;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import java.util.stream.Stream;
/*    */ import net.minecraft.class_2338;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SurfaceCommand
/*    */   extends Command
/*    */ {
/*    */   protected SurfaceCommand(IBaritone baritone) {
/* 36 */     super(baritone, new String[] { "surface", "top" });
/*    */   }
/*    */ 
/*    */   
/*    */   public void execute(String label, IArgConsumer args) throws CommandException {
/* 41 */     BetterBlockPos playerPos = this.baritone.getPlayerContext().playerFeet();
/* 42 */     int surfaceLevel = this.baritone.getPlayerContext().world().method_8615();
/* 43 */     int worldHeight = this.baritone.getPlayerContext().world().method_8322();
/*    */ 
/*    */ 
/*    */     
/* 47 */     if (playerPos.method_10264() > surfaceLevel && mc.field_1687.method_8320((class_2338)playerPos.up()).method_26204() instanceof net.minecraft.class_2189) {
/* 48 */       logDirect("Already at surface");
/*    */       
/*    */       return;
/*    */     } 
/* 52 */     int startingYPos = Math.max(playerPos.method_10264(), surfaceLevel);
/*    */     
/* 54 */     for (int currentIteratedY = startingYPos; currentIteratedY < worldHeight; currentIteratedY++) {
/* 55 */       BetterBlockPos newPos = new BetterBlockPos(playerPos.method_10263(), currentIteratedY, playerPos.method_10260());
/*    */       
/* 57 */       if (!(mc.field_1687.method_8320((class_2338)newPos).method_26204() instanceof net.minecraft.class_2189) && newPos.method_10264() > playerPos.method_10264()) {
/* 58 */         GoalBlock goalBlock = new GoalBlock((class_2338)newPos.up());
/* 59 */         logDirect(String.format("Going to: %s", new Object[] { goalBlock.toString() }));
/* 60 */         this.baritone.getCustomGoalProcess().setGoalAndPath((Goal)goalBlock);
/*    */         return;
/*    */       } 
/*    */     } 
/* 64 */     logDirect("No higher location found");
/*    */   }
/*    */ 
/*    */   
/*    */   public Stream<String> tabComplete(String label, IArgConsumer args) {
/* 69 */     return Stream.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShortDesc() {
/* 74 */     return "Used to get out of caves, mines, ...";
/*    */   }
/*    */ 
/*    */   
/*    */   public List<String> getLongDesc() {
/* 79 */     return Arrays.asList(new String[] { "The surface/top command tells Baritone to head towards the closest surface-like area.", "", "This can be the surface or the highest available air space, depending on circumstances.", "", "Usage:", "> surface - Used to get out of caves, mines, ...", "> top - Used to get out of caves, mines, ..." });
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\command\defaults\SurfaceCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */