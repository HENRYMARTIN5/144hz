/*     */ package baritone.command;
/*     */ 
/*     */ import baritone.api.BaritoneAPI;
/*     */ import baritone.api.IBaritone;
/*     */ import baritone.api.Settings;
/*     */ import baritone.api.command.IBaritoneChatControl;
/*     */ import baritone.api.command.argument.ICommandArgument;
/*     */ import baritone.api.command.exception.CommandNotEnoughArgumentsException;
/*     */ import baritone.api.command.exception.CommandNotFoundException;
/*     */ import baritone.api.command.helpers.TabCompleteHelper;
/*     */ import baritone.api.command.manager.ICommandManager;
/*     */ import baritone.api.event.events.ChatEvent;
/*     */ import baritone.api.event.events.TabCompleteEvent;
/*     */ import baritone.api.event.listener.AbstractGameEventListener;
/*     */ import baritone.api.event.listener.IGameEventListener;
/*     */ import baritone.api.utils.Helper;
/*     */ import baritone.api.utils.SettingsUtil;
/*     */ import baritone.command.argument.ArgConsumer;
/*     */ import baritone.command.argument.CommandArguments;
/*     */ import baritone.command.manager.CommandManager;
/*     */ import baritone.utils.accessor.IGuiScreen;
/*     */ import java.net.URI;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.stream.Stream;
/*     */ import net.minecraft.class_124;
/*     */ import net.minecraft.class_2558;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_2568;
/*     */ import net.minecraft.class_2585;
/*     */ import net.minecraft.class_3545;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExampleBaritoneControl
/*     */   implements Helper, AbstractGameEventListener
/*     */ {
/*  54 */   private static final Settings settings = BaritoneAPI.getSettings();
/*     */   private final ICommandManager manager;
/*     */   
/*     */   public ExampleBaritoneControl(IBaritone baritone) {
/*  58 */     this.manager = baritone.getCommandManager();
/*  59 */     baritone.getGameEventHandler().registerEventListener((IGameEventListener)this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onSendChatMessage(ChatEvent event) {
/*  64 */     String msg = event.getMessage();
/*  65 */     String prefix = (String)settings.prefix.value;
/*  66 */     boolean forceRun = msg.startsWith(IBaritoneChatControl.FORCE_COMMAND_PREFIX);
/*  67 */     if ((((Boolean)settings.prefixControl.value).booleanValue() && msg.startsWith(prefix)) || forceRun) {
/*  68 */       event.cancel();
/*  69 */       String commandStr = msg.substring(forceRun ? IBaritoneChatControl.FORCE_COMMAND_PREFIX.length() : prefix.length());
/*  70 */       if (!runCommand(commandStr) && !commandStr.trim().isEmpty()) {
/*  71 */         (new CommandNotFoundException((String)CommandManager.expand(commandStr).method_15442())).handle(null, null);
/*     */       }
/*  73 */     } else if ((((Boolean)settings.chatControl.value).booleanValue() || ((Boolean)settings.chatControlAnyway.value).booleanValue()) && runCommand(msg)) {
/*  74 */       event.cancel();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void logRanCommand(String command, String rest) {
/*  79 */     if (((Boolean)settings.echoCommands.value).booleanValue()) {
/*  80 */       String msg = command + rest;
/*  81 */       String toDisplay = ((Boolean)settings.censorRanCommands.value).booleanValue() ? (command + " ...") : msg;
/*  82 */       class_2585 class_2585 = new class_2585(String.format("> %s", new Object[] { toDisplay }));
/*  83 */       class_2585.method_10862(class_2585.method_10866()
/*  84 */           .method_27706(class_124.field_1068)
/*  85 */           .method_10949(new class_2568(class_2568.class_5247.field_24342, new class_2585("Click to rerun command")))
/*     */ 
/*     */ 
/*     */           
/*  89 */           .method_10958(new class_2558(class_2558.class_2559.field_11750, IBaritoneChatControl.FORCE_COMMAND_PREFIX + msg)));
/*     */ 
/*     */ 
/*     */       
/*  93 */       logDirect(new class_2561[] { (class_2561)class_2585 });
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean runCommand(String msg) {
/*  98 */     if (msg.trim().equalsIgnoreCase("damn")) {
/*  99 */       logDirect("daniel");
/* 100 */       return false;
/* 101 */     }  if (msg.trim().equalsIgnoreCase("orderpizza")) {
/*     */       try {
/* 103 */         ((IGuiScreen)mc.field_1755).openLinkInvoker(new URI("https://www.dominos.com/en/pages/order/"));
/* 104 */       } catch (NullPointerException|java.net.URISyntaxException nullPointerException) {}
/* 105 */       return false;
/*     */     } 
/* 107 */     if (msg.isEmpty()) {
/* 108 */       return runCommand("help");
/*     */     }
/* 110 */     class_3545<String, List<ICommandArgument>> pair = CommandManager.expand(msg);
/* 111 */     String command = (String)pair.method_15442();
/* 112 */     String rest = msg.substring(((String)pair.method_15442()).length());
/* 113 */     ArgConsumer argc = new ArgConsumer(this.manager, (List)pair.method_15441());
/* 114 */     if (!argc.hasAny()) {
/* 115 */       Settings.Setting setting = (Settings.Setting)settings.byLowerName.get(command.toLowerCase(Locale.US));
/* 116 */       if (setting != null) {
/* 117 */         logRanCommand(command, rest);
/* 118 */         if (setting.getValueClass() == Boolean.class) {
/* 119 */           this.manager.execute(String.format("set toggle %s", new Object[] { setting.getName() }));
/*     */         } else {
/* 121 */           this.manager.execute(String.format("set %s", new Object[] { setting.getName() }));
/*     */         } 
/* 123 */         return true;
/*     */       } 
/* 125 */     } else if (argc.hasExactlyOne()) {
/* 126 */       for (Settings.Setting setting : settings.allSettings) {
/* 127 */         if (setting.getName().equals("logger")) {
/*     */           continue;
/*     */         }
/* 130 */         if (setting.getName().equalsIgnoreCase((String)pair.method_15442())) {
/* 131 */           logRanCommand(command, rest);
/*     */           try {
/* 133 */             this.manager.execute(String.format("set %s %s", new Object[] { setting.getName(), argc.getString() }));
/* 134 */           } catch (CommandNotEnoughArgumentsException commandNotEnoughArgumentsException) {}
/* 135 */           return true;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 141 */     if (this.manager.getCommand((String)pair.method_15442()) != null) {
/* 142 */       logRanCommand(command, rest);
/*     */     }
/*     */     
/* 145 */     return this.manager.execute(pair);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onPreTabComplete(TabCompleteEvent event) {
/* 150 */     if (!((Boolean)settings.prefixControl.value).booleanValue()) {
/*     */       return;
/*     */     }
/* 153 */     String prefix = event.prefix;
/* 154 */     String commandPrefix = (String)settings.prefix.value;
/* 155 */     if (!prefix.startsWith(commandPrefix)) {
/*     */       return;
/*     */     }
/* 158 */     String msg = prefix.substring(commandPrefix.length());
/* 159 */     List<ICommandArgument> args = CommandArguments.from(msg, true);
/* 160 */     Stream<String> stream = tabComplete(msg);
/* 161 */     if (args.size() == 1) {
/* 162 */       stream = stream.map(x -> commandPrefix + x);
/*     */     }
/* 164 */     event.completions = stream.<String>toArray(x$0 -> new String[x$0]);
/*     */   }
/*     */   
/*     */   public Stream<String> tabComplete(String msg) {
/*     */     try {
/* 169 */       List<ICommandArgument> args = CommandArguments.from(msg, true);
/* 170 */       ArgConsumer argc = new ArgConsumer(this.manager, args);
/* 171 */       if (argc.hasAtMost(2)) {
/* 172 */         if (argc.hasExactly(1)) {
/* 173 */           return (new TabCompleteHelper())
/* 174 */             .addCommands(this.manager)
/* 175 */             .addSettings()
/* 176 */             .filterPrefix(argc.getString())
/* 177 */             .stream();
/*     */         }
/* 179 */         Settings.Setting setting = (Settings.Setting)settings.byLowerName.get(argc.getString().toLowerCase(Locale.US));
/* 180 */         if (setting != null) {
/* 181 */           if (setting.getValueClass() == Boolean.class) {
/* 182 */             TabCompleteHelper helper = new TabCompleteHelper();
/* 183 */             if (((Boolean)setting.value).booleanValue()) {
/* 184 */               helper.append(new String[] { "true", "false" });
/*     */             } else {
/* 186 */               helper.append(new String[] { "false", "true" });
/*     */             } 
/* 188 */             return helper.filterPrefix(argc.getString()).stream();
/*     */           } 
/* 190 */           return Stream.of(SettingsUtil.settingValueToString(setting));
/*     */         } 
/*     */       } 
/*     */       
/* 194 */       return this.manager.tabComplete(msg);
/* 195 */     } catch (CommandNotEnoughArgumentsException ignored) {
/* 196 */       return Stream.empty();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\command\ExampleBaritoneControl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */