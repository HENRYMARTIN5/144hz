/*    */ package baritone.command.defaults;
/*    */ 
/*    */ import baritone.api.IBaritone;
/*    */ import baritone.api.command.Command;
/*    */ import baritone.api.command.argument.IArgConsumer;
/*    */ import baritone.api.command.exception.CommandException;
/*    */ import baritone.api.command.exception.CommandInvalidStateException;
/*    */ import baritone.api.pathing.calc.IPathingControlManager;
/*    */ import baritone.api.process.IBaritoneProcess;
/*    */ import baritone.api.process.PathingCommand;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import java.util.stream.Stream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProcCommand
/*    */   extends Command
/*    */ {
/*    */   public ProcCommand(IBaritone baritone) {
/* 36 */     super(baritone, new String[] { "proc" });
/*    */   }
/*    */ 
/*    */   
/*    */   public void execute(String label, IArgConsumer args) throws CommandException {
/* 41 */     args.requireMax(0);
/* 42 */     IPathingControlManager pathingControlManager = this.baritone.getPathingControlManager();
/* 43 */     IBaritoneProcess process = pathingControlManager.mostRecentInControl().orElse(null);
/* 44 */     if (process == null) {
/* 45 */       throw new CommandInvalidStateException("No process in control");
/*    */     }
/* 47 */     logDirect(String.format("Class: %s\nPriority: %f\nTemporary: %b\nDisplay name: %s\nLast command: %s", new Object[] { process
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */             
/* 53 */             .getClass().getTypeName(), 
/* 54 */             Double.valueOf(process.priority()), 
/* 55 */             Boolean.valueOf(process.isTemporary()), process
/* 56 */             .displayName(), pathingControlManager
/*    */             
/* 58 */             .mostRecentCommand()
/* 59 */             .map(PathingCommand::toString)
/* 60 */             .orElse("None") }));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Stream<String> tabComplete(String label, IArgConsumer args) {
/* 66 */     return Stream.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShortDesc() {
/* 71 */     return "View process state information";
/*    */   }
/*    */ 
/*    */   
/*    */   public List<String> getLongDesc() {
/* 76 */     return Arrays.asList(new String[] { "The proc command provides miscellaneous information about the process currently controlling Baritone.", "", "You are not expected to understand this if you aren't familiar with how Baritone works.", "", "Usage:", "> proc - View process information, if present" });
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\command\defaults\ProcCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */