/*     */ package baritone.command.argparser;
/*     */ 
/*     */ import baritone.api.command.argparser.IArgParser;
/*     */ import baritone.api.command.argument.ICommandArgument;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultArgParsers
/*     */ {
/*     */   public enum IntArgumentParser
/*     */     implements IArgParser.Stateless<Integer>
/*     */   {
/*  30 */     INSTANCE;
/*     */ 
/*     */     
/*     */     public Class<Integer> getTarget() {
/*  34 */       return Integer.class;
/*     */     }
/*     */ 
/*     */     
/*     */     public Integer parseArg(ICommandArgument arg) throws RuntimeException {
/*  39 */       return Integer.valueOf(Integer.parseInt(arg.getValue()));
/*     */     }
/*     */   }
/*     */   
/*     */   public enum LongArgumentParser implements IArgParser.Stateless<Long> {
/*  44 */     INSTANCE;
/*     */ 
/*     */     
/*     */     public Class<Long> getTarget() {
/*  48 */       return Long.class;
/*     */     }
/*     */ 
/*     */     
/*     */     public Long parseArg(ICommandArgument arg) throws RuntimeException {
/*  53 */       return Long.valueOf(Long.parseLong(arg.getValue()));
/*     */     }
/*     */   }
/*     */   
/*     */   public enum FloatArgumentParser implements IArgParser.Stateless<Float> {
/*  58 */     INSTANCE;
/*     */ 
/*     */     
/*     */     public Class<Float> getTarget() {
/*  62 */       return Float.class;
/*     */     }
/*     */ 
/*     */     
/*     */     public Float parseArg(ICommandArgument arg) throws RuntimeException {
/*  67 */       String value = arg.getValue();
/*  68 */       if (!value.matches("^([+-]?(?:\\d+(?:\\.\\d*)?|\\.\\d+)|)$")) {
/*  69 */         throw new IllegalArgumentException("failed float format check");
/*     */       }
/*  71 */       return Float.valueOf(Float.parseFloat(value));
/*     */     }
/*     */   }
/*     */   
/*     */   public enum DoubleArgumentParser implements IArgParser.Stateless<Double> {
/*  76 */     INSTANCE;
/*     */ 
/*     */     
/*     */     public Class<Double> getTarget() {
/*  80 */       return Double.class;
/*     */     }
/*     */ 
/*     */     
/*     */     public Double parseArg(ICommandArgument arg) throws RuntimeException {
/*  85 */       String value = arg.getValue();
/*  86 */       if (!value.matches("^([+-]?(?:\\d+(?:\\.\\d*)?|\\.\\d+)|)$")) {
/*  87 */         throw new IllegalArgumentException("failed double format check");
/*     */       }
/*  89 */       return Double.valueOf(Double.parseDouble(value));
/*     */     }
/*     */   }
/*     */   
/*     */   public static class BooleanArgumentParser
/*     */     implements IArgParser.Stateless<Boolean> {
/*  95 */     public static final BooleanArgumentParser INSTANCE = new BooleanArgumentParser();
/*  96 */     public static final List<String> TRUTHY_VALUES = Arrays.asList(new String[] { "1", "true", "yes", "t", "y", "on", "enable" });
/*  97 */     public static final List<String> FALSY_VALUES = Arrays.asList(new String[] { "0", "false", "no", "f", "n", "off", "disable" });
/*     */ 
/*     */     
/*     */     public Class<Boolean> getTarget() {
/* 101 */       return Boolean.class;
/*     */     }
/*     */ 
/*     */     
/*     */     public Boolean parseArg(ICommandArgument arg) throws RuntimeException {
/* 106 */       String value = arg.getValue();
/* 107 */       if (TRUTHY_VALUES.contains(value.toLowerCase(Locale.US)))
/* 108 */         return Boolean.valueOf(true); 
/* 109 */       if (FALSY_VALUES.contains(value.toLowerCase(Locale.US))) {
/* 110 */         return Boolean.valueOf(false);
/*     */       }
/* 112 */       throw new IllegalArgumentException("invalid boolean");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/* 117 */   public static final List<IArgParser<?>> ALL = Arrays.asList((IArgParser<?>[])new IArgParser[] { (IArgParser)IntArgumentParser.INSTANCE, (IArgParser)LongArgumentParser.INSTANCE, (IArgParser)FloatArgumentParser.INSTANCE, (IArgParser)DoubleArgumentParser.INSTANCE, (IArgParser)BooleanArgumentParser.INSTANCE });
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\command\argparser\DefaultArgParsers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */