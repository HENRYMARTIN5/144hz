/*    */ package baritone.command.defaults;
/*    */ 
/*    */ import baritone.api.IBaritone;
/*    */ import baritone.api.command.Command;
/*    */ import baritone.api.command.argument.IArgConsumer;
/*    */ import baritone.api.command.datatypes.BlockById;
/*    */ import baritone.api.command.datatypes.ForBlockOptionalMeta;
/*    */ import baritone.api.command.datatypes.IDatatype;
/*    */ import baritone.api.command.datatypes.IDatatypeFor;
/*    */ import baritone.api.command.exception.CommandException;
/*    */ import baritone.api.utils.BlockOptionalMeta;
/*    */ import baritone.cache.WorldScanner;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import java.util.stream.Stream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MineCommand
/*    */   extends Command
/*    */ {
/*    */   public MineCommand(IBaritone baritone) {
/* 37 */     super(baritone, new String[] { "mine" });
/*    */   }
/*    */ 
/*    */   
/*    */   public void execute(String label, IArgConsumer args) throws CommandException {
/* 42 */     int quantity = ((Integer)args.getAsOrDefault(Integer.class, Integer.valueOf(0))).intValue();
/* 43 */     args.requireMin(1);
/* 44 */     List<BlockOptionalMeta> boms = new ArrayList<>();
/* 45 */     while (args.hasAny()) {
/* 46 */       boms.add(args.getDatatypeFor((IDatatypeFor)ForBlockOptionalMeta.INSTANCE));
/*    */     }
/* 48 */     WorldScanner.INSTANCE.repack(this.ctx);
/* 49 */     logDirect(String.format("Mining %s", new Object[] { boms.toString() }));
/* 50 */     this.baritone.getMineProcess().mine(quantity, boms.<BlockOptionalMeta>toArray(new BlockOptionalMeta[0]));
/*    */   }
/*    */ 
/*    */   
/*    */   public Stream<String> tabComplete(String label, IArgConsumer args) {
/* 55 */     return args.tabCompleteDatatype((IDatatype)BlockById.INSTANCE);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShortDesc() {
/* 60 */     return "Mine some blocks";
/*    */   }
/*    */ 
/*    */   
/*    */   public List<String> getLongDesc() {
/* 65 */     return Arrays.asList(new String[] { "The mine command allows you to tell Baritone to search for and mine individual blocks.", "", "The specified blocks can be ores (which are commonly cached), or any other block.", "", "Also see the legitMine settings (see #set l legitMine).", "", "Usage:", "> mine diamond_ore - Mines all diamonds it can find.", "> mine redstone_ore lit_redstone_ore - Mines redstone ore.", "> mine log:0 - Mines only oak logs." });
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\command\defaults\MineCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */