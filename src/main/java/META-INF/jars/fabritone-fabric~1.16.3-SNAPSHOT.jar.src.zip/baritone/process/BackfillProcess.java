/*     */ package baritone.process;
/*     */ 
/*     */ import baritone.Baritone;
/*     */ import baritone.api.IBaritone;
/*     */ import baritone.api.process.PathingCommand;
/*     */ import baritone.api.process.PathingCommandType;
/*     */ import baritone.api.utils.input.Input;
/*     */ import baritone.pathing.movement.Movement;
/*     */ import baritone.pathing.movement.MovementHelper;
/*     */ import baritone.pathing.movement.MovementState;
/*     */ import baritone.pathing.path.PathExecutor;
/*     */ import baritone.utils.BaritoneProcessHelper;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.stream.Collectors;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2680;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BackfillProcess
/*     */   extends BaritoneProcessHelper
/*     */ {
/*  39 */   public HashMap<class_2338, class_2680> blocksToReplace = new HashMap<>();
/*     */   
/*     */   public BackfillProcess(Baritone baritone) {
/*  42 */     super(baritone);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isActive() {
/*  47 */     if (this.ctx.player() == null || this.ctx.world() == null) {
/*  48 */       return false;
/*     */     }
/*  50 */     if (!((Boolean)(Baritone.settings()).backfill.value).booleanValue()) {
/*  51 */       return false;
/*     */     }
/*  53 */     if (((Boolean)(Baritone.settings()).allowParkour.value).booleanValue()) {
/*  54 */       logDirect("Backfill cannot be used with allowParkour true");
/*  55 */       (Baritone.settings()).backfill.value = Boolean.valueOf(false);
/*  56 */       return false;
/*     */     } 
/*  58 */     amIBreakingABlockHMMMMMMM();
/*  59 */     for (class_2338 pos : new ArrayList(this.blocksToReplace.keySet())) {
/*  60 */       if (this.ctx.world().method_22350(pos) instanceof net.minecraft.class_2812) {
/*  61 */         this.blocksToReplace.remove(pos);
/*     */       }
/*     */     } 
/*  64 */     this.baritone.getInputOverrideHandler().clearAllKeys();
/*     */     
/*  66 */     return !toFillIn().isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public PathingCommand onTick(boolean calcFailed, boolean isSafeToCancel) {
/*  71 */     if (!isSafeToCancel) {
/*  72 */       return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
/*     */     }
/*  74 */     this.baritone.getInputOverrideHandler().clearAllKeys();
/*  75 */     for (class_2338 toPlace : toFillIn()) {
/*  76 */       MovementState fake = new MovementState();
/*  77 */       switch (MovementHelper.attemptToPlaceABlock(fake, (IBaritone)this.baritone, toPlace, false, false)) {
/*     */         case NO_OPTION:
/*     */           continue;
/*     */         case READY_TO_PLACE:
/*  81 */           this.baritone.getInputOverrideHandler().setInputForceState(Input.CLICK_RIGHT, true);
/*  82 */           return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
/*     */         
/*     */         case ATTEMPTING:
/*  85 */           this.baritone.getLookBehavior().updateTarget(fake.getTarget().getRotation().get(), true);
/*  86 */           return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
/*     */       } 
/*  88 */       throw new IllegalStateException();
/*     */     } 
/*     */     
/*  91 */     return new PathingCommand(null, PathingCommandType.DEFER);
/*     */   }
/*     */   
/*     */   private void amIBreakingABlockHMMMMMMM() {
/*  95 */     if (!this.ctx.getSelectedBlock().isPresent()) {
/*     */       return;
/*     */     }
/*  98 */     this.blocksToReplace.put(this.ctx.getSelectedBlock().get(), this.ctx.world().method_8320(this.ctx.getSelectedBlock().get()));
/*     */   }
/*     */   
/*     */   public List<class_2338> toFillIn() {
/* 102 */     return (List<class_2338>)this.blocksToReplace
/* 103 */       .keySet()
/* 104 */       .stream()
/* 105 */       .filter(pos -> (this.ctx.world().method_8320(pos).method_26204() == class_2246.field_10124))
/* 106 */       .filter(pos -> this.baritone.getBuilderProcess().placementPlausible(pos, class_2246.field_10566.method_9564()))
/* 107 */       .filter(pos -> !partOfCurrentMovement(pos))
/* 108 */       .sorted(Comparator.comparingDouble(this.ctx.playerFeet()::method_10262).reversed())
/* 109 */       .collect(Collectors.toList());
/*     */   }
/*     */   
/*     */   private boolean partOfCurrentMovement(class_2338 pos) {
/* 113 */     PathExecutor exec = this.baritone.getPathingBehavior().getCurrent();
/* 114 */     if (exec == null || exec.finished() || exec.failed()) {
/* 115 */       return false;
/*     */     }
/* 117 */     Movement movement = exec.getPath().movements().get(exec.getPosition());
/* 118 */     return Arrays.<class_2338>asList(movement.toBreakAll()).contains(pos);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onLostControl() {
/* 123 */     if (this.blocksToReplace != null && !this.blocksToReplace.isEmpty()) {
/* 124 */       this.blocksToReplace.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String displayName0() {
/* 130 */     return "Backfill";
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTemporary() {
/* 135 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public double priority() {
/* 140 */     return 5.0D;
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\process\BackfillProcess.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */