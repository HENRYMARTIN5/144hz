/*     */ package baritone.process;
/*     */ 
/*     */ import baritone.Baritone;
/*     */ import baritone.api.pathing.goals.Goal;
/*     */ import baritone.api.pathing.goals.GoalBlock;
/*     */ import baritone.api.pathing.goals.GoalComposite;
/*     */ import baritone.api.process.IFarmProcess;
/*     */ import baritone.api.process.PathingCommand;
/*     */ import baritone.api.process.PathingCommandType;
/*     */ import baritone.api.utils.RayTraceUtils;
/*     */ import baritone.api.utils.Rotation;
/*     */ import baritone.api.utils.RotationUtils;
/*     */ import baritone.api.utils.input.Input;
/*     */ import baritone.cache.WorldScanner;
/*     */ import baritone.pathing.movement.MovementHelper;
/*     */ import baritone.utils.BaritoneProcessHelper;
/*     */ import baritone.utils.NotificationHelper;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Predicate;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1542;
/*     */ import net.minecraft.class_1792;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_1802;
/*     */ import net.minecraft.class_1922;
/*     */ import net.minecraft.class_1937;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2248;
/*     */ import net.minecraft.class_2256;
/*     */ import net.minecraft.class_2302;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_239;
/*     */ import net.minecraft.class_2421;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_2769;
/*     */ import net.minecraft.class_3965;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FarmProcess
/*     */   extends BaritoneProcessHelper
/*     */   implements IFarmProcess
/*     */ {
/*     */   private boolean active;
/*     */   private List<class_2338> locations;
/*     */   private int tickCount;
/*  61 */   private static final List<class_1792> FARMLAND_PLANTABLE = Arrays.asList(new class_1792[] { class_1802.field_8309, class_1802.field_8188, class_1802.field_8317, class_1802.field_8706, class_1802.field_8567, class_1802.field_8179 });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   private static final List<class_1792> PICKUP_DROPPED = Arrays.asList(new class_1792[] { class_1802.field_8309, class_1802.field_8186, class_1802.field_8188, class_1802.field_8497, class_2246.field_10545
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  75 */         .method_8389(), class_1802.field_8317, class_1802.field_8861, class_1802.field_8706, class_2246.field_10261
/*     */ 
/*     */ 
/*     */         
/*  79 */         .method_8389(), class_1802.field_8567, class_1802.field_8179, class_1802.field_8790, class_2246.field_10424
/*     */ 
/*     */ 
/*     */         
/*  83 */         .method_8389(), class_2246.field_10029
/*  84 */         .method_8389() });
/*     */ 
/*     */   
/*     */   public FarmProcess(Baritone baritone) {
/*  88 */     super(baritone);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isActive() {
/*  93 */     return this.active;
/*     */   }
/*     */ 
/*     */   
/*     */   public void farm() {
/*  98 */     this.active = true;
/*  99 */     this.locations = null;
/*     */   }
/*     */   
/*     */   private enum Harvest {
/* 103 */     WHEAT((String)class_2246.field_10293),
/* 104 */     CARROTS((String)class_2246.field_10609),
/* 105 */     POTATOES((String)class_2246.field_10247),
/* 106 */     BEETROOT((String)class_2246.field_10341),
/* 107 */     PUMPKIN((String)class_2246.field_10261, state -> true),
/* 108 */     MELON((String)class_2246.field_10545, state -> true),
/*     */     
/* 110 */     SUGARCANE((String)class_2246.field_10424, null)
/*     */     {
/*     */       public boolean readyToHarvest(class_1937 world, class_2338 pos, class_2680 state) {
/* 113 */         if (((Boolean)(Baritone.settings()).replantCrops.value).booleanValue()) {
/* 114 */           return world.method_8320(pos.method_10074()).method_26204() instanceof net.minecraft.class_2523;
/*     */         }
/* 116 */         return true;
/*     */       }
/*     */     },
/* 119 */     CACTUS((String)class_2246.field_10029, null)
/*     */     {
/*     */       public boolean readyToHarvest(class_1937 world, class_2338 pos, class_2680 state) {
/* 122 */         if (((Boolean)(Baritone.settings()).replantCrops.value).booleanValue()) {
/* 123 */           return world.method_8320(pos.method_10074()).method_26204() instanceof net.minecraft.class_2266;
/*     */         }
/* 125 */         return true;
/*     */       } },
/*     */     NETHERWART((String)class_2246.field_10029, null);
/*     */     
/*     */     static {
/*     */       NETHERWART = new Harvest("NETHERWART", 6, class_2246.field_9974, state -> (((Integer)state.method_11654((class_2769)class_2421.field_11306)).intValue() >= 3));
/*     */     }
/*     */     
/*     */     public final class_2248 block;
/*     */     public final Predicate<class_2680> readyToHarvest;
/*     */     
/*     */     Harvest(class_2248 block, Predicate<class_2680> readyToHarvest) {
/* 137 */       this.block = block;
/* 138 */       this.readyToHarvest = readyToHarvest;
/*     */     }
/*     */     
/*     */     public boolean readyToHarvest(class_1937 world, class_2338 pos, class_2680 state) {
/* 142 */       return this.readyToHarvest.test(state);
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean readyForHarvest(class_1937 world, class_2338 pos, class_2680 state) {
/* 147 */     for (Harvest harvest : Harvest.values()) {
/* 148 */       if (harvest.block == state.method_26204()) {
/* 149 */         return harvest.readyToHarvest(world, pos, state);
/*     */       }
/*     */     } 
/* 152 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isPlantable(class_1799 stack) {
/* 156 */     return FARMLAND_PLANTABLE.contains(stack.method_7909());
/*     */   }
/*     */   
/*     */   private boolean isBoneMeal(class_1799 stack) {
/* 160 */     return (!stack.method_7960() && stack.method_7909().equals(class_1802.field_8324));
/*     */   }
/*     */   
/*     */   private boolean isNetherWart(class_1799 stack) {
/* 164 */     return (!stack.method_7960() && stack.method_7909().equals(class_1802.field_8790));
/*     */   }
/*     */ 
/*     */   
/*     */   public PathingCommand onTick(boolean calcFailed, boolean isSafeToCancel) {
/* 169 */     ArrayList<class_2248> scan = new ArrayList<>();
/* 170 */     for (Harvest harvest : Harvest.values()) {
/* 171 */       scan.add(harvest.block);
/*     */     }
/* 173 */     if (((Boolean)(Baritone.settings()).replantCrops.value).booleanValue()) {
/* 174 */       scan.add(class_2246.field_10362);
/* 175 */       if (((Boolean)(Baritone.settings()).replantNetherWart.value).booleanValue()) {
/* 176 */         scan.add(class_2246.field_10114);
/*     */       }
/*     */     } 
/*     */     
/* 180 */     if (((Integer)(Baritone.settings()).mineGoalUpdateInterval.value).intValue() != 0 && this.tickCount++ % ((Integer)(Baritone.settings()).mineGoalUpdateInterval.value).intValue() == 0) {
/* 181 */       Baritone.getExecutor().execute(() -> this.locations = WorldScanner.INSTANCE.scanChunkRadius(this.ctx, scan, 256, 10, 10));
/*     */     }
/* 183 */     if (this.locations == null) {
/* 184 */       return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
/*     */     }
/* 186 */     List<class_2338> toBreak = new ArrayList<>();
/* 187 */     List<class_2338> openFarmland = new ArrayList<>();
/* 188 */     List<class_2338> bonemealable = new ArrayList<>();
/* 189 */     List<class_2338> openSoulsand = new ArrayList<>();
/* 190 */     for (class_2338 pos : this.locations) {
/* 191 */       class_2680 state = this.ctx.world().method_8320(pos);
/* 192 */       boolean airAbove = this.ctx.world().method_8320(pos.method_10084()).method_26204() instanceof net.minecraft.class_2189;
/* 193 */       if (state.method_26204() == class_2246.field_10362) {
/* 194 */         if (airAbove) {
/* 195 */           openFarmland.add(pos);
/*     */         }
/*     */         continue;
/*     */       } 
/* 199 */       if (state.method_26204() == class_2246.field_10114) {
/* 200 */         if (airAbove) {
/* 201 */           openSoulsand.add(pos);
/*     */         }
/*     */         continue;
/*     */       } 
/* 205 */       if (readyForHarvest(this.ctx.world(), pos, state)) {
/* 206 */         toBreak.add(pos);
/*     */         continue;
/*     */       } 
/* 209 */       if (state.method_26204() instanceof class_2256) {
/* 210 */         class_2256 ig = (class_2256)state.method_26204();
/* 211 */         if (ig.method_9651((class_1922)this.ctx.world(), pos, state, true) && ig.method_9650(this.ctx.world(), (this.ctx.world()).field_9229, pos, state)) {
/* 212 */           bonemealable.add(pos);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 217 */     this.baritone.getInputOverrideHandler().clearAllKeys();
/* 218 */     for (class_2338 pos : toBreak) {
/* 219 */       Optional<Rotation> rot = RotationUtils.reachable(this.ctx, pos);
/* 220 */       if (rot.isPresent() && isSafeToCancel) {
/* 221 */         this.baritone.getLookBehavior().updateTarget(rot.get(), true);
/* 222 */         MovementHelper.switchToBestToolFor(this.ctx, this.ctx.world().method_8320(pos));
/* 223 */         if (this.ctx.isLookingAt(pos)) {
/* 224 */           this.baritone.getInputOverrideHandler().setInputForceState(Input.CLICK_LEFT, true);
/*     */         }
/* 226 */         return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
/*     */       } 
/*     */     } 
/* 229 */     ArrayList<class_2338> both = new ArrayList<>(openFarmland);
/* 230 */     both.addAll(openSoulsand);
/* 231 */     for (class_2338 pos : both) {
/* 232 */       boolean soulsand = openSoulsand.contains(pos);
/* 233 */       Optional<Rotation> rot = RotationUtils.reachableOffset((class_1297)this.ctx.player(), pos, new class_243(pos.method_10263() + 0.5D, (pos.method_10264() + 1), pos.method_10260() + 0.5D), this.ctx.playerController().getBlockReachDistance(), false);
/* 234 */       if (rot.isPresent() && isSafeToCancel && this.baritone.getInventoryBehavior().throwaway(true, soulsand ? this::isNetherWart : this::isPlantable)) {
/* 235 */         class_239 result = RayTraceUtils.rayTraceTowards((class_1297)this.ctx.player(), rot.get(), this.ctx.playerController().getBlockReachDistance());
/* 236 */         if (result instanceof class_3965 && ((class_3965)result).method_17780() == class_2350.field_11036) {
/* 237 */           this.baritone.getLookBehavior().updateTarget(rot.get(), true);
/* 238 */           if (this.ctx.isLookingAt(pos)) {
/* 239 */             this.baritone.getInputOverrideHandler().setInputForceState(Input.CLICK_RIGHT, true);
/*     */           }
/* 241 */           return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
/*     */         } 
/*     */       } 
/*     */     } 
/* 245 */     for (class_2338 pos : bonemealable) {
/* 246 */       Optional<Rotation> rot = RotationUtils.reachable(this.ctx, pos);
/* 247 */       if (rot.isPresent() && isSafeToCancel && this.baritone.getInventoryBehavior().throwaway(true, this::isBoneMeal)) {
/* 248 */         this.baritone.getLookBehavior().updateTarget(rot.get(), true);
/* 249 */         if (this.ctx.isLookingAt(pos)) {
/* 250 */           this.baritone.getInputOverrideHandler().setInputForceState(Input.CLICK_RIGHT, true);
/*     */         }
/* 252 */         return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
/*     */       } 
/*     */     } 
/*     */     
/* 256 */     if (calcFailed) {
/* 257 */       logDirect("Farm failed");
/* 258 */       if (((Boolean)(Baritone.settings()).desktopNotifications.value).booleanValue() && ((Boolean)(Baritone.settings()).notificationOnFarmFail.value).booleanValue()) {
/* 259 */         NotificationHelper.notify("Farm failed", true);
/*     */       }
/* 261 */       onLostControl();
/* 262 */       return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
/*     */     } 
/*     */     
/* 265 */     List<Goal> goalz = new ArrayList<>();
/* 266 */     for (class_2338 pos : toBreak) {
/* 267 */       goalz.add(new BuilderProcess.GoalBreak(pos));
/*     */     }
/* 269 */     if (this.baritone.getInventoryBehavior().throwaway(false, this::isPlantable)) {
/* 270 */       for (class_2338 pos : openFarmland) {
/* 271 */         goalz.add(new GoalBlock(pos.method_10084()));
/*     */       }
/*     */     }
/* 274 */     if (this.baritone.getInventoryBehavior().throwaway(false, this::isNetherWart)) {
/* 275 */       for (class_2338 pos : openSoulsand) {
/* 276 */         goalz.add(new GoalBlock(pos.method_10084()));
/*     */       }
/*     */     }
/* 279 */     if (this.baritone.getInventoryBehavior().throwaway(false, this::isBoneMeal)) {
/* 280 */       for (class_2338 pos : bonemealable) {
/* 281 */         goalz.add(new GoalBlock(pos));
/*     */       }
/*     */     }
/* 284 */     for (class_1297 entity : this.ctx.entities()) {
/* 285 */       if (entity instanceof class_1542 && entity.method_24828()) {
/* 286 */         class_1542 ei = (class_1542)entity;
/* 287 */         if (PICKUP_DROPPED.contains(ei.method_6983().method_7909()))
/*     */         {
/* 289 */           goalz.add(new GoalBlock(new class_2338(entity.method_23317(), entity.method_23318() + 0.1D, entity.method_23321())));
/*     */         }
/*     */       } 
/*     */     } 
/* 293 */     return new PathingCommand((Goal)new GoalComposite(goalz.<Goal>toArray(new Goal[0])), PathingCommandType.SET_GOAL_AND_PATH);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onLostControl() {
/* 298 */     this.active = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public String displayName0() {
/* 303 */     return "Farming";
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\process\FarmProcess.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */