/*     */ package baritone.process;
/*     */ 
/*     */ import baritone.Baritone;
/*     */ import baritone.api.pathing.goals.Goal;
/*     */ import baritone.api.pathing.goals.GoalComposite;
/*     */ import baritone.api.pathing.goals.GoalNear;
/*     */ import baritone.api.pathing.goals.GoalXZ;
/*     */ import baritone.api.process.IFollowProcess;
/*     */ import baritone.api.process.PathingCommand;
/*     */ import baritone.api.process.PathingCommandType;
/*     */ import baritone.utils.BaritoneProcessHelper;
/*     */ import java.util.List;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.stream.Collectors;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_2338;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FollowProcess
/*     */   extends BaritoneProcessHelper
/*     */   implements IFollowProcess
/*     */ {
/*     */   private Predicate<class_1297> filter;
/*     */   private List<class_1297> cache;
/*     */   
/*     */   public FollowProcess(Baritone baritone) {
/*  47 */     super(baritone);
/*     */   }
/*     */ 
/*     */   
/*     */   public PathingCommand onTick(boolean calcFailed, boolean isSafeToCancel) {
/*  52 */     scanWorld();
/*  53 */     GoalComposite goalComposite = new GoalComposite((Goal[])this.cache.stream().map(this::towards).toArray(x$0 -> new Goal[x$0]));
/*  54 */     return new PathingCommand((Goal)goalComposite, PathingCommandType.REVALIDATE_GOAL_AND_PATH);
/*     */   }
/*     */   
/*     */   private Goal towards(class_1297 following) {
/*     */     class_2338 pos;
/*  59 */     if (((Double)(Baritone.settings()).followOffsetDistance.value).doubleValue() == 0.0D) {
/*  60 */       pos = following.method_24515();
/*     */     } else {
/*  62 */       GoalXZ g = GoalXZ.fromDirection(following.method_19538(), ((Float)(Baritone.settings()).followOffsetDirection.value).floatValue(), ((Double)(Baritone.settings()).followOffsetDistance.value).doubleValue());
/*  63 */       pos = new class_2338(g.getX(), following.method_23318(), g.getZ());
/*     */     } 
/*  65 */     return (Goal)new GoalNear(pos, ((Integer)(Baritone.settings()).followRadius.value).intValue());
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean followable(class_1297 entity) {
/*  70 */     if (entity == null) {
/*  71 */       return false;
/*     */     }
/*  73 */     if (!entity.method_5805()) {
/*  74 */       return false;
/*     */     }
/*  76 */     if (entity.equals(this.ctx.player())) {
/*  77 */       return false;
/*     */     }
/*  79 */     return this.ctx.entitiesStream().anyMatch(entity::equals);
/*     */   }
/*     */   
/*     */   private void scanWorld() {
/*  83 */     this
/*     */ 
/*     */ 
/*     */       
/*  87 */       .cache = (List<class_1297>)this.ctx.entitiesStream().filter(this::followable).filter(this.filter).distinct().collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isActive() {
/*  92 */     if (this.filter == null) {
/*  93 */       return false;
/*     */     }
/*  95 */     scanWorld();
/*  96 */     return !this.cache.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onLostControl() {
/* 101 */     this.filter = null;
/* 102 */     this.cache = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String displayName0() {
/* 107 */     return "Following " + this.cache;
/*     */   }
/*     */ 
/*     */   
/*     */   public void follow(Predicate<class_1297> filter) {
/* 112 */     this.filter = filter;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<class_1297> following() {
/* 117 */     return this.cache;
/*     */   }
/*     */ 
/*     */   
/*     */   public Predicate<class_1297> currentFilter() {
/* 122 */     return this.filter;
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\process\FollowProcess.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */