/*     */ package baritone.process;
/*     */ 
/*     */ import baritone.Baritone;
/*     */ import baritone.api.cache.ICachedWorld;
/*     */ import baritone.api.pathing.goals.Goal;
/*     */ import baritone.api.pathing.goals.GoalComposite;
/*     */ import baritone.api.pathing.goals.GoalXZ;
/*     */ import baritone.api.pathing.goals.GoalYLevel;
/*     */ import baritone.api.process.IExploreProcess;
/*     */ import baritone.api.process.PathingCommand;
/*     */ import baritone.api.process.PathingCommandType;
/*     */ import baritone.api.utils.MyChunkPos;
/*     */ import baritone.cache.CachedWorld;
/*     */ import baritone.utils.BaritoneProcessHelper;
/*     */ import baritone.utils.NotificationHelper;
/*     */ import com.google.gson.Gson;
/*     */ import com.google.gson.GsonBuilder;
/*     */ import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
/*     */ import java.io.InputStreamReader;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import net.minecraft.class_1923;
/*     */ import net.minecraft.class_2338;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ExploreProcess
/*     */   extends BaritoneProcessHelper
/*     */   implements IExploreProcess
/*     */ {
/*     */   private class_2338 explorationOrigin;
/*     */   private IChunkFilter filter;
/*     */   private int distanceCompleted;
/*     */   
/*     */   public ExploreProcess(Baritone baritone) {
/*  54 */     super(baritone);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isActive() {
/*  59 */     return (this.explorationOrigin != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void explore(int centerX, int centerZ) {
/*  64 */     this.explorationOrigin = new class_2338(centerX, 0, centerZ);
/*  65 */     this.distanceCompleted = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void applyJsonFilter(Path path, boolean invert) throws Exception {
/*  70 */     this.filter = new JsonChunkFilter(path, invert);
/*     */   }
/*     */   
/*     */   public IChunkFilter calcFilter() {
/*     */     IChunkFilter filter;
/*  75 */     if (this.filter != null) {
/*  76 */       filter = new EitherChunk(this.filter, new BaritoneChunkCache());
/*     */     } else {
/*  78 */       filter = new BaritoneChunkCache();
/*     */     } 
/*  80 */     return filter;
/*     */   }
/*     */ 
/*     */   
/*     */   public PathingCommand onTick(boolean calcFailed, boolean isSafeToCancel) {
/*  85 */     if (calcFailed) {
/*  86 */       logDirect("Failed");
/*  87 */       if (((Boolean)(Baritone.settings()).desktopNotifications.value).booleanValue() && ((Boolean)(Baritone.settings()).notificationOnExploreFinished.value).booleanValue()) {
/*  88 */         NotificationHelper.notify("Exploration failed", true);
/*     */       }
/*  90 */       onLostControl();
/*  91 */       return null;
/*     */     } 
/*  93 */     IChunkFilter filter = calcFilter();
/*  94 */     if (!((Boolean)(Baritone.settings()).disableCompletionCheck.value).booleanValue() && filter.countRemain() == 0) {
/*  95 */       logDirect("Explored all chunks");
/*  96 */       if (((Boolean)(Baritone.settings()).desktopNotifications.value).booleanValue() && ((Boolean)(Baritone.settings()).notificationOnExploreFinished.value).booleanValue()) {
/*  97 */         NotificationHelper.notify("Explored all chunks", false);
/*     */       }
/*  99 */       onLostControl();
/* 100 */       return null;
/*     */     } 
/* 102 */     Goal[] closestUncached = closestUncachedChunks(this.explorationOrigin, filter);
/* 103 */     if (closestUncached == null) {
/* 104 */       logDebug("awaiting region load from disk");
/* 105 */       return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
/*     */     } 
/* 107 */     return new PathingCommand((Goal)new GoalComposite(closestUncached), PathingCommandType.FORCE_REVALIDATE_GOAL_AND_PATH);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Goal[] closestUncachedChunks(class_2338 center, IChunkFilter filter) {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: invokevirtual method_10263 : ()I
/*     */     //   4: iconst_4
/*     */     //   5: ishr
/*     */     //   6: istore_3
/*     */     //   7: aload_1
/*     */     //   8: invokevirtual method_10260 : ()I
/*     */     //   11: iconst_4
/*     */     //   12: ishr
/*     */     //   13: istore #4
/*     */     //   15: aload_2
/*     */     //   16: invokeinterface countRemain : ()I
/*     */     //   21: invokestatic settings : ()Lbaritone/api/Settings;
/*     */     //   24: getfield exploreChunkSetMinimumSize : Lbaritone/api/Settings$Setting;
/*     */     //   27: getfield value : Ljava/lang/Object;
/*     */     //   30: checkcast java/lang/Integer
/*     */     //   33: invokevirtual intValue : ()I
/*     */     //   36: invokestatic min : (II)I
/*     */     //   39: istore #5
/*     */     //   41: new java/util/ArrayList
/*     */     //   44: dup
/*     */     //   45: invokespecial <init> : ()V
/*     */     //   48: astore #6
/*     */     //   50: invokestatic settings : ()Lbaritone/api/Settings;
/*     */     //   53: getfield worldExploringChunkOffset : Lbaritone/api/Settings$Setting;
/*     */     //   56: getfield value : Ljava/lang/Object;
/*     */     //   59: checkcast java/lang/Integer
/*     */     //   62: invokevirtual intValue : ()I
/*     */     //   65: istore #7
/*     */     //   67: aload_0
/*     */     //   68: getfield distanceCompleted : I
/*     */     //   71: istore #8
/*     */     //   73: iload #8
/*     */     //   75: ineg
/*     */     //   76: istore #9
/*     */     //   78: iload #9
/*     */     //   80: iload #8
/*     */     //   82: if_icmpgt -> 305
/*     */     //   85: iload #8
/*     */     //   87: iload #9
/*     */     //   89: invokestatic abs : (I)I
/*     */     //   92: isub
/*     */     //   93: istore #10
/*     */     //   95: iconst_0
/*     */     //   96: istore #11
/*     */     //   98: iload #11
/*     */     //   100: iconst_2
/*     */     //   101: if_icmpge -> 299
/*     */     //   104: iload #11
/*     */     //   106: iconst_2
/*     */     //   107: imul
/*     */     //   108: iconst_1
/*     */     //   109: isub
/*     */     //   110: iload #10
/*     */     //   112: imul
/*     */     //   113: istore #12
/*     */     //   115: iload #9
/*     */     //   117: invokestatic abs : (I)I
/*     */     //   120: iload #12
/*     */     //   122: invokestatic abs : (I)I
/*     */     //   125: iadd
/*     */     //   126: istore #13
/*     */     //   128: iload #13
/*     */     //   130: iload #8
/*     */     //   132: if_icmpeq -> 143
/*     */     //   135: new java/lang/IllegalStateException
/*     */     //   138: dup
/*     */     //   139: invokespecial <init> : ()V
/*     */     //   142: athrow
/*     */     //   143: getstatic baritone/process/ExploreProcess$2.$SwitchMap$baritone$process$ExploreProcess$Status : [I
/*     */     //   146: aload_2
/*     */     //   147: iload_3
/*     */     //   148: iload #9
/*     */     //   150: iadd
/*     */     //   151: iload #4
/*     */     //   153: iload #12
/*     */     //   155: iadd
/*     */     //   156: invokeinterface isAlreadyExplored : (II)Lbaritone/process/ExploreProcess$Status;
/*     */     //   161: invokevirtual ordinal : ()I
/*     */     //   164: iaload
/*     */     //   165: tableswitch default -> 200, 1 -> 192, 2 -> 194, 3 -> 197
/*     */     //   192: aconst_null
/*     */     //   193: areturn
/*     */     //   194: goto -> 200
/*     */     //   197: goto -> 293
/*     */     //   200: iload_3
/*     */     //   201: iload #9
/*     */     //   203: iadd
/*     */     //   204: iconst_4
/*     */     //   205: ishl
/*     */     //   206: bipush #8
/*     */     //   208: iadd
/*     */     //   209: istore #14
/*     */     //   211: iload #4
/*     */     //   213: iload #12
/*     */     //   215: iadd
/*     */     //   216: iconst_4
/*     */     //   217: ishl
/*     */     //   218: bipush #8
/*     */     //   220: iadd
/*     */     //   221: istore #15
/*     */     //   223: iload #7
/*     */     //   225: iconst_4
/*     */     //   226: ishl
/*     */     //   227: istore #16
/*     */     //   229: iload #9
/*     */     //   231: ifge -> 244
/*     */     //   234: iload #14
/*     */     //   236: iload #16
/*     */     //   238: isub
/*     */     //   239: istore #14
/*     */     //   241: goto -> 251
/*     */     //   244: iload #14
/*     */     //   246: iload #16
/*     */     //   248: iadd
/*     */     //   249: istore #14
/*     */     //   251: iload #12
/*     */     //   253: ifge -> 266
/*     */     //   256: iload #15
/*     */     //   258: iload #16
/*     */     //   260: isub
/*     */     //   261: istore #15
/*     */     //   263: goto -> 273
/*     */     //   266: iload #15
/*     */     //   268: iload #16
/*     */     //   270: iadd
/*     */     //   271: istore #15
/*     */     //   273: aload #6
/*     */     //   275: new net/minecraft/class_2338
/*     */     //   278: dup
/*     */     //   279: iload #14
/*     */     //   281: iconst_0
/*     */     //   282: iload #15
/*     */     //   284: invokespecial <init> : (III)V
/*     */     //   287: invokeinterface add : (Ljava/lang/Object;)Z
/*     */     //   292: pop
/*     */     //   293: iinc #11, 1
/*     */     //   296: goto -> 98
/*     */     //   299: iinc #9, 1
/*     */     //   302: goto -> 78
/*     */     //   305: iload #8
/*     */     //   307: bipush #10
/*     */     //   309: irem
/*     */     //   310: ifne -> 339
/*     */     //   313: aload_2
/*     */     //   314: invokeinterface countRemain : ()I
/*     */     //   319: invokestatic settings : ()Lbaritone/api/Settings;
/*     */     //   322: getfield exploreChunkSetMinimumSize : Lbaritone/api/Settings$Setting;
/*     */     //   325: getfield value : Ljava/lang/Object;
/*     */     //   328: checkcast java/lang/Integer
/*     */     //   331: invokevirtual intValue : ()I
/*     */     //   334: invokestatic min : (II)I
/*     */     //   337: istore #5
/*     */     //   339: aload #6
/*     */     //   341: invokeinterface size : ()I
/*     */     //   346: iload #5
/*     */     //   348: if_icmplt -> 382
/*     */     //   351: aload #6
/*     */     //   353: invokeinterface stream : ()Ljava/util/stream/Stream;
/*     */     //   358: <illegal opcode> apply : ()Ljava/util/function/Function;
/*     */     //   363: invokeinterface map : (Ljava/util/function/Function;)Ljava/util/stream/Stream;
/*     */     //   368: <illegal opcode> apply : ()Ljava/util/function/IntFunction;
/*     */     //   373: invokeinterface toArray : (Ljava/util/function/IntFunction;)[Ljava/lang/Object;
/*     */     //   378: checkcast [Lbaritone/api/pathing/goals/Goal;
/*     */     //   381: areturn
/*     */     //   382: aload #6
/*     */     //   384: invokeinterface isEmpty : ()Z
/*     */     //   389: ifeq -> 400
/*     */     //   392: aload_0
/*     */     //   393: iload #8
/*     */     //   395: iconst_1
/*     */     //   396: iadd
/*     */     //   397: putfield distanceCompleted : I
/*     */     //   400: iinc #8, 1
/*     */     //   403: goto -> 73
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #111	-> 0
/*     */     //   #112	-> 7
/*     */     //   #113	-> 15
/*     */     //   #114	-> 41
/*     */     //   #115	-> 50
/*     */     //   #116	-> 67
/*     */     //   #117	-> 73
/*     */     //   #118	-> 85
/*     */     //   #119	-> 95
/*     */     //   #120	-> 104
/*     */     //   #121	-> 115
/*     */     //   #122	-> 128
/*     */     //   #123	-> 135
/*     */     //   #125	-> 143
/*     */     //   #127	-> 192
/*     */     //   #129	-> 194
/*     */     //   #131	-> 197
/*     */     //   #134	-> 200
/*     */     //   #135	-> 211
/*     */     //   #136	-> 223
/*     */     //   #137	-> 229
/*     */     //   #138	-> 234
/*     */     //   #140	-> 244
/*     */     //   #142	-> 251
/*     */     //   #143	-> 256
/*     */     //   #145	-> 266
/*     */     //   #147	-> 273
/*     */     //   #119	-> 293
/*     */     //   #117	-> 299
/*     */     //   #150	-> 305
/*     */     //   #151	-> 313
/*     */     //   #153	-> 339
/*     */     //   #154	-> 351
/*     */     //   #156	-> 382
/*     */     //   #159	-> 392
/*     */     //   #116	-> 400
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   115	178	12	dz	I
/*     */     //   128	165	13	trueDist	I
/*     */     //   211	82	14	centerX	I
/*     */     //   223	70	15	centerZ	I
/*     */     //   229	64	16	offset	I
/*     */     //   98	201	11	mult	I
/*     */     //   95	204	10	zval	I
/*     */     //   78	227	9	dx	I
/*     */     //   73	333	8	dist	I
/*     */     //   0	406	0	this	Lbaritone/process/ExploreProcess;
/*     */     //   0	406	1	center	Lnet/minecraft/class_2338;
/*     */     //   0	406	2	filter	Lbaritone/process/ExploreProcess$IChunkFilter;
/*     */     //   7	399	3	chunkX	I
/*     */     //   15	391	4	chunkZ	I
/*     */     //   41	365	5	count	I
/*     */     //   50	356	6	centers	Ljava/util/List;
/*     */     //   67	339	7	renderDistance	I
/*     */     // Local variable type table:
/*     */     //   start	length	slot	name	signature
/*     */     //   50	356	6	centers	Ljava/util/List<Lnet/minecraft/class_2338;>;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Goal createGoal(int x, int z) {
/* 165 */     if (((Integer)(Baritone.settings()).exploreMaintainY.value).intValue() == -1) {
/* 166 */       return (Goal)new GoalXZ(x, z);
/*     */     }
/*     */ 
/*     */     
/* 170 */     return (Goal)new GoalXZ(x, z)
/*     */       {
/*     */         public double heuristic(int x, int y, int z) {
/* 173 */           return super.heuristic(x, y, z) + GoalYLevel.calculate(((Integer)(Baritone.settings()).exploreMaintainY.value).intValue(), y);
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   private enum Status {
/* 179 */     EXPLORED, NOT_EXPLORED, UNKNOWN;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class BaritoneChunkCache
/*     */     implements IChunkFilter
/*     */   {
/* 191 */     private final ICachedWorld cache = ExploreProcess.this.baritone.getWorldProvider().getCurrentWorld().getCachedWorld();
/*     */ 
/*     */     
/*     */     public ExploreProcess.Status isAlreadyExplored(int chunkX, int chunkZ) {
/* 195 */       int centerX = chunkX << 4;
/* 196 */       int centerZ = chunkZ << 4;
/* 197 */       if (this.cache.isCached(centerX, centerZ)) {
/* 198 */         return ExploreProcess.Status.EXPLORED;
/*     */       }
/* 200 */       if (!((CachedWorld)this.cache).regionLoaded(centerX, centerZ)) {
/* 201 */         Baritone.getExecutor().execute(() -> ((CachedWorld)this.cache).tryLoadFromDisk(centerX >> 9, centerZ >> 9));
/*     */ 
/*     */         
/* 204 */         return ExploreProcess.Status.UNKNOWN;
/*     */       } 
/* 206 */       return ExploreProcess.Status.NOT_EXPLORED;
/*     */     }
/*     */ 
/*     */     
/*     */     public int countRemain() {
/* 211 */       return Integer.MAX_VALUE;
/*     */     }
/*     */     
/*     */     private BaritoneChunkCache() {} }
/*     */   
/*     */   private class JsonChunkFilter implements IChunkFilter {
/*     */     private final boolean invert;
/*     */     private final LongOpenHashSet inFilter;
/*     */     private final MyChunkPos[] positions;
/*     */     
/*     */     private JsonChunkFilter(Path path, boolean invert) throws Exception {
/* 222 */       this.invert = invert;
/* 223 */       Gson gson = (new GsonBuilder()).create();
/* 224 */       this.positions = (MyChunkPos[])gson.fromJson(new InputStreamReader(Files.newInputStream(path, new java.nio.file.OpenOption[0])), MyChunkPos[].class);
/* 225 */       ExploreProcess.this.logDirect("Loaded " + this.positions.length + " positions");
/* 226 */       this.inFilter = new LongOpenHashSet();
/* 227 */       for (MyChunkPos mcp : this.positions) {
/* 228 */         this.inFilter.add(class_1923.method_8331(mcp.x, mcp.z));
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public ExploreProcess.Status isAlreadyExplored(int chunkX, int chunkZ) {
/* 234 */       if ((this.inFilter.contains(class_1923.method_8331(chunkX, chunkZ)) ^ this.invert) != 0)
/*     */       {
/*     */         
/* 237 */         return ExploreProcess.Status.EXPLORED;
/*     */       }
/*     */ 
/*     */       
/* 241 */       return ExploreProcess.Status.UNKNOWN;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int countRemain() {
/* 247 */       if (!this.invert)
/*     */       {
/* 249 */         return Integer.MAX_VALUE;
/*     */       }
/*     */ 
/*     */       
/* 253 */       int countRemain = 0;
/* 254 */       ExploreProcess.BaritoneChunkCache bcc = new ExploreProcess.BaritoneChunkCache();
/* 255 */       for (MyChunkPos pos : this.positions) {
/* 256 */         if (bcc.isAlreadyExplored(pos.x, pos.z) != ExploreProcess.Status.EXPLORED) {
/*     */           
/* 258 */           countRemain++;
/* 259 */           if (countRemain >= ((Integer)(Baritone.settings()).exploreChunkSetMinimumSize.value).intValue()) {
/* 260 */             return countRemain;
/*     */           }
/*     */         } 
/*     */       } 
/* 264 */       return countRemain;
/*     */     }
/*     */   }
/*     */   
/*     */   private class EitherChunk
/*     */     implements IChunkFilter {
/*     */     private final ExploreProcess.IChunkFilter a;
/*     */     private final ExploreProcess.IChunkFilter b;
/*     */     
/*     */     private EitherChunk(ExploreProcess.IChunkFilter a, ExploreProcess.IChunkFilter b) {
/* 274 */       this.a = a;
/* 275 */       this.b = b;
/*     */     }
/*     */ 
/*     */     
/*     */     public ExploreProcess.Status isAlreadyExplored(int chunkX, int chunkZ) {
/* 280 */       if (this.a.isAlreadyExplored(chunkX, chunkZ) == ExploreProcess.Status.EXPLORED) {
/* 281 */         return ExploreProcess.Status.EXPLORED;
/*     */       }
/* 283 */       return this.b.isAlreadyExplored(chunkX, chunkZ);
/*     */     }
/*     */ 
/*     */     
/*     */     public int countRemain() {
/* 288 */       return Math.min(this.a.countRemain(), this.b.countRemain());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void onLostControl() {
/* 294 */     this.explorationOrigin = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String displayName0() {
/* 299 */     return "Exploring around " + this.explorationOrigin + ", distance completed " + this.distanceCompleted + ", currently going to " + new GoalComposite(closestUncachedChunks(this.explorationOrigin, calcFilter()));
/*     */   }
/*     */   
/*     */   private static interface IChunkFilter {
/*     */     ExploreProcess.Status isAlreadyExplored(int param1Int1, int param1Int2);
/*     */     
/*     */     int countRemain();
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\process\ExploreProcess.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */