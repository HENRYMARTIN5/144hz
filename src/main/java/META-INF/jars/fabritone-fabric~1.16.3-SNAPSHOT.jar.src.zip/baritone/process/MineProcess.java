/*     */ package baritone.process;
/*     */ 
/*     */ import baritone.Baritone;
/*     */ import baritone.api.IBaritone;
/*     */ import baritone.api.pathing.goals.Goal;
/*     */ import baritone.api.pathing.goals.GoalBlock;
/*     */ import baritone.api.pathing.goals.GoalComposite;
/*     */ import baritone.api.pathing.goals.GoalRunAway;
/*     */ import baritone.api.pathing.goals.GoalTwoBlocks;
/*     */ import baritone.api.process.IMineProcess;
/*     */ import baritone.api.process.PathingCommand;
/*     */ import baritone.api.process.PathingCommandType;
/*     */ import baritone.api.utils.BetterBlockPos;
/*     */ import baritone.api.utils.BlockOptionalMeta;
/*     */ import baritone.api.utils.BlockOptionalMetaLookup;
/*     */ import baritone.api.utils.BlockUtils;
/*     */ import baritone.api.utils.Rotation;
/*     */ import baritone.api.utils.RotationUtils;
/*     */ import baritone.api.utils.input.Input;
/*     */ import baritone.cache.CachedChunk;
/*     */ import baritone.cache.WorldScanner;
/*     */ import baritone.pathing.movement.CalculationContext;
/*     */ import baritone.pathing.movement.MovementHelper;
/*     */ import baritone.utils.BaritoneProcessHelper;
/*     */ import baritone.utils.BlockStateInterface;
/*     */ import baritone.utils.NotificationHelper;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.stream.Collectors;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1542;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2248;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2382;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_638;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MineProcess
/*     */   extends BaritoneProcessHelper
/*     */   implements IMineProcess
/*     */ {
/*     */   private static final int ORE_LOCATIONS_COUNT = 64;
/*     */   private BlockOptionalMetaLookup filter;
/*     */   private List<class_2338> knownOreLocations;
/*     */   private List<class_2338> blacklist;
/*     */   private Map<class_2338, Long> anticipatedDrops;
/*     */   private class_2338 branchPoint;
/*     */   private GoalRunAway branchPointRunaway;
/*     */   private int desiredQuantity;
/*     */   private int tickCount;
/*     */   
/*     */   public MineProcess(Baritone baritone) {
/*  65 */     super(baritone);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isActive() {
/*  70 */     return (this.filter != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public PathingCommand onTick(boolean calcFailed, boolean isSafeToCancel) {
/*  75 */     if (this.desiredQuantity > 0) {
/*     */ 
/*     */       
/*  78 */       int i = (this.ctx.player()).field_7514.field_7547.stream().filter(stack -> this.filter.has(stack)).mapToInt(class_1799::method_7947).sum();
/*  79 */       System.out.println("Currently have " + i + " valid items");
/*  80 */       if (i >= this.desiredQuantity) {
/*  81 */         logDirect("Have " + i + " valid items");
/*  82 */         cancel();
/*  83 */         return null;
/*     */       } 
/*     */     } 
/*  86 */     if (calcFailed) {
/*  87 */       if (!this.knownOreLocations.isEmpty() && ((Boolean)(Baritone.settings()).blacklistClosestOnFailure.value).booleanValue()) {
/*  88 */         logDirect("Unable to find any path to " + this.filter + ", blacklisting presumably unreachable closest instance...");
/*  89 */         if (((Boolean)(Baritone.settings()).desktopNotifications.value).booleanValue() && ((Boolean)(Baritone.settings()).notificationOnMineFail.value).booleanValue()) {
/*  90 */           NotificationHelper.notify("Unable to find any path to " + this.filter + ", blacklisting presumably unreachable closest instance...", true);
/*     */         }
/*  92 */         this.knownOreLocations.stream().min(Comparator.comparingDouble(this.ctx.playerFeet()::method_10262)).ifPresent(this.blacklist::add);
/*  93 */         this.knownOreLocations.removeIf(this.blacklist::contains);
/*     */       } else {
/*  95 */         logDirect("Unable to find any path to " + this.filter + ", canceling mine");
/*  96 */         if (((Boolean)(Baritone.settings()).desktopNotifications.value).booleanValue() && ((Boolean)(Baritone.settings()).notificationOnMineFail.value).booleanValue()) {
/*  97 */           NotificationHelper.notify("Unable to find any path to " + this.filter + ", canceling mine", true);
/*     */         }
/*  99 */         cancel();
/* 100 */         return null;
/*     */       } 
/*     */     }
/* 103 */     if (!((Boolean)(Baritone.settings()).allowBreak.value).booleanValue()) {
/* 104 */       logDirect("Unable to mine when allowBreak is false!");
/* 105 */       cancel();
/* 106 */       return null;
/*     */     } 
/* 108 */     updateLoucaSystem();
/* 109 */     int mineGoalUpdateInterval = ((Integer)(Baritone.settings()).mineGoalUpdateInterval.value).intValue();
/* 110 */     List<class_2338> curr = new ArrayList<>(this.knownOreLocations);
/* 111 */     if (mineGoalUpdateInterval != 0 && this.tickCount++ % mineGoalUpdateInterval == 0) {
/* 112 */       CalculationContext context = new CalculationContext((IBaritone)this.baritone, true);
/* 113 */       Baritone.getExecutor().execute(() -> rescan(curr, context));
/*     */     } 
/* 115 */     if (((Boolean)(Baritone.settings()).legitMine.value).booleanValue()) {
/* 116 */       addNearby();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 122 */     Optional<class_2338> shaft = curr.stream().filter(pos -> (pos.method_10263() == this.ctx.playerFeet().method_10263() && pos.method_10260() == this.ctx.playerFeet().method_10260())).filter(pos -> (pos.method_10264() >= this.ctx.playerFeet().method_10264())).filter(pos -> !(BlockStateInterface.get(this.ctx, pos).method_26204() instanceof net.minecraft.class_2189)).min(Comparator.comparingDouble(this.ctx.playerFeet()::method_10262));
/* 123 */     this.baritone.getInputOverrideHandler().clearAllKeys();
/* 124 */     if (shaft.isPresent() && this.ctx.player().method_24828()) {
/* 125 */       class_2338 pos = shaft.get();
/* 126 */       class_2680 state = this.baritone.bsi.get0(pos);
/* 127 */       if (!MovementHelper.avoidBreaking(this.baritone.bsi, pos.method_10263(), pos.method_10264(), pos.method_10260(), state)) {
/* 128 */         Optional<Rotation> rot = RotationUtils.reachable(this.ctx, pos);
/* 129 */         if (rot.isPresent() && isSafeToCancel) {
/* 130 */           this.baritone.getLookBehavior().updateTarget(rot.get(), true);
/* 131 */           MovementHelper.switchToBestToolFor(this.ctx, this.ctx.world().method_8320(pos));
/* 132 */           if (this.ctx.isLookingAt(pos) || this.ctx.playerRotations().isReallyCloseTo(rot.get())) {
/* 133 */             this.baritone.getInputOverrideHandler().setInputForceState(Input.CLICK_LEFT, true);
/*     */           }
/* 135 */           return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
/*     */         } 
/*     */       } 
/*     */     } 
/* 139 */     PathingCommand command = updateGoal();
/* 140 */     if (command == null) {
/*     */ 
/*     */       
/* 143 */       cancel();
/* 144 */       return null;
/*     */     } 
/* 146 */     return command;
/*     */   }
/*     */ 
/*     */   
/*     */   private void updateLoucaSystem() {
/* 151 */     Map<class_2338, Long> copy = new HashMap<>(this.anticipatedDrops);
/* 152 */     this.ctx.getSelectedBlock().ifPresent(pos -> {
/*     */           if (this.knownOreLocations.contains(pos)) {
/*     */             copy.put(pos, Long.valueOf(System.currentTimeMillis() + ((Long)(Baritone.settings()).mineDropLoiterDurationMSThanksLouca.value).longValue()));
/*     */           }
/*     */         });
/*     */ 
/*     */     
/* 159 */     for (class_2338 pos : this.anticipatedDrops.keySet()) {
/* 160 */       if (((Long)copy.get(pos)).longValue() < System.currentTimeMillis()) {
/* 161 */         copy.remove(pos);
/*     */       }
/*     */     } 
/* 164 */     this.anticipatedDrops = copy;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onLostControl() {
/* 169 */     mine(0, (BlockOptionalMetaLookup)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public String displayName0() {
/* 174 */     return "Mine " + this.filter;
/*     */   }
/*     */   
/*     */   private PathingCommand updateGoal() {
/* 178 */     boolean legit = ((Boolean)(Baritone.settings()).legitMine.value).booleanValue();
/* 179 */     List<class_2338> locs = this.knownOreLocations;
/* 180 */     if (!locs.isEmpty()) {
/* 181 */       CalculationContext context = new CalculationContext((IBaritone)this.baritone);
/* 182 */       List<class_2338> locs2 = prune(context, new ArrayList<>(locs), this.filter, 64, this.blacklist, droppedItemsScan());
/*     */       
/* 184 */       GoalComposite goalComposite = new GoalComposite((Goal[])locs2.stream().map(loc -> coalesce(loc, locs2, context)).toArray(x$0 -> new Goal[x$0]));
/* 185 */       this.knownOreLocations = locs2;
/* 186 */       return new PathingCommand((Goal)goalComposite, legit ? PathingCommandType.FORCE_REVALIDATE_GOAL_AND_PATH : PathingCommandType.REVALIDATE_GOAL_AND_PATH);
/*     */     } 
/*     */     
/* 189 */     if (!legit) {
/* 190 */       return null;
/*     */     }
/*     */     
/* 193 */     int y = ((Integer)(Baritone.settings()).legitMineYLevel.value).intValue();
/* 194 */     if (this.branchPoint == null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 202 */       this.branchPoint = (class_2338)this.ctx.playerFeet();
/*     */     }
/*     */ 
/*     */     
/* 206 */     if (this.branchPointRunaway == null) {
/* 207 */       this.branchPointRunaway = new GoalRunAway(1.0D, Integer.valueOf(y), new class_2338[] { this.branchPoint })
/*     */         {
/*     */           public boolean isInGoal(int x, int y, int z) {
/* 210 */             return false;
/*     */           }
/*     */         };
/*     */     }
/* 214 */     return new PathingCommand((Goal)this.branchPointRunaway, PathingCommandType.REVALIDATE_GOAL_AND_PATH);
/*     */   }
/*     */   
/*     */   private void rescan(List<class_2338> already, CalculationContext context) {
/* 218 */     if (this.filter == null) {
/*     */       return;
/*     */     }
/* 221 */     if (((Boolean)(Baritone.settings()).legitMine.value).booleanValue()) {
/*     */       return;
/*     */     }
/* 224 */     List<class_2338> dropped = droppedItemsScan();
/* 225 */     List<class_2338> locs = searchWorld(context, this.filter, 64, already, this.blacklist, dropped);
/* 226 */     locs.addAll(dropped);
/* 227 */     if (locs.isEmpty()) {
/* 228 */       logDirect("No locations for " + this.filter + " known, cancelling");
/* 229 */       if (((Boolean)(Baritone.settings()).desktopNotifications.value).booleanValue() && ((Boolean)(Baritone.settings()).notificationOnMineFail.value).booleanValue()) {
/* 230 */         NotificationHelper.notify("No locations for " + this.filter + " known, cancelling", true);
/*     */       }
/* 232 */       cancel();
/*     */       return;
/*     */     } 
/* 235 */     this.knownOreLocations = locs;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean internalMiningGoal(class_2338 pos, CalculationContext context, List<class_2338> locs) {
/* 240 */     if (locs.contains(pos)) {
/* 241 */       return true;
/*     */     }
/* 243 */     class_2680 state = context.bsi.get0(pos);
/* 244 */     if (((Boolean)(Baritone.settings()).internalMiningAirException.value).booleanValue() && state.method_26204() instanceof net.minecraft.class_2189) {
/* 245 */       return true;
/*     */     }
/* 247 */     return (this.filter.has(state) && plausibleToBreak(context, pos));
/*     */   }
/*     */   
/*     */   private Goal coalesce(class_2338 loc, List<class_2338> locs, CalculationContext context) {
/* 251 */     boolean assumeVerticalShaftMine = !(this.baritone.bsi.get0(loc.method_10084()).method_26204() instanceof net.minecraft.class_2346);
/* 252 */     if (!((Boolean)(Baritone.settings()).forceInternalMining.value).booleanValue()) {
/* 253 */       if (assumeVerticalShaftMine)
/*     */       {
/* 255 */         return (Goal)new GoalThreeBlocks(loc);
/*     */       }
/*     */       
/* 258 */       return (Goal)new GoalTwoBlocks(loc);
/*     */     } 
/*     */     
/* 261 */     boolean upwardGoal = internalMiningGoal(loc.method_10084(), context, locs);
/* 262 */     boolean downwardGoal = internalMiningGoal(loc.method_10074(), context, locs);
/* 263 */     boolean doubleDownwardGoal = internalMiningGoal(loc.method_10087(2), context, locs);
/* 264 */     if (upwardGoal == downwardGoal) {
/* 265 */       if (doubleDownwardGoal && assumeVerticalShaftMine)
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 270 */         return (Goal)new GoalThreeBlocks(loc);
/*     */       }
/*     */       
/* 273 */       return (Goal)new GoalTwoBlocks(loc);
/*     */     } 
/*     */     
/* 276 */     if (upwardGoal)
/*     */     {
/*     */       
/* 279 */       return (Goal)new GoalBlock(loc);
/*     */     }
/*     */     
/* 282 */     if (doubleDownwardGoal && assumeVerticalShaftMine)
/*     */     {
/*     */       
/* 285 */       return (Goal)new GoalTwoBlocks(loc.method_10074());
/*     */     }
/*     */ 
/*     */     
/* 289 */     return (Goal)new GoalBlock(loc.method_10074());
/*     */   }
/*     */   
/*     */   private static class GoalThreeBlocks
/*     */     extends GoalTwoBlocks {
/*     */     public GoalThreeBlocks(class_2338 pos) {
/* 295 */       super(pos);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isInGoal(int x, int y, int z) {
/* 300 */       return (x == this.x && (y == this.y || y == this.y - 1 || y == this.y - 2) && z == this.z);
/*     */     }
/*     */ 
/*     */     
/*     */     public double heuristic(int x, int y, int z) {
/* 305 */       int xDiff = x - this.x;
/* 306 */       int yDiff = y - this.y;
/* 307 */       int zDiff = z - this.z;
/* 308 */       return GoalBlock.calculate(xDiff, (yDiff < -1) ? (yDiff + 2) : ((yDiff == -1) ? 0 : yDiff), zDiff);
/*     */     }
/*     */   }
/*     */   
/*     */   public List<class_2338> droppedItemsScan() {
/* 313 */     if (!((Boolean)(Baritone.settings()).mineScanDroppedItems.value).booleanValue()) {
/* 314 */       return Collections.emptyList();
/*     */     }
/* 316 */     List<class_2338> ret = new ArrayList<>();
/* 317 */     for (class_1297 entity : ((class_638)this.ctx.world()).method_18112()) {
/* 318 */       if (entity instanceof class_1542) {
/* 319 */         class_1542 ei = (class_1542)entity;
/* 320 */         if (this.filter.has(ei.method_6983())) {
/* 321 */           ret.add(entity.method_24515());
/*     */         }
/*     */       } 
/*     */     } 
/* 325 */     ret.addAll(this.anticipatedDrops.keySet());
/* 326 */     return ret;
/*     */   }
/*     */   
/*     */   public static List<class_2338> searchWorld(CalculationContext ctx, BlockOptionalMetaLookup filter, int max, List<class_2338> alreadyKnown, List<class_2338> blacklist, List<class_2338> dropped) {
/* 330 */     List<class_2338> locs = new ArrayList<>();
/* 331 */     List<class_2248> untracked = new ArrayList<>();
/* 332 */     for (BlockOptionalMeta bom : filter.blocks()) {
/* 333 */       class_2248 block = bom.getBlock();
/* 334 */       if (CachedChunk.BLOCKS_TO_KEEP_TRACK_OF.contains(block)) {
/* 335 */         BetterBlockPos pf = ctx.baritone.getPlayerContext().playerFeet();
/*     */ 
/*     */         
/* 338 */         locs.addAll(ctx.worldData.getCachedWorld().getLocationsOf(
/* 339 */               BlockUtils.blockToString(block), (
/* 340 */               (Integer)(Baritone.settings()).maxCachedWorldScanCount.value).intValue(), pf.x, pf.z, 2));
/*     */ 
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 346 */       untracked.add(block);
/*     */     } 
/*     */ 
/*     */     
/* 350 */     locs = prune(ctx, locs, filter, max, blacklist, dropped);
/*     */     
/* 352 */     if (!untracked.isEmpty() || (((Boolean)(Baritone.settings()).extendCacheOnThreshold.value).booleanValue() && locs.size() < max)) {
/* 353 */       locs.addAll(WorldScanner.INSTANCE.scanChunkRadius(ctx
/* 354 */             .getBaritone().getPlayerContext(), filter, max, 10, 32));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 362 */     locs.addAll(alreadyKnown);
/*     */     
/* 364 */     return prune(ctx, locs, filter, max, blacklist, dropped);
/*     */   }
/*     */   
/*     */   private void addNearby() {
/* 368 */     List<class_2338> dropped = droppedItemsScan();
/* 369 */     this.knownOreLocations.addAll(dropped);
/* 370 */     BetterBlockPos betterBlockPos = this.ctx.playerFeet();
/* 371 */     BlockStateInterface bsi = new BlockStateInterface(this.ctx);
/* 372 */     int searchDist = 10;
/* 373 */     double fakedBlockReachDistance = 20.0D;
/* 374 */     for (int x = betterBlockPos.method_10263() - searchDist; x <= betterBlockPos.method_10263() + searchDist; x++) {
/* 375 */       for (int y = betterBlockPos.method_10264() - searchDist; y <= betterBlockPos.method_10264() + searchDist; y++) {
/* 376 */         for (int z = betterBlockPos.method_10260() - searchDist; z <= betterBlockPos.method_10260() + searchDist; z++) {
/*     */ 
/*     */           
/* 379 */           if (this.filter.has(bsi.get0(x, y, z))) {
/* 380 */             class_2338 pos = new class_2338(x, y, z);
/* 381 */             if ((((Boolean)(Baritone.settings()).legitMineIncludeDiagonals.value).booleanValue() && this.knownOreLocations.stream().anyMatch(ore -> (ore.method_10262((class_2382)pos) <= 2.0D))) || RotationUtils.reachable(this.ctx.player(), pos, fakedBlockReachDistance).isPresent()) {
/* 382 */               this.knownOreLocations.add(pos);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 388 */     this.knownOreLocations = prune(new CalculationContext((IBaritone)this.baritone), this.knownOreLocations, this.filter, 64, this.blacklist, dropped);
/*     */   }
/*     */   
/*     */   private static List<class_2338> prune(CalculationContext ctx, List<class_2338> locs2, BlockOptionalMetaLookup filter, int max, List<class_2338> blacklist, List<class_2338> dropped) {
/* 392 */     dropped.removeIf(drop -> {
/*     */           for (class_2338 pos : locs2) {
/*     */             if (pos.method_10262((class_2382)drop) <= 9.0D && filter.has(ctx.get(pos.method_10263(), pos.method_10264(), pos.method_10260())) && plausibleToBreak(ctx, pos)) {
/*     */               return true;
/*     */             }
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           return false;
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 423 */     List<class_2338> locs = (List<class_2338>)locs2.stream().distinct().filter(pos -> (!ctx.bsi.worldContainsLoadedChunk(pos.method_10263(), pos.method_10260()) || filter.has(ctx.get(pos.method_10263(), pos.method_10264(), pos.method_10260())) || dropped.contains(pos))).filter(pos -> plausibleToBreak(ctx, pos)).filter(pos -> ((Boolean)(Baritone.settings()).allowOnlyExposedOres.value).booleanValue() ? isNextToAir(ctx, pos) : true).filter(pos -> (pos.method_10264() >= ((Integer)(Baritone.settings()).minYLevelWhileMining.value).intValue())).filter(pos -> !blacklist.contains(pos)).sorted(Comparator.comparingDouble(ctx.getBaritone().getPlayerContext().player().method_24515()::method_10262)).collect(Collectors.toList());
/*     */     
/* 425 */     if (locs.size() > max) {
/* 426 */       return locs.subList(0, max);
/*     */     }
/* 428 */     return locs;
/*     */   }
/*     */   
/*     */   public static boolean isNextToAir(CalculationContext ctx, class_2338 pos) {
/* 432 */     int radius = ((Integer)(Baritone.settings()).allowOnlyExposedOresDistance.value).intValue();
/* 433 */     for (int dx = -radius; dx <= radius; dx++) {
/* 434 */       for (int dy = -radius; dy <= radius; dy++) {
/* 435 */         for (int dz = -radius; dz <= radius; dz++) {
/* 436 */           if (Math.abs(dx) + Math.abs(dy) + Math.abs(dz) <= radius && 
/* 437 */             MovementHelper.isTransparent(ctx.getBlock(pos.method_10263() + dx, pos.method_10264() + dy, pos.method_10260() + dz))) {
/* 438 */             return true;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 443 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean plausibleToBreak(CalculationContext ctx, class_2338 pos) {
/* 448 */     if (MovementHelper.getMiningDurationTicks(ctx, pos.method_10263(), pos.method_10264(), pos.method_10260(), ctx.bsi.get0(pos), true) >= 1000000.0D) {
/* 449 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 453 */     return (ctx.bsi.get0(pos.method_10084()).method_26204() != class_2246.field_9987 || ctx.bsi.get0(pos.method_10074()).method_26204() != class_2246.field_9987);
/*     */   }
/*     */ 
/*     */   
/*     */   public void mineByName(int quantity, String... blocks) {
/* 458 */     mine(quantity, new BlockOptionalMetaLookup(blocks));
/*     */   }
/*     */ 
/*     */   
/*     */   public void mine(int quantity, BlockOptionalMetaLookup filter) {
/* 463 */     this.filter = filter;
/* 464 */     if (filter != null && !((Boolean)(Baritone.settings()).allowBreak.value).booleanValue()) {
/* 465 */       logDirect("Unable to mine when allowBreak is false!");
/* 466 */       mine(quantity, (BlockOptionalMetaLookup)null);
/*     */       return;
/*     */     } 
/* 469 */     this.desiredQuantity = quantity;
/* 470 */     this.knownOreLocations = new ArrayList<>();
/* 471 */     this.blacklist = new ArrayList<>();
/* 472 */     this.branchPoint = null;
/* 473 */     this.branchPointRunaway = null;
/* 474 */     this.anticipatedDrops = new HashMap<>();
/* 475 */     if (filter != null)
/* 476 */       rescan(new ArrayList<>(), new CalculationContext((IBaritone)this.baritone)); 
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\process\MineProcess.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */