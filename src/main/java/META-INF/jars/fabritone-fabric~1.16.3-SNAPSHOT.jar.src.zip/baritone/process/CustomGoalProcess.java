/*     */ package baritone.process;
/*     */ 
/*     */ import baritone.Baritone;
/*     */ import baritone.api.pathing.goals.Goal;
/*     */ import baritone.api.process.ICustomGoalProcess;
/*     */ import baritone.api.process.PathingCommand;
/*     */ import baritone.api.process.PathingCommandType;
/*     */ import baritone.utils.BaritoneProcessHelper;
/*     */ import baritone.utils.NotificationHelper;
/*     */ import net.minecraft.class_2338;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CustomGoalProcess
/*     */   extends BaritoneProcessHelper
/*     */   implements ICustomGoalProcess
/*     */ {
/*     */   private Goal goal;
/*     */   private State state;
/*     */   
/*     */   public CustomGoalProcess(Baritone baritone) {
/*  48 */     super(baritone);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setGoal(Goal goal) {
/*  53 */     this.goal = goal;
/*  54 */     if (this.state == State.NONE) {
/*  55 */       this.state = State.GOAL_SET;
/*     */     }
/*  57 */     if (this.state == State.EXECUTING) {
/*  58 */       this.state = State.PATH_REQUESTED;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void path() {
/*  64 */     this.state = State.PATH_REQUESTED;
/*     */   }
/*     */ 
/*     */   
/*     */   public Goal getGoal() {
/*  69 */     return this.goal;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isActive() {
/*  74 */     return (this.state != State.NONE);
/*     */   }
/*     */   
/*     */   public PathingCommand onTick(boolean calcFailed, boolean isSafeToCancel) {
/*     */     PathingCommand ret;
/*  79 */     switch (this.state) {
/*     */       case GOAL_SET:
/*  81 */         return new PathingCommand(this.goal, PathingCommandType.CANCEL_AND_SET_GOAL);
/*     */       
/*     */       case PATH_REQUESTED:
/*  84 */         ret = new PathingCommand(this.goal, PathingCommandType.FORCE_REVALIDATE_GOAL_AND_PATH);
/*  85 */         this.state = State.EXECUTING;
/*  86 */         return ret;
/*     */       case EXECUTING:
/*  88 */         if (calcFailed) {
/*  89 */           onLostControl();
/*  90 */           return new PathingCommand(this.goal, PathingCommandType.CANCEL_AND_SET_GOAL);
/*     */         } 
/*  92 */         if (this.goal == null || (this.goal.isInGoal((class_2338)this.ctx.playerFeet()) && this.goal.isInGoal((class_2338)this.baritone.getPathingBehavior().pathStart()))) {
/*  93 */           onLostControl();
/*  94 */           if (((Boolean)(Baritone.settings()).disconnectOnArrival.value).booleanValue()) {
/*  95 */             this.ctx.world().method_8525();
/*     */           }
/*  97 */           if (((Boolean)(Baritone.settings()).desktopNotifications.value).booleanValue() && ((Boolean)(Baritone.settings()).notificationOnPathComplete.value).booleanValue()) {
/*  98 */             NotificationHelper.notify("Pathing complete", false);
/*     */           }
/* 100 */           return new PathingCommand(this.goal, PathingCommandType.CANCEL_AND_SET_GOAL);
/*     */         } 
/* 102 */         return new PathingCommand(this.goal, PathingCommandType.SET_GOAL_AND_PATH);
/*     */     } 
/* 104 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onLostControl() {
/* 110 */     this.state = State.NONE;
/* 111 */     this.goal = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String displayName0() {
/* 116 */     return "Custom Goal " + this.goal;
/*     */   }
/*     */   
/*     */   protected enum State {
/* 120 */     NONE,
/* 121 */     GOAL_SET,
/* 122 */     PATH_REQUESTED,
/* 123 */     EXECUTING;
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\process\CustomGoalProcess.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */