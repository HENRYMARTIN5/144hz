/*     */ package baritone.process;
/*     */ 
/*     */ import baritone.Baritone;
/*     */ import baritone.api.IBaritone;
/*     */ import baritone.api.pathing.goals.Goal;
/*     */ import baritone.api.pathing.goals.GoalBlock;
/*     */ import baritone.api.pathing.goals.GoalComposite;
/*     */ import baritone.api.pathing.goals.GoalGetToBlock;
/*     */ import baritone.api.process.IBuilderProcess;
/*     */ import baritone.api.process.PathingCommand;
/*     */ import baritone.api.process.PathingCommandType;
/*     */ import baritone.api.schematic.FillSchematic;
/*     */ import baritone.api.schematic.ISchematic;
/*     */ import baritone.api.schematic.IStaticSchematic;
/*     */ import baritone.api.schematic.format.ISchematicFormat;
/*     */ import baritone.api.utils.BetterBlockPos;
/*     */ import baritone.api.utils.RayTraceUtils;
/*     */ import baritone.api.utils.Rotation;
/*     */ import baritone.api.utils.RotationUtils;
/*     */ import baritone.api.utils.input.Input;
/*     */ import baritone.pathing.movement.CalculationContext;
/*     */ import baritone.pathing.movement.Movement;
/*     */ import baritone.pathing.movement.MovementHelper;
/*     */ import baritone.utils.BaritoneProcessHelper;
/*     */ import baritone.utils.BlockStateInterface;
/*     */ import baritone.utils.NotificationHelper;
/*     */ import baritone.utils.PathingCommandContext;
/*     */ import baritone.utils.schematic.MapArtSchematic;
/*     */ import baritone.utils.schematic.SchematicSystem;
/*     */ import baritone.utils.schematic.schematica.SchematicaHelper;
/*     */ import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import java.util.OptionalInt;
/*     */ import net.minecraft.class_1268;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1657;
/*     */ import net.minecraft.class_1747;
/*     */ import net.minecraft.class_1750;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_1838;
/*     */ import net.minecraft.class_1922;
/*     */ import net.minecraft.class_1937;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_238;
/*     */ import net.minecraft.class_2382;
/*     */ import net.minecraft.class_239;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_265;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_3545;
/*     */ import net.minecraft.class_3965;
/*     */ import net.minecraft.class_4538;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BuilderProcess
/*     */   extends BaritoneProcessHelper
/*     */   implements IBuilderProcess
/*     */ {
/*     */   private HashSet<BetterBlockPos> incorrectPositions;
/*     */   private LongOpenHashSet observedCompleted;
/*     */   private String name;
/*     */   private ISchematic realSchematic;
/*     */   private ISchematic schematic;
/*     */   private class_2382 origin;
/*     */   private int ticks;
/*     */   private boolean paused;
/*     */   private int layer;
/*     */   private int numRepeats;
/*     */   private List<class_2680> approxPlaceable;
/*     */   
/*     */   public BuilderProcess(Baritone baritone) {
/*  84 */     super(baritone);
/*     */   }
/*     */ 
/*     */   
/*     */   public void build(String name, ISchematic schematic, class_2382 origin) {
/*  89 */     this.name = name;
/*  90 */     this.schematic = schematic;
/*  91 */     this.realSchematic = null;
/*  92 */     int x = origin.method_10263();
/*  93 */     int y = origin.method_10264();
/*  94 */     int z = origin.method_10260();
/*  95 */     if (((Boolean)(Baritone.settings()).schematicOrientationX.value).booleanValue()) {
/*  96 */       x += schematic.widthX();
/*     */     }
/*  98 */     if (((Boolean)(Baritone.settings()).schematicOrientationY.value).booleanValue()) {
/*  99 */       y += schematic.heightY();
/*     */     }
/* 101 */     if (((Boolean)(Baritone.settings()).schematicOrientationZ.value).booleanValue()) {
/* 102 */       z += schematic.lengthZ();
/*     */     }
/* 104 */     this.origin = new class_2382(x, y, z);
/* 105 */     this.paused = false;
/* 106 */     this.layer = ((Integer)(Baritone.settings()).startAtLayer.value).intValue();
/* 107 */     this.numRepeats = 0;
/* 108 */     this.observedCompleted = new LongOpenHashSet();
/*     */   }
/*     */   
/*     */   public void resume() {
/* 112 */     this.paused = false;
/*     */   }
/*     */   
/*     */   public void pause() {
/* 116 */     this.paused = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPaused() {
/* 121 */     return this.paused;
/*     */   }
/*     */   public boolean build(String name, File schematic, class_2382 origin) {
/*     */     IStaticSchematic iStaticSchematic;
/*     */     MapArtSchematic mapArtSchematic;
/* 126 */     Optional<ISchematicFormat> format = SchematicSystem.INSTANCE.getByFile(schematic);
/* 127 */     if (!format.isPresent()) {
/* 128 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 133 */       iStaticSchematic = ((ISchematicFormat)format.get()).parse(new FileInputStream(schematic));
/* 134 */     } catch (Exception e) {
/* 135 */       e.printStackTrace();
/* 136 */       return false;
/*     */     } 
/*     */     
/* 139 */     if (((Boolean)(Baritone.settings()).mapArtMode.value).booleanValue()) {
/* 140 */       mapArtSchematic = new MapArtSchematic(iStaticSchematic);
/*     */     }
/*     */     
/* 143 */     build(name, (ISchematic)mapArtSchematic, origin);
/* 144 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void buildOpenSchematic() {
/* 149 */     if (SchematicaHelper.isSchematicaPresent()) {
/* 150 */       Optional<class_3545<IStaticSchematic, class_2338>> schematic = SchematicaHelper.getOpenSchematic();
/* 151 */       if (schematic.isPresent()) {
/* 152 */         IStaticSchematic s = (IStaticSchematic)((class_3545)schematic.get()).method_15442();
/* 153 */         build(((IStaticSchematic)((class_3545)schematic
/* 154 */             .get()).method_15442()).toString(), 
/* 155 */             ((Boolean)(Baritone.settings()).mapArtMode.value).booleanValue() ? (ISchematic)new MapArtSchematic(s) : (ISchematic)s, (class_2382)((class_3545)schematic
/* 156 */             .get()).method_15441());
/*     */       } else {
/*     */         
/* 159 */         logDirect("No schematic currently open");
/*     */       } 
/*     */     } else {
/* 162 */       logDirect("Schematica is not present");
/*     */     } 
/*     */   }
/*     */   
/*     */   public void clearArea(class_2338 corner1, class_2338 corner2) {
/* 167 */     class_2338 origin = new class_2338(Math.min(corner1.method_10263(), corner2.method_10263()), Math.min(corner1.method_10264(), corner2.method_10264()), Math.min(corner1.method_10260(), corner2.method_10260()));
/* 168 */     int widthX = Math.abs(corner1.method_10263() - corner2.method_10263()) + 1;
/* 169 */     int heightY = Math.abs(corner1.method_10264() - corner2.method_10264()) + 1;
/* 170 */     int lengthZ = Math.abs(corner1.method_10260() - corner2.method_10260()) + 1;
/* 171 */     build("clear area", (ISchematic)new FillSchematic(widthX, heightY, lengthZ, class_2246.field_10124.method_9564()), (class_2382)origin);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<class_2680> getApproxPlaceable() {
/* 176 */     return new ArrayList<>(this.approxPlaceable);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isActive() {
/* 181 */     return (this.schematic != null);
/*     */   }
/*     */   
/*     */   public class_2680 placeAt(int x, int y, int z, class_2680 current) {
/* 185 */     if (!isActive()) {
/* 186 */       return null;
/*     */     }
/* 188 */     if (!this.schematic.inSchematic(x - this.origin.method_10263(), y - this.origin.method_10264(), z - this.origin.method_10260(), current)) {
/* 189 */       return null;
/*     */     }
/* 191 */     class_2680 state = this.schematic.desiredState(x - this.origin.method_10263(), y - this.origin.method_10264(), z - this.origin.method_10260(), current, this.approxPlaceable);
/* 192 */     if (state.method_26204() instanceof net.minecraft.class_2189) {
/* 193 */       return null;
/*     */     }
/* 195 */     return state;
/*     */   }
/*     */   
/*     */   private Optional<class_3545<BetterBlockPos, Rotation>> toBreakNearPlayer(BuilderCalculationContext bcc) {
/* 199 */     BetterBlockPos center = this.ctx.playerFeet();
/* 200 */     BetterBlockPos pathStart = this.baritone.getPathingBehavior().pathStart();
/* 201 */     for (int dx = -5; dx <= 5; dx++) {
/* 202 */       for (int dy = ((Boolean)(Baritone.settings()).breakFromAbove.value).booleanValue() ? -1 : 0; dy <= 5; dy++) {
/* 203 */         for (int dz = -5; dz <= 5; dz++) {
/* 204 */           int x = center.x + dx;
/* 205 */           int y = center.y + dy;
/* 206 */           int z = center.z + dz;
/* 207 */           if (dy != -1 || x != pathStart.x || z != pathStart.z) {
/*     */ 
/*     */             
/* 210 */             class_2680 desired = bcc.getSchematic(x, y, z, bcc.bsi.get0(x, y, z));
/* 211 */             if (desired != null) {
/*     */ 
/*     */               
/* 214 */               class_2680 curr = bcc.bsi.get0(x, y, z);
/* 215 */               if (!(curr.method_26204() instanceof net.minecraft.class_2189) && curr.method_26204() != class_2246.field_10382 && curr.method_26204() != class_2246.field_10164 && !valid(curr, desired, false)) {
/* 216 */                 BetterBlockPos pos = new BetterBlockPos(x, y, z);
/* 217 */                 Optional<Rotation> rot = RotationUtils.reachable(this.ctx.player(), (class_2338)pos, this.ctx.playerController().getBlockReachDistance());
/* 218 */                 if (rot.isPresent())
/* 219 */                   return Optional.of(new class_3545(pos, rot.get())); 
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 225 */     }  return Optional.empty();
/*     */   }
/*     */   
/*     */   public static class Placement
/*     */   {
/*     */     private final int hotbarSelection;
/*     */     private final class_2338 placeAgainst;
/*     */     private final class_2350 side;
/*     */     private final Rotation rot;
/*     */     
/*     */     public Placement(int hotbarSelection, class_2338 placeAgainst, class_2350 side, Rotation rot) {
/* 236 */       this.hotbarSelection = hotbarSelection;
/* 237 */       this.placeAgainst = placeAgainst;
/* 238 */       this.side = side;
/* 239 */       this.rot = rot;
/*     */     }
/*     */   }
/*     */   
/*     */   private Optional<Placement> searchForPlacables(BuilderCalculationContext bcc, List<class_2680> desirableOnHotbar) {
/* 244 */     BetterBlockPos center = this.ctx.playerFeet();
/* 245 */     for (int dx = -5; dx <= 5; dx++) {
/* 246 */       for (int dy = -5; dy <= 1; dy++) {
/* 247 */         for (int dz = -5; dz <= 5; dz++) {
/* 248 */           int x = center.x + dx;
/* 249 */           int y = center.y + dy;
/* 250 */           int z = center.z + dz;
/* 251 */           class_2680 desired = bcc.getSchematic(x, y, z, bcc.bsi.get0(x, y, z));
/* 252 */           if (desired != null) {
/*     */ 
/*     */             
/* 255 */             class_2680 curr = bcc.bsi.get0(x, y, z);
/* 256 */             if (MovementHelper.isReplaceable(x, y, z, curr, bcc.bsi) && !valid(curr, desired, false) && (
/* 257 */               dy != 1 || !(bcc.bsi.get0(x, y + 1, z).method_26204() instanceof net.minecraft.class_2189))) {
/*     */ 
/*     */               
/* 260 */               desirableOnHotbar.add(desired);
/* 261 */               Optional<Placement> opt = possibleToPlace(desired, x, y, z, bcc.bsi);
/* 262 */               if (opt.isPresent())
/* 263 */                 return opt; 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 269 */     return Optional.empty();
/*     */   }
/*     */   
/*     */   public boolean placementPlausible(class_2338 pos, class_2680 state) {
/* 273 */     class_265 voxelshape = state.method_26220((class_1922)this.ctx.world(), pos);
/* 274 */     return (voxelshape.method_1110() || this.ctx.world().method_8611(null, voxelshape.method_1096(pos.method_10263(), pos.method_10264(), pos.method_10260())));
/*     */   }
/*     */   
/*     */   private Optional<Placement> possibleToPlace(class_2680 toPlace, int x, int y, int z, BlockStateInterface bsi) {
/* 278 */     for (class_2350 against : class_2350.values()) {
/* 279 */       BetterBlockPos placeAgainstPos = (new BetterBlockPos(x, y, z)).offset(against);
/* 280 */       class_2680 placeAgainstState = bsi.get0((class_2338)placeAgainstPos);
/* 281 */       if (!MovementHelper.isReplaceable(placeAgainstPos.x, placeAgainstPos.y, placeAgainstPos.z, placeAgainstState, bsi))
/*     */       {
/*     */         
/* 284 */         if (toPlace.method_26184((class_4538)this.ctx.world(), (class_2338)new BetterBlockPos(x, y, z)))
/*     */         {
/*     */           
/* 287 */           if (placementPlausible((class_2338)new BetterBlockPos(x, y, z), toPlace)) {
/*     */ 
/*     */             
/* 290 */             class_238 aabb = placeAgainstState.method_26218((class_1922)this.ctx.world(), (class_2338)placeAgainstPos).method_1107();
/* 291 */             for (class_243 placementMultiplier : aabbSideMultipliers(against)) {
/* 292 */               double placeX = placeAgainstPos.x + aabb.field_1323 * placementMultiplier.field_1352 + aabb.field_1320 * (1.0D - placementMultiplier.field_1352);
/* 293 */               double placeY = placeAgainstPos.y + aabb.field_1322 * placementMultiplier.field_1351 + aabb.field_1325 * (1.0D - placementMultiplier.field_1351);
/* 294 */               double placeZ = placeAgainstPos.z + aabb.field_1321 * placementMultiplier.field_1350 + aabb.field_1324 * (1.0D - placementMultiplier.field_1350);
/* 295 */               Rotation rot = RotationUtils.calcRotationFromVec3d(RayTraceUtils.inferSneakingEyePosition((class_1297)this.ctx.player()), new class_243(placeX, placeY, placeZ), this.ctx.playerRotations());
/* 296 */               class_239 result = RayTraceUtils.rayTraceTowards((class_1297)this.ctx.player(), rot, this.ctx.playerController().getBlockReachDistance(), true);
/* 297 */               if (result != null && result.method_17783() == class_239.class_240.field_1332 && ((class_3965)result).method_17777().equals(placeAgainstPos) && ((class_3965)result).method_17780() == against.method_10153()) {
/* 298 */                 OptionalInt hotbar = hasAnyItemThatWouldPlace(toPlace, result, rot);
/* 299 */                 if (hotbar.isPresent())
/* 300 */                   return Optional.of(new Placement(hotbar.getAsInt(), (class_2338)placeAgainstPos, against.method_10153(), rot)); 
/*     */               } 
/*     */             } 
/*     */           }  }  } 
/*     */     } 
/* 305 */     return Optional.empty();
/*     */   }
/*     */   
/*     */   private OptionalInt hasAnyItemThatWouldPlace(class_2680 desired, class_239 result, Rotation rot) {
/* 309 */     for (int i = 0; i < 9; i++) {
/* 310 */       class_1799 stack = (class_1799)(this.ctx.player()).field_7514.field_7547.get(i);
/* 311 */       if (!stack.method_7960() && stack.method_7909() instanceof class_1747) {
/*     */ 
/*     */         
/* 314 */         float originalYaw = (this.ctx.player()).field_6031;
/* 315 */         float originalPitch = (this.ctx.player()).field_5965;
/*     */         
/* 317 */         (this.ctx.player()).field_6031 = rot.getYaw();
/* 318 */         (this.ctx.player()).field_5965 = rot.getPitch();
/*     */ 
/*     */         
/* 321 */         class_1750 meme = new class_1750(new class_1838(this.ctx.world(), (class_1657)this.ctx.player(), class_1268.field_5808, stack, (class_3965)result)
/*     */             {
/*     */             
/*     */             });
/*     */         
/* 326 */         class_2680 wouldBePlaced = ((class_1747)stack.method_7909()).method_7711().method_9605(meme);
/* 327 */         (this.ctx.player()).field_6031 = originalYaw;
/* 328 */         (this.ctx.player()).field_5965 = originalPitch;
/* 329 */         if (wouldBePlaced != null)
/*     */         {
/*     */           
/* 332 */           if (meme.method_7716())
/*     */           {
/*     */             
/* 335 */             if (valid(wouldBePlaced, desired, true))
/* 336 */               return OptionalInt.of(i);  }  } 
/*     */       } 
/*     */     } 
/* 339 */     return OptionalInt.empty();
/*     */   } private static class_243[] aabbSideMultipliers(class_2350 side) {
/*     */     double x;
/*     */     double z;
/* 343 */     switch (side) {
/*     */       case field_11036:
/* 345 */         return new class_243[] { new class_243(0.5D, 1.0D, 0.5D), new class_243(0.1D, 1.0D, 0.5D), new class_243(0.9D, 1.0D, 0.5D), new class_243(0.5D, 1.0D, 0.1D), new class_243(0.5D, 1.0D, 0.9D) };
/*     */       case field_11033:
/* 347 */         return new class_243[] { new class_243(0.5D, 0.0D, 0.5D), new class_243(0.1D, 0.0D, 0.5D), new class_243(0.9D, 0.0D, 0.5D), new class_243(0.5D, 0.0D, 0.1D), new class_243(0.5D, 0.0D, 0.9D) };
/*     */       case field_11043:
/*     */       case field_11035:
/*     */       case field_11034:
/*     */       case field_11039:
/* 352 */         x = (side.method_10148() == 0) ? 0.5D : ((1 + side.method_10148()) / 2.0D);
/* 353 */         z = (side.method_10165() == 0) ? 0.5D : ((1 + side.method_10165()) / 2.0D);
/* 354 */         return new class_243[] { new class_243(x, 0.25D, z), new class_243(x, 0.75D, z) };
/*     */     } 
/* 356 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PathingCommand onTick(boolean calcFailed, boolean isSafeToCancel) {
/* 362 */     this.approxPlaceable = approxPlaceable(36);
/* 363 */     if (this.baritone.getInputOverrideHandler().isInputForcedDown(Input.CLICK_LEFT)) {
/* 364 */       this.ticks = 5;
/*     */     } else {
/* 366 */       this.ticks--;
/*     */     } 
/* 368 */     this.baritone.getInputOverrideHandler().clearAllKeys();
/* 369 */     if (this.paused) {
/* 370 */       return new PathingCommand(null, PathingCommandType.CANCEL_AND_SET_GOAL);
/*     */     }
/* 372 */     if (((Boolean)(Baritone.settings()).buildInLayers.value).booleanValue()) {
/* 373 */       final int minYInclusive, maxYInclusive; if (this.realSchematic == null) {
/* 374 */         this.realSchematic = this.schematic;
/*     */       }
/* 376 */       final ISchematic realSchematic = this.realSchematic;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 381 */       if (((Boolean)(Baritone.settings()).layerOrder.value).booleanValue()) {
/* 382 */         maxYInclusive = realSchematic.heightY() - 1;
/* 383 */         minYInclusive = realSchematic.heightY() - this.layer;
/*     */       } else {
/* 385 */         maxYInclusive = this.layer - 1;
/* 386 */         minYInclusive = 0;
/*     */       } 
/* 388 */       this.schematic = new ISchematic()
/*     */         {
/*     */           public class_2680 desiredState(int x, int y, int z, class_2680 current, List<class_2680> approxPlaceable) {
/* 391 */             return realSchematic.desiredState(x, y, z, current, BuilderProcess.this.approxPlaceable);
/*     */           }
/*     */ 
/*     */           
/*     */           public boolean inSchematic(int x, int y, int z, class_2680 currentState) {
/* 396 */             return (super.inSchematic(x, y, z, currentState) && y >= minYInclusive && y <= maxYInclusive && realSchematic.inSchematic(x, y, z, currentState));
/*     */           }
/*     */ 
/*     */           
/*     */           public int widthX() {
/* 401 */             return realSchematic.widthX();
/*     */           }
/*     */ 
/*     */           
/*     */           public int heightY() {
/* 406 */             return realSchematic.heightY();
/*     */           }
/*     */ 
/*     */           
/*     */           public int lengthZ() {
/* 411 */             return realSchematic.lengthZ();
/*     */           }
/*     */         };
/*     */     } 
/* 415 */     BuilderCalculationContext bcc = new BuilderCalculationContext();
/* 416 */     if (!recalc(bcc)) {
/* 417 */       if (((Boolean)(Baritone.settings()).buildInLayers.value).booleanValue() && this.layer < this.realSchematic.heightY()) {
/* 418 */         logDirect("Starting layer " + this.layer);
/* 419 */         this.layer++;
/* 420 */         return onTick(calcFailed, isSafeToCancel);
/*     */       } 
/* 422 */       class_2382 repeat = (class_2382)(Baritone.settings()).buildRepeat.value;
/* 423 */       int max = ((Integer)(Baritone.settings()).buildRepeatCount.value).intValue();
/* 424 */       this.numRepeats++;
/* 425 */       if (repeat.equals(new class_2382(0, 0, 0)) || (max != -1 && this.numRepeats >= max)) {
/* 426 */         logDirect("Done building");
/* 427 */         if (((Boolean)(Baritone.settings()).desktopNotifications.value).booleanValue() && ((Boolean)(Baritone.settings()).notificationOnBuildFinished.value).booleanValue()) {
/* 428 */           NotificationHelper.notify("Done building", false);
/*     */         }
/* 430 */         onLostControl();
/* 431 */         return null;
/*     */       } 
/*     */       
/* 434 */       this.layer = 0;
/* 435 */       this.origin = (class_2382)(new class_2338(this.origin)).method_10081(repeat);
/* 436 */       logDirect("Repeating build in vector " + repeat + ", new origin is " + this.origin);
/* 437 */       return onTick(calcFailed, isSafeToCancel);
/*     */     } 
/* 439 */     if (((Boolean)(Baritone.settings()).distanceTrim.value).booleanValue()) {
/* 440 */       trim();
/*     */     }
/*     */     
/* 443 */     Optional<class_3545<BetterBlockPos, Rotation>> toBreak = toBreakNearPlayer(bcc);
/* 444 */     if (toBreak.isPresent() && isSafeToCancel && this.ctx.player().method_24828()) {
/*     */ 
/*     */       
/* 447 */       Rotation rot = (Rotation)((class_3545)toBreak.get()).method_15441();
/* 448 */       BetterBlockPos pos = (BetterBlockPos)((class_3545)toBreak.get()).method_15442();
/* 449 */       this.baritone.getLookBehavior().updateTarget(rot, true);
/* 450 */       MovementHelper.switchToBestToolFor(this.ctx, bcc.get((class_2338)pos));
/* 451 */       if (this.ctx.player().method_5715())
/*     */       {
/*     */ 
/*     */         
/* 455 */         this.baritone.getInputOverrideHandler().setInputForceState(Input.SNEAK, true);
/*     */       }
/* 457 */       if (this.ctx.isLookingAt((class_2338)pos) || this.ctx.playerRotations().isReallyCloseTo(rot)) {
/* 458 */         this.baritone.getInputOverrideHandler().setInputForceState(Input.CLICK_LEFT, true);
/*     */       }
/* 460 */       return new PathingCommand(null, PathingCommandType.CANCEL_AND_SET_GOAL);
/*     */     } 
/* 462 */     List<class_2680> desirableOnHotbar = new ArrayList<>();
/* 463 */     Optional<Placement> toPlace = searchForPlacables(bcc, desirableOnHotbar);
/* 464 */     if (toPlace.isPresent() && isSafeToCancel && this.ctx.player().method_24828() && this.ticks <= 0) {
/* 465 */       Rotation rot = (toPlace.get()).rot;
/* 466 */       this.baritone.getLookBehavior().updateTarget(rot, true);
/* 467 */       (this.ctx.player()).field_7514.field_7545 = (toPlace.get()).hotbarSelection;
/* 468 */       this.baritone.getInputOverrideHandler().setInputForceState(Input.SNEAK, true);
/* 469 */       if ((this.ctx.isLookingAt((toPlace.get()).placeAgainst) && ((class_3965)this.ctx.objectMouseOver()).method_17780().equals((toPlace.get()).side)) || this.ctx.playerRotations().isReallyCloseTo(rot)) {
/* 470 */         this.baritone.getInputOverrideHandler().setInputForceState(Input.CLICK_RIGHT, true);
/*     */       }
/* 472 */       return new PathingCommand(null, PathingCommandType.CANCEL_AND_SET_GOAL);
/*     */     } 
/*     */     
/* 475 */     if (((Boolean)(Baritone.settings()).allowInventory.value).booleanValue()) {
/* 476 */       ArrayList<Integer> usefulSlots = new ArrayList<>();
/* 477 */       List<class_2680> noValidHotbarOption = new ArrayList<>();
/*     */       
/* 479 */       label94: for (class_2680 desired : desirableOnHotbar) {
/* 480 */         for (int j = 0; j < 9; j++) {
/* 481 */           if (valid(this.approxPlaceable.get(j), desired, true)) {
/* 482 */             usefulSlots.add(Integer.valueOf(j));
/*     */             continue label94;
/*     */           } 
/*     */         } 
/* 486 */         noValidHotbarOption.add(desired);
/*     */       } 
/*     */ 
/*     */       
/* 490 */       for (int i = 9; i < 36; i++) {
/* 491 */         for (class_2680 desired : noValidHotbarOption) {
/* 492 */           if (valid(this.approxPlaceable.get(i), desired, true)) {
/* 493 */             this.baritone.getInventoryBehavior().attemptToPutOnHotbar(i, usefulSlots::contains);
/*     */             
/*     */             // Byte code: goto -> 1130
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 500 */     Goal goal = assemble(bcc, this.approxPlaceable.subList(0, 9));
/* 501 */     if (goal == null) {
/* 502 */       goal = assemble(bcc, this.approxPlaceable);
/* 503 */       if (goal == null) {
/* 504 */         if (((Boolean)(Baritone.settings()).skipFailedLayers.value).booleanValue() && ((Boolean)(Baritone.settings()).buildInLayers.value).booleanValue() && this.layer < this.realSchematic.heightY()) {
/* 505 */           logDirect("Skipping layer that I cannot construct! Layer #" + this.layer);
/* 506 */           this.layer++;
/* 507 */           return onTick(calcFailed, isSafeToCancel);
/*     */         } 
/* 509 */         logDirect("Unable to do it. Pausing. resume to resume, cancel to cancel");
/* 510 */         this.paused = true;
/* 511 */         return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
/*     */       } 
/*     */     } 
/* 514 */     return (PathingCommand)new PathingCommandContext(goal, PathingCommandType.FORCE_REVALIDATE_GOAL_AND_PATH, bcc);
/*     */   }
/*     */   
/*     */   private boolean recalc(BuilderCalculationContext bcc) {
/* 518 */     if (this.incorrectPositions == null) {
/* 519 */       this.incorrectPositions = new HashSet<>();
/* 520 */       fullRecalc(bcc);
/* 521 */       if (this.incorrectPositions.isEmpty()) {
/* 522 */         return false;
/*     */       }
/*     */     } 
/* 525 */     recalcNearby(bcc);
/* 526 */     if (this.incorrectPositions.isEmpty()) {
/* 527 */       fullRecalc(bcc);
/*     */     }
/* 529 */     return !this.incorrectPositions.isEmpty();
/*     */   }
/*     */   
/*     */   private void trim() {
/* 533 */     HashSet<BetterBlockPos> copy = new HashSet<>(this.incorrectPositions);
/* 534 */     copy.removeIf(pos -> (pos.method_10262((class_2382)this.ctx.player().method_24515()) > 200.0D));
/* 535 */     if (!copy.isEmpty()) {
/* 536 */       this.incorrectPositions = copy;
/*     */     }
/*     */   }
/*     */   
/*     */   private void recalcNearby(BuilderCalculationContext bcc) {
/* 541 */     BetterBlockPos center = this.ctx.playerFeet();
/* 542 */     int radius = ((Integer)(Baritone.settings()).builderTickScanRadius.value).intValue();
/* 543 */     for (int dx = -radius; dx <= radius; dx++) {
/* 544 */       for (int dy = -radius; dy <= radius; dy++) {
/* 545 */         for (int dz = -radius; dz <= radius; dz++) {
/* 546 */           int x = center.x + dx;
/* 547 */           int y = center.y + dy;
/* 548 */           int z = center.z + dz;
/* 549 */           class_2680 desired = bcc.getSchematic(x, y, z, bcc.bsi.get0(x, y, z));
/* 550 */           if (desired != null) {
/*     */             
/* 552 */             BetterBlockPos pos = new BetterBlockPos(x, y, z);
/* 553 */             if (valid(bcc.bsi.get0(x, y, z), desired, false)) {
/* 554 */               this.incorrectPositions.remove(pos);
/* 555 */               this.observedCompleted.add(BetterBlockPos.longHash(pos));
/*     */             } else {
/* 557 */               this.incorrectPositions.add(pos);
/* 558 */               this.observedCompleted.remove(BetterBlockPos.longHash(pos));
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void fullRecalc(BuilderCalculationContext bcc) {
/* 567 */     this.incorrectPositions = new HashSet<>();
/* 568 */     for (int y = 0; y < this.schematic.heightY(); y++) {
/* 569 */       for (int z = 0; z < this.schematic.lengthZ(); z++) {
/* 570 */         for (int x = 0; x < this.schematic.widthX(); x++) {
/* 571 */           int blockX = x + this.origin.method_10263();
/* 572 */           int blockY = y + this.origin.method_10264();
/* 573 */           int blockZ = z + this.origin.method_10260();
/* 574 */           class_2680 current = bcc.bsi.get0(blockX, blockY, blockZ);
/* 575 */           if (this.schematic.inSchematic(x, y, z, current))
/*     */           {
/*     */             
/* 578 */             if (bcc.bsi.worldContainsLoadedChunk(blockX, blockZ)) {
/*     */               
/* 580 */               if (valid(bcc.bsi.get0(blockX, blockY, blockZ), this.schematic.desiredState(x, y, z, current, this.approxPlaceable), false)) {
/* 581 */                 this.observedCompleted.add(BetterBlockPos.longHash(blockX, blockY, blockZ));
/*     */               } else {
/* 583 */                 this.incorrectPositions.add(new BetterBlockPos(blockX, blockY, blockZ));
/* 584 */                 this.observedCompleted.remove(BetterBlockPos.longHash(blockX, blockY, blockZ));
/* 585 */                 if (this.incorrectPositions.size() > ((Integer)(Baritone.settings()).incorrectSize.value).intValue())
/*     */                 {
/*     */                   return;
/*     */                 }
/*     */               }
/*     */             
/*     */             }
/* 592 */             else if (!this.observedCompleted.contains(BetterBlockPos.longHash(blockX, blockY, blockZ))) {
/*     */ 
/*     */               
/* 595 */               this.incorrectPositions.add(new BetterBlockPos(blockX, blockY, blockZ));
/* 596 */               if (this.incorrectPositions.size() > ((Integer)(Baritone.settings()).incorrectSize.value).intValue())
/*     */                 return; 
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private Goal assemble(BuilderCalculationContext bcc, List<class_2680> approxPlaceable) {
/* 606 */     List<BetterBlockPos> placeable = new ArrayList<>();
/* 607 */     List<BetterBlockPos> breakable = new ArrayList<>();
/* 608 */     List<BetterBlockPos> sourceLiquids = new ArrayList<>();
/* 609 */     this.incorrectPositions.forEach(pos -> {
/*     */           class_2680 state = bcc.bsi.get0((class_2338)pos);
/*     */ 
/*     */ 
/*     */           
/*     */           if (state.method_26204() instanceof net.minecraft.class_2189) {
/*     */             if (approxPlaceable.contains(bcc.getSchematic(pos.x, pos.y, pos.z, state))) {
/*     */               placeable.add(pos);
/*     */             }
/*     */           } else if (state.method_26204() instanceof net.minecraft.class_2404) {
/*     */             if (!MovementHelper.possiblyFlowing(state)) {
/*     */               sourceLiquids.add(pos);
/*     */             }
/*     */           } else {
/*     */             breakable.add(pos);
/*     */           } 
/*     */         });
/*     */ 
/*     */     
/* 628 */     List<Goal> toBreak = new ArrayList<>();
/* 629 */     breakable.forEach(pos -> toBreak.add(breakGoal((class_2338)pos, bcc)));
/* 630 */     List<Goal> toPlace = new ArrayList<>();
/* 631 */     placeable.forEach(pos -> {
/*     */           if (!placeable.contains(pos.down()) && !placeable.contains(pos.down(2))) {
/*     */             toPlace.add(placementGoal((class_2338)pos, bcc));
/*     */           }
/*     */         });
/* 636 */     sourceLiquids.forEach(pos -> toPlace.add(new GoalBlock((class_2338)pos.up())));
/*     */     
/* 638 */     if (!toPlace.isEmpty()) {
/* 639 */       return new JankyGoalComposite((Goal)new GoalComposite(toPlace.<Goal>toArray(new Goal[0])), (Goal)new GoalComposite(toBreak.<Goal>toArray(new Goal[0])));
/*     */     }
/* 641 */     if (toBreak.isEmpty()) {
/* 642 */       return null;
/*     */     }
/* 644 */     return (Goal)new GoalComposite(toBreak.<Goal>toArray(new Goal[0]));
/*     */   }
/*     */   
/*     */   public static class JankyGoalComposite
/*     */     implements Goal {
/*     */     private final Goal primary;
/*     */     private final Goal fallback;
/*     */     
/*     */     public JankyGoalComposite(Goal primary, Goal fallback) {
/* 653 */       this.primary = primary;
/* 654 */       this.fallback = fallback;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isInGoal(int x, int y, int z) {
/* 660 */       return (this.primary.isInGoal(x, y, z) || this.fallback.isInGoal(x, y, z));
/*     */     }
/*     */ 
/*     */     
/*     */     public double heuristic(int x, int y, int z) {
/* 665 */       return this.primary.heuristic(x, y, z);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 670 */       return "JankyComposite Primary: " + this.primary + " Fallback: " + this.fallback;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class GoalBreak
/*     */     extends GoalGetToBlock {
/*     */     public GoalBreak(class_2338 pos) {
/* 677 */       super(pos);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isInGoal(int x, int y, int z) {
/* 683 */       if (y > this.y) {
/* 684 */         return false;
/*     */       }
/*     */       
/* 687 */       return super.isInGoal(x, y, z);
/*     */     }
/*     */   }
/*     */   
/*     */   private Goal placementGoal(class_2338 pos, BuilderCalculationContext bcc) {
/* 692 */     if (!(this.ctx.world().method_8320(pos).method_26204() instanceof net.minecraft.class_2189)) {
/* 693 */       return (Goal)new GoalPlace(pos);
/*     */     }
/* 695 */     boolean allowSameLevel = !(this.ctx.world().method_8320(pos.method_10084()).method_26204() instanceof net.minecraft.class_2189);
/* 696 */     class_2680 current = this.ctx.world().method_8320(pos);
/* 697 */     for (class_2350 facing : Movement.HORIZONTALS_BUT_ALSO_DOWN_____SO_EVERY_DIRECTION_EXCEPT_UP) {
/*     */       
/* 699 */       if (MovementHelper.canPlaceAgainst(this.ctx, pos.method_10093(facing)) && placementPlausible(pos, bcc.getSchematic(pos.method_10263(), pos.method_10264(), pos.method_10260(), current))) {
/* 700 */         return (Goal)new GoalAdjacent(pos, pos.method_10093(facing), allowSameLevel);
/*     */       }
/*     */     } 
/* 703 */     return (Goal)new GoalPlace(pos);
/*     */   }
/*     */   
/*     */   private Goal breakGoal(class_2338 pos, BuilderCalculationContext bcc) {
/* 707 */     if (((Boolean)(Baritone.settings()).goalBreakFromAbove.value).booleanValue() && bcc.bsi.get0(pos.method_10084()).method_26204() instanceof net.minecraft.class_2189 && bcc.bsi.get0(pos.method_10086(2)).method_26204() instanceof net.minecraft.class_2189) {
/* 708 */       return new JankyGoalComposite((Goal)new GoalBreak(pos), (Goal)new GoalGetToBlock(pos.method_10084())
/*     */           {
/*     */             public boolean isInGoal(int x, int y, int z) {
/* 711 */               if (y > this.y || (x == this.x && y == this.y && z == this.z)) {
/* 712 */                 return false;
/*     */               }
/* 714 */               return super.isInGoal(x, y, z);
/*     */             }
/*     */           });
/*     */     }
/* 718 */     return (Goal)new GoalBreak(pos);
/*     */   }
/*     */   
/*     */   public static class GoalAdjacent
/*     */     extends GoalGetToBlock {
/*     */     private boolean allowSameLevel;
/*     */     private class_2338 no;
/*     */     
/*     */     public GoalAdjacent(class_2338 pos, class_2338 no, boolean allowSameLevel) {
/* 727 */       super(pos);
/* 728 */       this.no = no;
/* 729 */       this.allowSameLevel = allowSameLevel;
/*     */     }
/*     */     
/*     */     public boolean isInGoal(int x, int y, int z) {
/* 733 */       if (x == this.x && y == this.y && z == this.z) {
/* 734 */         return false;
/*     */       }
/* 736 */       if (x == this.no.method_10263() && y == this.no.method_10264() && z == this.no.method_10260()) {
/* 737 */         return false;
/*     */       }
/* 739 */       if (!this.allowSameLevel && y == this.y - 1) {
/* 740 */         return false;
/*     */       }
/* 742 */       if (y < this.y - 1) {
/* 743 */         return false;
/*     */       }
/* 745 */       return super.isInGoal(x, y, z);
/*     */     }
/*     */ 
/*     */     
/*     */     public double heuristic(int x, int y, int z) {
/* 750 */       return (this.y * 100) + super.heuristic(x, y, z);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class GoalPlace
/*     */     extends GoalBlock {
/*     */     public GoalPlace(class_2338 placeAt) {
/* 757 */       super(placeAt.method_10084());
/*     */     }
/*     */ 
/*     */     
/*     */     public double heuristic(int x, int y, int z) {
/* 762 */       return (this.y * 100) + super.heuristic(x, y, z);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void onLostControl() {
/* 768 */     this.incorrectPositions = null;
/* 769 */     this.name = null;
/* 770 */     this.schematic = null;
/* 771 */     this.realSchematic = null;
/* 772 */     this.layer = ((Integer)(Baritone.settings()).startAtLayer.value).intValue();
/* 773 */     this.numRepeats = 0;
/* 774 */     this.paused = false;
/* 775 */     this.observedCompleted = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String displayName0() {
/* 780 */     return this.paused ? "Builder Paused" : ("Building " + this.name);
/*     */   }
/*     */   
/*     */   private List<class_2680> approxPlaceable(int size) {
/* 784 */     List<class_2680> result = new ArrayList<>();
/* 785 */     for (int i = 0; i < size; i++) {
/* 786 */       class_1799 stack = (class_1799)(this.ctx.player()).field_7514.field_7547.get(i);
/* 787 */       if (stack.method_7960() || !(stack.method_7909() instanceof class_1747)) {
/* 788 */         result.add(class_2246.field_10124.method_9564());
/*     */       }
/*     */       else {
/*     */         
/* 792 */         result.add(((class_1747)stack.method_7909()).method_7711().method_9605(new class_1750(new class_1838(this.ctx.world(), (class_1657)this.ctx.player(), class_1268.field_5808, stack, new class_3965(new class_243(this.ctx.player().method_23317(), this.ctx.player().method_23318(), this.ctx.player().method_23321()), class_2350.field_11036, (class_2338)this.ctx.playerFeet(), false)) {  })));
/*     */       } 
/*     */     } 
/* 795 */     return result;
/*     */   }
/*     */   
/*     */   private boolean valid(class_2680 current, class_2680 desired, boolean itemVerify) {
/* 799 */     if (desired == null) {
/* 800 */       return true;
/*     */     }
/* 802 */     if (current.method_26204() instanceof net.minecraft.class_2404 && ((Boolean)(Baritone.settings()).okIfWater.value).booleanValue()) {
/* 803 */       return true;
/*     */     }
/* 805 */     if (current.method_26204() instanceof net.minecraft.class_2189 && ((List)(Baritone.settings()).okIfAir.value).contains(desired.method_26204())) {
/* 806 */       return true;
/*     */     }
/* 808 */     if (desired.method_26204() instanceof net.minecraft.class_2189 && ((List)(Baritone.settings()).buildIgnoreBlocks.value).contains(current.method_26204())) {
/* 809 */       return true;
/*     */     }
/*     */     
/* 812 */     if (desired.method_26204() instanceof net.minecraft.class_2189 && ((List)(Baritone.settings()).buildIgnoreBlocks.value).contains(current.method_26204())) {
/* 813 */       return true;
/*     */     }
/* 815 */     if (!(current.method_26204() instanceof net.minecraft.class_2189) && ((Boolean)(Baritone.settings()).buildIgnoreExisting.value).booleanValue() && !itemVerify) {
/* 816 */       return true;
/*     */     }
/* 818 */     return current.equals(desired);
/*     */   }
/*     */   
/*     */   public class BuilderCalculationContext
/*     */     extends CalculationContext {
/*     */     private final List<class_2680> placeable;
/*     */     private final ISchematic schematic;
/*     */     private final int originX;
/*     */     private final int originY;
/*     */     private final int originZ;
/*     */     
/*     */     public BuilderCalculationContext() {
/* 830 */       super((IBaritone)BuilderProcess.this.baritone, true);
/* 831 */       this.placeable = BuilderProcess.this.approxPlaceable(9);
/* 832 */       this.schematic = BuilderProcess.this.schematic;
/* 833 */       this.originX = BuilderProcess.this.origin.method_10263();
/* 834 */       this.originY = BuilderProcess.this.origin.method_10264();
/* 835 */       this.originZ = BuilderProcess.this.origin.method_10260();
/*     */       
/* 837 */       this.jumpPenalty += 10.0D;
/* 838 */       this.backtrackCostFavoringCoefficient = 1.0D;
/*     */     }
/*     */     
/*     */     private class_2680 getSchematic(int x, int y, int z, class_2680 current) {
/* 842 */       if (this.schematic.inSchematic(x - this.originX, y - this.originY, z - this.originZ, current)) {
/* 843 */         return this.schematic.desiredState(x - this.originX, y - this.originY, z - this.originZ, current, BuilderProcess.this.approxPlaceable);
/*     */       }
/* 845 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public double costOfPlacingAt(int x, int y, int z, class_2680 current) {
/* 851 */       if (isPossiblyProtected(x, y, z) || !this.worldBorder.canPlaceAt(x, z)) {
/* 852 */         return 1000000.0D;
/*     */       }
/* 854 */       class_2680 sch = getSchematic(x, y, z, current);
/* 855 */       if (sch != null) {
/*     */         
/* 857 */         if (sch.method_26204() instanceof net.minecraft.class_2189)
/*     */         {
/*     */           
/* 860 */           return this.placeBlockCost * 2.0D;
/*     */         }
/* 862 */         if (this.placeable.contains(sch)) {
/* 863 */           return 0.0D;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 868 */         if (!this.hasThrowaway) {
/* 869 */           return 1000000.0D;
/*     */         }
/*     */ 
/*     */         
/* 873 */         return this.placeBlockCost * 3.0D;
/*     */       } 
/* 875 */       if (this.hasThrowaway) {
/* 876 */         return this.placeBlockCost;
/*     */       }
/* 878 */       return 1000000.0D;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public double breakCostMultiplierAt(int x, int y, int z, class_2680 current) {
/* 885 */       if (!this.allowBreak || isPossiblyProtected(x, y, z)) {
/* 886 */         return 1000000.0D;
/*     */       }
/* 888 */       class_2680 sch = getSchematic(x, y, z, current);
/* 889 */       if (sch != null) {
/* 890 */         if (sch.method_26204() instanceof net.minecraft.class_2189)
/*     */         {
/*     */           
/* 893 */           return 1.0D;
/*     */         }
/*     */ 
/*     */         
/* 897 */         if (BuilderProcess.this.valid(this.bsi.get0(x, y, z), sch, false)) {
/* 898 */           return ((Double)(Baritone.settings()).breakCorrectBlockPenaltyMultiplier.value).doubleValue();
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 903 */         return 1.0D;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 909 */       return 1.0D;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\process\BuilderProcess.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */