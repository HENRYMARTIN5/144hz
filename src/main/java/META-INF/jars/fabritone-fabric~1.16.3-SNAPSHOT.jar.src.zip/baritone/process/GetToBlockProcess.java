/*     */ package baritone.process;
/*     */ 
/*     */ import baritone.Baritone;
/*     */ import baritone.api.IBaritone;
/*     */ import baritone.api.pathing.goals.Goal;
/*     */ import baritone.api.pathing.goals.GoalBlock;
/*     */ import baritone.api.pathing.goals.GoalComposite;
/*     */ import baritone.api.pathing.goals.GoalGetToBlock;
/*     */ import baritone.api.pathing.goals.GoalRunAway;
/*     */ import baritone.api.pathing.goals.GoalTwoBlocks;
/*     */ import baritone.api.process.IGetToBlockProcess;
/*     */ import baritone.api.process.PathingCommand;
/*     */ import baritone.api.process.PathingCommandType;
/*     */ import baritone.api.utils.BlockOptionalMeta;
/*     */ import baritone.api.utils.BlockOptionalMetaLookup;
/*     */ import baritone.api.utils.Rotation;
/*     */ import baritone.api.utils.RotationUtils;
/*     */ import baritone.api.utils.input.Input;
/*     */ import baritone.pathing.movement.CalculationContext;
/*     */ import baritone.pathing.movement.MovementHelper;
/*     */ import baritone.utils.BaritoneProcessHelper;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2248;
/*     */ import net.minecraft.class_2338;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class GetToBlockProcess
/*     */   extends BaritoneProcessHelper
/*     */   implements IGetToBlockProcess
/*     */ {
/*     */   private BlockOptionalMeta gettingTo;
/*     */   private List<class_2338> knownLocations;
/*     */   private List<class_2338> blacklist;
/*     */   private class_2338 start;
/*  47 */   private int tickCount = 0;
/*  48 */   private int arrivalTickCount = 0;
/*     */   
/*     */   public GetToBlockProcess(Baritone baritone) {
/*  51 */     super(baritone);
/*     */   }
/*     */ 
/*     */   
/*     */   public void getToBlock(BlockOptionalMeta block) {
/*  56 */     onLostControl();
/*  57 */     this.gettingTo = block;
/*  58 */     this.start = (class_2338)this.ctx.playerFeet();
/*  59 */     this.blacklist = new ArrayList<>();
/*  60 */     this.arrivalTickCount = 0;
/*  61 */     rescan(new ArrayList<>(), new CalculationContext((IBaritone)this.baritone));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isActive() {
/*  66 */     return (this.gettingTo != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized PathingCommand onTick(boolean calcFailed, boolean isSafeToCancel) {
/*  71 */     if (this.knownLocations == null) {
/*  72 */       rescan(new ArrayList<>(), new CalculationContext((IBaritone)this.baritone));
/*     */     }
/*  74 */     if (this.knownLocations.isEmpty()) {
/*  75 */       if (((Boolean)(Baritone.settings()).exploreForBlocks.value).booleanValue() && !calcFailed) {
/*  76 */         return new PathingCommand((Goal)new GoalRunAway(1.0D, new class_2338[] { this.start })
/*     */             {
/*     */               public boolean isInGoal(int x, int y, int z) {
/*  79 */                 return false;
/*     */               }
/*     */             }PathingCommandType.FORCE_REVALIDATE_GOAL_AND_PATH);
/*     */       }
/*  83 */       logDirect("No known locations of " + this.gettingTo + ", canceling GetToBlock");
/*  84 */       if (isSafeToCancel) {
/*  85 */         onLostControl();
/*     */       }
/*  87 */       return new PathingCommand(null, PathingCommandType.CANCEL_AND_SET_GOAL);
/*     */     } 
/*  89 */     GoalComposite goalComposite = new GoalComposite((Goal[])this.knownLocations.stream().map(this::createGoal).toArray(x$0 -> new Goal[x$0]));
/*  90 */     if (calcFailed) {
/*  91 */       if (((Boolean)(Baritone.settings()).blacklistClosestOnFailure.value).booleanValue()) {
/*  92 */         logDirect("Unable to find any path to " + this.gettingTo + ", blacklisting presumably unreachable closest instances...");
/*  93 */         blacklistClosest();
/*  94 */         return onTick(false, isSafeToCancel);
/*     */       } 
/*  96 */       logDirect("Unable to find any path to " + this.gettingTo + ", canceling GetToBlock");
/*  97 */       if (isSafeToCancel) {
/*  98 */         onLostControl();
/*     */       }
/* 100 */       return new PathingCommand((Goal)goalComposite, PathingCommandType.CANCEL_AND_SET_GOAL);
/*     */     } 
/*     */     
/* 103 */     int mineGoalUpdateInterval = ((Integer)(Baritone.settings()).mineGoalUpdateInterval.value).intValue();
/* 104 */     if (mineGoalUpdateInterval != 0 && this.tickCount++ % mineGoalUpdateInterval == 0) {
/* 105 */       List<class_2338> current = new ArrayList<>(this.knownLocations);
/* 106 */       CalculationContext context = new CalculationContext((IBaritone)this.baritone, true);
/* 107 */       Baritone.getExecutor().execute(() -> rescan(current, context));
/*     */     } 
/* 109 */     if (goalComposite.isInGoal((class_2338)this.ctx.playerFeet()) && goalComposite.isInGoal((class_2338)this.baritone.getPathingBehavior().pathStart()) && isSafeToCancel)
/*     */     {
/* 111 */       if (rightClickOnArrival(this.gettingTo.getBlock())) {
/* 112 */         if (rightClick()) {
/* 113 */           onLostControl();
/* 114 */           return new PathingCommand(null, PathingCommandType.CANCEL_AND_SET_GOAL);
/*     */         } 
/*     */       } else {
/* 117 */         onLostControl();
/* 118 */         return new PathingCommand(null, PathingCommandType.CANCEL_AND_SET_GOAL);
/*     */       } 
/*     */     }
/* 121 */     return new PathingCommand((Goal)goalComposite, PathingCommandType.REVALIDATE_GOAL_AND_PATH);
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized boolean blacklistClosest() {
/* 126 */     List<class_2338> newBlacklist = new ArrayList<>();
/* 127 */     this.knownLocations.stream().min(Comparator.comparingDouble(this.ctx.playerFeet()::method_10262)).ifPresent(newBlacklist::add);
/*     */     
/*     */     while (true) {
/* 130 */       for (class_2338 known : this.knownLocations) {
/* 131 */         for (class_2338 blacklist : newBlacklist) {
/* 132 */           if (areAdjacent(known, blacklist)) {
/* 133 */             newBlacklist.add(known);
/* 134 */             this.knownLocations.remove(known);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/*     */       break;
/*     */     } 
/* 141 */     switch (newBlacklist.size()) {
/*     */     
/*     */     } 
/*     */ 
/*     */     
/* 146 */     logDebug("Blacklisting unreachable locations " + newBlacklist);
/* 147 */     this.blacklist.addAll(newBlacklist);
/* 148 */     return !newBlacklist.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean areAdjacent(class_2338 posA, class_2338 posB) {
/* 153 */     int diffX = Math.abs(posA.method_10263() - posB.method_10263());
/* 154 */     int diffY = Math.abs(posA.method_10264() - posB.method_10264());
/* 155 */     int diffZ = Math.abs(posA.method_10260() - posB.method_10260());
/* 156 */     return (diffX + diffY + diffZ == 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void onLostControl() {
/* 161 */     this.gettingTo = null;
/* 162 */     this.knownLocations = null;
/* 163 */     this.start = null;
/* 164 */     this.blacklist = null;
/* 165 */     this.baritone.getInputOverrideHandler().clearAllKeys();
/*     */   }
/*     */ 
/*     */   
/*     */   public String displayName0() {
/* 170 */     if (this.knownLocations.isEmpty()) {
/* 171 */       return "Exploring randomly to find " + this.gettingTo + ", no known locations";
/*     */     }
/* 173 */     return "Get To " + this.gettingTo + ", " + this.knownLocations.size() + " known locations";
/*     */   }
/*     */   
/*     */   private synchronized void rescan(List<class_2338> known, CalculationContext context) {
/* 177 */     List<class_2338> positions = MineProcess.searchWorld(context, new BlockOptionalMetaLookup(new BlockOptionalMeta[] { this.gettingTo }, ), 64, known, this.blacklist, Collections.emptyList());
/* 178 */     positions.removeIf(this.blacklist::contains);
/* 179 */     this.knownLocations = positions;
/*     */   }
/*     */   
/*     */   private Goal createGoal(class_2338 pos) {
/* 183 */     if (walkIntoInsteadOfAdjacent(this.gettingTo.getBlock())) {
/* 184 */       return (Goal)new GoalTwoBlocks(pos);
/*     */     }
/* 186 */     if (blockOnTopMustBeRemoved(this.gettingTo.getBlock()) && MovementHelper.isBlockNormalCube(this.baritone.bsi.get0(pos.method_10084()))) {
/* 187 */       return (Goal)new GoalBlock(pos.method_10084());
/*     */     }
/* 189 */     return (Goal)new GoalGetToBlock(pos);
/*     */   }
/*     */   
/*     */   private boolean rightClick() {
/* 193 */     for (class_2338 pos : this.knownLocations) {
/* 194 */       Optional<Rotation> reachable = RotationUtils.reachable(this.ctx.player(), pos, this.ctx.playerController().getBlockReachDistance());
/* 195 */       if (reachable.isPresent()) {
/* 196 */         this.baritone.getLookBehavior().updateTarget(reachable.get(), true);
/* 197 */         if (this.knownLocations.contains(this.ctx.getSelectedBlock().orElse(null))) {
/* 198 */           this.baritone.getInputOverrideHandler().setInputForceState(Input.CLICK_RIGHT, true);
/* 199 */           System.out.println((this.ctx.player()).field_7498);
/* 200 */           if (!((this.ctx.player()).field_7498 instanceof net.minecraft.class_1723)) {
/* 201 */             return true;
/*     */           }
/*     */         } 
/* 204 */         if (this.arrivalTickCount++ > 20) {
/* 205 */           logDirect("Right click timed out");
/* 206 */           return true;
/*     */         } 
/* 208 */         return false;
/*     */       } 
/*     */     } 
/* 211 */     logDirect("Arrived but failed to right click open");
/* 212 */     return true;
/*     */   }
/*     */   
/*     */   private boolean walkIntoInsteadOfAdjacent(class_2248 block) {
/* 216 */     if (!((Boolean)(Baritone.settings()).enterPortal.value).booleanValue()) {
/* 217 */       return false;
/*     */     }
/* 219 */     return (block == class_2246.field_10316);
/*     */   }
/*     */   
/*     */   private boolean rightClickOnArrival(class_2248 block) {
/* 223 */     if (!((Boolean)(Baritone.settings()).rightClickContainerOnArrival.value).booleanValue()) {
/* 224 */       return false;
/*     */     }
/* 226 */     return (block == class_2246.field_9980 || block == class_2246.field_10181 || block == class_2246.field_10443 || block == class_2246.field_10034 || block == class_2246.field_10380);
/*     */   }
/*     */   
/*     */   private boolean blockOnTopMustBeRemoved(class_2248 block) {
/* 230 */     if (!rightClickOnArrival(block)) {
/* 231 */       return false;
/*     */     }
/*     */     
/* 234 */     return (block == class_2246.field_10443 || block == class_2246.field_10034 || block == class_2246.field_10380);
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\process\GetToBlockProcess.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */