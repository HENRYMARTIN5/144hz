/*     */ package baritone;
/*     */ import baritone.api.BaritoneAPI;
/*     */ import baritone.api.Settings;
/*     */ import baritone.api.behavior.ILookBehavior;
/*     */ import baritone.api.behavior.IPathingBehavior;
/*     */ import baritone.api.cache.IWorldProvider;
/*     */ import baritone.api.command.manager.ICommandManager;
/*     */ import baritone.api.event.listener.IEventBus;
/*     */ import baritone.api.event.listener.IGameEventListener;
/*     */ import baritone.api.pathing.calc.IPathingControlManager;
/*     */ import baritone.api.process.IBaritoneProcess;
/*     */ import baritone.api.process.IBuilderProcess;
/*     */ import baritone.api.process.ICustomGoalProcess;
/*     */ import baritone.api.process.IExploreProcess;
/*     */ import baritone.api.process.IFarmProcess;
/*     */ import baritone.api.process.IFollowProcess;
/*     */ import baritone.api.process.IGetToBlockProcess;
/*     */ import baritone.api.process.IMineProcess;
/*     */ import baritone.api.selection.ISelectionManager;
/*     */ import baritone.api.utils.Helper;
/*     */ import baritone.api.utils.IInputOverrideHandler;
/*     */ import baritone.api.utils.IPlayerContext;
/*     */ import baritone.behavior.Behavior;
/*     */ import baritone.behavior.InventoryBehavior;
/*     */ import baritone.behavior.LookBehavior;
/*     */ import baritone.behavior.MemoryBehavior;
/*     */ import baritone.behavior.PathingBehavior;
/*     */ import baritone.cache.WorldProvider;
/*     */ import baritone.command.manager.CommandManager;
/*     */ import baritone.event.GameEventHandler;
/*     */ import baritone.process.BackfillProcess;
/*     */ import baritone.process.BuilderProcess;
/*     */ import baritone.process.CustomGoalProcess;
/*     */ import baritone.process.ExploreProcess;
/*     */ import baritone.process.FarmProcess;
/*     */ import baritone.process.FollowProcess;
/*     */ import baritone.process.GetToBlockProcess;
/*     */ import baritone.process.MineProcess;
/*     */ import baritone.selection.SelectionManager;
/*     */ import baritone.utils.BaritoneAutoTest;
/*     */ import baritone.utils.BlockStateInterface;
/*     */ import baritone.utils.GuiClick;
/*     */ import baritone.utils.InputOverrideHandler;
/*     */ import baritone.utils.PathingControlManager;
/*     */ import baritone.utils.player.PrimaryPlayerContext;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.attribute.FileAttribute;
/*     */ import java.util.concurrent.SynchronousQueue;
/*     */ import java.util.concurrent.ThreadPoolExecutor;
/*     */ 
/*     */ public class Baritone implements IBaritone {
/*  54 */   private static ThreadPoolExecutor threadPool = new ThreadPoolExecutor(4, 2147483647, 60L, TimeUnit.SECONDS, new SynchronousQueue<>());
/*     */   
/*  56 */   private static File dir = new File((class_310.method_1551()).field_1697, "baritone"); private GameEventHandler gameEventHandler; private PathingBehavior pathingBehavior; static {
/*  57 */     if (!Files.exists(dir.toPath(), new java.nio.file.LinkOption[0])) {
/*     */       try {
/*  59 */         Files.createDirectories(dir.toPath(), (FileAttribute<?>[])new FileAttribute[0]);
/*  60 */       } catch (IOException iOException) {}
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private LookBehavior lookBehavior;
/*     */   
/*     */   private MemoryBehavior memoryBehavior;
/*     */   
/*     */   private InventoryBehavior inventoryBehavior;
/*     */   
/*     */   private InputOverrideHandler inputOverrideHandler;
/*     */   
/*     */   private FollowProcess followProcess;
/*     */   
/*     */   private MineProcess mineProcess;
/*     */   
/*     */   private GetToBlockProcess getToBlockProcess;
/*     */   private CustomGoalProcess customGoalProcess;
/*     */   private BuilderProcess builderProcess;
/*     */   private ExploreProcess exploreProcess;
/*     */   private BackfillProcess backfillProcess;
/*     */   private FarmProcess farmProcess;
/*     */   private PathingControlManager pathingControlManager;
/*     */   private SelectionManager selectionManager;
/*     */   private CommandManager commandManager;
/*     */   private IPlayerContext playerContext;
/*     */   private WorldProvider worldProvider;
/*     */   public BlockStateInterface bsi;
/*     */   
/*     */   Baritone() {
/*  91 */     this.gameEventHandler = new GameEventHandler(this);
/*     */ 
/*     */     
/*  94 */     this.playerContext = (IPlayerContext)PrimaryPlayerContext.INSTANCE;
/*     */ 
/*     */ 
/*     */     
/*  98 */     this.pathingBehavior = new PathingBehavior(this);
/*  99 */     this.lookBehavior = new LookBehavior(this);
/* 100 */     this.memoryBehavior = new MemoryBehavior(this);
/* 101 */     this.inventoryBehavior = new InventoryBehavior(this);
/* 102 */     this.inputOverrideHandler = new InputOverrideHandler(this);
/*     */ 
/*     */     
/* 105 */     this.pathingControlManager = new PathingControlManager(this);
/*     */     
/* 107 */     this.pathingControlManager.registerProcess((IBaritoneProcess)(this.followProcess = new FollowProcess(this)));
/* 108 */     this.pathingControlManager.registerProcess((IBaritoneProcess)(this.mineProcess = new MineProcess(this)));
/* 109 */     this.pathingControlManager.registerProcess((IBaritoneProcess)(this.customGoalProcess = new CustomGoalProcess(this)));
/* 110 */     this.pathingControlManager.registerProcess((IBaritoneProcess)(this.getToBlockProcess = new GetToBlockProcess(this)));
/* 111 */     this.pathingControlManager.registerProcess((IBaritoneProcess)(this.builderProcess = new BuilderProcess(this)));
/* 112 */     this.pathingControlManager.registerProcess((IBaritoneProcess)(this.exploreProcess = new ExploreProcess(this)));
/* 113 */     this.pathingControlManager.registerProcess((IBaritoneProcess)(this.backfillProcess = new BackfillProcess(this)));
/* 114 */     this.pathingControlManager.registerProcess((IBaritoneProcess)(this.farmProcess = new FarmProcess(this)));
/*     */ 
/*     */     
/* 117 */     this.worldProvider = new WorldProvider();
/* 118 */     this.selectionManager = new SelectionManager(this);
/* 119 */     this.commandManager = new CommandManager(this);
/*     */     
/* 121 */     if (BaritoneAutoTest.ENABLE_AUTO_TEST) {
/* 122 */       this.gameEventHandler.registerEventListener((IGameEventListener)BaritoneAutoTest.INSTANCE);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public PathingControlManager getPathingControlManager() {
/* 128 */     return this.pathingControlManager;
/*     */   }
/*     */   
/*     */   public void registerBehavior(Behavior behavior) {
/* 132 */     this.gameEventHandler.registerEventListener((IGameEventListener)behavior);
/*     */   }
/*     */ 
/*     */   
/*     */   public InputOverrideHandler getInputOverrideHandler() {
/* 137 */     return this.inputOverrideHandler;
/*     */   }
/*     */ 
/*     */   
/*     */   public CustomGoalProcess getCustomGoalProcess() {
/* 142 */     return this.customGoalProcess;
/*     */   }
/*     */ 
/*     */   
/*     */   public GetToBlockProcess getGetToBlockProcess() {
/* 147 */     return this.getToBlockProcess;
/*     */   }
/*     */ 
/*     */   
/*     */   public IPlayerContext getPlayerContext() {
/* 152 */     return this.playerContext;
/*     */   }
/*     */   
/*     */   public MemoryBehavior getMemoryBehavior() {
/* 156 */     return this.memoryBehavior;
/*     */   }
/*     */ 
/*     */   
/*     */   public FollowProcess getFollowProcess() {
/* 161 */     return this.followProcess;
/*     */   }
/*     */ 
/*     */   
/*     */   public BuilderProcess getBuilderProcess() {
/* 166 */     return this.builderProcess;
/*     */   }
/*     */   
/*     */   public InventoryBehavior getInventoryBehavior() {
/* 170 */     return this.inventoryBehavior;
/*     */   }
/*     */ 
/*     */   
/*     */   public LookBehavior getLookBehavior() {
/* 175 */     return this.lookBehavior;
/*     */   }
/*     */   
/*     */   public ExploreProcess getExploreProcess() {
/* 179 */     return this.exploreProcess;
/*     */   }
/*     */ 
/*     */   
/*     */   public MineProcess getMineProcess() {
/* 184 */     return this.mineProcess;
/*     */   }
/*     */   
/*     */   public FarmProcess getFarmProcess() {
/* 188 */     return this.farmProcess;
/*     */   }
/*     */ 
/*     */   
/*     */   public PathingBehavior getPathingBehavior() {
/* 193 */     return this.pathingBehavior;
/*     */   }
/*     */ 
/*     */   
/*     */   public SelectionManager getSelectionManager() {
/* 198 */     return this.selectionManager;
/*     */   }
/*     */ 
/*     */   
/*     */   public WorldProvider getWorldProvider() {
/* 203 */     return this.worldProvider;
/*     */   }
/*     */ 
/*     */   
/*     */   public IEventBus getGameEventHandler() {
/* 208 */     return (IEventBus)this.gameEventHandler;
/*     */   }
/*     */ 
/*     */   
/*     */   public CommandManager getCommandManager() {
/* 213 */     return this.commandManager;
/*     */   }
/*     */ 
/*     */   
/*     */   public void openClick() {
/* 218 */     (new Thread(() -> {
/*     */           try {
/*     */             Thread.sleep(100L);
/*     */             Helper.mc.execute(());
/* 222 */           } catch (Exception exception) {}
/* 223 */         })).start();
/*     */   }
/*     */   
/*     */   public static Settings settings() {
/* 227 */     return BaritoneAPI.getSettings();
/*     */   }
/*     */   
/*     */   public static File getDir() {
/* 231 */     return dir;
/*     */   }
/*     */   
/*     */   public static Executor getExecutor() {
/* 235 */     return threadPool;
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\Baritone.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */