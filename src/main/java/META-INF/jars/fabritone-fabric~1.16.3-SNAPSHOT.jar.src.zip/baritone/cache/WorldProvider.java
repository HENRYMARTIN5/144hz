/*     */ package baritone.cache;
/*     */ 
/*     */ import baritone.Baritone;
/*     */ import baritone.api.cache.IWorldData;
/*     */ import baritone.api.cache.IWorldProvider;
/*     */ import baritone.api.utils.Helper;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.attribute.FileAttribute;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.function.Consumer;
/*     */ import net.minecraft.class_1132;
/*     */ import net.minecraft.class_1937;
/*     */ import net.minecraft.class_2874;
/*     */ import net.minecraft.class_5218;
/*     */ import net.minecraft.class_5321;
/*     */ import org.apache.commons.lang3.SystemUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WorldProvider
/*     */   implements IWorldProvider, Helper
/*     */ {
/*  45 */   private static final Map<Path, WorldData> worldCache = new HashMap<>();
/*     */   
/*     */   private WorldData currentWorld;
/*     */ 
/*     */   
/*     */   public final WorldData getCurrentWorld() {
/*  51 */     return this.currentWorld;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void initWorld(class_5321<class_1937> world) {
/*     */     File directory, readme;
/*  63 */     class_1132 integratedServer = mc.method_1576();
/*     */ 
/*     */     
/*  66 */     if (mc.method_1542()) {
/*  67 */       directory = class_2874.method_12488(world, integratedServer.method_27050(class_5218.field_24188).toFile());
/*     */ 
/*     */       
/*  70 */       if (directory.toPath().relativize(mc.field_1697.toPath()).getNameCount() != 2)
/*     */       {
/*  72 */         directory = directory.getParentFile();
/*     */       }
/*     */       
/*  75 */       directory = new File(directory, "baritone");
/*  76 */       readme = directory;
/*     */     } else {
/*  78 */       String folderName = mc.method_1589() ? "realms" : (mc.method_1558()).field_3761;
/*  79 */       if (SystemUtils.IS_OS_WINDOWS) {
/*  80 */         folderName = folderName.replace(":", "_");
/*     */       }
/*  82 */       directory = new File(Baritone.getDir(), folderName);
/*  83 */       readme = Baritone.getDir();
/*     */     } 
/*     */ 
/*     */     
/*  87 */     try (FileOutputStream out = new FileOutputStream(new File(readme, "readme.txt"))) {
/*     */       
/*  89 */       out.write("https://github.com/cabaletta/baritone\n".getBytes());
/*  90 */     } catch (IOException iOException) {}
/*     */ 
/*     */     
/*  93 */     Path dir = class_2874.method_12488(world, directory).toPath();
/*  94 */     if (!Files.exists(dir, new java.nio.file.LinkOption[0])) {
/*     */       try {
/*  96 */         Files.createDirectories(dir, (FileAttribute<?>[])new FileAttribute[0]);
/*  97 */       } catch (IOException iOException) {}
/*     */     }
/*     */     
/* 100 */     System.out.println("Baritone world data dir: " + dir);
/* 101 */     synchronized (worldCache) {
/* 102 */       this.currentWorld = worldCache.computeIfAbsent(dir, d -> new WorldData(d, world));
/*     */     } 
/*     */   }
/*     */   
/*     */   public final void closeWorld() {
/* 107 */     WorldData world = this.currentWorld;
/* 108 */     this.currentWorld = null;
/* 109 */     if (world == null) {
/*     */       return;
/*     */     }
/* 112 */     world.onClose();
/*     */   }
/*     */   
/*     */   public final void ifWorldLoaded(Consumer<WorldData> currentWorldConsumer) {
/* 116 */     if (this.currentWorld != null)
/* 117 */       currentWorldConsumer.accept(this.currentWorld); 
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\cache\WorldProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */