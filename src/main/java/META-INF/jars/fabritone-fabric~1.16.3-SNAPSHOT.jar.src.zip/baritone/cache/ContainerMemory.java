/*     */ package baritone.cache;
/*     */ 
/*     */ import baritone.Baritone;
/*     */ import baritone.api.cache.IContainerMemory;
/*     */ import baritone.api.cache.IRememberedInventory;
/*     */ import baritone.api.utils.IPlayerContext;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.Unpooled;
/*     */ import java.io.IOException;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.NoSuchFileException;
/*     */ import java.nio.file.Path;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2540;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContainerMemory
/*     */   implements IContainerMemory
/*     */ {
/*     */   private final Path saveTo;
/*  42 */   private final Map<class_2338, RememberedInventory> inventories = new HashMap<>();
/*     */ 
/*     */   
/*     */   public ContainerMemory(Path saveTo) {
/*  46 */     this.saveTo = saveTo;
/*     */     try {
/*  48 */       read(Files.readAllBytes(saveTo));
/*  49 */     } catch (NoSuchFileException ignored) {
/*  50 */       this.inventories.clear();
/*  51 */     } catch (Exception ex) {
/*  52 */       ex.printStackTrace();
/*  53 */       this.inventories.clear();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void read(byte[] bytes) throws IOException {
/*  58 */     class_2540 in = new class_2540(Unpooled.wrappedBuffer(bytes));
/*  59 */     int chests = in.readInt();
/*  60 */     for (int i = 0; i < chests; i++) {
/*  61 */       int x = in.readInt();
/*  62 */       int y = in.readInt();
/*  63 */       int z = in.readInt();
/*  64 */       RememberedInventory rem = new RememberedInventory();
/*  65 */       rem.items.addAll(readItemStacks(in));
/*  66 */       rem.size = rem.items.size();
/*  67 */       rem.windowId = -1;
/*  68 */       if (!rem.items.isEmpty())
/*     */       {
/*     */         
/*  71 */         this.inventories.put(new class_2338(x, y, z), rem); } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public synchronized void save() throws IOException {
/*  76 */     if (!((Boolean)(Baritone.settings()).containerMemory.value).booleanValue()) {
/*     */       return;
/*     */     }
/*  79 */     ByteBuf buf = Unpooled.buffer(0, 2147483647);
/*  80 */     class_2540 out = new class_2540(buf);
/*  81 */     out.writeInt(this.inventories.size());
/*  82 */     for (Map.Entry<class_2338, RememberedInventory> entry : this.inventories.entrySet()) {
/*  83 */       out = new class_2540(out.writeInt(((class_2338)entry.getKey()).method_10263()));
/*  84 */       out = new class_2540(out.writeInt(((class_2338)entry.getKey()).method_10264()));
/*  85 */       out = new class_2540(out.writeInt(((class_2338)entry.getKey()).method_10260()));
/*  86 */       out = writeItemStacks(((RememberedInventory)entry.getValue()).getContents(), out);
/*     */     } 
/*  88 */     Files.write(this.saveTo, out.array(), new java.nio.file.OpenOption[0]);
/*     */   }
/*     */   
/*     */   public synchronized void setup(class_2338 pos, int windowId, int slotCount) {
/*  92 */     RememberedInventory inventory = this.inventories.computeIfAbsent(pos, x -> new RememberedInventory());
/*  93 */     inventory.windowId = windowId;
/*  94 */     inventory.size = slotCount;
/*     */   }
/*     */   
/*     */   public synchronized Optional<RememberedInventory> getInventoryFromWindow(int windowId) {
/*  98 */     return this.inventories.values().stream().filter(i -> (i.windowId == windowId)).findFirst();
/*     */   }
/*     */ 
/*     */   
/*     */   public final synchronized RememberedInventory getInventoryByPos(class_2338 pos) {
/* 103 */     return this.inventories.get(pos);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final synchronized Map<class_2338, IRememberedInventory> getRememberedInventories() {
/* 109 */     return new HashMap<>((Map)this.inventories);
/*     */   }
/*     */   
/*     */   public static List<class_1799> readItemStacks(byte[] bytes) throws IOException {
/* 113 */     class_2540 in = new class_2540(Unpooled.wrappedBuffer(bytes));
/* 114 */     return readItemStacks(in);
/*     */   }
/*     */   
/*     */   public static List<class_1799> readItemStacks(class_2540 in) throws IOException {
/* 118 */     int count = in.readInt();
/* 119 */     List<class_1799> result = new ArrayList<>();
/* 120 */     for (int i = 0; i < count; i++) {
/* 121 */       result.add(in.method_10819());
/*     */     }
/* 123 */     return result;
/*     */   }
/*     */   
/*     */   public static byte[] writeItemStacks(List<class_1799> write) {
/* 127 */     ByteBuf buf = Unpooled.buffer(0, 2147483647);
/* 128 */     class_2540 out = new class_2540(buf);
/* 129 */     out = writeItemStacks(write, out);
/* 130 */     return out.array();
/*     */   }
/*     */   
/*     */   public static class_2540 writeItemStacks(List<class_1799> write, class_2540 out2) {
/* 134 */     class_2540 out = out2;
/* 135 */     out = new class_2540(out.writeInt(write.size()));
/* 136 */     for (class_1799 stack : write) {
/* 137 */       out = out.method_10793(stack);
/*     */     }
/* 139 */     return out;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class RememberedInventory
/*     */     implements IRememberedInventory
/*     */   {
/* 165 */     private final List<class_1799> items = new ArrayList<>();
/*     */     private int windowId;
/*     */     private int size;
/*     */     
/*     */     public final List<class_1799> getContents() {
/* 170 */       return Collections.unmodifiableList(this.items);
/*     */     }
/*     */ 
/*     */     
/*     */     public final int getSize() {
/* 175 */       return this.size;
/*     */     }
/*     */     
/*     */     public void updateFromOpenWindow(IPlayerContext ctx) {
/* 179 */       this.items.clear();
/* 180 */       this.items.addAll((ctx.player()).field_7498.method_7602().subList(0, this.size));
/*     */     }
/*     */     
/*     */     private RememberedInventory() {}
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\cache\ContainerMemory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */