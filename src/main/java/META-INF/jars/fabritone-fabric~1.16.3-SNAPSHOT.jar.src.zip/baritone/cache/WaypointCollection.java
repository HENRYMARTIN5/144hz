/*     */ package baritone.cache;
/*     */ 
/*     */ import baritone.api.cache.IWaypoint;
/*     */ import baritone.api.cache.IWaypointCollection;
/*     */ import baritone.api.cache.Waypoint;
/*     */ import baritone.api.utils.BetterBlockPos;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.attribute.FileAttribute;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Collectors;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WaypointCollection
/*     */   implements IWaypointCollection
/*     */ {
/*     */   private static final long WAYPOINT_MAGIC_VALUE = 121977993584L;
/*     */   private final Path directory;
/*     */   private final Map<IWaypoint.Tag, Set<IWaypoint>> waypoints;
/*     */   
/*     */   WaypointCollection(Path directory) {
/*  47 */     this.directory = directory;
/*  48 */     if (!Files.exists(directory, new java.nio.file.LinkOption[0])) {
/*     */       try {
/*  50 */         Files.createDirectories(directory, (FileAttribute<?>[])new FileAttribute[0]);
/*  51 */       } catch (IOException iOException) {}
/*     */     }
/*  53 */     System.out.println("Would save waypoints to " + directory);
/*  54 */     this.waypoints = new HashMap<>();
/*  55 */     load();
/*     */   }
/*     */   
/*     */   private void load() {
/*  59 */     for (IWaypoint.Tag tag : IWaypoint.Tag.values()) {
/*  60 */       load(tag);
/*     */     }
/*     */   }
/*     */   
/*     */   private synchronized void load(IWaypoint.Tag tag) {
/*  65 */     this.waypoints.put(tag, new HashSet<>());
/*     */     
/*  67 */     Path fileName = this.directory.resolve(tag.name().toLowerCase() + ".mp4");
/*  68 */     if (!Files.exists(fileName, new java.nio.file.LinkOption[0])) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  73 */     try(FileInputStream fileIn = new FileInputStream(fileName.toFile()); 
/*  74 */         BufferedInputStream bufIn = new BufferedInputStream(fileIn); 
/*  75 */         DataInputStream in = new DataInputStream(bufIn)) {
/*     */       
/*  77 */       long magic = in.readLong();
/*  78 */       if (magic != 121977993584L) {
/*  79 */         throw new IOException("Bad magic value " + magic);
/*     */       }
/*     */       
/*  82 */       long length = in.readLong();
/*  83 */       while (length-- > 0L) {
/*  84 */         String name = in.readUTF();
/*  85 */         long creationTimestamp = in.readLong();
/*  86 */         int x = in.readInt();
/*  87 */         int y = in.readInt();
/*  88 */         int z = in.readInt();
/*  89 */         ((Set<Waypoint>)this.waypoints.get(tag)).add(new Waypoint(name, tag, new BetterBlockPos(x, y, z), creationTimestamp));
/*     */       } 
/*  91 */     } catch (IOException iOException) {}
/*     */   }
/*     */   
/*     */   private synchronized void save(IWaypoint.Tag tag) {
/*  95 */     Path fileName = this.directory.resolve(tag.name().toLowerCase() + ".mp4");
/*     */     
/*  97 */     try(FileOutputStream fileOut = new FileOutputStream(fileName.toFile()); 
/*  98 */         BufferedOutputStream bufOut = new BufferedOutputStream(fileOut); 
/*  99 */         DataOutputStream out = new DataOutputStream(bufOut)) {
/*     */       
/* 101 */       out.writeLong(121977993584L);
/* 102 */       out.writeLong(((Set)this.waypoints.get(tag)).size());
/* 103 */       for (IWaypoint waypoint : this.waypoints.get(tag)) {
/* 104 */         out.writeUTF(waypoint.getName());
/* 105 */         out.writeLong(waypoint.getCreationTimestamp());
/* 106 */         out.writeInt(waypoint.getLocation().method_10263());
/* 107 */         out.writeInt(waypoint.getLocation().method_10264());
/* 108 */         out.writeInt(waypoint.getLocation().method_10260());
/*     */       } 
/* 110 */     } catch (IOException ex) {
/* 111 */       ex.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addWaypoint(IWaypoint waypoint) {
/* 118 */     if (((Set<IWaypoint>)this.waypoints.get(waypoint.getTag())).add(waypoint)) {
/* 119 */       save(waypoint.getTag());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeWaypoint(IWaypoint waypoint) {
/* 125 */     if (((Set)this.waypoints.get(waypoint.getTag())).remove(waypoint)) {
/* 126 */       save(waypoint.getTag());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IWaypoint getMostRecentByTag(IWaypoint.Tag tag) {
/* 133 */     return ((Set<IWaypoint>)this.waypoints.get(tag)).stream().min(Comparator.comparingLong(w -> -w.getCreationTimestamp())).orElse(null);
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<IWaypoint> getByTag(IWaypoint.Tag tag) {
/* 138 */     return Collections.unmodifiableSet(this.waypoints.get(tag));
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<IWaypoint> getAllWaypoints() {
/* 143 */     return (Set<IWaypoint>)this.waypoints.values().stream().flatMap(Collection::stream).collect(Collectors.toSet());
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\cache\WaypointCollection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */