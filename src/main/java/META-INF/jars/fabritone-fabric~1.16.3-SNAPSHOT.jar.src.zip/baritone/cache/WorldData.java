/*    */ package baritone.cache;
/*    */ 
/*    */ import baritone.Baritone;
/*    */ import baritone.api.cache.ICachedWorld;
/*    */ import baritone.api.cache.IContainerMemory;
/*    */ import baritone.api.cache.IWaypointCollection;
/*    */ import baritone.api.cache.IWorldData;
/*    */ import java.io.IOException;
/*    */ import java.nio.file.Path;
/*    */ import net.minecraft.class_1937;
/*    */ import net.minecraft.class_5321;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WorldData
/*    */   implements IWorldData
/*    */ {
/*    */   public final CachedWorld cache;
/*    */   private final WaypointCollection waypoints;
/*    */   private final ContainerMemory containerMemory;
/*    */   public final Path directory;
/*    */   public final class_5321<class_1937> dimension;
/*    */   
/*    */   WorldData(Path directory, class_5321<class_1937> dimension) {
/* 46 */     this.directory = directory;
/* 47 */     this.cache = new CachedWorld(directory.resolve("cache"), dimension);
/* 48 */     this.waypoints = new WaypointCollection(directory.resolve("waypoints"));
/* 49 */     this.containerMemory = new ContainerMemory(directory.resolve("containers"));
/* 50 */     this.dimension = dimension;
/*    */   }
/*    */   
/*    */   public void onClose() {
/* 54 */     Baritone.getExecutor().execute(() -> {
/*    */           System.out.println("Started saving the world in a new thread");
/*    */           this.cache.save();
/*    */         });
/* 58 */     Baritone.getExecutor().execute(() -> {
/*    */           System.out.println("Started saving saved containers in a new thread");
/*    */           try {
/*    */             this.containerMemory.save();
/* 62 */           } catch (IOException e) {
/*    */             e.printStackTrace();
/*    */             System.out.println("Failed to save saved containers");
/*    */           } 
/*    */         });
/*    */   }
/*    */ 
/*    */   
/*    */   public ICachedWorld getCachedWorld() {
/* 71 */     return this.cache;
/*    */   }
/*    */ 
/*    */   
/*    */   public IWaypointCollection getWaypoints() {
/* 76 */     return this.waypoints;
/*    */   }
/*    */ 
/*    */   
/*    */   public IContainerMemory getContainerMemory() {
/* 81 */     return this.containerMemory;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\cache\WorldData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */