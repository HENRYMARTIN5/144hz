/*     */ package baritone.cache;
/*     */ 
/*     */ import baritone.Baritone;
/*     */ import baritone.api.cache.ICachedRegion;
/*     */ import baritone.api.utils.BlockUtils;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.Paths;
/*     */ import java.nio.file.attribute.FileAttribute;
/*     */ import java.util.ArrayList;
/*     */ import java.util.BitSet;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.zip.GZIPInputStream;
/*     */ import java.util.zip.GZIPOutputStream;
/*     */ import net.minecraft.class_1937;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_5321;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CachedRegion
/*     */   implements ICachedRegion
/*     */ {
/*     */   private static final byte CHUNK_NOT_PRESENT = 0;
/*     */   private static final byte CHUNK_PRESENT = 1;
/*     */   private static final int CACHED_REGION_MAGIC = 456022910;
/*  53 */   private final CachedChunk[][] chunks = new CachedChunk[32][32];
/*     */ 
/*     */ 
/*     */   
/*     */   private final int x;
/*     */ 
/*     */ 
/*     */   
/*     */   private final int z;
/*     */ 
/*     */ 
/*     */   
/*     */   private final class_5321<class_1937> dimension;
/*     */ 
/*     */   
/*     */   private boolean hasUnsavedChanges;
/*     */ 
/*     */ 
/*     */   
/*     */   CachedRegion(int x, int z, class_5321<class_1937> dimension) {
/*  73 */     this.x = x;
/*  74 */     this.z = z;
/*  75 */     this.hasUnsavedChanges = false;
/*  76 */     this.dimension = dimension;
/*     */   }
/*     */ 
/*     */   
/*     */   public final class_2680 getBlock(int x, int y, int z) {
/*  81 */     CachedChunk chunk = this.chunks[x >> 4][z >> 4];
/*  82 */     if (chunk != null) {
/*  83 */       return chunk.getBlock(x & 0xF, y, z & 0xF, this.dimension);
/*     */     }
/*  85 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isCached(int x, int z) {
/*  90 */     return (this.chunks[x >> 4][z >> 4] != null);
/*     */   }
/*     */   
/*     */   public final ArrayList<class_2338> getLocationsOf(String block) {
/*  94 */     ArrayList<class_2338> res = new ArrayList<>();
/*  95 */     for (int chunkX = 0; chunkX < 32; chunkX++) {
/*  96 */       for (int chunkZ = 0; chunkZ < 32; chunkZ++) {
/*  97 */         if (this.chunks[chunkX][chunkZ] != null) {
/*     */ 
/*     */           
/* 100 */           ArrayList<class_2338> locs = this.chunks[chunkX][chunkZ].getAbsoluteBlocks(block);
/* 101 */           if (locs != null)
/* 102 */             res.addAll(locs); 
/*     */         } 
/*     */       } 
/*     */     } 
/* 106 */     return res;
/*     */   }
/*     */   
/*     */   public final synchronized void updateCachedChunk(int chunkX, int chunkZ, CachedChunk chunk) {
/* 110 */     this.chunks[chunkX][chunkZ] = chunk;
/* 111 */     this.hasUnsavedChanges = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public final synchronized void save(String directory) {
/* 116 */     if (!this.hasUnsavedChanges) {
/*     */       return;
/*     */     }
/* 119 */     removeExpired();
/*     */     try {
/* 121 */       Path path = Paths.get(directory, new String[0]);
/* 122 */       if (!Files.exists(path, new java.nio.file.LinkOption[0])) {
/* 123 */         Files.createDirectories(path, (FileAttribute<?>[])new FileAttribute[0]);
/*     */       }
/*     */       
/* 126 */       System.out.println("Saving region " + this.x + "," + this.z + " to disk " + path);
/* 127 */       Path regionFile = getRegionFile(path, this.x, this.z);
/* 128 */       if (!Files.exists(regionFile, new java.nio.file.LinkOption[0])) {
/* 129 */         Files.createFile(regionFile, (FileAttribute<?>[])new FileAttribute[0]);
/*     */       }
/*     */       
/* 132 */       try(FileOutputStream fileOut = new FileOutputStream(regionFile.toFile()); 
/* 133 */           GZIPOutputStream gzipOut = new GZIPOutputStream(fileOut, 16384); 
/* 134 */           DataOutputStream out = new DataOutputStream(gzipOut)) {
/*     */         
/* 136 */         out.writeInt(456022910); int x;
/* 137 */         for (x = 0; x < 32; x++) {
/* 138 */           for (int z = 0; z < 32; z++) {
/* 139 */             CachedChunk chunk = this.chunks[x][z];
/* 140 */             if (chunk == null) {
/* 141 */               out.write(0);
/*     */             } else {
/* 143 */               out.write(1);
/* 144 */               byte[] chunkBytes = chunk.toByteArray();
/* 145 */               out.write(chunkBytes);
/*     */               
/* 147 */               out.write(new byte[16384 - chunkBytes.length]);
/*     */             } 
/*     */           } 
/*     */         } 
/* 151 */         for (x = 0; x < 32; x++) {
/* 152 */           for (int z = 0; z < 32; z++) {
/* 153 */             if (this.chunks[x][z] != null) {
/* 154 */               for (int i = 0; i < 256; i++) {
/* 155 */                 out.writeUTF(BlockUtils.blockToString(this.chunks[x][z].getOverview()[i].method_26204()));
/*     */               }
/*     */             }
/*     */           } 
/*     */         } 
/* 160 */         for (x = 0; x < 32; x++) {
/* 161 */           for (int z = 0; z < 32; z++) {
/* 162 */             if (this.chunks[x][z] != null) {
/* 163 */               Map<String, List<class_2338>> locs = this.chunks[x][z].getRelativeBlocks();
/* 164 */               out.writeShort(locs.entrySet().size());
/* 165 */               for (Map.Entry<String, List<class_2338>> entry : locs.entrySet()) {
/* 166 */                 out.writeUTF(entry.getKey());
/* 167 */                 out.writeShort(((List)entry.getValue()).size());
/* 168 */                 for (class_2338 pos : entry.getValue()) {
/* 169 */                   out.writeByte((byte)(pos.method_10260() << 4 | pos.method_10263()));
/* 170 */                   out.writeByte((byte)pos.method_10264());
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/* 176 */         for (x = 0; x < 32; x++) {
/* 177 */           for (int z = 0; z < 32; z++) {
/* 178 */             if (this.chunks[x][z] != null) {
/* 179 */               out.writeLong((this.chunks[x][z]).cacheTimestamp);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/* 184 */       this.hasUnsavedChanges = false;
/* 185 */       System.out.println("Saved region successfully");
/* 186 */     } catch (Exception ex) {
/* 187 */       ex.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public synchronized void load(String directory) {
/*     */     try {
/* 193 */       Path path = Paths.get(directory, new String[0]);
/* 194 */       if (!Files.exists(path, new java.nio.file.LinkOption[0])) {
/* 195 */         Files.createDirectories(path, (FileAttribute<?>[])new FileAttribute[0]);
/*     */       }
/*     */       
/* 198 */       Path regionFile = getRegionFile(path, this.x, this.z);
/* 199 */       if (!Files.exists(regionFile, new java.nio.file.LinkOption[0])) {
/*     */         return;
/*     */       }
/*     */       
/* 203 */       System.out.println("Loading region " + this.x + "," + this.z + " from disk " + path);
/* 204 */       long start = System.nanoTime() / 1000000L;
/*     */ 
/*     */       
/* 207 */       try(FileInputStream fileIn = new FileInputStream(regionFile.toFile()); 
/* 208 */           GZIPInputStream gzipIn = new GZIPInputStream(fileIn, 32768); 
/* 209 */           DataInputStream in = new DataInputStream(gzipIn)) {
/*     */         
/* 211 */         int magic = in.readInt();
/* 212 */         if (magic != 456022910)
/*     */         {
/*     */ 
/*     */           
/* 216 */           throw new IOException("Bad magic value " + magic);
/*     */         }
/* 218 */         boolean[][] present = new boolean[32][32];
/* 219 */         BitSet[][] bitSets = new BitSet[32][32];
/* 220 */         Map[][] arrayOfMap = new Map[32][32];
/* 221 */         class_2680[][][] overview = new class_2680[32][32][];
/* 222 */         long[][] cacheTimestamp = new long[32][32]; int x;
/* 223 */         for (x = 0; x < 32; x++) {
/* 224 */           for (int z = 0; z < 32; z++) {
/* 225 */             byte[] bytes; int isChunkPresent = in.read();
/* 226 */             switch (isChunkPresent) {
/*     */               case 1:
/* 228 */                 bytes = new byte[16384];
/* 229 */                 in.readFully(bytes);
/* 230 */                 bitSets[x][z] = BitSet.valueOf(bytes);
/* 231 */                 arrayOfMap[x][z] = new HashMap<>();
/* 232 */                 overview[x][z] = new class_2680[256];
/* 233 */                 present[x][z] = true;
/*     */                 break;
/*     */               case 0:
/*     */                 break;
/*     */               default:
/* 238 */                 throw new IOException("Malformed stream");
/*     */             } 
/*     */           } 
/*     */         } 
/* 242 */         for (x = 0; x < 32; x++) {
/* 243 */           for (int z = 0; z < 32; z++) {
/* 244 */             if (present[x][z]) {
/* 245 */               for (int i = 0; i < 256; i++) {
/* 246 */                 overview[x][z][i] = BlockUtils.stringToBlockRequired(in.readUTF()).method_9564();
/*     */               }
/*     */             }
/*     */           } 
/*     */         } 
/* 251 */         for (x = 0; x < 32; x++) {
/* 252 */           for (int z = 0; z < 32; z++) {
/* 253 */             if (present[x][z]) {
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 258 */               int numSpecialBlockTypes = in.readShort() & 0xFFFF;
/* 259 */               for (int i = 0; i < numSpecialBlockTypes; i++) {
/* 260 */                 String blockName = in.readUTF();
/* 261 */                 BlockUtils.stringToBlockRequired(blockName);
/* 262 */                 List<class_2338> locs = new ArrayList<>();
/* 263 */                 arrayOfMap[x][z].put(blockName, locs);
/* 264 */                 int numLocations = in.readShort() & 0xFFFF;
/* 265 */                 if (numLocations == 0)
/*     */                 {
/* 267 */                   numLocations = 65536;
/*     */                 }
/* 269 */                 for (int j = 0; j < numLocations; j++) {
/* 270 */                   byte xz = in.readByte();
/* 271 */                   int X = xz & 0xF;
/* 272 */                   int Z = xz >>> 4 & 0xF;
/* 273 */                   int Y = in.readByte() & 0xFF;
/* 274 */                   locs.add(new class_2338(X, Y, Z));
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/* 280 */         for (x = 0; x < 32; x++) {
/* 281 */           for (int z = 0; z < 32; z++) {
/* 282 */             if (present[x][z]) {
/* 283 */               cacheTimestamp[x][z] = in.readLong();
/*     */             }
/*     */           } 
/*     */         } 
/*     */         
/* 288 */         for (x = 0; x < 32; x++) {
/* 289 */           for (int z = 0; z < 32; z++) {
/* 290 */             if (present[x][z]) {
/* 291 */               int regionX = this.x;
/* 292 */               int regionZ = this.z;
/* 293 */               int chunkX = x + 32 * regionX;
/* 294 */               int chunkZ = z + 32 * regionZ;
/* 295 */               this.chunks[x][z] = new CachedChunk(chunkX, chunkZ, bitSets[x][z], overview[x][z], arrayOfMap[x][z], cacheTimestamp[x][z]);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 300 */       removeExpired();
/* 301 */       this.hasUnsavedChanges = false;
/* 302 */       long end = System.nanoTime() / 1000000L;
/* 303 */       System.out.println("Loaded region successfully in " + (end - start) + "ms");
/* 304 */     } catch (Exception ex) {
/* 305 */       ex.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public final synchronized void removeExpired() {
/* 310 */     long expiry = ((Long)(Baritone.settings()).cachedChunksExpirySeconds.value).longValue();
/* 311 */     if (expiry < 0L) {
/*     */       return;
/*     */     }
/* 314 */     long now = System.currentTimeMillis();
/* 315 */     long oldestAcceptableAge = now - expiry * 1000L;
/* 316 */     for (int x = 0; x < 32; x++) {
/* 317 */       for (int z = 0; z < 32; z++) {
/* 318 */         if (this.chunks[x][z] != null && (this.chunks[x][z]).cacheTimestamp < oldestAcceptableAge) {
/* 319 */           System.out.println("Removing chunk " + (x + 32 * this.x) + "," + (z + 32 * this.z) + " because it was cached " + ((now - (this.chunks[x][z]).cacheTimestamp) / 1000L) + " seconds ago, and max age is " + expiry);
/* 320 */           this.chunks[x][z] = null;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public final synchronized CachedChunk mostRecentlyModified() {
/* 327 */     CachedChunk recent = null;
/* 328 */     for (int x = 0; x < 32; x++) {
/* 329 */       for (int z = 0; z < 32; z++) {
/* 330 */         if (this.chunks[x][z] != null)
/*     */         {
/*     */           
/* 333 */           if (recent == null || (this.chunks[x][z]).cacheTimestamp > recent.cacheTimestamp)
/* 334 */             recent = this.chunks[x][z]; 
/*     */         }
/*     */       } 
/*     */     } 
/* 338 */     return recent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getX() {
/* 346 */     return this.x;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getZ() {
/* 354 */     return this.z;
/*     */   }
/*     */   
/*     */   private static Path getRegionFile(Path cacheDir, int regionX, int regionZ) {
/* 358 */     return Paths.get(cacheDir.toString(), new String[] { "r." + regionX + "." + regionZ + ".bcr" });
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\cache\CachedRegion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */