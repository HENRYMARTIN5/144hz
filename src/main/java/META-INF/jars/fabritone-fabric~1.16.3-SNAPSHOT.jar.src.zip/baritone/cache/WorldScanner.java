/*     */ package baritone.cache;
/*     */ 
/*     */ import baritone.api.cache.ICachedWorld;
/*     */ import baritone.api.cache.IWorldScanner;
/*     */ import baritone.api.utils.BetterBlockPos;
/*     */ import baritone.api.utils.BlockOptionalMetaLookup;
/*     */ import baritone.api.utils.IPlayerContext;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import java.util.stream.IntStream;
/*     */ import net.minecraft.class_1923;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_2791;
/*     */ import net.minecraft.class_2802;
/*     */ import net.minecraft.class_2818;
/*     */ import net.minecraft.class_2826;
/*     */ import net.minecraft.class_2841;
/*     */ import net.minecraft.class_631;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum WorldScanner
/*     */   implements IWorldScanner
/*     */ {
/*  36 */   INSTANCE;
/*     */   static {
/*  38 */     DEFAULT_COORDINATE_ITERATION_ORDER = IntStream.range(0, 16).toArray();
/*     */   }
/*     */   private static final int[] DEFAULT_COORDINATE_ITERATION_ORDER;
/*     */   public List<class_2338> scanChunkRadius(IPlayerContext ctx, BlockOptionalMetaLookup filter, int max, int yLevelThreshold, int maxSearchRadius) {
/*  42 */     ArrayList<class_2338> res = new ArrayList<>();
/*     */     
/*  44 */     if (filter.blocks().isEmpty()) {
/*  45 */       return res;
/*     */     }
/*  47 */     class_631 chunkProvider = (class_631)ctx.world().method_8398();
/*     */     
/*  49 */     int maxSearchRadiusSq = maxSearchRadius * maxSearchRadius;
/*  50 */     int playerChunkX = ctx.playerFeet().method_10263() >> 4;
/*  51 */     int playerChunkZ = ctx.playerFeet().method_10260() >> 4;
/*  52 */     int playerY = ctx.playerFeet().method_10264();
/*     */     
/*  54 */     int playerYBlockStateContainerIndex = playerY >> 4;
/*  55 */     int[] coordinateIterationOrder = IntStream.range(0, 16).boxed().sorted(Comparator.comparingInt(y -> Math.abs(y.intValue() - playerYBlockStateContainerIndex))).mapToInt(x -> x.intValue()).toArray();
/*     */     
/*  57 */     int searchRadiusSq = 0;
/*  58 */     boolean foundWithinY = false;
/*     */     while (true) {
/*  60 */       boolean allUnloaded = true;
/*  61 */       boolean foundChunks = false;
/*  62 */       for (int xoff = -searchRadiusSq; xoff <= searchRadiusSq; xoff++) {
/*  63 */         for (int zoff = -searchRadiusSq; zoff <= searchRadiusSq; zoff++) {
/*  64 */           int distance = xoff * xoff + zoff * zoff;
/*  65 */           if (distance == searchRadiusSq) {
/*     */ 
/*     */             
/*  68 */             foundChunks = true;
/*  69 */             int chunkX = xoff + playerChunkX;
/*  70 */             int chunkZ = zoff + playerChunkZ;
/*  71 */             class_2818 chunk = chunkProvider.method_2857(chunkX, chunkZ, null, false);
/*  72 */             if (chunk != null) {
/*     */ 
/*     */               
/*  75 */               allUnloaded = false;
/*  76 */               if (scanChunkInto(chunkX << 4, chunkZ << 4, (class_2791)chunk, filter, res, max, yLevelThreshold, playerY, coordinateIterationOrder))
/*  77 */                 foundWithinY = true; 
/*     */             } 
/*     */           } 
/*     */         } 
/*  81 */       }  if ((allUnloaded && foundChunks) || (res
/*  82 */         .size() >= max && (searchRadiusSq > maxSearchRadiusSq || (searchRadiusSq > 1 && foundWithinY))))
/*     */       {
/*     */         
/*  85 */         return res;
/*     */       }
/*  87 */       searchRadiusSq++;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public List<class_2338> scanChunk(IPlayerContext ctx, BlockOptionalMetaLookup filter, class_1923 pos, int max, int yLevelThreshold) {
/*  93 */     if (filter.blocks().isEmpty()) {
/*  94 */       return Collections.emptyList();
/*     */     }
/*     */     
/*  97 */     class_631 chunkProvider = (class_631)ctx.world().method_8398();
/*  98 */     class_2818 chunk = chunkProvider.method_2857(pos.field_9181, pos.field_9180, null, false);
/*  99 */     int playerY = ctx.playerFeet().method_10264();
/*     */     
/* 101 */     if (chunk == null || chunk.method_12223()) {
/* 102 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 105 */     ArrayList<class_2338> res = new ArrayList<>();
/* 106 */     scanChunkInto(pos.field_9181 << 4, pos.field_9180 << 4, (class_2791)chunk, filter, res, max, yLevelThreshold, playerY, DEFAULT_COORDINATE_ITERATION_ORDER);
/* 107 */     return res;
/*     */   }
/*     */ 
/*     */   
/*     */   public int repack(IPlayerContext ctx) {
/* 112 */     return repack(ctx, 40);
/*     */   }
/*     */ 
/*     */   
/*     */   public int repack(IPlayerContext ctx, int range) {
/* 117 */     class_2802 chunkProvider = ctx.world().method_8398();
/* 118 */     ICachedWorld cachedWorld = ctx.worldData().getCachedWorld();
/*     */     
/* 120 */     BetterBlockPos playerPos = ctx.playerFeet();
/*     */     
/* 122 */     int playerChunkX = playerPos.method_10263() >> 4;
/* 123 */     int playerChunkZ = playerPos.method_10260() >> 4;
/*     */     
/* 125 */     int minX = playerChunkX - range;
/* 126 */     int minZ = playerChunkZ - range;
/* 127 */     int maxX = playerChunkX + range;
/* 128 */     int maxZ = playerChunkZ + range;
/*     */     
/* 130 */     int queued = 0;
/* 131 */     for (int x = minX; x <= maxX; x++) {
/* 132 */       for (int z = minZ; z <= maxZ; z++) {
/* 133 */         class_2818 chunk = chunkProvider.method_12126(x, z, false);
/*     */         
/* 135 */         if (chunk != null && !chunk.method_12223()) {
/* 136 */           queued++;
/* 137 */           cachedWorld.queueForPacking(chunk);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 142 */     return queued;
/*     */   }
/*     */   
/*     */   private boolean scanChunkInto(int chunkX, int chunkZ, class_2791 chunk, BlockOptionalMetaLookup filter, Collection<class_2338> result, int max, int yLevelThreshold, int playerY, int[] coordinateIterationOrder) {
/* 146 */     class_2826[] chunkInternalStorageArray = chunk.method_12006();
/* 147 */     boolean foundWithinY = false;
/* 148 */     for (int yIndex = 0; yIndex < 16; yIndex++) {
/* 149 */       int y0 = coordinateIterationOrder[yIndex];
/* 150 */       class_2826 section = chunkInternalStorageArray[y0];
/* 151 */       if (section != null && !class_2826.method_18090(section)) {
/*     */ 
/*     */         
/* 154 */         int yReal = y0 << 4;
/* 155 */         class_2841<class_2680> bsc = section.method_12265();
/* 156 */         for (int yy = 0; yy < 16; yy++) {
/* 157 */           for (int z = 0; z < 16; z++) {
/* 158 */             for (int x = 0; x < 16; x++) {
/* 159 */               class_2680 state = (class_2680)bsc.method_12321(x, yy, z);
/* 160 */               if (filter.has(state)) {
/* 161 */                 int y = yReal | yy;
/* 162 */                 if (result.size() >= max) {
/* 163 */                   if (Math.abs(y - playerY) < yLevelThreshold) {
/* 164 */                     foundWithinY = true;
/*     */                   }
/* 166 */                   else if (foundWithinY) {
/*     */ 
/*     */                     
/* 169 */                     return true;
/*     */                   } 
/*     */                 }
/*     */                 
/* 173 */                 result.add(new class_2338(chunkX | x, y, chunkZ | z));
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 179 */     }  return foundWithinY;
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\cache\WorldScanner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */