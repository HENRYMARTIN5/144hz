/*     */ package baritone.cache;
/*     */ 
/*     */ import baritone.api.utils.BlockUtils;
/*     */ import baritone.utils.pathing.PathingBlockType;
/*     */ import com.google.common.collect.ImmutableSet;
/*     */ import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
/*     */ import java.util.ArrayList;
/*     */ import java.util.BitSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.minecraft.class_1937;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2248;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_5321;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CachedChunk
/*     */ {
/*  42 */   public static final ImmutableSet<class_2248> BLOCKS_TO_KEEP_TRACK_OF = ImmutableSet.of(class_2246.field_10443, class_2246.field_10181, class_2246.field_10034, class_2246.field_10380, class_2246.field_10027, class_2246.field_10398, (Object[])new class_2248[] { class_2246.field_10260, class_2246.field_10499, class_2246.field_10282, class_2246.field_10199, class_2246.field_10407, class_2246.field_10063, class_2246.field_10203, class_2246.field_10600, class_2246.field_10275, class_2246.field_10051, class_2246.field_10140, class_2246.field_10320, class_2246.field_10532, class_2246.field_10268, class_2246.field_10605, class_2246.field_10373, class_2246.field_10055, class_2246.field_10068, class_2246.field_10371, class_2246.field_10316, class_2246.field_10312, class_2246.field_10327, class_2246.field_10333, class_2246.field_10042, class_2246.field_10509, class_2246.field_10337, class_2246.field_10472, class_2246.field_10432, class_2246.field_10208, class_2246.field_10241, class_2246.field_10581, class_2246.field_10481, class_2246.field_10388, class_2246.field_10177, class_2246.field_10101, class_2246.field_10485, class_2246.field_10535, class_2246.field_10120, class_2246.field_10410, class_2246.field_10230, class_2246.field_10621, class_2246.field_10356, class_2246.field_10180, class_2246.field_10610, class_2246.field_10141, class_2246.field_10326, class_2246.field_10109, class_2246.field_10019, class_2246.field_10527, class_2246.field_10288, class_2246.field_10561, class_2246.field_10069, class_2246.field_10461, class_2246.field_10081, class_2246.field_10223, class_2246.field_10613, class_2246.field_10343, class_2246.field_9974, class_2246.field_9983, class_2246.field_10597 });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int SIZE = 131072;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int SIZE_IN_BYTES = 16384;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int x;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int z;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final BitSet data;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Int2ObjectOpenHashMap<String> special;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final class_2680[] overview;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int[] heightMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Map<String, List<class_2338>> specialBlockLocations;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final long cacheTimestamp;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   CachedChunk(int x, int z, BitSet data, class_2680[] overview, Map<String, List<class_2338>> specialBlockLocations, long cacheTimestamp) {
/* 157 */     validateSize(data);
/*     */     
/* 159 */     this.x = x;
/* 160 */     this.z = z;
/* 161 */     this.data = data;
/* 162 */     this.overview = overview;
/* 163 */     this.heightMap = new int[256];
/* 164 */     this.specialBlockLocations = specialBlockLocations;
/* 165 */     this.cacheTimestamp = cacheTimestamp;
/* 166 */     if (specialBlockLocations.isEmpty()) {
/* 167 */       this.special = null;
/*     */     } else {
/* 169 */       this.special = new Int2ObjectOpenHashMap();
/* 170 */       setSpecial();
/*     */     } 
/* 172 */     calculateHeightMap();
/*     */   }
/*     */   
/*     */   private final void setSpecial() {
/* 176 */     for (Map.Entry<String, List<class_2338>> entry : this.specialBlockLocations.entrySet()) {
/* 177 */       for (class_2338 pos : entry.getValue()) {
/* 178 */         this.special.put(getPositionIndex(pos.method_10263(), pos.method_10264(), pos.method_10260()), entry.getKey());
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public final class_2680 getBlock(int x, int y, int z, class_5321<class_1937> dimension) {
/* 184 */     int index = getPositionIndex(x, y, z);
/* 185 */     PathingBlockType type = getType(index);
/* 186 */     int internalPos = z << 4 | x;
/* 187 */     if (this.heightMap[internalPos] == y && type != PathingBlockType.AVOID)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 195 */       return this.overview[internalPos];
/*     */     }
/* 197 */     if (this.special != null) {
/* 198 */       String str = (String)this.special.get(index);
/* 199 */       if (str != null) {
/* 200 */         return BlockUtils.stringToBlockRequired(str).method_9564();
/*     */       }
/*     */     } 
/*     */     
/* 204 */     if (type == PathingBlockType.SOLID) {
/* 205 */       if (y == 127 && dimension == class_1937.field_25180)
/*     */       {
/* 207 */         return class_2246.field_9987.method_9564();
/*     */       }
/* 209 */       if (y < 5 && dimension == class_1937.field_25179)
/*     */       {
/*     */ 
/*     */         
/* 213 */         return class_2246.field_10540.method_9564();
/*     */       }
/*     */     } 
/* 216 */     return ChunkPacker.pathingTypeToBlock(type, dimension);
/*     */   }
/*     */   
/*     */   private PathingBlockType getType(int index) {
/* 220 */     return PathingBlockType.fromBits(this.data.get(index), this.data.get(index + 1));
/*     */   }
/*     */   
/*     */   private void calculateHeightMap() {
/* 224 */     for (int z = 0; z < 16; z++) {
/* 225 */       for (int x = 0; x < 16; x++) {
/* 226 */         int index = z << 4 | x;
/* 227 */         this.heightMap[index] = 0;
/* 228 */         for (int y = 256; y >= 0; y--) {
/* 229 */           int i = getPositionIndex(x, y, z);
/* 230 */           if (this.data.get(i) || this.data.get(i + 1)) {
/* 231 */             this.heightMap[index] = y;
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public final class_2680[] getOverview() {
/* 240 */     return this.overview;
/*     */   }
/*     */   
/*     */   public final Map<String, List<class_2338>> getRelativeBlocks() {
/* 244 */     return this.specialBlockLocations;
/*     */   }
/*     */   
/*     */   public final ArrayList<class_2338> getAbsoluteBlocks(String blockType) {
/* 248 */     if (this.specialBlockLocations.get(blockType) == null) {
/* 249 */       return null;
/*     */     }
/* 251 */     ArrayList<class_2338> res = new ArrayList<>();
/* 252 */     for (class_2338 pos : this.specialBlockLocations.get(blockType)) {
/* 253 */       res.add(new class_2338(pos.method_10263() + this.x * 16, pos.method_10264(), pos.method_10260() + this.z * 16));
/*     */     }
/* 255 */     return res;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final byte[] toByteArray() {
/* 262 */     return this.data.toByteArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getPositionIndex(int x, int y, int z) {
/* 274 */     return x << 1 | z << 5 | y << 9;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void validateSize(BitSet data) {
/* 286 */     if (data.size() > 131072)
/* 287 */       throw new IllegalArgumentException("BitSet of invalid length provided"); 
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\cache\CachedChunk.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */