/*     */ package baritone.cache;
/*     */ 
/*     */ import baritone.Baritone;
/*     */ import baritone.api.BaritoneAPI;
/*     */ import baritone.api.IBaritone;
/*     */ import baritone.api.cache.ICachedRegion;
/*     */ import baritone.api.cache.ICachedWorld;
/*     */ import baritone.api.cache.IWorldData;
/*     */ import baritone.api.utils.Helper;
/*     */ import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
/*     */ import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
/*     */ import java.io.IOException;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.attribute.FileAttribute;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.LinkedBlockingQueue;
/*     */ import net.minecraft.class_1923;
/*     */ import net.minecraft.class_1937;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2818;
/*     */ import net.minecraft.class_5321;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CachedWorld
/*     */   implements ICachedWorld, Helper
/*     */ {
/*     */   private static final int REGION_MAX = 58594;
/*  57 */   private Long2ObjectMap<CachedRegion> cachedRegions = (Long2ObjectMap<CachedRegion>)new Long2ObjectOpenHashMap();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String directory;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   private final LinkedBlockingQueue<class_1923> toPackQueue = new LinkedBlockingQueue<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   private final Map<class_1923, class_2818> toPackMap = new ConcurrentHashMap<>();
/*     */   
/*     */   private final class_5321<class_1937> dimension;
/*     */   
/*     */   CachedWorld(Path directory, class_5321<class_1937> dimension) {
/*  79 */     if (!Files.exists(directory, new java.nio.file.LinkOption[0])) {
/*     */       try {
/*  81 */         Files.createDirectories(directory, (FileAttribute<?>[])new FileAttribute[0]);
/*  82 */       } catch (IOException iOException) {}
/*     */     }
/*     */     
/*  85 */     this.directory = directory.toString();
/*  86 */     this.dimension = dimension;
/*  87 */     System.out.println("Cached world directory: " + directory);
/*  88 */     Baritone.getExecutor().execute(new PackerThread());
/*  89 */     Baritone.getExecutor().execute(() -> {
/*     */           try {
/*     */             Thread.sleep(30000L);
/*     */ 
/*     */             
/*     */             while (true) {
/*     */               save();
/*     */               
/*     */               Thread.sleep(600000L);
/*     */             } 
/*  99 */           } catch (InterruptedException e) {
/*     */             e.printStackTrace();
/*     */             return;
/*     */           } 
/*     */         });
/*     */   }
/*     */   
/*     */   public final void queueForPacking(class_2818 chunk) {
/* 107 */     if (this.toPackMap.put(chunk.method_12004(), chunk) == null) {
/* 108 */       this.toPackQueue.add(chunk.method_12004());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isCached(int blockX, int blockZ) {
/* 114 */     CachedRegion region = getRegion(blockX >> 9, blockZ >> 9);
/* 115 */     if (region == null) {
/* 116 */       return false;
/*     */     }
/* 118 */     return region.isCached(blockX & 0x1FF, blockZ & 0x1FF);
/*     */   }
/*     */   
/*     */   public final boolean regionLoaded(int blockX, int blockZ) {
/* 122 */     return (getRegion(blockX >> 9, blockZ >> 9) != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public final ArrayList<class_2338> getLocationsOf(String block, int maximum, int centerX, int centerZ, int maxRegionDistanceSq) {
/* 127 */     ArrayList<class_2338> res = new ArrayList<>();
/* 128 */     int centerRegionX = centerX >> 9;
/* 129 */     int centerRegionZ = centerZ >> 9;
/*     */     
/* 131 */     int searchRadius = 0;
/* 132 */     while (searchRadius <= maxRegionDistanceSq) {
/* 133 */       for (int xoff = -searchRadius; xoff <= searchRadius; xoff++) {
/* 134 */         for (int zoff = -searchRadius; zoff <= searchRadius; zoff++) {
/* 135 */           int distance = xoff * xoff + zoff * zoff;
/* 136 */           if (distance == searchRadius) {
/*     */ 
/*     */             
/* 139 */             int regionX = xoff + centerRegionX;
/* 140 */             int regionZ = zoff + centerRegionZ;
/* 141 */             CachedRegion region = getOrCreateRegion(regionX, regionZ);
/* 142 */             if (region != null)
/*     */             {
/* 144 */               res.addAll(region.getLocationsOf(block)); } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 148 */       if (res.size() >= maximum) {
/* 149 */         return res;
/*     */       }
/* 151 */       searchRadius++;
/*     */     } 
/* 153 */     return res;
/*     */   }
/*     */   
/*     */   private void updateCachedChunk(CachedChunk chunk) {
/* 157 */     CachedRegion region = getOrCreateRegion(chunk.x >> 5, chunk.z >> 5);
/* 158 */     region.updateCachedChunk(chunk.x & 0x1F, chunk.z & 0x1F, chunk);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void save() {
/* 163 */     if (!((Boolean)(Baritone.settings()).chunkCaching.value).booleanValue()) {
/* 164 */       System.out.println("Not saving to disk; chunk caching is disabled.");
/* 165 */       allRegions().forEach(region -> {
/*     */             if (region != null) {
/*     */               region.removeExpired();
/*     */             }
/*     */           });
/* 170 */       prune();
/*     */       return;
/*     */     } 
/* 173 */     long start = System.nanoTime() / 1000000L;
/* 174 */     allRegions().parallelStream().forEach(region -> {
/*     */           if (region != null) {
/*     */             region.save(this.directory);
/*     */           }
/*     */         });
/* 179 */     long now = System.nanoTime() / 1000000L;
/* 180 */     System.out.println("World save took " + (now - start) + "ms");
/* 181 */     prune();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void prune() {
/* 188 */     if (!((Boolean)(Baritone.settings()).pruneRegionsFromRAM.value).booleanValue()) {
/*     */       return;
/*     */     }
/* 191 */     class_2338 pruneCenter = guessPosition();
/* 192 */     for (CachedRegion region : allRegions()) {
/* 193 */       if (region == null) {
/*     */         continue;
/*     */       }
/* 196 */       int distX = (region.getX() << 9) + 256 - pruneCenter.method_10263();
/* 197 */       int distZ = (region.getZ() << 9) + 256 - pruneCenter.method_10260();
/* 198 */       double dist = Math.sqrt((distX * distX + distZ * distZ));
/* 199 */       if (dist > 1024.0D) {
/* 200 */         if (!((Boolean)(Baritone.settings()).censorCoordinates.value).booleanValue()) {
/* 201 */           logDebug("Deleting cached region " + region.getX() + "," + region.getZ() + " from ram");
/*     */         }
/* 203 */         this.cachedRegions.remove(getRegionID(region.getX(), region.getZ()));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class_2338 guessPosition() {
/* 212 */     for (IBaritone ibaritone : BaritoneAPI.getProvider().getAllBaritones()) {
/* 213 */       IWorldData data = ibaritone.getWorldProvider().getCurrentWorld();
/* 214 */       if (data != null && data.getCachedWorld() == this) {
/* 215 */         return (class_2338)ibaritone.getPlayerContext().playerFeet();
/*     */       }
/*     */     } 
/* 218 */     CachedChunk mostRecentlyModified = null;
/* 219 */     for (CachedRegion region : allRegions()) {
/* 220 */       if (region == null) {
/*     */         continue;
/*     */       }
/* 223 */       CachedChunk ch = region.mostRecentlyModified();
/* 224 */       if (ch == null) {
/*     */         continue;
/*     */       }
/* 227 */       if (mostRecentlyModified == null || mostRecentlyModified.cacheTimestamp < ch.cacheTimestamp) {
/* 228 */         mostRecentlyModified = ch;
/*     */       }
/*     */     } 
/* 231 */     if (mostRecentlyModified == null) {
/* 232 */       return new class_2338(0, 0, 0);
/*     */     }
/* 234 */     return new class_2338((mostRecentlyModified.x << 4) + 8, 0, (mostRecentlyModified.z << 4) + 8);
/*     */   }
/*     */   
/*     */   private synchronized List<CachedRegion> allRegions() {
/* 238 */     return new ArrayList<>((Collection<? extends CachedRegion>)this.cachedRegions.values());
/*     */   }
/*     */ 
/*     */   
/*     */   public final void reloadAllFromDisk() {
/* 243 */     long start = System.nanoTime() / 1000000L;
/* 244 */     allRegions().forEach(region -> {
/*     */           if (region != null) {
/*     */             region.load(this.directory);
/*     */           }
/*     */         });
/* 249 */     long now = System.nanoTime() / 1000000L;
/* 250 */     System.out.println("World load took " + (now - start) + "ms");
/*     */   }
/*     */ 
/*     */   
/*     */   public final synchronized CachedRegion getRegion(int regionX, int regionZ) {
/* 255 */     return (CachedRegion)this.cachedRegions.get(getRegionID(regionX, regionZ));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized CachedRegion getOrCreateRegion(int regionX, int regionZ) {
/* 267 */     return (CachedRegion)this.cachedRegions.computeIfAbsent(getRegionID(regionX, regionZ), id -> {
/*     */           CachedRegion newRegion = new CachedRegion(regionX, regionZ, this.dimension);
/*     */           newRegion.load(this.directory);
/*     */           return newRegion;
/*     */         });
/*     */   }
/*     */   
/*     */   public void tryLoadFromDisk(int regionX, int regionZ) {
/* 275 */     getOrCreateRegion(regionX, regionZ);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long getRegionID(int regionX, int regionZ) {
/* 287 */     if (!isRegionInWorld(regionX, regionZ)) {
/* 288 */       return 0L;
/*     */     }
/*     */     
/* 291 */     return regionX & 0xFFFFFFFFL | (regionZ & 0xFFFFFFFFL) << 32L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isRegionInWorld(int regionX, int regionZ) {
/* 302 */     return (regionX <= 58594 && regionX >= -58594 && regionZ <= 58594 && regionZ >= -58594);
/*     */   }
/*     */   
/*     */   private class PackerThread implements Runnable {
/*     */     public void run() {
/*     */       while (true) {
/*     */         try {
/*     */           while (true) {
/* 310 */             class_1923 pos = CachedWorld.this.toPackQueue.take();
/* 311 */             class_2818 chunk = (class_2818)CachedWorld.this.toPackMap.remove(pos);
/* 312 */             CachedChunk cached = ChunkPacker.pack(chunk);
/* 313 */             CachedWorld.this.updateCachedChunk(cached);
/*     */           } 
/* 315 */         } catch (InterruptedException e) {
/* 316 */           e.printStackTrace();
/*     */           break;
/* 318 */         } catch (Throwable th) {
/*     */           
/* 320 */           th.printStackTrace();
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     private PackerThread() {}
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\cache\CachedWorld.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */