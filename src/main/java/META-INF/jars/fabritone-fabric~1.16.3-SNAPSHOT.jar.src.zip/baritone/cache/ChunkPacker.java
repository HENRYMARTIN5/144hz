/*     */ package baritone.cache;
/*     */ 
/*     */ import baritone.api.utils.BlockUtils;
/*     */ import baritone.pathing.movement.MovementHelper;
/*     */ import baritone.utils.BlockStateInterface;
/*     */ import baritone.utils.pathing.PathingBlockType;
/*     */ import java.util.ArrayList;
/*     */ import java.util.BitSet;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.minecraft.class_1922;
/*     */ import net.minecraft.class_1937;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2248;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_2791;
/*     */ import net.minecraft.class_2818;
/*     */ import net.minecraft.class_2826;
/*     */ import net.minecraft.class_2841;
/*     */ import net.minecraft.class_5321;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ChunkPacker
/*     */ {
/*     */   public static CachedChunk pack(class_2818 chunk) {
/*  48 */     Map<String, List<class_2338>> specialBlocks = new HashMap<>();
/*  49 */     BitSet bitSet = new BitSet(131072);
/*     */     try {
/*  51 */       class_2826[] chunkInternalStorageArray = chunk.method_12006();
/*  52 */       for (int y0 = 0; y0 < 16; y0++) {
/*  53 */         class_2826 extendedblockstorage = chunkInternalStorageArray[y0];
/*  54 */         if (extendedblockstorage != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*  65 */           class_2841<class_2680> bsc = extendedblockstorage.method_12265();
/*  66 */           int yReal = y0 << 4;
/*     */ 
/*     */           
/*  69 */           for (int y1 = 0; y1 < 16; y1++) {
/*  70 */             int y = y1 | yReal;
/*  71 */             for (int i = 0; i < 16; i++) {
/*  72 */               for (int x = 0; x < 16; x++) {
/*  73 */                 int index = CachedChunk.getPositionIndex(x, y, i);
/*  74 */                 class_2680 state = (class_2680)bsc.method_12321(x, y1, i);
/*  75 */                 boolean[] bits = getPathingBlockType(state, chunk, x, y, i).getBits();
/*  76 */                 bitSet.set(index, bits[0]);
/*  77 */                 bitSet.set(index + 1, bits[1]);
/*  78 */                 class_2248 block = state.method_26204();
/*  79 */                 if (CachedChunk.BLOCKS_TO_KEEP_TRACK_OF.contains(block))
/*  80 */                 { String name = BlockUtils.blockToString(block);
/*  81 */                   ((List<class_2338>)specialBlocks.computeIfAbsent(name, b -> new ArrayList())).add(new class_2338(x, y, i)); } 
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*  87 */     } catch (Exception e) {
/*  88 */       e.printStackTrace();
/*     */     } 
/*     */ 
/*     */     
/*  92 */     class_2680[] blocks = new class_2680[256];
/*     */ 
/*     */     
/*  95 */     for (int z = 0; z < 16; z++) {
/*     */       
/*  97 */       for (int x = 0; x < 16; x++) {
/*  98 */         int y = 255; while (true) { if (y >= 0) {
/*  99 */             int index = CachedChunk.getPositionIndex(x, y, z);
/* 100 */             if (bitSet.get(index) || bitSet.get(index + 1)) {
/* 101 */               blocks[z << 4 | x] = BlockStateInterface.getFromChunk((class_2791)chunk, x, y, z); break;
/*     */             }  y--;
/*     */             continue;
/*     */           } 
/* 105 */           blocks[z << 4 | x] = class_2246.field_10124.method_9564(); break; }
/*     */       
/*     */       } 
/*     */     } 
/* 109 */     return new CachedChunk((chunk.method_12004()).field_9181, (chunk.method_12004()).field_9180, bitSet, blocks, specialBlocks, System.currentTimeMillis());
/*     */   }
/*     */   
/*     */   private static PathingBlockType getPathingBlockType(class_2680 state, class_2818 chunk, int x, int y, int z) {
/* 113 */     class_2248 block = state.method_26204();
/* 114 */     if (MovementHelper.isWater(state)) {
/*     */ 
/*     */       
/* 117 */       if (MovementHelper.possiblyFlowing(state)) {
/* 118 */         return PathingBlockType.AVOID;
/*     */       }
/* 120 */       if ((x != 15 && 
/* 121 */         MovementHelper.possiblyFlowing(BlockStateInterface.getFromChunk((class_2791)chunk, x + 1, y, z))) || (x != 0 && 
/* 122 */         MovementHelper.possiblyFlowing(BlockStateInterface.getFromChunk((class_2791)chunk, x - 1, y, z))) || (z != 15 && 
/* 123 */         MovementHelper.possiblyFlowing(BlockStateInterface.getFromChunk((class_2791)chunk, x, y, z + 1))) || (z != 0 && 
/* 124 */         MovementHelper.possiblyFlowing(BlockStateInterface.getFromChunk((class_2791)chunk, x, y, z - 1))))
/*     */       {
/* 126 */         return PathingBlockType.AVOID;
/*     */       }
/* 128 */       if (x == 0 || x == 15 || z == 0 || z == 15) {
/* 129 */         class_243 flow = state.method_26227().method_15758((class_1922)chunk.method_12200(), new class_2338(x + (chunk.method_12004()).field_9181 << 4, y, z + (chunk.method_12004()).field_9180 << 4));
/* 130 */         if (flow.field_1352 != 0.0D || flow.field_1350 != 0.0D) {
/* 131 */           return PathingBlockType.WATER;
/*     */         }
/* 133 */         return PathingBlockType.AVOID;
/*     */       } 
/* 135 */       return PathingBlockType.WATER;
/*     */     } 
/*     */     
/* 138 */     if (MovementHelper.avoidWalkingInto(state) || MovementHelper.isBottomSlab(state)) {
/* 139 */       return PathingBlockType.AVOID;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 145 */     if (block instanceof net.minecraft.class_2189 || block instanceof net.minecraft.class_2526 || block instanceof net.minecraft.class_2320 || block instanceof net.minecraft.class_2356) {
/* 146 */       return PathingBlockType.AIR;
/*     */     }
/*     */     
/* 149 */     return PathingBlockType.SOLID;
/*     */   }
/*     */   
/*     */   public static class_2680 pathingTypeToBlock(PathingBlockType type, class_5321<class_1937> dimension) {
/* 153 */     switch (type) {
/*     */       case AIR:
/* 155 */         return class_2246.field_10124.method_9564();
/*     */       case WATER:
/* 157 */         return class_2246.field_10382.method_9564();
/*     */       case AVOID:
/* 159 */         return class_2246.field_10164.method_9564();
/*     */       
/*     */       case SOLID:
/* 162 */         if (dimension == class_1937.field_25179) {
/* 163 */           return class_2246.field_10340.method_9564();
/*     */         }
/* 165 */         if (dimension == class_1937.field_25180) {
/* 166 */           return class_2246.field_10515.method_9564();
/*     */         }
/* 168 */         if (dimension == class_1937.field_25181)
/* 169 */           return class_2246.field_10471.method_9564(); 
/*     */         break;
/*     */     } 
/* 172 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\cache\ChunkPacker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */