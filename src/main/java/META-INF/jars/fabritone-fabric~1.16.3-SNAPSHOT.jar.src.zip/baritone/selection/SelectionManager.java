/*     */ package baritone.selection;
/*     */ 
/*     */ import baritone.Baritone;
/*     */ import baritone.api.selection.ISelection;
/*     */ import baritone.api.selection.ISelectionManager;
/*     */ import baritone.api.utils.BetterBlockPos;
/*     */ import java.util.LinkedList;
/*     */ import java.util.ListIterator;
/*     */ import net.minecraft.class_2350;
/*     */ 
/*     */ public class SelectionManager
/*     */   implements ISelectionManager
/*     */ {
/*  14 */   private final LinkedList<ISelection> selections = new LinkedList<>();
/*  15 */   private ISelection[] selectionsArr = new ISelection[0];
/*     */   
/*     */   public SelectionManager(Baritone baritone) {
/*  18 */     new SelectionRenderer(baritone, this);
/*     */   }
/*     */   
/*     */   private void resetSelectionsArr() {
/*  22 */     this.selectionsArr = this.selections.<ISelection>toArray(new ISelection[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized ISelection addSelection(ISelection selection) {
/*  27 */     this.selections.add(selection);
/*  28 */     resetSelectionsArr();
/*  29 */     return selection;
/*     */   }
/*     */ 
/*     */   
/*     */   public ISelection addSelection(BetterBlockPos pos1, BetterBlockPos pos2) {
/*  34 */     return addSelection(new Selection(pos1, pos2));
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized ISelection removeSelection(ISelection selection) {
/*  39 */     this.selections.remove(selection);
/*  40 */     resetSelectionsArr();
/*  41 */     return selection;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized ISelection[] removeAllSelections() {
/*  46 */     ISelection[] selectionsArr = getSelections();
/*  47 */     this.selections.clear();
/*  48 */     resetSelectionsArr();
/*  49 */     return selectionsArr;
/*     */   }
/*     */ 
/*     */   
/*     */   public ISelection[] getSelections() {
/*  54 */     return this.selectionsArr;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized ISelection getOnlySelection() {
/*  59 */     if (this.selections.size() == 1) {
/*  60 */       return this.selections.peekFirst();
/*     */     }
/*     */     
/*  63 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public ISelection getLastSelection() {
/*  68 */     return this.selections.peekLast();
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized ISelection expand(ISelection selection, class_2350 direction, int blocks) {
/*  73 */     for (ListIterator<ISelection> it = this.selections.listIterator(); it.hasNext(); ) {
/*  74 */       ISelection current = it.next();
/*     */       
/*  76 */       if (current == selection) {
/*  77 */         it.remove();
/*  78 */         it.add(current.expand(direction, blocks));
/*  79 */         resetSelectionsArr();
/*  80 */         return it.previous();
/*     */       } 
/*     */     } 
/*     */     
/*  84 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized ISelection contract(ISelection selection, class_2350 direction, int blocks) {
/*  89 */     for (ListIterator<ISelection> it = this.selections.listIterator(); it.hasNext(); ) {
/*  90 */       ISelection current = it.next();
/*     */       
/*  92 */       if (current == selection) {
/*  93 */         it.remove();
/*  94 */         it.add(current.contract(direction, blocks));
/*  95 */         resetSelectionsArr();
/*  96 */         return it.previous();
/*     */       } 
/*     */     } 
/*     */     
/* 100 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized ISelection shift(ISelection selection, class_2350 direction, int blocks) {
/* 105 */     for (ListIterator<ISelection> it = this.selections.listIterator(); it.hasNext(); ) {
/* 106 */       ISelection current = it.next();
/*     */       
/* 108 */       if (current == selection) {
/* 109 */         it.remove();
/* 110 */         it.add(current.shift(direction, blocks));
/* 111 */         resetSelectionsArr();
/* 112 */         return it.previous();
/*     */       } 
/*     */     } 
/*     */     
/* 116 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\selection\SelectionManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */