/*    */ package baritone.selection;
/*    */ 
/*    */ import baritone.Baritone;
/*    */ import baritone.api.event.events.RenderEvent;
/*    */ import baritone.api.event.listener.AbstractGameEventListener;
/*    */ import baritone.api.event.listener.IGameEventListener;
/*    */ import baritone.api.selection.ISelection;
/*    */ import baritone.utils.IRenderer;
/*    */ import java.awt.Color;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_238;
/*    */ import net.minecraft.class_4587;
/*    */ 
/*    */ public class SelectionRenderer implements IRenderer, AbstractGameEventListener {
/*    */   public static final double SELECTION_BOX_EXPANSION = 0.005D;
/*    */   
/*    */   SelectionRenderer(Baritone baritone, SelectionManager manager) {
/* 18 */     this.manager = manager;
/* 19 */     baritone.getGameEventHandler().registerEventListener((IGameEventListener)this);
/*    */   }
/*    */   private final SelectionManager manager;
/*    */   public static void renderSelections(class_4587 stack, ISelection[] selections) {
/* 23 */     float opacity = ((Float)settings.selectionOpacity.value).floatValue();
/* 24 */     boolean ignoreDepth = ((Boolean)settings.renderSelectionIgnoreDepth.value).booleanValue();
/* 25 */     float lineWidth = ((Float)settings.selectionLineWidth.value).floatValue();
/*    */     
/* 27 */     if (!((Boolean)settings.renderSelection.value).booleanValue()) {
/*    */       return;
/*    */     }
/*    */     
/* 31 */     IRenderer.startLines((Color)settings.colorSelection.value, opacity, lineWidth, ignoreDepth);
/*    */     
/* 33 */     for (ISelection selection : selections) {
/* 34 */       IRenderer.drawAABB(stack, selection.aabb(), 0.005D);
/*    */     }
/*    */     
/* 37 */     if (((Boolean)settings.renderSelectionCorners.value).booleanValue()) {
/* 38 */       IRenderer.glColor((Color)settings.colorSelectionPos1.value, opacity);
/*    */       
/* 40 */       for (ISelection selection : selections) {
/* 41 */         IRenderer.drawAABB(stack, new class_238((class_2338)selection.pos1(), selection.pos1().method_10069(1, 1, 1)));
/*    */       }
/*    */       
/* 44 */       IRenderer.glColor((Color)settings.colorSelectionPos2.value, opacity);
/*    */       
/* 46 */       for (ISelection selection : selections) {
/* 47 */         IRenderer.drawAABB(stack, new class_238((class_2338)selection.pos2(), selection.pos2().method_10069(1, 1, 1)));
/*    */       }
/*    */     } 
/*    */     
/* 51 */     IRenderer.endLines(ignoreDepth);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onRenderPass(RenderEvent event) {
/* 56 */     renderSelections(event.getModelViewStack(), this.manager.getSelections());
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\selection\SelectionRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */