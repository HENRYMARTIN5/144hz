/*     */ package baritone.selection;
/*     */ 
/*     */ import baritone.api.selection.ISelection;
/*     */ import baritone.api.utils.BetterBlockPos;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_238;
/*     */ import net.minecraft.class_2382;
/*     */ 
/*     */ public class Selection implements ISelection {
/*     */   private final BetterBlockPos pos1;
/*     */   private final BetterBlockPos pos2;
/*     */   private final BetterBlockPos min;
/*     */   private final BetterBlockPos max;
/*     */   private final class_2382 size;
/*     */   private final class_238 aabb;
/*     */   
/*     */   public Selection(BetterBlockPos pos1, BetterBlockPos pos2) {
/*  19 */     this.pos1 = pos1;
/*  20 */     this.pos2 = pos2;
/*     */     
/*  22 */     this
/*     */ 
/*     */       
/*  25 */       .min = new BetterBlockPos(Math.min(pos1.x, pos2.x), Math.min(pos1.y, pos2.y), Math.min(pos1.z, pos2.z));
/*     */ 
/*     */     
/*  28 */     this
/*     */ 
/*     */       
/*  31 */       .max = new BetterBlockPos(Math.max(pos1.x, pos2.x), Math.max(pos1.y, pos2.y), Math.max(pos1.z, pos2.z));
/*     */ 
/*     */     
/*  34 */     this.size = new class_2382(this.max.x - this.min.x + 1, this.max.y - this.min.y + 1, this.max.z - this.min.z + 1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  40 */     this.aabb = new class_238((class_2338)this.min, this.max.method_10069(1, 1, 1));
/*     */   }
/*     */ 
/*     */   
/*     */   public BetterBlockPos pos1() {
/*  45 */     return this.pos1;
/*     */   }
/*     */ 
/*     */   
/*     */   public BetterBlockPos pos2() {
/*  50 */     return this.pos2;
/*     */   }
/*     */ 
/*     */   
/*     */   public BetterBlockPos min() {
/*  55 */     return this.min;
/*     */   }
/*     */ 
/*     */   
/*     */   public BetterBlockPos max() {
/*  60 */     return this.max;
/*     */   }
/*     */ 
/*     */   
/*     */   public class_2382 size() {
/*  65 */     return this.size;
/*     */   }
/*     */ 
/*     */   
/*     */   public class_238 aabb() {
/*  70 */     return this.aabb;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  75 */     return this.pos1.hashCode() ^ this.pos2.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  80 */     return String.format("Selection{pos1=%s,pos2=%s}", new Object[] { this.pos1, this.pos2 });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isPos2(class_2350 facing) {
/*  94 */     boolean negative = (facing.method_10171().method_10181() < 0);
/*     */     
/*  96 */     switch (facing.method_10166()) {
/*     */       case field_11048:
/*  98 */         return ((this.pos2.x > this.pos1.x)) ^ negative;
/*     */       case field_11052:
/* 100 */         return ((this.pos2.y > this.pos1.y)) ^ negative;
/*     */       case field_11051:
/* 102 */         return ((this.pos2.z > this.pos1.z)) ^ negative;
/*     */     } 
/* 104 */     throw new IllegalStateException("Bad Direction.Axis");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ISelection expand(class_2350 direction, int blocks) {
/* 110 */     if (isPos2(direction)) {
/* 111 */       return new Selection(this.pos1, this.pos2.offset(direction, blocks));
/*     */     }
/* 113 */     return new Selection(this.pos1.offset(direction, blocks), this.pos2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ISelection contract(class_2350 direction, int blocks) {
/* 119 */     if (isPos2(direction)) {
/* 120 */       return new Selection(this.pos1.offset(direction, blocks), this.pos2);
/*     */     }
/* 122 */     return new Selection(this.pos1, this.pos2.offset(direction, blocks));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ISelection shift(class_2350 direction, int blocks) {
/* 128 */     return new Selection(this.pos1.offset(direction, blocks), this.pos2.offset(direction, blocks));
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\fabritone-fabric~1.16.3-SNAPSHOT.jar!\baritone\selection\Selection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */