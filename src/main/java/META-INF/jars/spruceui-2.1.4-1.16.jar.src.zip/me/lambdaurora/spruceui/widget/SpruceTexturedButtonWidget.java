/*    */ package me.lambdaurora.spruceui.widget;
/*    */ 
/*    */ import com.mojang.blaze3d.systems.RenderSystem;
/*    */ import me.lambdaurora.spruceui.Position;
/*    */ import net.minecraft.class_2561;
/*    */ import net.minecraft.class_2960;
/*    */ import net.minecraft.class_4587;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpruceTexturedButtonWidget
/*    */   extends SpruceButtonWidget
/*    */ {
/*    */   private final class_2960 texture;
/*    */   private final int u;
/*    */   private final int v;
/*    */   private final int hoveredVOffset;
/*    */   private final int textureWidth;
/*    */   private final int textureHeight;
/*    */   private final boolean showMessage;
/*    */   
/*    */   public SpruceTexturedButtonWidget(Position position, int width, int height, class_2561 message, SpruceButtonWidget.PressAction action, int u, int v, int hoveredVOffset, class_2960 texture) {
/* 35 */     this(position, width, height, message, false, action, u, v, hoveredVOffset, texture);
/*    */   }
/*    */   
/*    */   public SpruceTexturedButtonWidget(Position position, int width, int height, class_2561 message, boolean showMessage, SpruceButtonWidget.PressAction action, int u, int v, int hoveredVOffset, class_2960 texture) {
/* 39 */     this(position, width, height, message, showMessage, action, u, v, hoveredVOffset, texture, 256, 256);
/*    */   }
/*    */   
/*    */   public SpruceTexturedButtonWidget(Position position, int width, int height, class_2561 message, SpruceButtonWidget.PressAction action, int u, int v, int hoveredVOffset, class_2960 texture, int textureWidth, int textureHeight) {
/* 43 */     this(position, width, height, message, false, action, u, v, hoveredVOffset, texture, textureWidth, textureHeight);
/*    */   }
/*    */   
/*    */   public SpruceTexturedButtonWidget(Position position, int width, int height, class_2561 message, boolean showMessage, SpruceButtonWidget.PressAction action, int u, int v, int hoveredVOffset, class_2960 texture, int textureWidth, int textureHeight) {
/* 47 */     super(position, width, height, message, action);
/* 48 */     this.texture = texture;
/* 49 */     this.u = u;
/* 50 */     this.v = v;
/* 51 */     this.hoveredVOffset = hoveredVOffset;
/* 52 */     this.textureWidth = textureWidth;
/* 53 */     this.textureHeight = textureHeight;
/* 54 */     this.showMessage = showMessage;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void renderButton(class_4587 matrices, int mouseX, int mouseY, float delta) {
/* 61 */     if (this.showMessage) {
/* 62 */       super.renderButton(matrices, mouseX, mouseY, delta);
/*    */     }
/*    */   }
/*    */   
/*    */   protected void renderBackground(class_4587 matrices, int mouseX, int mouseY, float delta) {
/* 67 */     this.client.method_1531().method_22813(this.texture);
/* 68 */     int v = this.v;
/* 69 */     if (isFocusedOrHovered()) {
/* 70 */       v += this.hoveredVOffset;
/*    */     }
/*    */     
/* 73 */     RenderSystem.color4f(1.0F, 1.0F, 1.0F, getAlpha());
/* 74 */     RenderSystem.enableDepthTest();
/* 75 */     method_25290(matrices, getX(), getY(), this.u, v, getWidth(), getHeight(), this.textureWidth, this.textureHeight);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 80 */     return "SpruceTexturedButtonWidget{position=" + 
/* 81 */       getPosition() + ", width=" + 
/* 82 */       getWidth() + ", height=" + 
/* 83 */       getHeight() + ", visible=" + 
/* 84 */       isVisible() + ", active=" + 
/* 85 */       isActive() + ", message=" + 
/* 86 */       getMessage() + ", focused=" + 
/* 87 */       isFocused() + ", hovered=" + 
/* 88 */       isMouseHovered() + ", wasHovered=" + this.wasHovered + ", dragging=" + this.dragging + ", lastDrag=" + this.lastDrag + ", alpha=" + 
/*    */ 
/*    */ 
/*    */       
/* 92 */       getAlpha() + ", texture=" + this.texture + ", u=" + this.u + ", v=" + this.v + ", hoveredVOffset=" + this.hoveredVOffset + ", textureWidth=" + this.textureWidth + ", textureHeight=" + this.textureHeight + ", showMessage=" + this.showMessage + '}';
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\widget\SpruceTexturedButtonWidget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */