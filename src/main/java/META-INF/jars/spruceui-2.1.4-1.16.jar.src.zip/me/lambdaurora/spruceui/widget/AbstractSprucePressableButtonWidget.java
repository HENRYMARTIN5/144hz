/*    */ package me.lambdaurora.spruceui.widget;
/*    */ 
/*    */ import me.lambdaurora.spruceui.Position;
/*    */ import net.minecraft.class_2561;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractSprucePressableButtonWidget
/*    */   extends AbstractSpruceButtonWidget
/*    */ {
/*    */   public AbstractSprucePressableButtonWidget(@NotNull Position position, int width, int height, @NotNull class_2561 message) {
/* 26 */     super(position, width, height, message);
/*    */   }
/*    */ 
/*    */   
/*    */   public abstract void onPress();
/*    */   
/*    */   public void onClick(double mouseX, double mouseY) {
/* 33 */     onPress();
/* 34 */     playDownSound();
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean onKeyPress(int keyCode, int scanCode, int modifiers) {
/* 39 */     if (keyCode == 257 || keyCode == 335) {
/* 40 */       onPress();
/* 41 */       playDownSound();
/* 42 */       return true;
/*    */     } 
/* 44 */     return false;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\widget\AbstractSprucePressableButtonWidget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */