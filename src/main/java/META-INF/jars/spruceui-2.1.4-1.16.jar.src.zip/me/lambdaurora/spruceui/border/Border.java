/*    */ package me.lambdaurora.spruceui.border;
/*    */ 
/*    */ import me.lambdaurora.spruceui.widget.SpruceWidget;
/*    */ import net.minecraft.class_310;
/*    */ import net.minecraft.class_4587;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Border
/*    */ {
/* 24 */   private final class_310 client = class_310.method_1551();
/*    */   
/*    */   public abstract void render(class_4587 paramclass_4587, SpruceWidget paramSpruceWidget, int paramInt1, int paramInt2, float paramFloat);
/*    */   
/*    */   public abstract int getThickness();
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\border\Border.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */