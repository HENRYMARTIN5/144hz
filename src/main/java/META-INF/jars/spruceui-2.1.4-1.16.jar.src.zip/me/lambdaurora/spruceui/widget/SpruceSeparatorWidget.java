/*     */ package me.lambdaurora.spruceui.widget;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import me.lambdaurora.spruceui.Position;
/*     */ import me.lambdaurora.spruceui.Tooltip;
/*     */ import me.lambdaurora.spruceui.Tooltipable;
/*     */ import me.lambdaurora.spruceui.navigation.NavigationDirection;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_2585;
/*     */ import net.minecraft.class_2588;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_332;
/*     */ import net.minecraft.class_339;
/*     */ import net.minecraft.class_4587;
/*     */ import net.minecraft.class_5348;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpruceSeparatorWidget
/*     */   extends AbstractSpruceWidget
/*     */   implements Tooltipable
/*     */ {
/*  38 */   private final class_310 client = class_310.method_1551();
/*     */   private class_2561 title;
/*     */   private class_2561 tooltip;
/*     */   private int tooltipTicks;
/*     */   private long lastTick;
/*     */   
/*     */   public SpruceSeparatorWidget(Position position, int width, @Nullable class_2561 title) {
/*  45 */     super(position);
/*  46 */     this.width = width;
/*  47 */     this.height = 9;
/*  48 */     this.title = title;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public SpruceSeparatorWidget(@Nullable class_2561 title, int x, int y, int width) {
/*  53 */     this(Position.of(x, y), width, title);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public Optional<class_2561> getTitle() {
/*  62 */     return Optional.ofNullable(this.title);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTitle(@Nullable class_2561 title) {
/*  71 */     if (!Objects.equals(title, this.title)) {
/*  72 */       queueNarration(250);
/*     */     }
/*  74 */     this.title = title;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Optional<class_2561> getTooltip() {
/*  79 */     return Optional.ofNullable(this.tooltip);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTooltip(@Nullable class_2561 tooltip) {
/*  84 */     this.tooltip = tooltip;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean requiresCursor() {
/*  91 */     return (this.tooltip == null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void renderWidget(class_4587 matrices, int mouseX, int mouseY, float delta) {
/*  98 */     if (this.title != null) {
/*  99 */       int titleWidth = this.client.field_1772.method_27525((class_5348)this.title);
/* 100 */       int titleX = getX() + getWidth() / 2 - titleWidth / 2;
/* 101 */       if (this.width > titleWidth) {
/* 102 */         method_25294(matrices, getX(), getY() + 4, titleX - 5, getY() + 6, -2039584);
/* 103 */         method_25294(matrices, titleX + titleWidth + 5, getY() + 4, getX() + getWidth(), getY() + 6, -2039584);
/*     */       } 
/* 105 */       class_332.method_27535(matrices, this.client.field_1772, this.title, titleX, getY(), -1);
/*     */     } else {
/* 107 */       method_25294(matrices, getX(), getY() + 4, getX() + getWidth(), getY() + 6, -2039584);
/*     */     } 
/*     */     
/* 110 */     Tooltip.queueFor(this, mouseX, mouseY, this.tooltipTicks, i -> this.tooltipTicks = i.intValue(), this.lastTick, i -> this.lastTick = i.longValue());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   protected Optional<class_2561> getNarrationMessage() {
/* 117 */     return getTitle().map(class_2561::method_10851)
/* 118 */       .filter(title -> !title.isEmpty())
/* 119 */       .map(title -> new class_2588("spruceui.narrator.separator", new Object[] { title }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ButtonWrapper
/*     */     extends class_339
/*     */   {
/*     */     private final SpruceSeparatorWidget widget;
/*     */ 
/*     */ 
/*     */     
/*     */     public ButtonWrapper(@NotNull SpruceSeparatorWidget separator, int height) {
/* 133 */       super(separator.getX(), separator.getY(), separator.getWidth(), height, separator.getTitle().orElse(class_2585.field_24366));
/* 134 */       this.widget = separator;
/*     */     }
/*     */ 
/*     */     
/*     */     public void method_25394(class_4587 matrices, int mouseX, int mouseY, float delta) {
/* 139 */       this.widget.getPosition().setRelativeY(this.field_22761 + this.field_22759 / 2 - 4);
/* 140 */       this.widget.method_25394(matrices, mouseX, mouseY, delta);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean method_25407(boolean down) {
/* 145 */       return this.widget.onNavigation(down ? NavigationDirection.DOWN : NavigationDirection.UP, true);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\widget\SpruceSeparatorWidget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */