/*     */ package me.lambdaurora.spruceui.widget.container;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import me.lambdaurora.spruceui.Position;
/*     */ import me.lambdaurora.spruceui.SprucePositioned;
/*     */ import me.lambdaurora.spruceui.navigation.NavigationDirection;
/*     */ import me.lambdaurora.spruceui.navigation.NavigationUtils;
/*     */ import me.lambdaurora.spruceui.widget.AbstractSpruceWidget;
/*     */ import me.lambdaurora.spruceui.widget.SpruceWidget;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractSpruceParentWidget<E extends SpruceWidget>
/*     */   extends AbstractSpruceWidget
/*     */   implements SpruceParentWidget<E>
/*     */ {
/*     */   private final Class<E> childClass;
/*     */   @Nullable
/*     */   private E focused;
/*     */   
/*     */   public AbstractSpruceParentWidget(@NotNull Position position, Class<E> childClass) {
/*  36 */     super(position);
/*  37 */     this.childClass = childClass;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFocused(boolean focused) {
/*  42 */     super.setFocused(focused);
/*  43 */     if (!focused) {
/*  44 */       setFocused((E)null);
/*     */     }
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public E getFocused() {
/*  50 */     return this.focused;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFocused(@Nullable E focused) {
/*  55 */     if (this.focused == focused)
/*     */       return; 
/*  57 */     if (this.focused != null)
/*  58 */       this.focused.setFocused(false); 
/*  59 */     if (focused == null) {
/*  60 */       this.focused = null;
/*  61 */     } else if (this.childClass.isInstance(focused)) {
/*  62 */       this.focused = focused;
/*  63 */       this.focused.setFocused(true);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void setOwnerShip(E child) {
/*  68 */     child.getPosition().setAnchor((SprucePositioned)this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean onNavigation(@NotNull NavigationDirection direction, boolean tab) {
/*  75 */     if (requiresCursor()) return false; 
/*  76 */     boolean result = NavigationUtils.tryNavigate(direction, tab, children(), (SpruceWidget)this.focused, this::setFocused, false);
/*  77 */     if (result)
/*  78 */       setFocused(true); 
/*  79 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean onMouseClick(double mouseX, double mouseY, int button) {
/*     */     SpruceWidget spruceWidget;
/*  86 */     Iterator<E> it = children().iterator();
/*     */ 
/*     */     
/*     */     do {
/*  90 */       if (!it.hasNext()) {
/*  91 */         return false;
/*     */       }
/*     */       
/*  94 */       spruceWidget = (SpruceWidget)it.next();
/*  95 */     } while (!spruceWidget.method_25402(mouseX, mouseY, button));
/*     */     
/*  97 */     setFocused((E)spruceWidget);
/*  98 */     if (button == 0) {
/*  99 */       setDragging(true);
/*     */     }
/*     */     
/* 102 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onMouseRelease(double mouseX, double mouseY, int button) {
/* 107 */     setDragging(false);
/* 108 */     return hoveredElement(mouseX, mouseY).filter(element -> element.method_25406(mouseX, mouseY, button)).isPresent();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onMouseDrag(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
/* 113 */     return (getFocused() != null && isDragging() && button == 0 && 
/* 114 */       getFocused().method_25403(mouseX, mouseY, button, deltaX, deltaY));
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onMouseScroll(double mouseX, double mouseY, double amount) {
/* 119 */     return hoveredElement(mouseX, mouseY).filter(element -> element.method_25401(mouseX, mouseY, amount)).isPresent();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onKeyPress(int keyCode, int scanCode, int modifiers) {
/* 124 */     return (getFocused() != null && getFocused().method_25404(keyCode, scanCode, modifiers));
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onKeyRelease(int keyCode, int scanCode, int modifiers) {
/* 129 */     return (getFocused() != null && getFocused().method_16803(keyCode, scanCode, modifiers));
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onCharTyped(char chr, int keyCode) {
/* 134 */     return (getFocused() != null && getFocused().method_25400(chr, keyCode));
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\widget\container\AbstractSpruceParentWidget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */