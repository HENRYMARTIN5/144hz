/*    */ package me.lambdaurora.spruceui.widget.container;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.function.Consumer;
/*    */ import me.lambdaurora.spruceui.Position;
/*    */ import me.lambdaurora.spruceui.background.Background;
/*    */ import me.lambdaurora.spruceui.background.EmptyBackground;
/*    */ import me.lambdaurora.spruceui.border.Border;
/*    */ import me.lambdaurora.spruceui.border.EmptyBorder;
/*    */ import me.lambdaurora.spruceui.widget.SpruceWidget;
/*    */ import me.lambdaurora.spruceui.widget.WithBackground;
/*    */ import me.lambdaurora.spruceui.widget.WithBorder;
/*    */ import net.minecraft.class_4587;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpruceContainerWidget
/*    */   extends AbstractSpruceParentWidget<SpruceWidget>
/*    */   implements WithBackground, WithBorder
/*    */ {
/* 35 */   private final List<SpruceWidget> children = new ArrayList<>();
/* 36 */   private Background background = (Background)EmptyBackground.EMPTY_BACKGROUND;
/* 37 */   private Border border = (Border)EmptyBorder.EMPTY_BORDER;
/*    */   
/*    */   public SpruceContainerWidget(Position position, int width, int height) {
/* 40 */     super(position, SpruceWidget.class);
/* 41 */     this.width = width;
/* 42 */     this.height = height;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Background getBackground() {
/* 47 */     return this.background;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setBackground(@NotNull Background background) {
/* 52 */     this.background = background;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Border getBorder() {
/* 57 */     return this.border;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setBorder(@NotNull Border border) {
/* 62 */     this.border = border;
/*    */   }
/*    */   
/*    */   public void addChild(@NotNull SpruceWidget child) {
/* 66 */     setOwnerShip(child);
/* 67 */     this.children.add(child);
/*    */   }
/*    */   
/*    */   public void addChildren(@NotNull ChildrenFactory childrenFactory) {
/* 71 */     childrenFactory.build(this.width, this.height, this::addChild);
/*    */   }
/*    */ 
/*    */   
/*    */   public List<SpruceWidget> children() {
/* 76 */     return this.children;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void renderWidget(class_4587 matrices, int mouseX, int mouseY, float delta) {
/* 83 */     this.children.forEach(child -> child.method_25394(matrices, mouseX, mouseY, delta));
/* 84 */     getBorder().render(matrices, this, mouseX, mouseY, delta);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void renderBackground(class_4587 matrices, int mouseX, int mouseY, float delta) {
/* 89 */     getBackground().render(matrices, this, 0, mouseX, mouseY, delta);
/*    */   }
/*    */   
/*    */   public static interface ChildrenFactory {
/*    */     void build(int param1Int1, int param1Int2, Consumer<SpruceWidget> param1Consumer);
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\widget\container\SpruceContainerWidget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */