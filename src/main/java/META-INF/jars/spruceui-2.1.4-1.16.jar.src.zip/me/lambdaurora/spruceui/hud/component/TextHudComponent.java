/*    */ package me.lambdaurora.spruceui.hud.component;
/*    */ 
/*    */ import me.lambdaurora.spruceui.hud.HudComponent;
/*    */ import net.minecraft.class_2561;
/*    */ import net.minecraft.class_310;
/*    */ import net.minecraft.class_332;
/*    */ import net.minecraft.class_4587;
/*    */ import org.aperlambda.lambdacommon.Identifier;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TextHudComponent
/*    */   extends HudComponent
/*    */ {
/*    */   protected class_310 client;
/*    */   protected class_2561 text;
/*    */   protected int color;
/*    */   
/*    */   public TextHudComponent(@NotNull Identifier identifier, int x, int y, class_2561 text) {
/* 33 */     this(identifier, x, y, text, -1);
/*    */   }
/*    */   
/*    */   public TextHudComponent(@NotNull Identifier identifier, int x, int y, class_2561 text, int color) {
/* 37 */     super(identifier, x, y);
/* 38 */     this.client = class_310.method_1551();
/* 39 */     this.text = text;
/* 40 */     this.color = color;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public class_2561 getText() {
/* 49 */     return this.text;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setText(class_2561 text) {
/* 58 */     this.text = text;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getColor() {
/* 67 */     return this.color;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setColor(int color) {
/* 76 */     this.color = color;
/*    */   }
/*    */ 
/*    */   
/*    */   public void render(class_4587 matrices, float tickDelta) {
/* 81 */     class_332.method_27535(matrices, this.client.field_1772, this.text, this.x, this.y, this.color);
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\hud\component\TextHudComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */