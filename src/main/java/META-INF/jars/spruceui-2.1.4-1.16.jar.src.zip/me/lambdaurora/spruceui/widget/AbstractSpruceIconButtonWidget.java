/*    */ package me.lambdaurora.spruceui.widget;
/*    */ 
/*    */ import me.lambdaurora.spruceui.Position;
/*    */ import net.minecraft.class_2561;
/*    */ import net.minecraft.class_3532;
/*    */ import net.minecraft.class_4587;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractSpruceIconButtonWidget
/*    */   extends SpruceButtonWidget
/*    */ {
/*    */   public AbstractSpruceIconButtonWidget(Position position, int width, int height, class_2561 message, SpruceButtonWidget.PressAction action) {
/* 19 */     super(position, width, height, message, action);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected abstract int renderIcon(class_4587 paramclass_4587, int paramInt1, int paramInt2, float paramFloat);
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void renderButton(class_4587 matrices, int mouseX, int mouseY, float delta) {
/* 31 */     int iconWidth = renderIcon(matrices, mouseX, mouseY, delta);
/* 32 */     if (!getMessage().getString().isEmpty()) {
/* 33 */       int color = isActive() ? 16777215 : 10526880;
/* 34 */       method_27534(matrices, this.client.field_1772, getMessage(), getX() + 8 + iconWidth + (getWidth() - 8 - iconWidth - 6) / 2, 
/* 35 */           getY() + (this.height - 8) / 2, color | class_3532.method_15386(getAlpha() * 255.0F) << 24);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\widget\AbstractSpruceIconButtonWidget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */