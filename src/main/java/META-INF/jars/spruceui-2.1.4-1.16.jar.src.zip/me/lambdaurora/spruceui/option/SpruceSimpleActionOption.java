/*     */ package me.lambdaurora.spruceui.option;
/*     */ 
/*     */ import me.lambdaurora.spruceui.Position;
/*     */ import me.lambdaurora.spruceui.widget.SpruceButtonWidget;
/*     */ import me.lambdaurora.spruceui.widget.SpruceTexturedButtonWidget;
/*     */ import me.lambdaurora.spruceui.widget.SpruceWidget;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_2588;
/*     */ import net.minecraft.class_2960;
/*     */ import org.aperlambda.lambdacommon.utils.Nameable;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SpruceSimpleActionOption
/*     */   extends SpruceOption
/*     */   implements Nameable
/*     */ {
/*     */   private final ButtonFactory buttonFactory;
/*     */   private final SpruceButtonWidget.PressAction action;
/*     */   
/*     */   public SpruceSimpleActionOption(String key, ButtonFactory buttonFactory, SpruceButtonWidget.PressAction action, @Nullable class_2561 tooltip) {
/*  34 */     super(key);
/*  35 */     this.buttonFactory = buttonFactory;
/*  36 */     this.action = action;
/*  37 */     setTooltip(tooltip);
/*     */   }
/*     */   
/*     */   public SpruceSimpleActionOption(String key, ButtonFactory buttonFactory, SpruceButtonWidget.PressAction action) {
/*  41 */     this(key, buttonFactory, action, (class_2561)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public SpruceWidget createWidget(Position position, int width) {
/*  46 */     SpruceButtonWidget button = this.buttonFactory.build(position, width, (class_2561)new class_2588(this.key), this.action);
/*  47 */     getOptionTooltip().ifPresent(button::setTooltip);
/*  48 */     return (SpruceWidget)button;
/*     */   }
/*     */   
/*     */   public static SpruceSimpleActionOption of(String key, SpruceButtonWidget.PressAction action) {
/*  52 */     return new SpruceSimpleActionOption(key, (position, width, message, action1) -> new SpruceButtonWidget(position, width, 20, message, action1), action);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static SpruceSimpleActionOption of(String key, SpruceButtonWidget.PressAction action, @Nullable class_2561 tooltip) {
/*  58 */     return new SpruceSimpleActionOption(key, (position, width, message, action1) -> new SpruceButtonWidget(position, width, 20, message, action1), action, tooltip);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static SpruceSimpleActionOption reset(SpruceButtonWidget.PressAction action) {
/*  64 */     return reset(action, (class_2561)null);
/*     */   }
/*     */   
/*     */   public static SpruceSimpleActionOption reset(SpruceButtonWidget.PressAction action, @Nullable class_2561 tooltip) {
/*  68 */     return new SpruceSimpleActionOption("spruceui.reset", (position, width, message, action1) -> new SpruceButtonWidget(position, width, 20, message, action1), action, tooltip);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SpruceSimpleActionOption textured(String key, SpruceButtonWidget.PressAction action, int u, int v, int hoveredVOffset, class_2960 texture) {
/*  75 */     return textured(key, action, u, v, hoveredVOffset, texture, (class_2561)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public static SpruceSimpleActionOption textured(String key, SpruceButtonWidget.PressAction action, int u, int v, int hoveredVOffset, class_2960 texture, @Nullable class_2561 tooltip) {
/*  80 */     return new SpruceSimpleActionOption(key, (position, width, message, action1) -> new SpruceTexturedButtonWidget(position, width, 20, message, action1, u, v, hoveredVOffset, texture), action, tooltip);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SpruceSimpleActionOption textured(String key, SpruceButtonWidget.PressAction action, int u, int v, int hoveredVOffset, class_2960 texture, int textureWidth, int textureHeight) {
/*  87 */     return textured(key, action, u, v, hoveredVOffset, texture, textureWidth, textureHeight, (class_2561)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public static SpruceSimpleActionOption textured(String key, SpruceButtonWidget.PressAction action, int u, int v, int hoveredVOffset, class_2960 texture, int textureWidth, int textureHeight, @Nullable class_2561 tooltip) {
/*  92 */     return new SpruceSimpleActionOption(key, (position, width, message, action1) -> new SpruceTexturedButtonWidget(position, width, 20, message, action1, u, v, hoveredVOffset, texture, textureWidth, textureHeight), action, tooltip);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SpruceSimpleActionOption texturedWithMessage(String key, SpruceButtonWidget.PressAction action, int u, int v, int hoveredVOffset, class_2960 texture, int textureWidth, int textureHeight) {
/* 100 */     return texturedWithMessage(key, action, u, v, hoveredVOffset, texture, textureWidth, textureHeight, (class_2561)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public static SpruceSimpleActionOption texturedWithMessage(String key, SpruceButtonWidget.PressAction action, int u, int v, int hoveredVOffset, class_2960 texture, int textureWidth, int textureHeight, @Nullable class_2561 tooltip) {
/* 105 */     return new SpruceSimpleActionOption(key, (position, width, message, action1) -> new SpruceTexturedButtonWidget(position, width, 20, message, true, action1, u, v, hoveredVOffset, texture, textureWidth, textureHeight), action, tooltip);
/*     */   }
/*     */   
/*     */   public static interface ButtonFactory {
/*     */     SpruceButtonWidget build(Position param1Position, int param1Int, class_2561 param1class_2561, SpruceButtonWidget.PressAction param1PressAction);
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\option\SpruceSimpleActionOption.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */