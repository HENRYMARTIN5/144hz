package me.lambdaurora.spruceui.background;

import me.lambdaurora.spruceui.widget.SpruceWidget;
import net.minecraft.class_4587;

public interface Background {
  void render(class_4587 paramclass_4587, SpruceWidget paramSpruceWidget, int paramInt1, int paramInt2, int paramInt3, float paramFloat);
}


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\background\Background.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */