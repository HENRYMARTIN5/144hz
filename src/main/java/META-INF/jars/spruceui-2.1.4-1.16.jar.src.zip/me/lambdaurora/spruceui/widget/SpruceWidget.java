/*     */ package me.lambdaurora.spruceui.widget;
/*     */ 
/*     */ import me.lambdaurora.spruceui.Position;
/*     */ import me.lambdaurora.spruceui.SprucePositioned;
/*     */ import net.minecraft.class_4068;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface SpruceWidget
/*     */   extends SprucePositioned, SpruceElement, class_4068
/*     */ {
/*     */   @NotNull
/*     */   Position getPosition();
/*     */   
/*     */   default int getX() {
/*  34 */     return getPosition().getX();
/*     */   }
/*     */ 
/*     */   
/*     */   default int getY() {
/*  39 */     return getPosition().getY();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isVisible();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setVisible(boolean paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getWidth();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getHeight();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isActive();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setActive(boolean paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isFocused();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setFocused(boolean paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isMouseHovered();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean isFocusedOrHovered() {
/* 111 */     return (isMouseHovered() || isFocused());
/*     */   }
/*     */ 
/*     */   
/*     */   default boolean method_25405(double mouseX, double mouseY) {
/* 116 */     return (isVisible() && mouseX >= getX() && mouseX < (getX() + getWidth()) && mouseY >= getY() && mouseY < (getY() + getHeight()));
/*     */   }
/*     */   
/*     */   boolean isDragging();
/*     */   
/*     */   void setDragging(boolean paramBoolean);
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\widget\SpruceWidget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */