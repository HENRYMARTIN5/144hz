/*     */ package me.lambdaurora.spruceui.widget.container.tabbed;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import me.lambdaurora.spruceui.Position;
/*     */ import me.lambdaurora.spruceui.SprucePositioned;
/*     */ import me.lambdaurora.spruceui.background.Background;
/*     */ import me.lambdaurora.spruceui.background.EmptyBackground;
/*     */ import me.lambdaurora.spruceui.navigation.NavigationDirection;
/*     */ import me.lambdaurora.spruceui.widget.AbstractSpruceWidget;
/*     */ import me.lambdaurora.spruceui.widget.SpruceSeparatorWidget;
/*     */ import me.lambdaurora.spruceui.widget.SpruceWidget;
/*     */ import me.lambdaurora.spruceui.widget.WithBackground;
/*     */ import me.lambdaurora.spruceui.widget.container.AbstractSpruceParentWidget;
/*     */ import me.lambdaurora.spruceui.widget.container.SpruceEntryListWidget;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_4587;
/*     */ import net.minecraft.class_5348;
/*     */ import net.minecraft.class_5481;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpruceTabbedWidget
/*     */   extends AbstractSpruceParentWidget<SpruceWidget>
/*     */ {
/*     */   private final class_2561 title;
/*     */   private final SideTabList list;
/*     */   private final Position anchor;
/*     */   private boolean isLeft = false;
/*     */   
/*     */   public SpruceTabbedWidget(@NotNull Position position, int width, int height, @Nullable class_2561 title) {
/*  47 */     this(position, width, height, title, Math.max(100, width / 8), (title != null) ? 20 : 0);
/*     */   }
/*     */   
/*     */   public SpruceTabbedWidget(@NotNull Position position, int width, int height, @Nullable class_2561 title, int sideWidth, int sideTopOffset) {
/*  51 */     super(position, SpruceWidget.class);
/*  52 */     this.width = width;
/*  53 */     this.height = height;
/*  54 */     this.title = title;
/*  55 */     this.list = new SideTabList(Position.of((SprucePositioned)position, 0, sideTopOffset), sideWidth, height - sideTopOffset);
/*  56 */     this.anchor = Position.of((SprucePositioned)this, this.list.getWidth(), 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SideTabList getList() {
/*  65 */     return this.list;
/*     */   }
/*     */   
/*     */   public void addTabEntry(class_2561 title, @Nullable class_2561 description, ContainerFactory factory) {
/*  69 */     addTabEntry(title, description, factory.build(getWidth() - this.list.getWidth(), getHeight()));
/*     */   }
/*     */   
/*     */   public void addTabEntry(class_2561 title, @Nullable class_2561 description, AbstractSpruceWidget container) {
/*  73 */     TabEntry entry = this.list.addTabEntry(title, description, container);
/*  74 */     entry.container.getPosition().setAnchor((SprucePositioned)this.anchor);
/*     */   }
/*     */   
/*     */   public void addSeparatorEntry(class_2561 title) {
/*  78 */     this.list.addSeparatorEntry(title);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFocused(@Nullable SpruceWidget focused) {
/*  83 */     super.setFocused(focused);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<SpruceWidget> children() {
/*  88 */     if (this.list.getCurrentTab() == null)
/*  89 */       return (List)Collections.singletonList(this.list); 
/*  90 */     return Arrays.asList(new SpruceWidget[] { (SpruceWidget)this.list, (SpruceWidget)TabEntry.access$000(this.list.getCurrentTab()) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean onNavigation(@NotNull NavigationDirection direction, boolean tab) {
/*  97 */     if (requiresCursor()) return false;
/*     */     
/*  99 */     if (tab) {
/* 100 */       boolean result = (this.list.getCurrentTab()).container.onNavigation(direction, tab);
/* 101 */       setFocused((this.list.getCurrentTab()).container.isFocused() ? (SpruceWidget)(this.list.getCurrentTab()).container : null);
/* 102 */       return result;
/*     */     } 
/*     */     
/* 105 */     if (direction.isHorizontal()) {
/* 106 */       if (direction == NavigationDirection.RIGHT) {
/* 107 */         if ((this.list.getCurrentTab()).container.onNavigation(direction, tab))
/* 108 */           setFocused((SpruceWidget)(this.list.getCurrentTab()).container); 
/* 109 */       } else if (getFocused() != this.list) {
/* 110 */         boolean result = (this.list.getCurrentTab()).container.onNavigation(direction, tab);
/* 111 */         if (!result)
/* 112 */           setFocused((SpruceWidget)this.list); 
/*     */       } 
/* 114 */       return true;
/*     */     } 
/* 116 */     if (!isFocused()) {
/* 117 */       setFocused(true);
/* 118 */       setFocused(this.isLeft ? (SpruceWidget)this.list : (SpruceWidget)(this.list.getCurrentTab()).container);
/*     */     } else {
/* 120 */       this.isLeft = (getFocused() == this.list);
/*     */     } 
/*     */     
/* 123 */     if (getFocused() == null) {
/* 124 */       setFocused(this.isLeft ? (SpruceWidget)this.list : (SpruceWidget)(this.list.getCurrentTab()).container);
/*     */     }
/*     */     
/* 127 */     return getFocused().onNavigation(direction, tab);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void renderWidget(class_4587 matrices, int mouseX, int mouseY, float delta) {
/* 135 */     if (this.title != null) {
/* 136 */       method_27534(matrices, this.client.field_1772, this.title, getX() + this.list.getWidth() / 2, getY() + 6, -1);
/*     */     }
/* 138 */     this.list.method_25394(matrices, mouseX, mouseY, delta);
/* 139 */     if (this.list.getCurrentTab() != null)
/* 140 */       (this.list.getCurrentTab()).container.method_25394(matrices, mouseX, mouseY, delta); 
/*     */   }
/*     */   
/*     */   public static abstract class Entry extends SpruceEntryListWidget.Entry implements WithBackground {
/*     */     protected final SpruceTabbedWidget.SideTabList parent;
/*     */     private final class_2561 title;
/* 146 */     private Background background = (Background)EmptyBackground.EMPTY_BACKGROUND;
/*     */     
/*     */     protected Entry(SpruceTabbedWidget.SideTabList parent, class_2561 title) {
/* 149 */       this.parent = parent;
/* 150 */       this.title = title;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getWidth() {
/* 155 */       return this.parent.getInnerWidth();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public class_2561 getTitle() {
/* 164 */       return this.title;
/*     */     }
/*     */     
/*     */     @NotNull
/*     */     public Background getBackground() {
/* 169 */       return this.background;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setBackground(@NotNull Background background) {
/* 174 */       this.background = background;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void renderBackground(class_4587 matrices, int mouseX, int mouseY, float delta) {
/* 181 */       getBackground().render(matrices, (SpruceWidget)this, 0, mouseX, mouseY, delta);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class TabEntry extends Entry {
/*     */     private final List<class_5481> title;
/*     */     private final List<class_5481> description;
/*     */     private final AbstractSpruceWidget container;
/*     */     private boolean selected;
/*     */     
/*     */     protected TabEntry(SpruceTabbedWidget.SideTabList parent, class_2561 title, @Nullable class_2561 description, AbstractSpruceWidget container) {
/* 192 */       super(parent, title);
/* 193 */       this.title = this.client.field_1772.method_1728((class_5348)title, this.parent.getWidth() - 18);
/* 194 */       if (description == null) { this.description = null; }
/* 195 */       else { this.description = this.client.field_1772.method_1728((class_5348)description, this.parent.getWidth() - 18); }
/* 196 */        this.container = container;
/*     */       
/* 198 */       if (container instanceof SpruceEntryListWidget) {
/* 199 */         ((SpruceEntryListWidget)container).setAllowOutsideHorizontalNavigation(true);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public int getHeight() {
/* 205 */       this.client.field_1772.getClass();
/* 206 */       this.client.field_1772.getClass(); return 4 + this.title.size() * 9 + 4 + ((this.description == null) ? 0 : (this.description.size() * 9 + 4)) + 4;
/*     */     }
/*     */     
/*     */     public boolean isSelected() {
/* 210 */       return this.selected;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setFocused(boolean focused) {
/* 215 */       super.setFocused(focused);
/* 216 */       if (focused) {
/* 217 */         this.selected = true;
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected boolean onMouseClick(double mouseX, double mouseY, int button) {
/* 224 */       if (button == 0) {
/* 225 */         playDownSound();
/* 226 */         this.parent.setSelected(this);
/* 227 */         return true;
/*     */       } 
/* 229 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void renderWidget(class_4587 matrices, int mouseX, int mouseY, float delta) {
/* 236 */       int y = getY() + 4; Iterator<class_5481> it;
/* 237 */       for (it = this.title.iterator(); it.hasNext(); y += 9) {
/* 238 */         class_5481 line = it.next();
/* 239 */         this.client.field_1772.method_27528(matrices, line, (getX() + 4), y, 16777215);
/*     */       } 
/* 241 */       if (this.description != null) {
/* 242 */         y += 4;
/* 243 */         for (it = this.description.iterator(); it.hasNext(); y += 9) {
/* 244 */           class_5481 line = it.next();
/* 245 */           this.client.field_1772.method_27528(matrices, line, (getX() + 8), y, 16777215);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     protected void renderBackground(class_4587 matrices, int mouseX, int mouseY, float delta) {
/* 252 */       super.renderBackground(matrices, mouseX, mouseY, delta);
/* 253 */       if (isFocused() && this.parent.isFocused()) {
/* 254 */         method_25294(matrices, getX(), getY(), getX() + getWidth(), getY() + getHeight() - 4, 805306367);
/* 255 */       } else if (this.selected || isMouseHovered()) {
/* 256 */         method_25294(matrices, getX(), getY(), getX() + getWidth(), getY() + getHeight() - 4, 452984831);
/*     */       } 
/*     */     }
/*     */     
/*     */     public String toString() {
/* 261 */       return "SpruceTabbedWidget$TabEntry{title=" + 
/* 262 */         getTitle() + ", description=" + this.description + ", position=" + 
/*     */         
/* 264 */         getPosition() + ", width=" + 
/* 265 */         getWidth() + ", height=" + 
/* 266 */         getHeight() + ", container=" + this.container + ", selected=" + this.selected + ", background=" + 
/*     */ 
/*     */         
/* 269 */         getBackground() + '}';
/*     */     }
/*     */   }
/*     */   
/*     */   public static class SeparatorEntry
/*     */     extends Entry {
/*     */     private final SpruceSeparatorWidget separatorWidget;
/*     */     
/*     */     protected SeparatorEntry(SpruceTabbedWidget.SideTabList parent, class_2561 title) {
/* 278 */       super(parent, title);
/* 279 */       this.separatorWidget = new SpruceSeparatorWidget(Position.of((SprucePositioned)this, 0, 2), getWidth(), title)
/*     */         {
/*     */           public int getWidth() {
/* 282 */             return SpruceTabbedWidget.SeparatorEntry.this.getWidth();
/*     */           }
/*     */         };
/*     */     }
/*     */     
/*     */     public SpruceSeparatorWidget getSeparatorWidget() {
/* 288 */       return this.separatorWidget;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getHeight() {
/* 293 */       return this.separatorWidget.getHeight() + 6;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean onNavigation(@NotNull NavigationDirection direction, boolean tab) {
/* 300 */       return this.separatorWidget.onNavigation(direction, tab);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void renderWidget(class_4587 matrices, int mouseX, int mouseY, float delta) {
/* 307 */       this.separatorWidget.method_25394(matrices, mouseX, mouseY, delta);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 312 */       return "SpruceTabbedWidget$SeparatorEntry{title=" + 
/* 313 */         getTitle() + ", position=" + 
/* 314 */         getPosition() + ", width=" + 
/* 315 */         getWidth() + ", height=" + 
/* 316 */         getHeight() + ", background=" + 
/* 317 */         getBackground() + '}';
/*     */     }
/*     */   }
/*     */   
/*     */   public static class SideTabList
/*     */     extends SpruceEntryListWidget<Entry> {
/* 323 */     private SpruceTabbedWidget.TabEntry currentTab = null;
/*     */     
/*     */     protected SideTabList(@NotNull Position position, int width, int height) {
/* 326 */       super(position, width, height, 0, SpruceTabbedWidget.Entry.class);
/* 327 */       setRenderTransition(false);
/*     */     }
/*     */     
/*     */     public SpruceTabbedWidget.TabEntry getCurrentTab() {
/* 331 */       return this.currentTab;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setFocused(boolean focused) {
/* 336 */       super.setFocused(focused);
/* 337 */       if (!focused)
/* 338 */         setSelected(this.currentTab); 
/*     */     }
/*     */     
/*     */     public void setSelected(SpruceTabbedWidget.TabEntry tab) {
/* 342 */       if (this.currentTab != null)
/* 343 */         this.currentTab.selected = false; 
/* 344 */       tab.setFocused(true);
/* 345 */       setFocused((SpruceWidget)tab);
/* 346 */       this.currentTab = tab;
/*     */     }
/*     */     
/*     */     public SpruceTabbedWidget.TabEntry addTabEntry(class_2561 title, @Nullable class_2561 description, AbstractSpruceWidget container) {
/* 350 */       SpruceTabbedWidget.TabEntry entry = new SpruceTabbedWidget.TabEntry(this, title, description, container);
/* 351 */       addEntry(entry);
/* 352 */       if (getCurrentTab() == null)
/* 353 */         setSelected(entry); 
/* 354 */       return entry;
/*     */     }
/*     */     
/*     */     public SpruceTabbedWidget.SeparatorEntry addSeparatorEntry(class_2561 title) {
/* 358 */       SpruceTabbedWidget.SeparatorEntry entry = new SpruceTabbedWidget.SeparatorEntry(this, title);
/* 359 */       addEntry(entry);
/* 360 */       return entry;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean onNavigation(@NotNull NavigationDirection direction, boolean tab) {
/* 367 */       if (requiresCursor()) return false; 
/* 368 */       SpruceTabbedWidget.Entry old = (SpruceTabbedWidget.Entry)getFocused();
/* 369 */       boolean result = super.onNavigation(direction, tab);
/* 370 */       SpruceTabbedWidget.Entry focused = (SpruceTabbedWidget.Entry)getFocused();
/* 371 */       if (result && old != focused && focused instanceof SpruceTabbedWidget.TabEntry) {
/* 372 */         setSelected((SpruceTabbedWidget.TabEntry)focused);
/*     */       }
/* 374 */       return result;
/*     */     }
/*     */   }
/*     */   
/*     */   public static interface ContainerFactory {
/*     */     AbstractSpruceWidget build(int param1Int1, int param1Int2);
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\widget\container\tabbed\SpruceTabbedWidget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */