/*     */ package me.lambdaurora.spruceui.widget.text;
/*     */ 
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Predicate;
/*     */ import me.lambdaurora.spruceui.Position;
/*     */ import me.lambdaurora.spruceui.Tooltip;
/*     */ import me.lambdaurora.spruceui.Tooltipable;
/*     */ import me.lambdaurora.spruceui.navigation.NavigationDirection;
/*     */ import net.minecraft.class_155;
/*     */ import net.minecraft.class_156;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_2583;
/*     */ import net.minecraft.class_2585;
/*     */ import net.minecraft.class_287;
/*     */ import net.minecraft.class_289;
/*     */ import net.minecraft.class_290;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_3532;
/*     */ import net.minecraft.class_437;
/*     */ import net.minecraft.class_4493;
/*     */ import net.minecraft.class_4587;
/*     */ import net.minecraft.class_5481;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpruceTextFieldWidget
/*     */   extends AbstractSpruceTextInputWidget
/*     */   implements Tooltipable
/*     */ {
/*     */   public static final Predicate<String> INTEGER_INPUT_PREDICATE;
/*     */   public static final Predicate<String> FLOAT_INPUT_PREDICATE;
/*     */   public static final Predicate<String> DOUBLE_INPUT_PREDICATE;
/*     */   
/*     */   static {
/*  50 */     INTEGER_INPUT_PREDICATE = (input -> {
/*     */         if (input.isEmpty() || input.equals("-"))
/*     */           return true;  try {
/*     */           Integer.parseInt(input);
/*     */           return true;
/*  55 */         } catch (NumberFormatException e) {
/*     */           return false;
/*     */         } 
/*     */       });
/*  59 */     FLOAT_INPUT_PREDICATE = (input -> {
/*     */         if (input.isEmpty() || input.equals("-") || input.equals("."))
/*     */           return true;  try {
/*     */           Float.parseFloat(input);
/*     */           return true;
/*  64 */         } catch (NumberFormatException e) {
/*     */           return false;
/*     */         } 
/*     */       });
/*  68 */     DOUBLE_INPUT_PREDICATE = (input -> {
/*     */         if (input.isEmpty() || input.equals("-") || input.equals("."))
/*     */           return true;  try {
/*     */           Double.parseDouble(input);
/*     */           return true;
/*  73 */         } catch (NumberFormatException e) {
/*     */           return false;
/*     */         } 
/*     */       });
/*     */   }
/*  78 */   private final Cursor cursor = new Cursor(true);
/*  79 */   private final Selection selection = new Selection();
/*  80 */   private String text = "";
/*     */   
/*     */   private class_2561 tooltip;
/*     */   
/*     */   private Consumer<String> changedListener;
/*     */   private Predicate<String> textPredicate;
/*     */   private BiFunction<String, Integer, class_5481> renderTextProvider;
/*  87 */   private int firstCharacterIndex = 0;
/*     */   private long editingTime;
/*     */   private int tooltipTicks;
/*     */   private long lastTick;
/*     */   
/*     */   public SpruceTextFieldWidget(@NotNull Position position, int width, int height, class_2561 title) {
/*  93 */     super(position, width, height, title);
/*  94 */     this.cursor.toStart();
/*  95 */     sanitize();
/*     */     
/*  97 */     this.changedListener = (input -> {
/*     */       
/*  99 */       }); this.textPredicate = Objects::nonNull;
/* 100 */     this.renderTextProvider = ((input, firstCharacterIndex) -> class_5481.method_30747(input, class_2583.field_24360));
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public String getText() {
/* 105 */     return this.text;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setText(String text) {
/* 110 */     if (this.textPredicate.test(text)) {
/* 111 */       this.text = text;
/*     */       
/* 113 */       setCursorToEnd();
/* 114 */       this.selection.cancel();
/* 115 */       sanitize();
/* 116 */       onChanged();
/*     */     } 
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Optional<class_2561> getTooltip() {
/* 122 */     return Optional.ofNullable(this.tooltip);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTooltip(@Nullable class_2561 tooltip) {
/* 127 */     this.tooltip = tooltip;
/*     */   }
/*     */   
/*     */   public Consumer<String> getChangedListener() {
/* 131 */     return this.changedListener;
/*     */   }
/*     */   
/*     */   public void setChangedListener(Consumer<String> changedListener) {
/* 135 */     this.changedListener = changedListener;
/*     */   }
/*     */   
/*     */   public Predicate<String> getTextPredicate() {
/* 139 */     return this.textPredicate;
/*     */   }
/*     */   
/*     */   public void setTextPredicate(Predicate<String> textPredicate) {
/* 143 */     this.textPredicate = textPredicate;
/*     */   }
/*     */   
/*     */   public BiFunction<String, Integer, class_5481> getRenderTextProvider() {
/* 147 */     return this.renderTextProvider;
/*     */   }
/*     */   
/*     */   public void setRenderTextProvider(BiFunction<String, Integer, class_5481> renderTextProvider) {
/* 151 */     this.renderTextProvider = renderTextProvider;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCursorToStart() {
/* 156 */     this.cursor.toStart();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCursorToEnd() {
/* 161 */     this.cursor.toEnd();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void sanitize() {
/* 166 */     this.cursor.sanitize();
/*     */     
/* 168 */     int textLength = this.text.length();
/* 169 */     if (this.firstCharacterIndex > textLength) {
/* 170 */       this.firstCharacterIndex = textLength;
/*     */     }
/*     */     
/* 173 */     int width = getInnerWidth();
/* 174 */     String string = this.client.field_1772.method_27523(this.text.substring(this.firstCharacterIndex), width);
/* 175 */     int l = string.length() + this.firstCharacterIndex;
/* 176 */     if (this.cursor.column == this.firstCharacterIndex) {
/* 177 */       this.firstCharacterIndex -= this.client.field_1772.method_27524(this.text, width, true).length();
/*     */     }
/*     */     
/* 180 */     if (this.cursor.column > l) {
/* 181 */       this.firstCharacterIndex += this.cursor.column - l;
/* 182 */     } else if (this.cursor.column <= this.firstCharacterIndex) {
/* 183 */       this.firstCharacterIndex -= this.firstCharacterIndex - this.cursor.column;
/*     */     } 
/*     */     
/* 186 */     this.firstCharacterIndex = class_3532.method_15340(this.firstCharacterIndex, 0, textLength);
/*     */   }
/*     */   
/*     */   private void onChanged() {
/* 190 */     if (this.changedListener != null) {
/* 191 */       this.changedListener.accept(this.text);
/*     */     }
/*     */     
/* 194 */     this.editingTime = class_156.method_658() + 5000L;
/* 195 */     queueNarration(500);
/*     */   }
/*     */   
/*     */   private boolean onSelectionUpdate(@NotNull Runnable action) {
/* 199 */     this.selection.tryStartSelection();
/* 200 */     action.run();
/* 201 */     this.selection.moveToCursor();
/* 202 */     sanitize();
/* 203 */     return true;
/*     */   }
/*     */   private void insertCharacter(char character) {
/*     */     String newText;
/* 207 */     if (getText().isEmpty()) {
/* 208 */       setText(String.valueOf(character));
/*     */       return;
/*     */     } 
/* 211 */     this.selection.erase();
/*     */ 
/*     */     
/* 214 */     if (character == '\n') {
/*     */       return;
/*     */     }
/*     */     
/* 218 */     String text = getText();
/* 219 */     int cursorPosition = this.cursor.getPosition();
/*     */ 
/*     */     
/* 222 */     if (cursorPosition >= text.length()) {
/* 223 */       newText = text + character;
/*     */     } else {
/* 225 */       newText = text.substring(0, cursorPosition) + character + text.substring(cursorPosition);
/*     */     } 
/*     */     
/* 228 */     if (this.textPredicate.test(newText)) {
/* 229 */       this.text = newText;
/* 230 */       onChanged();
/* 231 */       this.cursor.moveRight();
/*     */     } 
/* 233 */     sanitize();
/*     */   }
/*     */   
/*     */   private void eraseCharacter() {
/* 237 */     if (this.selection.erase()) {
/* 238 */       sanitize();
/*     */       
/*     */       return;
/*     */     } 
/* 242 */     if (this.cursor.column == 0) {
/*     */       return;
/*     */     }
/* 245 */     String text = getText();
/* 246 */     int cursorPosition = this.cursor.getPosition();
/* 247 */     String newText = text.substring(0, cursorPosition - 1) + text.substring(cursorPosition);
/* 248 */     if (this.textPredicate.test(newText)) {
/* 249 */       this.text = newText;
/* 250 */       onChanged();
/* 251 */       this.cursor.moveLeft();
/*     */     } 
/* 253 */     sanitize();
/*     */   }
/*     */   
/*     */   private void removeCharacterForward() {
/* 257 */     if (this.selection.erase()) {
/* 258 */       sanitize();
/*     */       
/*     */       return;
/*     */     } 
/* 262 */     if (getText().isEmpty()) {
/* 263 */       sanitize();
/*     */       
/*     */       return;
/*     */     } 
/* 267 */     if (this.cursor.column >= getText().length()) {
/*     */       return;
/*     */     }
/* 270 */     String text = getText();
/* 271 */     int cursorPosition = this.cursor.getPosition();
/*     */     
/* 273 */     String newText = text.substring(0, cursorPosition) + text.substring(cursorPosition + 1);
/* 274 */     if (this.textPredicate.test(newText)) {
/* 275 */       this.text = newText;
/* 276 */       onChanged();
/*     */     } 
/* 278 */     sanitize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(@NotNull String text) {
/*     */     String newText;
/* 287 */     if (text.isEmpty()) {
/*     */       return;
/*     */     }
/* 290 */     if (getText().isEmpty()) {
/* 291 */       setText(text);
/* 292 */       setCursorToEnd();
/*     */       return;
/*     */     } 
/* 295 */     this.selection.erase();
/*     */     
/* 297 */     String oldText = getText();
/* 298 */     int position = this.cursor.getPosition();
/*     */ 
/*     */     
/* 301 */     if (position >= oldText.length()) {
/* 302 */       newText = oldText + text;
/*     */     } else {
/* 304 */       newText = oldText.substring(0, position) + text + oldText.substring(position);
/*     */     } 
/*     */     
/* 307 */     if (this.textPredicate.test(newText)) {
/* 308 */       this.text = newText;
/* 309 */       onChanged();
/* 310 */       this.cursor.move(text.length());
/*     */     } 
/* 312 */     sanitize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean onNavigation(@NotNull NavigationDirection direction, boolean tab) {
/* 319 */     if (requiresCursor()) return false; 
/* 320 */     if (!tab && direction.isHorizontal()) {
/* 321 */       setFocused(true);
/* 322 */       boolean result = false;
/* 323 */       switch (direction) {
/*     */         case RIGHT:
/* 325 */           result = onSelectionUpdate(this.cursor::moveRight);
/*     */           break;
/*     */         case LEFT:
/* 328 */           result = onSelectionUpdate(this.cursor::moveLeft);
/*     */           break;
/*     */       } 
/*     */ 
/*     */       
/* 333 */       if (result)
/* 334 */         return true; 
/*     */     } 
/* 336 */     return super.onNavigation(direction, tab);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean onCharTyped(char chr, int keyCode) {
/* 343 */     if (!isEditorActive() || !class_155.method_643(chr)) {
/* 344 */       return false;
/*     */     }
/* 346 */     if (isActive()) {
/* 347 */       insertCharacter(chr);
/* 348 */       this.selection.cancel();
/*     */     } 
/* 350 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onKeyPress(int keyCode, int scanCode, int modifiers) {
/* 355 */     if (!isEditorActive()) {
/* 356 */       return false;
/*     */     }
/* 358 */     if (class_437.method_25439(keyCode)) {
/* 359 */       this.selection.selectAll();
/* 360 */       sanitize();
/* 361 */       return true;
/* 362 */     }  if (class_437.method_25437(keyCode)) {
/* 363 */       write((class_310.method_1551()).field_1774.method_1460());
/* 364 */       return true;
/* 365 */     }  if (class_437.method_25438(keyCode) || class_437.method_25436(keyCode)) {
/* 366 */       String selected = this.selection.getSelectedText();
/* 367 */       if (!selected.isEmpty())
/* 368 */         (class_310.method_1551()).field_1774.method_1455(selected); 
/* 369 */       if (class_437.method_25436(keyCode)) {
/* 370 */         this.selection.erase();
/* 371 */         sanitize();
/*     */       } 
/* 373 */       return true;
/*     */     } 
/*     */     
/* 376 */     switch (keyCode) {
/*     */       case 262:
/* 378 */         return onSelectionUpdate(this.cursor::moveRight);
/*     */       case 263:
/* 380 */         return onSelectionUpdate(this.cursor::moveLeft);
/*     */       case 269:
/* 382 */         return onSelectionUpdate(this.cursor::toEnd);
/*     */       case 268:
/* 384 */         return onSelectionUpdate(this.cursor::toStart);
/*     */       case 259:
/* 386 */         eraseCharacter();
/* 387 */         return true;
/*     */       case 261:
/* 389 */         removeCharacterForward();
/* 390 */         return true;
/*     */       case 68:
/* 392 */         if (class_437.method_25441() && !this.text.isEmpty()) {
/* 393 */           setText("");
/*     */         }
/* 395 */         return true;
/*     */     } 
/* 397 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean onMouseClick(double mouseX, double mouseY, int button) {
/* 403 */     if (button == 0) {
/* 404 */       int x = class_3532.method_15357(mouseX) - getX() - 4;
/*     */       
/* 406 */       setFocused(true);
/*     */       
/* 408 */       onSelectionUpdate(() -> {
/*     */             String displayedText = this.client.field_1772.method_27523(this.text.substring(this.firstCharacterIndex), getInnerWidth());
/*     */             
/*     */             this.cursor.lastColumn = this.cursor.column = this.firstCharacterIndex + this.client.field_1772.method_27523(displayedText, x).length();
/*     */           });
/* 413 */       return true;
/*     */     } 
/*     */     
/* 416 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void renderWidget(class_4587 matrices, int mouseX, int mouseY, float delta) {
/* 423 */     super.renderWidget(matrices, mouseX, mouseY, delta);
/*     */     
/* 425 */     drawText(matrices);
/* 426 */     drawCursor(matrices);
/*     */     
/* 428 */     if (!this.dragging && this.editingTime == 0L) {
/* 429 */       Tooltip.queueFor(this, mouseX, mouseY, this.tooltipTicks, i -> this.tooltipTicks = i.intValue(), this.lastTick, i -> this.lastTick = i.longValue());
/* 430 */     } else if (this.editingTime < class_156.method_658()) {
/* 431 */       this.editingTime = 0L;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void drawText(@NotNull class_4587 matrices) {
/* 441 */     int textColor = getTextColor();
/* 442 */     int x = getX() + 4;
/* 443 */     int y = getY() + getHeight() / 2 - 4;
/*     */     
/* 445 */     String displayedText = this.client.field_1772.method_27523(this.text.substring(this.firstCharacterIndex), getInnerWidth());
/*     */     
/* 447 */     this.client.field_1772.method_27517(matrices, this.renderTextProvider.apply(displayedText, Integer.valueOf(this.firstCharacterIndex)), x, y, textColor);
/* 448 */     drawSelection(displayedText, y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void drawSelection(@NotNull String line, int lineY) {
/* 458 */     if (!isFocused() || !this.selection.active) {
/*     */       return;
/*     */     }
/* 461 */     int startIndex = Math.max(0, (this.selection.getStart()).column - this.firstCharacterIndex);
/* 462 */     int endIndex = Math.min(line.length(), (this.selection.getEnd()).column - this.firstCharacterIndex);
/*     */     
/* 464 */     if (startIndex >= line.length()) {
/*     */       return;
/*     */     }
/* 467 */     int x = getX() + 4 + this.client.field_1772.method_1727(line.substring(0, startIndex));
/* 468 */     String selected = line.substring(startIndex, endIndex);
/*     */     
/* 470 */     int x2 = x + this.client.field_1772.method_1727(selected);
/* 471 */     this.client.field_1772.getClass(); int y2 = lineY + 9;
/*     */     
/* 473 */     class_289 tessellator = class_289.method_1348();
/* 474 */     class_287 buffer = tessellator.method_1349();
/* 475 */     RenderSystem.color4f(0.0F, 0.0F, 255.0F, 255.0F);
/* 476 */     RenderSystem.disableTexture();
/* 477 */     RenderSystem.enableColorLogicOp();
/* 478 */     RenderSystem.logicOp(class_4493.class_1030.field_5110);
/* 479 */     buffer.method_1328(7, class_290.field_1592);
/* 480 */     buffer.method_22912(x, y2, 0.0D).method_1344();
/* 481 */     buffer.method_22912(x2, y2, 0.0D).method_1344();
/* 482 */     buffer.method_22912(x2, lineY, 0.0D).method_1344();
/* 483 */     buffer.method_22912(x, lineY, 0.0D).method_1344();
/* 484 */     tessellator.method_1350();
/* 485 */     RenderSystem.disableColorLogicOp();
/* 486 */     RenderSystem.enableTexture();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void drawCursor(@NotNull class_4587 matrices) {
/* 495 */     if (!isFocused()) {
/*     */       return;
/*     */     }
/* 498 */     int cursorY = getY() + getHeight() / 2 - 4;
/*     */     
/* 500 */     if (this.text.isEmpty()) {
/* 501 */       method_27535(matrices, this.client.field_1772, (class_2561)new class_2585("_"), getX() + 4, cursorY, -2039584);
/*     */       
/*     */       return;
/*     */     } 
/* 505 */     this.cursor.sanitize();
/*     */     
/* 507 */     String cursorLine = this.text.substring(this.firstCharacterIndex);
/* 508 */     int cursorX = getX() + 4 + this.client.field_1772.method_1727(cursorLine.substring(0, this.cursor.column - this.firstCharacterIndex));
/*     */     
/* 510 */     if (this.cursor.column - this.firstCharacterIndex < cursorLine.length()) {
/* 511 */       method_25294(matrices, cursorX - 1, cursorY - 1, cursorX, cursorY + 9, -2039584);
/*     */     } else {
/* 513 */       this.client.field_1772.method_1720(matrices, "_", cursorX, cursorY, -2039584);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public class Cursor
/*     */   {
/*     */     boolean main;
/*     */ 
/*     */     
/* 524 */     int column = 0;
/* 525 */     private int lastColumn = 0;
/*     */     
/*     */     public Cursor(boolean main) {
/* 528 */       this.main = main;
/*     */     }
/*     */     
/*     */     public void toStart() {
/* 532 */       this.lastColumn = this.column = 0;
/*     */     }
/*     */     
/*     */     public void moveRight() {
/* 536 */       move(1);
/*     */     }
/*     */     
/*     */     public void moveLeft() {
/* 540 */       move(-1);
/*     */     }
/*     */     
/*     */     public void move(int amount) {
/* 544 */       this.column += amount;
/*     */       
/* 546 */       if (this.column < 0) {
/* 547 */         toStart();
/* 548 */       } else if (this.column > SpruceTextFieldWidget.this.text.length()) {
/* 549 */         this.column = SpruceTextFieldWidget.this.text.length();
/*     */       } 
/*     */       
/* 552 */       this.lastColumn = this.column;
/*     */       
/* 554 */       if (amount < 0 && this.column <= SpruceTextFieldWidget.this.firstCharacterIndex) {
/* 555 */         SpruceTextFieldWidget.this.firstCharacterIndex = class_3532.method_15340(SpruceTextFieldWidget.this.firstCharacterIndex = this.column - 1, 0, SpruceTextFieldWidget.this.text.length());
/*     */       }
/*     */     }
/*     */     
/*     */     public void toEnd() {
/* 560 */       this.lastColumn = this.column = SpruceTextFieldWidget.this.text.length();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void copy(@NotNull Cursor cursor) {
/* 569 */       this.lastColumn = this.column = cursor.column;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void sanitize() {
/* 576 */       if (this.column < 0) {
/* 577 */         toStart();
/* 578 */       } else if (this.column > SpruceTextFieldWidget.this.text.length()) {
/* 579 */         this.column = SpruceTextFieldWidget.this.text.length();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isSame(@NotNull Cursor other) {
/* 589 */       return (this.column == other.column);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getPosition() {
/* 598 */       return this.column;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 603 */       return "SpruceTextAreaWidget$Cursor{main=" + this.main + ", column=" + this.column + ", lastColumn=" + this.lastColumn + "}";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class Selection
/*     */   {
/* 617 */     private SpruceTextFieldWidget.Cursor anchor = new SpruceTextFieldWidget.Cursor(false);
/* 618 */     private SpruceTextFieldWidget.Cursor follower = new SpruceTextFieldWidget.Cursor(false);
/*     */ 
/*     */     
/*     */     private boolean active = false;
/*     */ 
/*     */     
/*     */     public void selectAll() {
/* 625 */       this.anchor.toStart();
/* 626 */       SpruceTextFieldWidget.this.cursor.toEnd();
/* 627 */       this.follower.copy(SpruceTextFieldWidget.this.cursor);
/* 628 */       this.active = true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 635 */       this.anchor.toStart();
/* 636 */       this.follower.toStart();
/* 637 */       this.active = false;
/*     */     }
/*     */     
/*     */     public void tryStartSelection() {
/* 641 */       if (!this.active && class_437.method_25442()) {
/* 642 */         startSelection();
/*     */       }
/*     */     }
/*     */     
/*     */     public void startSelection() {
/* 647 */       this.anchor.copy(SpruceTextFieldWidget.this.cursor);
/* 648 */       this.follower.copy(SpruceTextFieldWidget.this.cursor);
/* 649 */       this.active = true;
/*     */     }
/*     */     
/*     */     public void moveToCursor() {
/* 653 */       if (!this.active) {
/*     */         return;
/*     */       }
/* 656 */       if (class_437.method_25442()) {
/* 657 */         this.follower.copy(SpruceTextFieldWidget.this.cursor);
/*     */       } else {
/* 659 */         cancel();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean erase() {
/* 669 */       if (!this.active) {
/* 670 */         return false;
/*     */       }
/* 672 */       SpruceTextFieldWidget.Cursor start = getStart();
/* 673 */       SpruceTextFieldWidget.Cursor end = getEnd();
/*     */       
/* 675 */       if (start.isSame(end)) {
/* 676 */         cancel();
/* 677 */         return false;
/*     */       } 
/*     */       
/* 680 */       if (start.column == 0 && end.column >= SpruceTextFieldWidget.this.text.length()) {
/* 681 */         SpruceTextFieldWidget.this.text = "";
/* 682 */         cancel();
/* 683 */         return true;
/*     */       } 
/*     */       
/* 686 */       String text = SpruceTextFieldWidget.this.getText();
/* 687 */       String newText = text.substring(0, start.getPosition()) + text.substring(end.getPosition());
/* 688 */       if (SpruceTextFieldWidget.this.textPredicate.test(newText)) {
/* 689 */         SpruceTextFieldWidget.this.text = newText;
/* 690 */         SpruceTextFieldWidget.this.onChanged();
/*     */       } 
/*     */       
/* 693 */       SpruceTextFieldWidget.this.cursor.copy(start);
/*     */       
/* 695 */       cancel();
/* 696 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @NotNull
/*     */     public String getSelectedText() {
/* 705 */       if (!this.active) {
/* 706 */         return "";
/*     */       }
/* 708 */       SpruceTextFieldWidget.Cursor start = getStart();
/* 709 */       SpruceTextFieldWidget.Cursor end = getEnd();
/*     */       
/* 711 */       if (start.isSame(end)) {
/* 712 */         return "";
/*     */       }
/* 714 */       return SpruceTextFieldWidget.this.getText().substring(start.getPosition(), end.getPosition());
/*     */     }
/*     */     @NotNull
/*     */     public SpruceTextFieldWidget.Cursor getStart() {
/* 718 */       return isInverted() ? this.follower : this.anchor;
/*     */     }
/*     */     @NotNull
/*     */     public SpruceTextFieldWidget.Cursor getEnd() {
/* 722 */       return isInverted() ? this.anchor : this.follower;
/*     */     }
/*     */     
/*     */     private boolean isInverted() {
/* 726 */       return (this.anchor.column > this.follower.column);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\widget\text\SpruceTextFieldWidget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */