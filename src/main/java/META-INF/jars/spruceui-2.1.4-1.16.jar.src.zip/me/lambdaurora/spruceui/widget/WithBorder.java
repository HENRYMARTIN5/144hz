/*    */ package me.lambdaurora.spruceui.widget;
/*    */ 
/*    */ import me.lambdaurora.spruceui.border.Border;
/*    */ import me.lambdaurora.spruceui.border.EmptyBorder;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface WithBorder
/*    */ {
/*    */   default boolean hasBorder() {
/* 30 */     return (getBorder().getThickness() != 0 && getBorder() != EmptyBorder.EMPTY_BORDER);
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   Border getBorder();
/*    */   
/*    */   void setBorder(@NotNull Border paramBorder);
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\widget\WithBorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */