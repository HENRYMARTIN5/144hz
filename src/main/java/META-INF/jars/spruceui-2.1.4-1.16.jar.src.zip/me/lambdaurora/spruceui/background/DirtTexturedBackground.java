/*    */ package me.lambdaurora.spruceui.background;
/*    */ 
/*    */ import me.lambdaurora.spruceui.util.RenderUtil;
/*    */ import me.lambdaurora.spruceui.widget.SpruceWidget;
/*    */ import net.minecraft.class_310;
/*    */ import net.minecraft.class_4587;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DirtTexturedBackground
/*    */   implements Background
/*    */ {
/* 18 */   public static final Background NORMAL = new DirtTexturedBackground(64, 64, 64, 255);
/* 19 */   public static final Background DARKENED = new DirtTexturedBackground(32, 32, 32, 255);
/*    */   
/* 21 */   private final class_310 client = class_310.method_1551();
/*    */   private final int red;
/*    */   private final int green;
/*    */   private final int blue;
/*    */   private final int alpha;
/*    */   
/*    */   public DirtTexturedBackground(int red, int green, int blue, int alpha) {
/* 28 */     this.red = red;
/* 29 */     this.green = green;
/* 30 */     this.blue = blue;
/* 31 */     this.alpha = alpha;
/*    */   }
/*    */ 
/*    */   
/*    */   public void render(class_4587 matrices, SpruceWidget widget, int vOffset, int mouseX, int mouseY, float delta) {
/* 36 */     RenderUtil.renderBackgroundTexture(this.client, widget.getX(), widget.getY(), widget.getWidth(), widget.getHeight(), vOffset / 32.0F, this.red, this.green, this.blue, this.alpha);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 42 */     return "DirtTexturedBackground{red=" + this.red + ", green=" + this.green + ", blue=" + this.blue + ", alpha=" + this.alpha + '}';
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\background\DirtTexturedBackground.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */