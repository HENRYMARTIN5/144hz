/*    */ package me.lambdaurora.spruceui.option;
/*    */ 
/*    */ import java.util.function.Consumer;
/*    */ import java.util.function.Supplier;
/*    */ import me.lambdaurora.spruceui.Position;
/*    */ import me.lambdaurora.spruceui.widget.SpruceWidget;
/*    */ import me.lambdaurora.spruceui.widget.text.SpruceNamedTextFieldWidget;
/*    */ import me.lambdaurora.spruceui.widget.text.SpruceTextFieldWidget;
/*    */ import net.minecraft.class_124;
/*    */ import net.minecraft.class_2561;
/*    */ import net.minecraft.class_2583;
/*    */ import net.minecraft.class_5481;
/*    */ import org.aperlambda.lambdacommon.utils.LambdaUtils;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpruceIntegerInputOption
/*    */   extends SpruceOption
/*    */ {
/*    */   private final Supplier<Integer> getter;
/*    */   private final Consumer<Integer> setter;
/*    */   
/*    */   public SpruceIntegerInputOption(String key, Supplier<Integer> getter, Consumer<Integer> setter, @Nullable class_2561 tooltip) {
/* 38 */     super(key);
/* 39 */     this.getter = getter;
/* 40 */     this.setter = setter;
/* 41 */     setTooltip(tooltip);
/*    */   }
/*    */ 
/*    */   
/*    */   public SpruceWidget createWidget(Position position, int width) {
/* 46 */     SpruceTextFieldWidget textField = new SpruceTextFieldWidget(position, width, 20, getPrefix());
/* 47 */     textField.setText(String.valueOf(get()));
/* 48 */     textField.setTextPredicate(SpruceTextFieldWidget.INTEGER_INPUT_PREDICATE);
/* 49 */     textField.setRenderTextProvider((displayedText, offset) -> {
/*    */           try {
/*    */             Integer.parseInt(textField.getText());
/*    */             return class_5481.method_30747(displayedText, class_2583.field_24360);
/* 53 */           } catch (NumberFormatException e) {
/*    */             return class_5481.method_30747(displayedText, class_2583.field_24360.method_10977(class_124.field_1061));
/*    */           } 
/*    */         });
/* 57 */     textField.setChangedListener(input -> {
/*    */           int value = LambdaUtils.parseIntFromString(input);
/*    */           set(value);
/*    */         });
/* 61 */     getOptionTooltip().ifPresent(textField::setTooltip);
/* 62 */     return (SpruceWidget)new SpruceNamedTextFieldWidget(textField);
/*    */   }
/*    */   
/*    */   public void set(int value) {
/* 66 */     this.setter.accept(Integer.valueOf(value));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int get() {
/* 75 */     return ((Integer)this.getter.get()).intValue();
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\option\SpruceIntegerInputOption.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */