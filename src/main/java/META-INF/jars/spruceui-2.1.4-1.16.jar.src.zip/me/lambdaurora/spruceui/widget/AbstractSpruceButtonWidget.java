/*     */ package me.lambdaurora.spruceui.widget;
/*     */ 
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import me.lambdaurora.spruceui.Position;
/*     */ import me.lambdaurora.spruceui.Tooltip;
/*     */ import me.lambdaurora.spruceui.Tooltipable;
/*     */ import me.lambdaurora.spruceui.wrapper.VanillaButtonWrapper;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_2588;
/*     */ import net.minecraft.class_339;
/*     */ import net.minecraft.class_3532;
/*     */ import net.minecraft.class_4587;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractSpruceButtonWidget
/*     */   extends AbstractSpruceWidget
/*     */   implements Tooltipable
/*     */ {
/*     */   private class_2561 message;
/*     */   private class_2561 tooltip;
/*     */   private int tooltipTicks;
/*     */   private long lastTick;
/*  41 */   protected float alpha = 1.0F;
/*     */   
/*     */   public AbstractSpruceButtonWidget(@NotNull Position position, int width, int height, @NotNull class_2561 message) {
/*  44 */     super(position);
/*  45 */     this.width = width;
/*  46 */     this.height = height;
/*  47 */     this.message = message;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public class_2561 getMessage() {
/*  56 */     return this.message;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMessage(@NotNull class_2561 message) {
/*  65 */     if (!Objects.equals(message.getString(), this.message.getString())) {
/*  66 */       queueNarration(250);
/*     */     }
/*     */     
/*  69 */     this.message = message;
/*     */   }
/*     */   
/*     */   public float getAlpha() {
/*  73 */     return this.alpha;
/*     */   }
/*     */   
/*     */   public void setAlpha(float value) {
/*  77 */     this.alpha = value;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Optional<class_2561> getTooltip() {
/*  82 */     return Optional.ofNullable(this.tooltip);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTooltip(@Nullable class_2561 tooltip) {
/*  87 */     this.tooltip = tooltip;
/*     */   }
/*     */   
/*     */   public VanillaButtonWrapper asVanilla() {
/*  91 */     return new VanillaButtonWrapper(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isValidClickButton(int button) {
/*  97 */     return (button == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onMouseClick(double mouseX, double mouseY, int button) {
/* 102 */     if (isValidClickButton(button)) {
/* 103 */       onClick(mouseX, mouseY);
/* 104 */       return true;
/*     */     } 
/* 106 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean onMouseRelease(double mouseX, double mouseY, int button) {
/* 111 */     if (isValidClickButton(button)) {
/* 112 */       onRelease(mouseX, mouseY);
/* 113 */       return true;
/*     */     } 
/* 115 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onMouseDrag(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
/* 120 */     if (isValidClickButton(button)) {
/* 121 */       onDrag(mouseX, mouseY, deltaX, deltaY);
/* 122 */       return true;
/*     */     } 
/* 124 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onClick(double mouseX, double mouseY) {}
/*     */ 
/*     */   
/*     */   protected void onRelease(double mouseX, double mouseY) {}
/*     */ 
/*     */   
/*     */   protected void onDrag(double mouseX, double mouseY, double deltaX, double deltaY) {}
/*     */ 
/*     */   
/*     */   protected int getVOffset() {
/* 139 */     if (!isActive())
/* 140 */       return 0; 
/* 141 */     return isFocusedOrHovered() ? 2 : 1;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void renderWidget(class_4587 matrices, int mouseX, int mouseY, float delta) {
/* 146 */     renderButton(matrices, mouseX, mouseY, delta);
/* 147 */     if (!this.dragging)
/* 148 */       Tooltip.queueFor(this, mouseX, mouseY, this.tooltipTicks, i -> this.tooltipTicks = i.intValue(), this.lastTick, i -> this.lastTick = i.longValue()); 
/*     */   }
/*     */   
/*     */   protected void renderButton(class_4587 matrices, int mouseX, int mouseY, float delta) {
/* 152 */     int color = this.active ? 16777215 : 10526880;
/* 153 */     method_27534(matrices, this.client.field_1772, getMessage(), getX() + getWidth() / 2, getY() + (getHeight() - 8) / 2, color | 
/* 154 */         class_3532.method_15386(this.alpha * 255.0F) << 24);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void renderBackground(class_4587 matrices, int mouseX, int mouseY, float delta) {
/* 159 */     this.client.method_1531().method_22813(class_339.field_22757);
/* 160 */     RenderSystem.color4f(1.0F, 1.0F, 1.0F, getAlpha());
/* 161 */     RenderSystem.enableBlend();
/* 162 */     RenderSystem.defaultBlendFunc();
/* 163 */     RenderSystem.enableDepthTest();
/* 164 */     int v = 46 + getVOffset() * 20;
/* 165 */     if (getWidth() / 2 < 200) {
/* 166 */       method_25302(matrices, 
/* 167 */           getX(), getY(), 0, v, 
/*     */           
/* 169 */           getWidth() / 2, getHeight());
/* 170 */       method_25302(matrices, 
/* 171 */           getX() + getWidth() / 2, getY(), 200 - 
/* 172 */           getWidth() / 2, v, 
/* 173 */           getWidth() / 2, getHeight());
/*     */     } else {
/* 175 */       int middleWidth = getWidth() - 100;
/* 176 */       method_25302(matrices, 
/* 177 */           getX(), getY(), 0, v, 50, 
/*     */           
/* 179 */           getHeight());
/*     */       
/*     */       int x;
/* 182 */       for (x = 50; x < middleWidth; x += 100) {
/* 183 */         method_25302(matrices, 
/* 184 */             getX() + x, getY(), 50, v, 100, 
/*     */             
/* 186 */             getHeight());
/*     */       }
/*     */       
/* 189 */       if (x - middleWidth > 0) {
/* 190 */         method_25302(matrices, 
/* 191 */             getX() + x, getY(), 50, v, x - middleWidth, 
/*     */             
/* 193 */             getHeight());
/*     */       }
/*     */       
/* 196 */       method_25302(matrices, 
/* 197 */           getX() + getWidth() - 50, getY(), 150, v, 50, 
/*     */           
/* 199 */           getHeight());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   protected Optional<class_2561> getNarrationMessage() {
/* 207 */     return (Optional)Optional.of(new class_2588("gui.narrate.button", new Object[] { getMessage() }));
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\widget\AbstractSpruceButtonWidget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */