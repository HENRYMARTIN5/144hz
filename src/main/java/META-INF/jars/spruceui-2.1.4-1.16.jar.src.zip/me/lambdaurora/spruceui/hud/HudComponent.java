/*    */ package me.lambdaurora.spruceui.hud;
/*    */ 
/*    */ import net.minecraft.class_332;
/*    */ import net.minecraft.class_4587;
/*    */ import org.aperlambda.lambdacommon.Identifier;
/*    */ import org.aperlambda.lambdacommon.utils.Identifiable;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class HudComponent
/*    */   extends class_332
/*    */   implements Identifiable
/*    */ {
/*    */   protected final Identifier identifier;
/*    */   protected boolean enabled = true;
/*    */   protected int x;
/*    */   protected int y;
/*    */   
/*    */   protected HudComponent(@NotNull Identifier identifier, int x, int y) {
/* 32 */     this.identifier = identifier;
/* 33 */     this.x = x;
/* 34 */     this.y = y;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getTranslationKey() {
/* 43 */     return this.identifier.getNamespace() + ".hud.component." + this.identifier.getName();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isEnabled() {
/* 52 */     return this.enabled;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setEnabled(boolean enabled) {
/* 61 */     this.enabled = enabled;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public abstract void render(class_4587 paramclass_4587, float paramFloat);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void tick() {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean hasTicks() {
/* 88 */     return false;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Identifier getIdentifier() {
/* 93 */     return this.identifier;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\hud\HudComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */