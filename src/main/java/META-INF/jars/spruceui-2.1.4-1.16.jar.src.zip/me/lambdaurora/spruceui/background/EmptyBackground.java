/*    */ package me.lambdaurora.spruceui.background;
/*    */ 
/*    */ import me.lambdaurora.spruceui.widget.SpruceWidget;
/*    */ import net.minecraft.class_4587;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class EmptyBackground
/*    */   implements Background
/*    */ {
/* 23 */   public static final EmptyBackground EMPTY_BACKGROUND = new EmptyBackground();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void render(class_4587 matrices, SpruceWidget widget, int vOffset, int mouseX, int mouseY, float delta) {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 35 */     return "EmptyBackground{}";
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\background\EmptyBackground.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */