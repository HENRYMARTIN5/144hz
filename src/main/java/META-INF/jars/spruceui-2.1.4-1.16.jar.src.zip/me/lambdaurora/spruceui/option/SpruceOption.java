/*    */ package me.lambdaurora.spruceui.option;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import java.util.Optional;
/*    */ import me.lambdaurora.spruceui.Position;
/*    */ import me.lambdaurora.spruceui.widget.SpruceWidget;
/*    */ import net.minecraft.class_1074;
/*    */ import net.minecraft.class_2561;
/*    */ import net.minecraft.class_2588;
/*    */ import org.aperlambda.lambdacommon.utils.Nameable;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class SpruceOption
/*    */   implements Nameable
/*    */ {
/*    */   public final String key;
/* 33 */   private Optional<class_2561> tooltip = Optional.empty();
/*    */   
/*    */   public SpruceOption(String key) {
/* 36 */     Objects.requireNonNull(key, "Cannot create an option without a key.");
/* 37 */     this.key = key;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public String getName() {
/* 42 */     return class_1074.method_4662(this.key, new Object[0]);
/*    */   }
/*    */   
/*    */   public Optional<class_2561> getOptionTooltip() {
/* 46 */     return this.tooltip;
/*    */   }
/*    */   
/*    */   public void setTooltip(@Nullable class_2561 tooltip) {
/* 50 */     this.tooltip = Optional.ofNullable(tooltip);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public class_2561 getPrefix() {
/* 59 */     return (class_2561)new class_2588(this.key);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public class_2561 getDisplayText(class_2561 value) {
/* 69 */     return (class_2561)new class_2588("spruceui.options.generic", new Object[] { getPrefix(), value });
/*    */   }
/*    */   
/*    */   public abstract SpruceWidget createWidget(Position paramPosition, int paramInt);
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\option\SpruceOption.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */