/*     */ package me.lambdaurora.spruceui.option;
/*     */ 
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import me.lambdaurora.spruceui.Position;
/*     */ import me.lambdaurora.spruceui.SpruceTexts;
/*     */ import me.lambdaurora.spruceui.widget.SpruceButtonWidget;
/*     */ import me.lambdaurora.spruceui.widget.SpruceWidget;
/*     */ import net.minecraft.class_124;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_5250;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpruceBooleanOption
/*     */   extends SpruceOption
/*     */ {
/*     */   private final Supplier<Boolean> getter;
/*     */   private final Consumer<Boolean> setter;
/*     */   private final boolean colored;
/*     */   
/*     */   public SpruceBooleanOption(String key, Supplier<Boolean> getter, Consumer<Boolean> setter, @Nullable class_2561 tooltip) {
/*  39 */     this(key, getter, setter, tooltip, false);
/*     */   }
/*     */   
/*     */   public SpruceBooleanOption(String key, Supplier<Boolean> getter, Consumer<Boolean> setter, @Nullable class_2561 tooltip, boolean colored) {
/*  43 */     super(key);
/*  44 */     this.getter = getter;
/*  45 */     this.setter = setter;
/*  46 */     this.colored = colored;
/*  47 */     setTooltip(tooltip);
/*     */   }
/*     */   
/*     */   public void set(@NotNull String value) {
/*  51 */     set("true".equals(value));
/*     */   }
/*     */   
/*     */   public void set() {
/*  55 */     set(!get());
/*     */   }
/*     */   
/*     */   private void set(boolean value) {
/*  59 */     this.setter.accept(Boolean.valueOf(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean get() {
/*  68 */     return ((Boolean)this.getter.get()).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isColored() {
/*  77 */     return this.colored;
/*     */   }
/*     */ 
/*     */   
/*     */   public SpruceWidget createWidget(Position position, int width) {
/*  82 */     SpruceButtonWidget button = new SpruceButtonWidget(position, width, 20, getDisplayText(), btn -> {
/*     */           set();
/*     */           btn.setMessage(getDisplayText());
/*     */         });
/*  86 */     getOptionTooltip().ifPresent(button::setTooltip);
/*  87 */     return (SpruceWidget)button;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class_2561 getDisplayText() {
/*     */     class_5250 class_5250;
/*  96 */     boolean value = get();
/*  97 */     class_2561 toggleText = SpruceTexts.getToggleText(value);
/*  98 */     if (this.colored)
/*  99 */       class_5250 = toggleText.method_27662().method_10862(toggleText.method_10866().method_10977(value ? class_124.field_1060 : class_124.field_1061)); 
/* 100 */     return getDisplayText((class_2561)class_5250);
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\option\SpruceBooleanOption.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */