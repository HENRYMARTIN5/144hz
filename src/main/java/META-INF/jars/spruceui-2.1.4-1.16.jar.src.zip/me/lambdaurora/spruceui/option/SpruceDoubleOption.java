/*     */ package me.lambdaurora.spruceui.option;
/*     */ 
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import me.lambdaurora.spruceui.Position;
/*     */ import me.lambdaurora.spruceui.widget.SpruceWidget;
/*     */ import me.lambdaurora.spruceui.widget.option.SpruceOptionSliderWidget;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_3532;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpruceDoubleOption
/*     */   extends SpruceOption
/*     */ {
/*     */   protected final float step;
/*     */   protected final double min;
/*     */   protected double max;
/*     */   private final Supplier<Double> getter;
/*     */   private final Consumer<Double> setter;
/*     */   private final Function<SpruceDoubleOption, class_2561> displayStringGetter;
/*     */   
/*     */   public SpruceDoubleOption(String key, double min, double max, float step, Supplier<Double> getter, Consumer<Double> setter, Function<SpruceDoubleOption, class_2561> displayStringGetter, @Nullable class_2561 tooltip) {
/*  41 */     super(key);
/*  42 */     this.min = min;
/*  43 */     this.max = max;
/*  44 */     this.step = step;
/*  45 */     this.getter = getter;
/*  46 */     this.setter = setter;
/*  47 */     this.displayStringGetter = displayStringGetter;
/*  48 */     setTooltip(tooltip);
/*     */   }
/*     */ 
/*     */   
/*     */   public SpruceWidget createWidget(Position position, int width) {
/*  53 */     SpruceOptionSliderWidget slider = new SpruceOptionSliderWidget(position, width, 20, this);
/*  54 */     getOptionTooltip().ifPresent(slider::setTooltip);
/*  55 */     return (SpruceWidget)slider;
/*     */   }
/*     */   
/*     */   public double getRatio(double value) {
/*  59 */     return class_3532.method_15350((adjust(value) - this.min) / (this.max - this.min), 0.0D, 1.0D);
/*     */   }
/*     */   
/*     */   public double getValue(double ratio) {
/*  63 */     return adjust(class_3532.method_16436(class_3532.method_15350(ratio, 0.0D, 1.0D), this.min, this.max));
/*     */   }
/*     */   
/*     */   private double adjust(double value) {
/*  67 */     if (this.step > 0.0F) {
/*  68 */       value = (this.step * (float)Math.round(value / this.step));
/*     */     }
/*     */     
/*  71 */     return class_3532.method_15350(value, this.min, this.max);
/*     */   }
/*     */   
/*     */   public double getMin() {
/*  75 */     return this.min;
/*     */   }
/*     */   
/*     */   public double getMax() {
/*  79 */     return this.max;
/*     */   }
/*     */   
/*     */   public void setMax(float max) {
/*  83 */     this.max = max;
/*     */   }
/*     */   
/*     */   public void set(double value) {
/*  87 */     this.setter.accept(Double.valueOf(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double get() {
/*  96 */     return ((Double)this.getter.get()).doubleValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class_2561 getDisplayString() {
/* 105 */     return this.displayStringGetter.apply(this);
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\option\SpruceDoubleOption.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */