/*     */ package me.lambdaurora.spruceui.screen;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.Optional;
/*     */ import java.util.function.BooleanSupplier;
/*     */ import java.util.function.Supplier;
/*     */ import me.lambdaurora.spruceui.SprucePositioned;
/*     */ import me.lambdaurora.spruceui.Tooltip;
/*     */ import me.lambdaurora.spruceui.navigation.NavigationDirection;
/*     */ import me.lambdaurora.spruceui.util.ScissorManager;
/*     */ import me.lambdaurora.spruceui.widget.SpruceElement;
/*     */ import me.lambdaurora.spruceui.widget.SpruceWidget;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_364;
/*     */ import net.minecraft.class_4068;
/*     */ import net.minecraft.class_437;
/*     */ import net.minecraft.class_4587;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SpruceScreen
/*     */   extends class_437
/*     */   implements SprucePositioned, SpruceElement
/*     */ {
/*     */   protected double scaleFactor;
/*     */   
/*     */   protected SpruceScreen(@NotNull class_2561 title) {
/*  43 */     super(title);
/*     */   }
/*     */ 
/*     */   
/*     */   public void method_25395(class_364 focused) {
/*  48 */     class_364 old = method_25399();
/*  49 */     if (old == focused)
/*  50 */       return;  if (old instanceof SpruceWidget)
/*  51 */       ((SpruceWidget)old).setFocused(false); 
/*  52 */     super.method_25395(focused);
/*  53 */     if (focused instanceof SpruceWidget) {
/*  54 */       ((SpruceWidget)focused).setFocused(true);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void method_25426() {
/*  59 */     this.scaleFactor = this.field_22787.method_22683().method_4495();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean method_25404(int keyCode, int scanCode, int modifiers) {
/*  66 */     Optional<NavigationDirection> direction = NavigationDirection.fromKey(keyCode, class_437.method_25442());
/*  67 */     return ((Boolean)direction.<Boolean>map(dir -> Boolean.valueOf(onNavigation(dir, (keyCode == 258))))
/*  68 */       .orElseGet(() -> Boolean.valueOf(super.method_25404(keyCode, scanCode, modifiers)))).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean onNavigation(@NotNull NavigationDirection direction, boolean tab) {
/*  75 */     if (requiresCursor()) return false; 
/*  76 */     class_364 focused = method_25399();
/*  77 */     boolean isNonNull = (focused != null);
/*  78 */     if (!isNonNull || !tryNavigating(focused, direction, tab)) {
/*  79 */       int next; class_364 nextElement; List<? extends class_364> list = method_25396();
/*  80 */       int i = list.indexOf(focused);
/*     */       
/*  82 */       if (isNonNull && i >= 0) { next = i + (direction.isLookingForward() ? 1 : 0); }
/*  83 */       else if (direction.isLookingForward()) { next = 0; }
/*  84 */       else { next = list.size(); }
/*     */       
/*  86 */       ListIterator<? extends class_364> iterator = list.listIterator(next);
/*  87 */       BooleanSupplier hasNext = direction.isLookingForward() ? iterator::hasNext : iterator::hasPrevious;
/*  88 */       Supplier<class_364> nextGetter = direction.isLookingForward() ? iterator::next : iterator::previous;
/*     */ 
/*     */       
/*     */       do {
/*  92 */         if (!hasNext.getAsBoolean()) {
/*  93 */           method_25395((class_364)null);
/*  94 */           return false;
/*     */         } 
/*     */         
/*  97 */         nextElement = nextGetter.get();
/*  98 */       } while (!tryNavigating(nextElement, direction, tab));
/*     */       
/* 100 */       method_25395(nextElement);
/*     */     } 
/* 102 */     return true;
/*     */   }
/*     */   
/*     */   private boolean tryNavigating(@NotNull class_364 element, @NotNull NavigationDirection direction, boolean tab) {
/* 106 */     if (element instanceof SpruceElement) {
/* 107 */       return ((SpruceElement)element).onNavigation(direction, tab);
/*     */     }
/* 109 */     return element.method_25407(direction.isLookingForward());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void method_25394(class_4587 matrices, int mouseX, int mouseY, float delta) {
/* 116 */     ScissorManager.pushScaleFactor(this.scaleFactor);
/* 117 */     method_25420(matrices);
/* 118 */     renderWidgets(matrices, mouseX, mouseY, delta);
/* 119 */     renderTitle(matrices, mouseX, mouseY, delta);
/* 120 */     Tooltip.renderAll(this, matrices);
/* 121 */     ScissorManager.popScaleFactor();
/*     */   }
/*     */ 
/*     */   
/*     */   public void renderTitle(class_4587 matrices, int mouseX, int mouseY, float delta) {}
/*     */   
/*     */   public void renderWidgets(class_4587 matrices, int mouseX, int mouseY, float delta) {
/* 128 */     for (class_364 element : method_25396()) {
/* 129 */       if (element instanceof class_4068)
/* 130 */         ((class_4068)element).method_25394(matrices, mouseX, mouseY, delta); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\screen\SpruceScreen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */