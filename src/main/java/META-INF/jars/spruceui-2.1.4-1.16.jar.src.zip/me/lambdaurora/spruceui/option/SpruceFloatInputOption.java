/*    */ package me.lambdaurora.spruceui.option;
/*    */ 
/*    */ import java.util.function.Consumer;
/*    */ import java.util.function.Supplier;
/*    */ import me.lambdaurora.spruceui.Position;
/*    */ import me.lambdaurora.spruceui.widget.SpruceWidget;
/*    */ import me.lambdaurora.spruceui.widget.text.SpruceNamedTextFieldWidget;
/*    */ import me.lambdaurora.spruceui.widget.text.SpruceTextFieldWidget;
/*    */ import net.minecraft.class_124;
/*    */ import net.minecraft.class_2561;
/*    */ import net.minecraft.class_2583;
/*    */ import net.minecraft.class_5481;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpruceFloatInputOption
/*    */   extends SpruceOption
/*    */ {
/*    */   private final Supplier<Float> getter;
/*    */   private final Consumer<Float> setter;
/*    */   
/*    */   public SpruceFloatInputOption(String key, Supplier<Float> getter, Consumer<Float> setter, @Nullable class_2561 tooltip) {
/* 37 */     super(key);
/* 38 */     this.getter = getter;
/* 39 */     this.setter = setter;
/* 40 */     setTooltip(tooltip);
/*    */   }
/*    */ 
/*    */   
/*    */   public SpruceWidget createWidget(Position position, int width) {
/* 45 */     SpruceTextFieldWidget textField = new SpruceTextFieldWidget(position, width, 20, getPrefix());
/* 46 */     textField.setText(String.valueOf(get()));
/* 47 */     textField.setTextPredicate(SpruceTextFieldWidget.FLOAT_INPUT_PREDICATE);
/* 48 */     textField.setRenderTextProvider((displayedText, offset) -> {
/*    */           try {
/*    */             Float.parseFloat(textField.getText());
/*    */             return class_5481.method_30747(displayedText, class_2583.field_24360);
/* 52 */           } catch (NumberFormatException e) {
/*    */             return class_5481.method_30747(displayedText, class_2583.field_24360.method_10977(class_124.field_1061));
/*    */           } 
/*    */         });
/* 56 */     textField.setChangedListener(input -> {
/*    */           float value;
/*    */           try {
/*    */             value = Float.parseFloat(input);
/* 60 */           } catch (NumberFormatException e) {
/*    */             value = 0.0F;
/*    */           } 
/*    */           set(value);
/*    */         });
/* 65 */     getOptionTooltip().ifPresent(textField::setTooltip);
/* 66 */     return (SpruceWidget)new SpruceNamedTextFieldWidget(textField);
/*    */   }
/*    */   
/*    */   public void set(float value) {
/* 70 */     this.setter.accept(Float.valueOf(value));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public float get() {
/* 79 */     return ((Float)this.getter.get()).floatValue();
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\option\SpruceFloatInputOption.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */