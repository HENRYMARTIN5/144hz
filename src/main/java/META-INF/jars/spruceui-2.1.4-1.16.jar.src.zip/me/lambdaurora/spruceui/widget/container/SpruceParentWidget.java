/*    */ package me.lambdaurora.spruceui.widget.container;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.Optional;
/*    */ import me.lambdaurora.spruceui.navigation.NavigationDirection;
/*    */ import me.lambdaurora.spruceui.navigation.NavigationUtils;
/*    */ import me.lambdaurora.spruceui.widget.SpruceWidget;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface SpruceParentWidget<E extends SpruceWidget>
/*    */   extends SpruceWidget
/*    */ {
/*    */   List<E> children();
/*    */   
/*    */   @Nullable
/*    */   E getFocused();
/*    */   
/*    */   void setFocused(@Nullable E paramE);
/*    */   
/*    */   default Optional<E> hoveredElement(double mouseX, double mouseY) {
/*    */     SpruceWidget spruceWidget;
/* 37 */     Iterator<E> it = children().iterator();
/*    */ 
/*    */     
/*    */     do {
/* 41 */       if (!it.hasNext()) {
/* 42 */         return Optional.empty();
/*    */       }
/*    */       
/* 45 */       spruceWidget = (SpruceWidget)it.next();
/* 46 */     } while (!spruceWidget.method_25405(mouseX, mouseY));
/*    */     
/* 48 */     return Optional.of((E)spruceWidget);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default boolean onNavigation(@NotNull NavigationDirection direction, boolean tab) {
/* 55 */     if (requiresCursor()) return false; 
/* 56 */     boolean result = NavigationUtils.tryNavigate(direction, tab, children(), (SpruceWidget)getFocused(), this::setFocused, false);
/* 57 */     if (result)
/* 58 */       setFocused(true); 
/* 59 */     return result;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\widget\container\SpruceParentWidget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */