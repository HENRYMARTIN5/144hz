/*     */ package me.lambdaurora.spruceui.widget.text;
/*     */ 
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import me.lambdaurora.spruceui.Position;
/*     */ import me.lambdaurora.spruceui.border.Border;
/*     */ import me.lambdaurora.spruceui.navigation.NavigationDirection;
/*     */ import me.lambdaurora.spruceui.util.MultilineText;
/*     */ import net.minecraft.class_155;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_2585;
/*     */ import net.minecraft.class_287;
/*     */ import net.minecraft.class_289;
/*     */ import net.minecraft.class_290;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_327;
/*     */ import net.minecraft.class_3532;
/*     */ import net.minecraft.class_437;
/*     */ import net.minecraft.class_4493;
/*     */ import net.minecraft.class_4587;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpruceTextAreaWidget
/*     */   extends AbstractSpruceTextInputWidget
/*     */ {
/*     */   private final class_327 textRenderer;
/*     */   private final MultilineText lines;
/*  47 */   private final Cursor cursor = new Cursor(true);
/*  48 */   private final Selection selection = new Selection();
/*  49 */   private int firstLine = 0;
/*     */   private int displayedLines;
/*     */   
/*     */   public SpruceTextAreaWidget(@NotNull Position position, int width, int height, class_2561 title) {
/*  53 */     super(position, width, height, title);
/*  54 */     this.textRenderer = this.client.field_1772;
/*  55 */     this.textRenderer.getClass(); this.displayedLines = getInnerHeight() / 9;
/*  56 */     this.lines = new MultilineText(getInnerWidth());
/*  57 */     this.cursor.toStart();
/*  58 */     sanitize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public List<String> getLines() {
/*  67 */     return this.lines.getLines();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLines(@NotNull List<String> lines) {
/*  76 */     this.lines.setLines(lines);
/*  77 */     this.selection.active = false;
/*  78 */     setCursorToEnd();
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public String getText() {
/*  83 */     return this.lines.getText();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setText(@Nullable String text) {
/*  88 */     this.lines.clear();
/*  89 */     if (text != null) {
/*  90 */       this.lines.setText(text);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/*  97 */     this.lines.clear();
/*  98 */     sanitize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEditable() {
/* 107 */     return isActive();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEditable(boolean editable) {
/* 117 */     setActive(editable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDisplayedLines(int lines) {
/* 126 */     if (lines <= 0)
/* 127 */       lines = 1; 
/* 128 */     this.displayedLines = lines;
/*     */     
/* 130 */     this.cursor.adjustFirstLine();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBorder(@NotNull Border border) {
/* 135 */     super.setBorder(border);
/* 136 */     this.lines.setWidth(getInnerWidth());
/* 137 */     sanitize();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCursorToStart() {
/* 142 */     this.cursor.toStart();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCursorToEnd() {
/* 147 */     this.cursor.toEnd();
/*     */   }
/*     */   private void insertCharacter(char character) {
/*     */     String newText;
/* 151 */     if (this.lines.isEmpty()) {
/* 152 */       this.lines.add(String.valueOf(character));
/* 153 */       setCursorToStart();
/*     */       return;
/*     */     } 
/* 156 */     this.selection.erase();
/*     */ 
/*     */     
/* 159 */     if (character == '\n') {
/*     */       String line;
/* 161 */       if (this.cursor.row == this.lines.size() - 1 && (line = this.lines.get(this.cursor.row)) != null && this.cursor.column >= line.length() - 1) {
/* 162 */         int currentRow = this.cursor.row;
/* 163 */         if (!line.endsWith("\n"))
/* 164 */           this.lines.replaceRow(currentRow, s -> s + "\n"); 
/* 165 */         this.lines.add(currentRow + 1, "");
/* 166 */         this.cursor.moveDown();
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 171 */     String text = getText();
/* 172 */     int cursorPosition = this.cursor.getPosition();
/* 173 */     int oldSize = this.lines.size();
/*     */ 
/*     */     
/* 176 */     if (cursorPosition >= text.length()) {
/* 177 */       newText = text + character;
/*     */     } else {
/* 179 */       newText = text.substring(0, cursorPosition) + character + text.substring(cursorPosition);
/*     */     } 
/*     */     
/* 182 */     this.lines.clear();
/* 183 */     this.lines.add(newText);
/*     */     
/* 185 */     if (character == '\n') {
/* 186 */       this.cursor.moveRight();
/*     */     } else {
/*     */       
/* 189 */       this.cursor.moveRight();
/* 190 */       if (oldSize + 1 == this.lines.size())
/* 191 */         this.cursor.moveRight(); 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void eraseCharacter() {
/* 196 */     if (this.selection.erase()) {
/* 197 */       sanitize();
/*     */       
/*     */       return;
/*     */     } 
/* 201 */     String line = this.lines.get(this.cursor.row);
/*     */     
/* 203 */     if ((line.isEmpty() || line.equals("\n")) && this.lines.size() != 1) {
/* 204 */       this.lines.remove(this.cursor.row);
/* 205 */       this.cursor.moveUp();
/* 206 */       this.cursor.toRowEnd();
/*     */       
/*     */       return;
/*     */     } 
/* 210 */     if (this.cursor.column == 0 && this.cursor.row == 0) {
/*     */       return;
/*     */     }
/* 213 */     String text = getText();
/* 214 */     int cursorPosition = this.cursor.getPosition();
/* 215 */     this.cursor.moveLeft();
/* 216 */     this.lines.clear();
/* 217 */     this.lines.add(text.substring(0, cursorPosition - 1) + text.substring(cursorPosition));
/* 218 */     sanitize();
/*     */   }
/*     */   
/*     */   private void removeCharacterForward() {
/* 222 */     if (this.selection.erase()) {
/* 223 */       sanitize();
/*     */       
/*     */       return;
/*     */     } 
/* 227 */     String line = this.lines.get(this.cursor.row);
/*     */     
/* 229 */     if (line.isEmpty()) {
/* 230 */       int row = this.cursor.row;
/* 231 */       if (row >= this.lines.size() - 1)
/*     */         return; 
/* 233 */       this.lines.remove(row);
/* 234 */       sanitize();
/*     */       
/*     */       return;
/*     */     } 
/* 238 */     if (this.cursor.column >= line.length() && this.cursor.row == this.lines.size() - 1) {
/*     */       return;
/*     */     }
/* 241 */     String text = getText();
/* 242 */     int cursorPosition = this.cursor.getPosition();
/*     */     
/* 244 */     String newText = text.substring(0, cursorPosition) + text.substring(cursorPosition + 1);
/* 245 */     this.lines.clear();
/* 246 */     this.lines.add(newText);
/* 247 */     sanitize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(@NotNull String text) {
/*     */     String newText;
/* 256 */     if (text.isEmpty()) {
/*     */       return;
/*     */     }
/* 259 */     if (this.lines.isEmpty()) {
/* 260 */       this.lines.add(text);
/* 261 */       this.cursor.toEnd();
/*     */       return;
/*     */     } 
/* 264 */     this.selection.erase();
/*     */     
/* 266 */     int oldSize = this.lines.size();
/*     */     
/* 268 */     String whole = getText();
/* 269 */     int position = this.cursor.getPosition();
/*     */ 
/*     */     
/* 272 */     if (position >= whole.length()) {
/* 273 */       newText = whole + text;
/*     */     } else {
/* 275 */       newText = whole.substring(0, position) + text + whole.substring(position);
/*     */     } 
/*     */     
/* 278 */     this.lines.clear();
/* 279 */     this.lines.setLines(Arrays.asList(newText.split("\n")));
/*     */     
/* 281 */     for (int i = 0; i < text.length(); i++) {
/* 282 */       if (text.charAt(i) == '\n')
/* 283 */         this.cursor.moveRight(); 
/* 284 */       this.cursor.moveRight();
/*     */     } 
/* 286 */     if (oldSize < this.lines.size()) this.cursor.moveRight(); 
/*     */   }
/*     */   
/*     */   protected boolean doesLineOccupyFullSpace(@NotNull String cursorLine) {
/* 290 */     return (this.textRenderer.method_1727(cursorLine) >= getInnerWidth());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void sanitize() {
/* 295 */     if (this.lines.isEmpty())
/* 296 */       this.lines.add(""); 
/* 297 */     this.cursor.sanitize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean onNavigation(@NotNull NavigationDirection direction, boolean tab) {
/* 304 */     if (requiresCursor()) return false; 
/* 305 */     if (!tab) {
/* 306 */       setFocused(true);
/* 307 */       boolean result = false;
/* 308 */       switch (direction) {
/*     */         case RIGHT:
/* 310 */           result = onSelectionUpdate(this.cursor::moveRight);
/*     */           break;
/*     */         case LEFT:
/* 313 */           result = onSelectionUpdate(this.cursor::moveLeft);
/*     */           break;
/*     */         case UP:
/* 316 */           result = onSelectionUpdate(this.cursor::moveUp);
/*     */           break;
/*     */         case DOWN:
/* 319 */           result = onSelectionUpdate(this.cursor::moveDown);
/*     */           break;
/*     */       } 
/* 322 */       if (result)
/* 323 */         return true; 
/*     */     } 
/* 325 */     return super.onNavigation(direction, tab);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean onCharTyped(char chr, int keyCode) {
/* 332 */     if (!isEditorActive() || !class_155.method_643(chr)) {
/* 333 */       return false;
/*     */     }
/* 335 */     if (isEditable()) {
/* 336 */       insertCharacter(chr);
/* 337 */       this.selection.cancel();
/*     */     } 
/* 339 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onKeyPress(int keyCode, int scanCode, int modifiers) {
/* 344 */     if (!isEditorActive()) {
/* 345 */       return false;
/*     */     }
/* 347 */     if (class_437.method_25439(keyCode)) {
/* 348 */       this.selection.selectAll();
/* 349 */       return true;
/* 350 */     }  if (class_437.method_25437(keyCode)) {
/* 351 */       write((class_310.method_1551()).field_1774.method_1460());
/* 352 */       return true;
/* 353 */     }  if (class_437.method_25438(keyCode) || class_437.method_25436(keyCode)) {
/* 354 */       String selected = this.selection.getSelectedText();
/* 355 */       if (!selected.isEmpty())
/* 356 */         (class_310.method_1551()).field_1774.method_1455(selected); 
/* 357 */       if (class_437.method_25436(keyCode) && isEditable()) {
/* 358 */         this.selection.erase();
/* 359 */         sanitize();
/*     */       } 
/* 361 */       return true;
/*     */     } 
/*     */     
/* 364 */     switch (keyCode) {
/*     */       case 262:
/* 366 */         return onSelectionUpdate(this.cursor::moveRight);
/*     */       case 263:
/* 368 */         return onSelectionUpdate(this.cursor::moveLeft);
/*     */       case 265:
/* 370 */         return onSelectionUpdate(this.cursor::moveUp);
/*     */       case 264:
/* 372 */         return onSelectionUpdate(this.cursor::moveDown);
/*     */       case 269:
/* 374 */         return onSelectionUpdate(class_437.method_25441() ? this.cursor::toEnd : this.cursor::toRowEnd);
/*     */       case 268:
/* 376 */         return onSelectionUpdate(class_437.method_25441() ? this.cursor::toStart : this.cursor::toLineStart);
/*     */       case 266:
/* 378 */         return onSelectionUpdate(() -> this.cursor.moveVertical(-this.cursor.row));
/*     */       case 267:
/* 380 */         return onSelectionUpdate(() -> this.cursor.moveVertical(this.lines.size() - this.cursor.row));
/*     */       case 257:
/*     */       case 335:
/* 383 */         if (isEditable())
/* 384 */           insertCharacter('\n'); 
/* 385 */         return true;
/*     */       case 259:
/* 387 */         if (isEditable())
/* 388 */           eraseCharacter(); 
/* 389 */         return true;
/*     */       case 261:
/* 391 */         if (isEditable())
/* 392 */           removeCharacterForward(); 
/* 393 */         return true;
/*     */       case 68:
/* 395 */         if (class_437.method_25441() && isEditable() && !this.lines.isEmpty()) {
/* 396 */           this.lines.remove(this.cursor.row);
/* 397 */           sanitize();
/*     */         } 
/* 399 */         return true;
/*     */     } 
/* 401 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean onSelectionUpdate(@NotNull Runnable action) {
/* 406 */     this.selection.tryStartSelection();
/* 407 */     action.run();
/* 408 */     this.selection.moveToCursor();
/* 409 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onMouseClick(double mouseX, double mouseY, int button) {
/* 414 */     if (button == 0) {
/* 415 */       int x = class_3532.method_15357(mouseX) - getX() - 4;
/* 416 */       int y = class_3532.method_15357(mouseY) - getY() - 4;
/*     */       
/* 418 */       setFocused(true);
/*     */       
/* 420 */       int row = this.firstLine + y / 9;
/* 421 */       if (row >= this.lines.size()) {
/* 422 */         this.cursor.toEnd();
/* 423 */         return true;
/* 424 */       }  if (row < 0) {
/* 425 */         this.cursor.toStart();
/* 426 */         return true;
/*     */       } 
/*     */       
/* 429 */       onSelectionUpdate(() -> {
/*     */             this.cursor.row = row;
/*     */             
/*     */             this.cursor.lastColumn = this.cursor.column = this.textRenderer.method_27523(this.lines.get(row), x).length();
/*     */           });
/*     */       
/* 435 */       return true;
/*     */     } 
/*     */     
/* 438 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onMouseScroll(double mouseX, double mouseY, double amount) {
/* 443 */     if (!isEditorActive()) {
/* 444 */       return false;
/*     */     }
/*     */     
/* 447 */     if (amount > 0.0D) {
/* 448 */       this.cursor.moveUp();
/*     */     } else {
/* 450 */       this.cursor.moveDown();
/*     */     } 
/* 452 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void renderWidget(class_4587 matrices, int mouseX, int mouseY, float delta) {
/* 459 */     super.renderWidget(matrices, mouseX, mouseY, delta);
/*     */     
/* 461 */     drawText(matrices);
/* 462 */     drawCursor(matrices);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void drawText(@NotNull class_4587 matrices) {
/* 471 */     int length = Math.min(this.lines.size(), this.displayedLines);
/*     */     
/* 473 */     int textColor = getTextColor();
/* 474 */     int textX = getX() + 4;
/*     */     
/* 476 */     int lineY = getY() + 4;
/* 477 */     for (int row = this.firstLine; row < this.firstLine + length; row++) {
/* 478 */       String line = this.lines.get(row);
/* 479 */       if (line != null) {
/*     */         
/* 481 */         if (line.endsWith("\n")) line = line.substring(0, line.length() - 1);
/*     */         
/* 483 */         method_27535(matrices, this.textRenderer, (class_2561)new class_2585(line), textX, lineY, textColor);
/* 484 */         drawSelection(matrices, line, lineY, row);
/*     */         
/* 486 */         this.textRenderer.getClass(); lineY += 9;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void drawSelection(@NotNull class_4587 matrices, @NotNull String line, int lineY, int row) {
/*     */     int startIndex, endIndex;
/* 499 */     if (!isFocused())
/*     */       return; 
/* 501 */     if (!this.selection.isRowSelected(row)) {
/*     */       return;
/*     */     }
/*     */     
/* 505 */     if ((this.selection.getStart()).row != row) { startIndex = 0; }
/* 506 */     else { startIndex = (this.selection.getStart()).column; }
/*     */ 
/*     */     
/* 509 */     if ((this.selection.getEnd()).row != row) { endIndex = line.length(); }
/* 510 */     else { endIndex = (this.selection.getEnd()).column; }
/*     */     
/* 512 */     if (endIndex >= line.length()) {
/* 513 */       endIndex = line.length();
/*     */     }
/* 515 */     if (startIndex >= line.length() || startIndex == endIndex) {
/*     */       return;
/*     */     }
/* 518 */     int x = getX() + 4 + this.textRenderer.method_1727(line.substring(0, startIndex));
/* 519 */     String selected = line.substring(startIndex, endIndex);
/*     */     
/* 521 */     int x2 = x + this.textRenderer.method_1727(selected);
/* 522 */     this.textRenderer.getClass(); int y2 = lineY + 9;
/*     */     
/* 524 */     class_289 tessellator = class_289.method_1348();
/* 525 */     class_287 buffer = tessellator.method_1349();
/* 526 */     RenderSystem.color4f(0.0F, 0.0F, 255.0F, 255.0F);
/* 527 */     RenderSystem.disableTexture();
/* 528 */     RenderSystem.enableColorLogicOp();
/* 529 */     RenderSystem.logicOp(class_4493.class_1030.field_5110);
/* 530 */     buffer.method_1328(7, class_290.field_1592);
/* 531 */     buffer.method_22912(x, y2, 0.0D).method_1344();
/* 532 */     buffer.method_22912(x2, y2, 0.0D).method_1344();
/* 533 */     buffer.method_22912(x2, lineY, 0.0D).method_1344();
/* 534 */     buffer.method_22912(x, lineY, 0.0D).method_1344();
/* 535 */     tessellator.method_1350();
/* 536 */     RenderSystem.disableColorLogicOp();
/* 537 */     RenderSystem.enableTexture();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void drawCursor(@NotNull class_4587 matrices) {
/* 546 */     if (!isFocused())
/*     */       return; 
/* 548 */     if (this.lines.isEmpty()) {
/* 549 */       method_27535(matrices, this.textRenderer, (class_2561)new class_2585("_"), getX(), getY() + 4, -2039584);
/*     */       
/*     */       return;
/*     */     } 
/* 553 */     this.cursor.sanitize();
/*     */     
/* 555 */     int actualRow = this.cursor.row - this.firstLine;
/* 556 */     String cursorLine = this.lines.get(this.cursor.row);
/* 557 */     int cursorX = getX() + 4 + this.textRenderer.method_1727(cursorLine.substring(0, this.cursor.column));
/* 558 */     this.textRenderer.getClass(); int cursorY = getY() + 4 + actualRow * 9;
/*     */     
/* 560 */     if (this.cursor.row < this.lines.size() - 1 || this.cursor.column < cursorLine.length() || doesLineOccupyFullSpace(cursorLine)) {
/* 561 */       method_25294(matrices, cursorX - 1, cursorY - 1, cursorX, cursorY + 9, -2039584);
/*     */     } else {
/* 563 */       this.textRenderer.method_1720(matrices, "_", cursorX, cursorY, -2039584);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public class Cursor
/*     */   {
/*     */     boolean main;
/*     */ 
/*     */     
/* 574 */     int row = 0;
/* 575 */     int column = 0;
/* 576 */     private int lastColumn = 0;
/*     */     
/*     */     public Cursor(boolean main) {
/* 579 */       this.main = main;
/*     */     }
/*     */     
/*     */     public void toLineStart() {
/* 583 */       this.lastColumn = this.column = 0;
/*     */     }
/*     */     
/*     */     public void resetRow() {
/* 587 */       this.row = 0;
/*     */     }
/*     */     
/*     */     public void moveRight() {
/* 591 */       moveHorizontal(1);
/*     */     }
/*     */     
/*     */     public void moveLeft() {
/* 595 */       moveHorizontal(-1);
/*     */     }
/*     */     
/*     */     public void moveUp() {
/* 599 */       moveVertical(-1);
/*     */     }
/*     */     
/*     */     public void moveDown() {
/* 603 */       moveVertical(1);
/*     */     }
/*     */     
/*     */     public void moveHorizontal(int amount) {
/* 607 */       this.column += amount;
/*     */       
/* 609 */       if (this.row >= SpruceTextAreaWidget.this.lines.size()) {
/* 610 */         this.row = SpruceTextAreaWidget.this.lines.size() - 1;
/* 611 */         this.column = SpruceTextAreaWidget.this.lines.get(this.row).length();
/*     */       } 
/* 613 */       if (this.column < 0) {
/* 614 */         if (this.row == 0) { toLineStart(); }
/*     */         else
/* 616 */         { this.row--;
/* 617 */           this.column = SpruceTextAreaWidget.this.lines.get(this.row).length(); }
/*     */       
/*     */       }
/*     */       
/* 621 */       String line = SpruceTextAreaWidget.this.lines.get(this.row);
/* 622 */       if (line.endsWith("\n")) line = line.substring(0, line.length() - 1);
/*     */       
/* 624 */       if (this.column > line.length()) {
/* 625 */         if (amount > 0 && this.row != SpruceTextAreaWidget.this.lines.size() - 1) {
/* 626 */           this.column = 0;
/* 627 */           this.row++;
/*     */         } else {
/* 629 */           this.column = line.length();
/*     */         } 
/*     */       }
/* 632 */       this.lastColumn = this.column;
/*     */       
/* 634 */       adjustFirstLine();
/*     */     }
/*     */     
/*     */     public void moveVertical(int amount) {
/* 638 */       this.row += amount;
/* 639 */       this.column = this.lastColumn;
/* 640 */       sanitize();
/*     */       
/* 642 */       adjustFirstLine();
/*     */     }
/*     */     
/*     */     public void toStart() {
/* 646 */       resetRow();
/* 647 */       toLineStart();
/* 648 */       adjustFirstLine();
/*     */     }
/*     */     
/*     */     public void toEnd() {
/* 652 */       this.row = Math.max(0, SpruceTextAreaWidget.this.lines.size() - 1);
/* 653 */       String line = SpruceTextAreaWidget.this.lines.get(this.row);
/* 654 */       if (line == null) {
/* 655 */         this.lastColumn = this.column = 0;
/* 656 */       } else if (line.endsWith("\n")) {
/* 657 */         this.lastColumn = this.column = line.length() - 1;
/*     */       } else {
/* 659 */         this.lastColumn = this.column = line.length();
/* 660 */       }  adjustFirstLine();
/*     */     }
/*     */     
/*     */     public void toRowEnd() {
/* 664 */       String line = SpruceTextAreaWidget.this.lines.get(this.row);
/* 665 */       if (line == null) {
/* 666 */         this.lastColumn = this.column = 0;
/* 667 */       } else if (line.endsWith("\n")) {
/* 668 */         this.lastColumn = this.column = line.length() - 1;
/*     */       } else {
/* 670 */         this.lastColumn = this.column = line.length();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void copy(@NotNull Cursor cursor) {
/* 679 */       this.row = cursor.row;
/* 680 */       this.lastColumn = this.column = cursor.column;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void sanitize() {
/* 687 */       if (SpruceTextAreaWidget.this.lines.size() <= this.row)
/* 688 */         this.row = SpruceTextAreaWidget.this.lines.size() - 1; 
/* 689 */       if (this.row < 0) {
/* 690 */         resetRow();
/*     */       }
/* 692 */       String line = SpruceTextAreaWidget.this.lines.get(this.row);
/* 693 */       if (line.endsWith("\n")) line = line.substring(0, line.length() - 1); 
/* 694 */       if (this.column > line.length()) {
/* 695 */         this.column = line.length();
/*     */       }
/* 697 */       adjustFirstLine();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isSame(@NotNull Cursor other) {
/* 707 */       return (this.row == other.row && this.column == other.column);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getPosition() {
/* 716 */       int position = 0; int i;
/* 717 */       for (i = 0; i < this.row; ) { position += SpruceTextAreaWidget.this.lines.get(i).length(); i++; }
/* 718 */        for (i = 0; i < this.column; ) { position++; i++; }
/* 719 */        return position;
/*     */     }
/*     */     
/*     */     private void adjustFirstLine() {
/* 723 */       if (!this.main) {
/*     */         return;
/*     */       }
/* 726 */       if (SpruceTextAreaWidget.this.firstLine > this.row) {
/* 727 */         SpruceTextAreaWidget.this.firstLine = this.row;
/*     */       }
/* 729 */       if (SpruceTextAreaWidget.this.firstLine == SpruceTextAreaWidget.this.lines.size())
/* 730 */         SpruceTextAreaWidget.this.firstLine--; 
/* 731 */       int endLine = SpruceTextAreaWidget.this.firstLine + SpruceTextAreaWidget.this.displayedLines - 1;
/* 732 */       if (endLine >= SpruceTextAreaWidget.this.lines.size()) {
/* 733 */         SpruceTextAreaWidget.this.firstLine = SpruceTextAreaWidget.this.lines.size() - SpruceTextAreaWidget.this.displayedLines - 1;
/*     */       }
/*     */       
/* 736 */       if (this.row >= SpruceTextAreaWidget.this.firstLine + SpruceTextAreaWidget.this.displayedLines) {
/* 737 */         SpruceTextAreaWidget.this.firstLine = this.row - SpruceTextAreaWidget.this.displayedLines + 1;
/*     */       }
/* 739 */       if (SpruceTextAreaWidget.this.firstLine < 0) {
/* 740 */         SpruceTextAreaWidget.this.firstLine = 0;
/*     */       }
/*     */     }
/*     */     
/*     */     public String toString() {
/* 745 */       return "SpruceTextAreaWidget$Cursor{main=" + this.main + ", row=" + this.row + ", column=" + this.column + ", lastColumn=" + this.lastColumn + "}";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class Selection
/*     */   {
/* 760 */     private SpruceTextAreaWidget.Cursor anchor = new SpruceTextAreaWidget.Cursor(false);
/* 761 */     private SpruceTextAreaWidget.Cursor follower = new SpruceTextAreaWidget.Cursor(false);
/*     */ 
/*     */     
/*     */     private boolean active = false;
/*     */ 
/*     */     
/*     */     public void selectAll() {
/* 768 */       this.anchor.toStart();
/* 769 */       SpruceTextAreaWidget.this.cursor.toEnd();
/* 770 */       this.follower.copy(SpruceTextAreaWidget.this.cursor);
/* 771 */       this.active = true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 778 */       this.anchor.toStart();
/* 779 */       this.follower.toStart();
/* 780 */       this.active = false;
/*     */     }
/*     */     
/*     */     public void tryStartSelection() {
/* 784 */       if (!this.active && class_437.method_25442()) {
/* 785 */         startSelection();
/*     */       }
/*     */     }
/*     */     
/*     */     public void startSelection() {
/* 790 */       this.anchor.copy(SpruceTextAreaWidget.this.cursor);
/* 791 */       this.follower.copy(SpruceTextAreaWidget.this.cursor);
/* 792 */       this.active = true;
/*     */     }
/*     */     
/*     */     public boolean isRowSelected(int row) {
/* 796 */       return (this.active && (getStart()).row <= row && row <= (getEnd()).row);
/*     */     }
/*     */     
/*     */     public void moveToCursor() {
/* 800 */       if (!this.active) {
/*     */         return;
/*     */       }
/* 803 */       if (class_437.method_25442()) {
/* 804 */         this.follower.copy(SpruceTextAreaWidget.this.cursor);
/*     */       } else {
/* 806 */         cancel();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean erase() {
/* 816 */       if (!this.active) {
/* 817 */         return false;
/*     */       }
/* 819 */       SpruceTextAreaWidget.Cursor start = getStart();
/* 820 */       SpruceTextAreaWidget.Cursor end = getEnd();
/*     */       
/* 822 */       if (start.isSame(end)) {
/* 823 */         cancel();
/* 824 */         return false;
/*     */       } 
/*     */       
/* 827 */       if (start.row == 0 && start.column == 0 && end.row == SpruceTextAreaWidget.this.lines.size() - 1 && end.column >= SpruceTextAreaWidget.this.lines.get(SpruceTextAreaWidget.this.lines.size() - 1).length()) {
/* 828 */         SpruceTextAreaWidget.this.lines.clear();
/* 829 */         SpruceTextAreaWidget.this.lines.add("");
/* 830 */         cancel();
/* 831 */         return true;
/*     */       } 
/*     */       
/* 834 */       if (start.row == end.row) {
/* 835 */         String line = SpruceTextAreaWidget.this.lines.get(start.row);
/*     */         
/* 837 */         if (start.column == 0 && end.column >= line.length()) {
/* 838 */           SpruceTextAreaWidget.this.lines.remove(start.row);
/*     */         } else {
/* 840 */           SpruceTextAreaWidget.this.lines.replaceRow(start.row, line.substring(0, start.column) + line.substring(end.column));
/*     */         } 
/* 842 */         SpruceTextAreaWidget.this.cursor.copy(start);
/* 843 */         cancel();
/* 844 */         return true;
/*     */       } 
/*     */       
/* 847 */       String text = SpruceTextAreaWidget.this.getText();
/* 848 */       String newText = text.substring(0, start.getPosition()) + text.substring(end.getPosition());
/*     */       
/* 850 */       SpruceTextAreaWidget.this.lines.clear();
/* 851 */       SpruceTextAreaWidget.this.lines.add(newText);
/*     */       
/* 853 */       SpruceTextAreaWidget.this.cursor.copy(start);
/*     */       
/* 855 */       cancel();
/* 856 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @NotNull
/*     */     public String getSelectedText() {
/* 865 */       if (!this.active) {
/* 866 */         return "";
/*     */       }
/* 868 */       SpruceTextAreaWidget.Cursor start = getStart();
/* 869 */       SpruceTextAreaWidget.Cursor end = getEnd();
/*     */       
/* 871 */       if (start.isSame(end)) {
/* 872 */         return "";
/*     */       }
/* 874 */       if (start.row == end.row) {
/* 875 */         return SpruceTextAreaWidget.this.lines.get(start.row).substring(start.column, end.column);
/*     */       }
/* 877 */       return SpruceTextAreaWidget.this.getText().substring(start.getPosition(), end.getPosition());
/*     */     }
/*     */     @NotNull
/*     */     public SpruceTextAreaWidget.Cursor getStart() {
/* 881 */       return isInverted() ? this.follower : this.anchor;
/*     */     }
/*     */     @NotNull
/*     */     public SpruceTextAreaWidget.Cursor getEnd() {
/* 885 */       return isInverted() ? this.anchor : this.follower;
/*     */     }
/*     */     
/*     */     private boolean isInverted() {
/* 889 */       return (this.anchor.row > this.follower.row || (this.anchor.row == this.follower.row && this.anchor.column > this.follower.column));
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\widget\text\SpruceTextAreaWidget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */