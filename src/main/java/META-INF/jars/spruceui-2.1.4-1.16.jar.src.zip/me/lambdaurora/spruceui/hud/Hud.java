/*     */ package me.lambdaurora.spruceui.hud;
/*     */ 
/*     */ import com.google.common.collect.ImmutableList;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.class_2960;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_332;
/*     */ import net.minecraft.class_4587;
/*     */ import org.aperlambda.lambdacommon.Identifier;
/*     */ import org.aperlambda.lambdacommon.utils.Identifiable;
/*     */ import org.aperlambda.lambdacommon.utils.function.Predicates;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Hud
/*     */   extends class_332
/*     */   implements Identifiable
/*     */ {
/*     */   protected final Identifier identifier;
/*  33 */   protected final List<HudComponent> components = new ArrayList<>();
/*     */   private boolean enabled = true;
/*     */   protected boolean visible = true;
/*     */   
/*     */   public Hud(@NotNull Identifier identifier) {
/*  38 */     this.identifier = identifier;
/*     */   }
/*     */   
/*     */   public Hud(@NotNull class_2960 identifier) {
/*  42 */     this(new Identifier(identifier.toString()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTranslationKey() {
/*  51 */     return this.identifier.getNamespace() + ".hud." + this.identifier.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled() {
/*  60 */     return this.enabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnabled(boolean enabled) {
/*  69 */     this.enabled = enabled;
/*  70 */     if (enabled) {
/*  71 */       class_310 client = class_310.method_1551();
/*  72 */       init(client, client.method_22683().method_4486(), client.method_22683().method_4502());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isVisible() {
/*  82 */     return this.visible;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVisible(boolean visible) {
/*  91 */     this.visible = visible;
/*     */   }
/*     */   
/*     */   public void init(@NotNull class_310 client, int screenWidth, int screenHeight) {
/*  95 */     this.components.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void render(class_4587 matrices, float tickDelta) {
/* 105 */     this.components.stream().filter(HudComponent::isEnabled).forEach(component -> component.render(matrices, tickDelta));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void tick() {
/* 115 */     this.components.stream().filter(Predicates.and(HudComponent::hasTicks, HudComponent::isEnabled)).forEach(HudComponent::tick);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasTicks() {
/* 125 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public List<HudComponent> getComponents() {
/* 134 */     return (List<HudComponent>)ImmutableList.copyOf(this.components);
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Identifier getIdentifier() {
/* 139 */     return this.identifier;
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\hud\Hud.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */