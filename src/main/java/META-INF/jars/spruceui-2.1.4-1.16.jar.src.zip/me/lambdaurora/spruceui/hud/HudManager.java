/*     */ package me.lambdaurora.spruceui.hud;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Optional;
/*     */ import me.lambdaurora.spruceui.event.OpenScreenCallback;
/*     */ import me.lambdaurora.spruceui.event.ResolutionChangeCallback;
/*     */ import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
/*     */ import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_437;
/*     */ import net.minecraft.class_4587;
/*     */ import org.aperlambda.lambdacommon.Identifier;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HudManager
/*     */ {
/*  32 */   private static final HashMap<Identifier, Hud> HUDS = new HashMap<>();
/*     */   
/*     */   public void initialize() {
/*  35 */     HudRenderCallback.EVENT.register((matrices, tickDelta) -> HUDS.forEach(()));
/*     */ 
/*     */ 
/*     */     
/*  39 */     ClientTickEvents.END_CLIENT_TICK.register(client -> {
/*     */           if (!canRenderHuds(client)) {
/*     */             return;
/*     */           }
/*     */           
/*     */           HUDS.forEach(());
/*     */         });
/*     */     
/*  47 */     OpenScreenCallback.EVENT.register((client, screen) -> initAll(client, client.method_22683().method_4486(), client.method_22683().method_4502()));
/*  48 */     ResolutionChangeCallback.EVENT.register(client -> initAll(client, client.method_22683().method_4486(), client.method_22683().method_4502()));
/*     */   }
/*     */   
/*     */   protected static void initAll(@NotNull class_310 client, int screenWidth, int screenHeight) {
/*  52 */     if (!canRenderHuds(client))
/*     */       return; 
/*  54 */     HUDS.forEach((id, hud) -> {
/*     */           if (hud.isEnabled()) {
/*     */             hud.init(client, screenWidth, screenHeight);
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void register(@NotNull Hud hud) {
/*  66 */     if (HUDS.containsKey(hud.getIdentifier()))
/*  67 */       throw new IllegalArgumentException("Cannot register the same HUD twice!"); 
/*  68 */     HUDS.put(hud.getIdentifier(), hud);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void unregister(@NotNull Identifier identifier) {
/*  77 */     HUDS.remove(identifier);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void unregister(@NotNull Hud hud) {
/*  86 */     unregister(hud.getIdentifier());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean canRenderHuds(@NotNull class_310 client) {
/*  96 */     return (client.field_1687 != null && (!client.field_1690.field_1842 || client.field_1755 != null));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Optional<Hud> getHud(@NotNull Identifier identifier) {
/* 106 */     return Optional.ofNullable(HUDS.get(identifier));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Collection<Hud> getHuds() {
/* 115 */     return HUDS.values();
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\hud\HudManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */