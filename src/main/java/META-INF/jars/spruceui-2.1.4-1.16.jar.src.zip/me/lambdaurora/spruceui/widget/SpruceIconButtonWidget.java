/*    */ package me.lambdaurora.spruceui.widget;
/*    */ 
/*    */ import me.lambdaurora.spruceui.Position;
/*    */ import net.minecraft.class_2561;
/*    */ import net.minecraft.class_4587;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpruceIconButtonWidget
/*    */   extends AbstractSpruceIconButtonWidget
/*    */ {
/*    */   public SpruceIconButtonWidget(Position position, int width, int height, class_2561 message, SpruceButtonWidget.PressAction action) {
/* 18 */     super(position, width, height, message, action);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected int renderIcon(class_4587 matrices, int mouseX, int mouseY, float delta) {
/* 27 */     return 0;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\widget\SpruceIconButtonWidget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */