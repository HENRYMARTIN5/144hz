/*    */ package me.lambdaurora.spruceui.widget;
/*    */ 
/*    */ import com.mojang.blaze3d.systems.RenderSystem;
/*    */ import me.lambdaurora.spruceui.Position;
/*    */ import net.minecraft.class_2477;
/*    */ import net.minecraft.class_2561;
/*    */ import net.minecraft.class_2960;
/*    */ import net.minecraft.class_3532;
/*    */ import net.minecraft.class_4493;
/*    */ import net.minecraft.class_4587;
/*    */ import net.minecraft.class_5348;
/*    */ import net.minecraft.class_5481;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpruceToggleSwitch
/*    */   extends AbstractSpruceBooleanButtonWidget
/*    */ {
/* 31 */   private static final class_2960 TEXTURE = new class_2960("spruceui", "textures/gui/toggle_switch.png");
/*    */   
/*    */   public SpruceToggleSwitch(@NotNull Position position, int width, int height, @NotNull class_2561 message, boolean value) {
/* 34 */     super(position, width, height, message, value);
/*    */   }
/*    */   
/*    */   public SpruceToggleSwitch(@NotNull Position position, int width, int height, @NotNull class_2561 message, boolean value, boolean showMessage) {
/* 38 */     super(position, width, height, message, value, showMessage);
/*    */   }
/*    */   
/*    */   public SpruceToggleSwitch(@NotNull Position position, int width, int height, @NotNull class_2561 message, @NotNull AbstractSpruceBooleanButtonWidget.PressAction action, boolean value) {
/* 42 */     super(position, width, height, message, action, value);
/*    */   }
/*    */   
/*    */   public SpruceToggleSwitch(@NotNull Position position, int width, int height, @NotNull class_2561 message, @NotNull AbstractSpruceBooleanButtonWidget.PressAction action, boolean value, boolean showMessage) {
/* 46 */     super(position, width, height, message, action, value, showMessage);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void renderButton(class_4587 matrices, int mouseX, int mouseY, float delta) {
/* 51 */     RenderSystem.enableDepthTest();
/* 52 */     RenderSystem.enableBlend();
/* 53 */     RenderSystem.defaultBlendFunc();
/* 54 */     RenderSystem.blendFunc(class_4493.class_4535.field_22541, class_4493.class_4534.field_22523);
/* 55 */     method_25290(matrices, getX() + (getValue() ? 14 : 0), getY() + getHeight() / 2 - 9, getValue() ? 50.0F : 32.0F, isFocusedOrHovered() ? 18.0F : 0.0F, 18, 18, 68, 36);
/*    */ 
/*    */     
/* 58 */     if (this.showMessage) {
/* 59 */       class_5481 message = class_2477.method_10517().method_30934(this.client.field_1772.method_1714((class_5348)getMessage(), getWidth() - 40));
/* 60 */       this.client.field_1772.method_27517(matrices, message, (getX() + 36), getY() + (getHeight() - 8) / 2.0F, 0xE0E0E0 | 
/* 61 */           class_3532.method_15386(this.alpha * 255.0F) << 24);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   protected void renderBackground(class_4587 matrices, int mouseX, int mouseY, float delta) {
/* 67 */     this.client.method_1531().method_22813(TEXTURE);
/* 68 */     RenderSystem.enableDepthTest();
/* 69 */     RenderSystem.color4f(1.0F, 1.0F, 1.0F, this.alpha);
/* 70 */     RenderSystem.enableBlend();
/* 71 */     RenderSystem.defaultBlendFunc();
/* 72 */     RenderSystem.blendFunc(class_4493.class_4535.field_22541, class_4493.class_4534.field_22523);
/* 73 */     method_25290(matrices, getX(), getY() + getHeight() / 2 - 9, 0.0F, isFocusedOrHovered() ? 18.0F : 0.0F, 32, 18, 68, 36);
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\widget\SpruceToggleSwitch.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */