/*    */ package me.lambdaurora.spruceui.widget;
/*    */ 
/*    */ import me.lambdaurora.spruceui.Position;
/*    */ import net.minecraft.class_2561;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpruceButtonWidget
/*    */   extends AbstractSprucePressableButtonWidget
/*    */ {
/*    */   private PressAction action;
/*    */   
/*    */   public SpruceButtonWidget(Position position, int width, int height, class_2561 message, PressAction action) {
/* 26 */     super(position, width, height, message);
/* 27 */     this.action = action;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onPress() {
/* 32 */     this.action.onPress(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 37 */     return getClass().getSimpleName() + '{' + "position=" + 
/* 38 */       getPosition() + ", width=" + 
/* 39 */       getWidth() + ", height=" + 
/* 40 */       getHeight() + ", visible=" + 
/* 41 */       isVisible() + ", active=" + 
/* 42 */       isActive() + ", message=" + 
/* 43 */       getMessage() + ", focused=" + 
/* 44 */       isFocused() + ", hovered=" + 
/* 45 */       isMouseHovered() + ", wasHovered=" + this.wasHovered + ", dragging=" + this.dragging + ", lastDrag=" + this.lastDrag + ", alpha=" + 
/*    */ 
/*    */ 
/*    */       
/* 49 */       getAlpha() + '}';
/*    */   }
/*    */   
/*    */   public static interface PressAction {
/*    */     void onPress(SpruceButtonWidget param1SpruceButtonWidget);
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\widget\SpruceButtonWidget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */