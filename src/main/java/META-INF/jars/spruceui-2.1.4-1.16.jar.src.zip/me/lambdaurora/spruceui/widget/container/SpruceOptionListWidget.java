/*     */ package me.lambdaurora.spruceui.widget.container;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import me.lambdaurora.spruceui.Position;
/*     */ import me.lambdaurora.spruceui.SprucePositioned;
/*     */ import me.lambdaurora.spruceui.navigation.NavigationDirection;
/*     */ import me.lambdaurora.spruceui.navigation.NavigationUtils;
/*     */ import me.lambdaurora.spruceui.option.SpruceOption;
/*     */ import me.lambdaurora.spruceui.widget.SpruceWidget;
/*     */ import net.minecraft.class_4587;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpruceOptionListWidget
/*     */   extends SpruceEntryListWidget<SpruceOptionListWidget.OptionEntry>
/*     */ {
/*  36 */   private int lastIndex = 0;
/*     */   
/*     */   public SpruceOptionListWidget(@NotNull Position position, int width, int height) {
/*  39 */     super(position, width, height, 4, OptionEntry.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int addSingleOptionEntry(SpruceOption option) {
/*  49 */     return addEntry(OptionEntry.create(this, option, false));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int addSmallSingleOptionEntry(SpruceOption option) {
/*  59 */     return addEntry(OptionEntry.create(this, option, true));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addOptionEntry(SpruceOption firstOption, @Nullable SpruceOption secondOption) {
/*  71 */     addEntry(OptionEntry.create(this, firstOption, secondOption));
/*     */   }
/*     */   
/*     */   public void addAll(SpruceOption[] options) {
/*  75 */     for (int i = 0; i < options.length; i += 2)
/*  76 */       addOptionEntry(options[i], (i < options.length - 1) ? options[i + 1] : null); 
/*     */   }
/*     */   
/*     */   public static class OptionEntry
/*     */     extends SpruceEntryListWidget.Entry implements SpruceParentWidget<SpruceWidget> {
/*  81 */     private final List<SpruceWidget> children = new ArrayList<>();
/*     */     
/*     */     private final SpruceOptionListWidget parent;
/*     */ 
/*     */     
/*     */     private OptionEntry(SpruceOptionListWidget parent) {
/*  87 */       this.parent = parent;
/*     */     } @Nullable
/*     */     private SpruceWidget focused; private boolean dragging;
/*     */     public static OptionEntry create(SpruceOptionListWidget parent, SpruceOption option, boolean small) {
/*  91 */       OptionEntry entry = new OptionEntry(parent);
/*  92 */       entry.children.add(option.createWidget(Position.of((SprucePositioned)entry, entry.getWidth() / 2 - (small ? 75 : 155), 2), small ? 150 : 310));
/*  93 */       return entry;
/*     */     }
/*     */     
/*     */     public static OptionEntry create(SpruceOptionListWidget parent, SpruceOption firstOption, @Nullable SpruceOption secondOption) {
/*  97 */       OptionEntry entry = new OptionEntry(parent);
/*  98 */       entry.children.add(firstOption.createWidget(Position.of((SprucePositioned)entry, entry.getWidth() / 2 - 155, 2), 150));
/*  99 */       if (secondOption != null) {
/* 100 */         entry.children.add(secondOption.createWidget(Position.of((SprucePositioned)entry, entry.getWidth() / 2 - 155 + 160, 2), 150));
/*     */       }
/* 102 */       return entry;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getWidth() {
/* 107 */       return this.parent.getWidth() - this.parent.getBorder().getThickness() * 2;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getHeight() {
/* 112 */       return this.children.stream().mapToInt(SpruceWidget::getHeight).reduce(Integer::max).orElse(0) + 4;
/*     */     }
/*     */ 
/*     */     
/*     */     public List<SpruceWidget> children() {
/* 117 */       return this.children;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public SpruceWidget getFocused() {
/* 122 */       return this.focused;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setFocused(@Nullable SpruceWidget focused) {
/* 127 */       if (this.focused == focused)
/*     */         return; 
/* 129 */       if (this.focused != null)
/* 130 */         this.focused.setFocused(false); 
/* 131 */       this.focused = focused;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setFocused(boolean focused) {
/* 136 */       super.setFocused(focused);
/* 137 */       if (!focused) {
/* 138 */         setFocused((SpruceWidget)null);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected boolean onMouseClick(double mouseX, double mouseY, int button) {
/*     */       SpruceWidget element;
/* 146 */       Iterator<SpruceWidget> it = children().iterator();
/*     */ 
/*     */       
/*     */       do {
/* 150 */         if (!it.hasNext()) {
/* 151 */           return false;
/*     */         }
/*     */         
/* 154 */         element = it.next();
/* 155 */       } while (!element.method_25402(mouseX, mouseY, button));
/*     */       
/* 157 */       setFocused(element);
/* 158 */       if (button == 0) {
/* 159 */         this.dragging = true;
/*     */       }
/* 161 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean onMouseRelease(double mouseX, double mouseY, int button) {
/* 166 */       this.dragging = false;
/* 167 */       return hoveredElement(mouseX, mouseY).filter(element -> element.method_25406(mouseX, mouseY, button)).isPresent();
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean onMouseDrag(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
/* 172 */       return (getFocused() != null && this.dragging && button == 0 && 
/* 173 */         getFocused().method_25403(mouseX, mouseY, button, deltaX, deltaY));
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean onKeyPress(int keyCode, int scanCode, int modifiers) {
/* 178 */       return (this.focused != null && this.focused.method_25404(keyCode, scanCode, modifiers));
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean onKeyRelease(int keyCode, int scanCode, int modifiers) {
/* 183 */       return (this.focused != null && this.focused.method_16803(keyCode, scanCode, modifiers));
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean onCharTyped(char chr, int keyCode) {
/* 188 */       return (this.focused != null && this.focused.method_25400(chr, keyCode));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void renderWidget(class_4587 matrices, int mouseX, int mouseY, float delta) {
/* 195 */       this.children.forEach(widget -> widget.method_25394(matrices, mouseX, mouseY, delta));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean onNavigation(@NotNull NavigationDirection direction, boolean tab) {
/* 202 */       if (requiresCursor()) return false; 
/* 203 */       if (!tab && direction.isVertical()) {
/* 204 */         if (isFocused()) {
/* 205 */           setFocused((SpruceWidget)null);
/* 206 */           return false;
/*     */         } 
/* 208 */         int lastIndex = this.parent.lastIndex;
/* 209 */         if (lastIndex >= this.children.size())
/* 210 */           lastIndex = this.children.size() - 1; 
/* 211 */         if (!((SpruceWidget)this.children.get(lastIndex)).onNavigation(direction, tab))
/* 212 */           return false; 
/* 213 */         setFocused(this.children.get(lastIndex));
/* 214 */         return true;
/*     */       } 
/*     */       
/* 217 */       boolean result = NavigationUtils.tryNavigate(direction, tab, this.children, this.focused, this::setFocused, true);
/* 218 */       if (result) {
/* 219 */         setFocused(true);
/* 220 */         if (direction.isHorizontal() && getFocused() != null) {
/* 221 */           this.parent.lastIndex = this.children.indexOf(getFocused());
/*     */         }
/*     */       } 
/* 224 */       return result;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\widget\container\SpruceOptionListWidget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */