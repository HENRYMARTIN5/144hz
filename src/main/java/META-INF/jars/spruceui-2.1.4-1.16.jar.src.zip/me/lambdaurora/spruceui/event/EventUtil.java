/*    */ package me.lambdaurora.spruceui.event;
/*    */ 
/*    */ import net.fabricmc.fabric.api.event.Event;
/*    */ import net.fabricmc.fabric.api.event.EventFactory;
/*    */ import net.minecraft.class_310;
/*    */ import net.minecraft.class_437;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class EventUtil
/*    */ {
/*    */   private EventUtil() {
/* 24 */     throw new UnsupportedOperationException("EventUtil is a singleton.");
/*    */   }
/*    */   
/*    */   static Event<OpenScreenCallback> makeOpenScreenEvent() {
/* 28 */     return EventFactory.createArrayBacked(OpenScreenCallback.class, listeners -> ());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void onOpenScreen(OpenScreenCallback pre, OpenScreenCallback post) {
/* 42 */     OpenScreenCallback.PRE.register(pre);
/* 43 */     OpenScreenCallback.EVENT.register(post);
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\event\EventUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */