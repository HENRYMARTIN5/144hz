/*    */ package me.lambdaurora.spruceui.option;
/*    */ 
/*    */ import me.lambdaurora.spruceui.Position;
/*    */ import me.lambdaurora.spruceui.widget.SpruceSeparatorWidget;
/*    */ import me.lambdaurora.spruceui.widget.SpruceWidget;
/*    */ import net.minecraft.class_2561;
/*    */ import net.minecraft.class_2588;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpruceSeparatorOption
/*    */   extends SpruceOption
/*    */ {
/*    */   private final boolean showTitle;
/*    */   
/*    */   public SpruceSeparatorOption(String key, boolean showTitle, @Nullable class_2561 tooltip) {
/* 30 */     super(key);
/* 31 */     this.showTitle = showTitle;
/* 32 */     setTooltip(tooltip);
/*    */   }
/*    */ 
/*    */   
/*    */   public SpruceWidget createWidget(Position position, int width) {
/* 37 */     SpruceSeparatorWidget separator = new SpruceSeparatorWidget(position, width, this.showTitle ? (class_2561)new class_2588(this.key) : null);
/* 38 */     getOptionTooltip().ifPresent(separator::setTooltip);
/* 39 */     return (SpruceWidget)separator;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\option\SpruceSeparatorOption.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */