/*     */ package me.lambdaurora.spruceui.util;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.function.Function;
/*     */ import net.minecraft.class_310;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MultilineText
/*     */ {
/*  30 */   private final List<String> rows = new ArrayList<>();
/*     */   private int width;
/*     */   
/*     */   public MultilineText(int width) {
/*  34 */     this.width = width;
/*     */   }
/*     */   
/*     */   public MultilineText(int width, @Nullable String text) {
/*  38 */     this(width);
/*  39 */     if (text == null)
/*     */       return; 
/*  41 */     this.rows.addAll(wrap(text, width));
/*     */   }
/*     */   
/*     */   public MultilineText(int width, @NotNull Collection<? extends String> lines) {
/*  45 */     this(width);
/*  46 */     this.rows.addAll(wrap(lines, width));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getWidth() {
/*  55 */     return this.width;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWidth(int width) {
/*  64 */     if (this.width != width) {
/*  65 */       this.width = width;
/*  66 */       recompute();
/*     */     } 
/*     */   }
/*     */   @NotNull
/*     */   public List<String> getRows() {
/*  71 */     return this.rows;
/*     */   }
/*     */   @NotNull
/*     */   public List<String> getLines() {
/*  75 */     List<String> lines = new ArrayList<>();
/*     */     
/*  77 */     StringBuilder stringBuilder = new StringBuilder();
/*  78 */     for (String row : this.rows) {
/*  79 */       stringBuilder.append(row.replace("\n", ""));
/*  80 */       if (row.endsWith("\n")) {
/*  81 */         lines.add(stringBuilder.toString());
/*  82 */         stringBuilder = new StringBuilder();
/*     */       } 
/*     */     } 
/*     */     
/*  86 */     return lines;
/*     */   }
/*     */   
/*     */   public void setLines(Collection<? extends String> lines) {
/*  90 */     clear();
/*  91 */     addAll(wrap(lines, this.width));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public String getText() {
/* 100 */     StringBuilder builder = new StringBuilder();
/* 101 */     for (String row : this.rows)
/* 102 */       builder.append(row); 
/* 103 */     return builder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setText(@NotNull String text) {
/* 112 */     clear();
/* 113 */     add(text);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void recompute() {
/* 120 */     String text = getText();
/* 121 */     clear();
/* 122 */     add(text);
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/* 126 */     return this.rows.isEmpty();
/*     */   }
/*     */   
/*     */   public int size() {
/* 130 */     return this.rows.size();
/*     */   }
/*     */   @Nullable
/*     */   public String get(int row) {
/* 134 */     return this.rows.get(row);
/*     */   }
/*     */   
/*     */   public void addAll(Collection<? extends String> lines) {
/* 138 */     this.rows.addAll(lines);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(String line) {
/* 147 */     if (line.length() > 1) {
/* 148 */       this.rows.addAll(wrap(line, this.width));
/*     */     } else {
/* 150 */       this.rows.add(line);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(int row, String line) {
/* 160 */     this.rows.add(row, line);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String remove(int row) {
/* 170 */     if (row < 0 || row >= this.rows.size())
/* 171 */       return null; 
/* 172 */     return this.rows.remove(row);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void replaceRow(int row, @NotNull String line) {
/* 182 */     if (row < 0 || row >= this.rows.size())
/*     */       return; 
/* 184 */     remove(row);
/* 185 */     this.rows.add(row, line);
/*     */   }
/*     */   
/*     */   public void replaceRow(int row, @NotNull Function<String, String> replacer) {
/* 189 */     if (row < 0 || row >= this.rows.size())
/*     */       return; 
/* 191 */     String line = get(row);
/* 192 */     replaceRow(row, replacer.apply(line));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 199 */     this.rows.clear();
/*     */   }
/*     */   @NotNull
/*     */   public static Collection<? extends String> wrap(@NotNull String text, int width) {
/* 203 */     return wrap(Arrays.asList(text.split("\n")), width);
/*     */   }
/*     */   @NotNull
/*     */   public static Collection<? extends String> wrap(@NotNull Collection<? extends String> text, int width) {
/* 207 */     class_310 client = class_310.method_1551();
/* 208 */     if (client == null) {
/* 209 */       return text;
/*     */     }
/* 211 */     List<String> lines = new ArrayList<>();
/*     */     
/* 213 */     for (String line : text) {
/* 214 */       if (line.equals("\n") || line.isEmpty()) {
/* 215 */         lines.add("\n");
/*     */         
/*     */         continue;
/*     */       } 
/* 219 */       if (line.endsWith("\n")) line = line.substring(0, line.length() - 1); 
/* 220 */       while (!line.isEmpty()) {
/* 221 */         String str = client.field_1772.method_27523(line, width);
/* 222 */         line = line.substring(str.length());
/* 223 */         lines.add(str);
/*     */       } 
/* 225 */       String part = lines.remove(lines.size() - 1);
/* 226 */       lines.add(part + "\n");
/*     */     } 
/*     */     
/* 229 */     return lines;
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceu\\util\MultilineText.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */