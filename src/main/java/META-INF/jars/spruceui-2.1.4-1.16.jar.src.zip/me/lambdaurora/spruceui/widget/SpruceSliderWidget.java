/*     */ package me.lambdaurora.spruceui.widget;
/*     */ 
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Consumer;
/*     */ import me.lambdaurora.spruceui.Position;
/*     */ import me.lambdaurora.spruceui.Tooltipable;
/*     */ import me.lambdaurora.spruceui.navigation.NavigationDirection;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_2588;
/*     */ import net.minecraft.class_339;
/*     */ import net.minecraft.class_3532;
/*     */ import net.minecraft.class_4587;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpruceSliderWidget
/*     */   extends AbstractSpruceButtonWidget
/*     */   implements Tooltipable
/*     */ {
/*     */   private class_2561 baseMessage;
/*     */   protected double value;
/*     */   private final Consumer<SpruceSliderWidget> applyConsumer;
/*     */   private double multiplier;
/*     */   private String sign;
/*     */   
/*     */   public SpruceSliderWidget(Position position, int width, int height, @NotNull class_2561 message, double value, @NotNull Consumer<SpruceSliderWidget> applyConsumer, double multiplier, String sign) {
/*  41 */     super(position, width, height, message);
/*  42 */     this.value = value;
/*  43 */     this.baseMessage = message;
/*  44 */     this.applyConsumer = applyConsumer;
/*  45 */     this.multiplier = multiplier;
/*  46 */     this.sign = sign;
/*  47 */     updateMessage();
/*     */   }
/*     */   
/*     */   public SpruceSliderWidget(Position position, int width, int height, @NotNull class_2561 message, double progress, @NotNull Consumer<SpruceSliderWidget> applyConsumer) {
/*  51 */     this(position, width, height, message, progress, applyConsumer, 100.0D, "%");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getValue() {
/*  60 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setValue(double value) {
/*  69 */     double oldValue = this.value;
/*  70 */     this.value = class_3532.method_15350(value, 0.0D, 1.0D);
/*  71 */     if (oldValue != this.value) {
/*  72 */       applyValue();
/*     */     }
/*     */     
/*  75 */     updateMessage();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIntValue() {
/*  85 */     return (int)(this.value * this.multiplier);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIntValue(int value) {
/*  94 */     setValue(value / this.multiplier);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public class_2561 getBaseMessage() {
/* 103 */     return this.baseMessage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBaseMessage(@NotNull class_2561 baseMessage) {
/* 112 */     this.baseMessage = baseMessage;
/*     */   }
/*     */   
/*     */   protected void updateMessage() {
/* 116 */     setMessage((class_2561)this.baseMessage.method_27662().method_27693(": " + getIntValue() + this.sign));
/*     */   }
/*     */   
/*     */   protected void applyValue() {
/* 120 */     this.applyConsumer.accept(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean onNavigation(@NotNull NavigationDirection direction, boolean tab) {
/* 127 */     if (direction.isHorizontal() && !tab && ((
/* 128 */       direction.isLookingForward() && this.value < 1.0D) || this.value > 0.0D)) {
/* 129 */       setValue(getValue() + (direction.isLookingForward() ? (1.0D / this.multiplier) : -(1.0D / this.multiplier)));
/* 130 */       return true;
/*     */     } 
/*     */     
/* 133 */     return super.onNavigation(direction, tab);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onClick(double mouseX, double mouseY) {
/* 140 */     setValueFromMouse(mouseX);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void onRelease(double mouseX, double mouseY) {
/* 145 */     playDownSound();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void onDrag(double mouseX, double mouseY, double deltaX, double deltaY) {
/* 150 */     setValueFromMouse(mouseX);
/*     */   }
/*     */   
/*     */   private void setValueFromMouse(double mouseX) {
/* 154 */     setValue((mouseX - (getX() + 4)) / (getWidth() - 8));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getVOffset() {
/* 161 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void renderButton(class_4587 matrices, int mouseX, int mouseY, float delta) {
/* 166 */     this.client.method_1531().method_22813(class_339.field_22757);
/* 167 */     RenderSystem.color4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 168 */     int vOffset = (isFocusedOrHovered() ? 2 : 1) * 20;
/* 169 */     method_25302(matrices, getX() + (int)(this.value * (getWidth() - 8)), getY(), 0, 46 + vOffset, 4, 20);
/* 170 */     method_25302(matrices, getX() + (int)(this.value * (getWidth() - 8)) + 4, getY(), 196, 46 + vOffset, 4, 20);
/*     */     
/* 172 */     super.renderButton(matrices, mouseX, mouseY, delta);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   protected Optional<class_2561> getNarrationMessage() {
/* 179 */     return (Optional)Optional.of(new class_2588("gui.narrate.slider", new Object[] { getMessage() }));
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\widget\SpruceSliderWidget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */