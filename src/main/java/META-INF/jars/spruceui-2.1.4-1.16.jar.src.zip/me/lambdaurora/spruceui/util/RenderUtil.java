/*     */ package me.lambdaurora.spruceui.util;
/*     */ 
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import net.minecraft.class_287;
/*     */ import net.minecraft.class_289;
/*     */ import net.minecraft.class_290;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_437;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RenderUtil
/*     */ {
/*     */   private RenderUtil() {
/*  21 */     throw new IllegalStateException("RenderUtil only contains static-definitions.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void renderBackgroundTexture(class_310 client, int x, int y, int width, int height, float vOffset) {
/*  36 */     renderBackgroundTexture(client, x, y, width, height, vOffset, 64, 64, 64, 255);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void renderBackgroundTexture(class_310 client, int x, int y, int width, int height, float vOffset, int red, int green, int blue, int alpha) {
/*  55 */     class_289 tessellator = class_289.method_1348();
/*  56 */     class_287 bufferBuilder = tessellator.method_1349();
/*  57 */     client.method_1531().method_22813(class_437.field_22735);
/*  58 */     RenderSystem.color4f(1.0F, 1.0F, 1.0F, 1.0F);
/*     */     
/*  60 */     int right = x + width;
/*  61 */     int bottom = y + height;
/*     */     
/*  63 */     bufferBuilder.method_1328(7, class_290.field_1575);
/*  64 */     bufferBuilder.method_22912(x, bottom, 0.0D)
/*  65 */       .method_22913(0.0F, bottom / 32.0F + vOffset)
/*  66 */       .method_1336(red, green, blue, alpha).method_1344();
/*  67 */     bufferBuilder.method_22912(right, bottom, 0.0D)
/*  68 */       .method_22913(right / 32.0F, bottom / 32.0F + vOffset)
/*  69 */       .method_1336(red, green, blue, alpha).method_1344();
/*  70 */     bufferBuilder.method_22912(right, y, 0.0D)
/*  71 */       .method_22913(right / 32.0F, y / 32.0F + vOffset)
/*  72 */       .method_1336(red, green, blue, alpha).method_1344();
/*  73 */     bufferBuilder.method_22912(x, y, 0.0D)
/*  74 */       .method_22913(0.0F, y / 32.0F + vOffset)
/*  75 */       .method_1336(red, green, blue, alpha).method_1344();
/*  76 */     tessellator.method_1350();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void renderSelectionBox(int x, int y, int width, int height, int red, int green, int blue, int alpha) {
/*  92 */     class_289 tessellator = class_289.method_1348();
/*  93 */     class_287 bufferBuilder = tessellator.method_1349();
/*  94 */     RenderSystem.disableTexture();
/*     */     
/*  96 */     int top = y + height;
/*  97 */     int right = x + width;
/*     */     
/*  99 */     RenderSystem.color4f(red / 255.0F, green / 255.0F, blue / 255.0F, alpha / 255.0F);
/* 100 */     bufferBuilder.method_1328(7, class_290.field_1592);
/* 101 */     bufferBuilder.method_22912(x, top, 0.0D).method_1344();
/* 102 */     bufferBuilder.method_22912(right, top, 0.0D).method_1344();
/* 103 */     bufferBuilder.method_22912(right, y, 0.0D).method_1344();
/* 104 */     bufferBuilder.method_22912(x, y, 0.0D).method_1344();
/* 105 */     tessellator.method_1350();
/* 106 */     RenderSystem.color4f(0.0F, 0.0F, 0.0F, 1.0F);
/* 107 */     bufferBuilder.method_1328(7, class_290.field_1592);
/* 108 */     bufferBuilder.method_22912((x + 1), (top - 1), 0.0D).method_1344();
/* 109 */     bufferBuilder.method_22912((right - 1), (top - 1), 0.0D).method_1344();
/* 110 */     bufferBuilder.method_22912((right - 1), (y + 1), 0.0D).method_1344();
/* 111 */     bufferBuilder.method_22912((x + 1), (y + 1), 0.0D).method_1344();
/* 112 */     tessellator.method_1350();
/* 113 */     RenderSystem.enableTexture();
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceu\\util\RenderUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */