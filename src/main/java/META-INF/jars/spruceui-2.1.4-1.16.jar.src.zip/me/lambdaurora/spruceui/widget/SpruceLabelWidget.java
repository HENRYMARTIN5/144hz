/*     */ package me.lambdaurora.spruceui.widget;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Consumer;
/*     */ import me.lambdaurora.spruceui.Position;
/*     */ import me.lambdaurora.spruceui.Tooltip;
/*     */ import me.lambdaurora.spruceui.Tooltipable;
/*     */ import me.lambdaurora.spruceui.border.Border;
/*     */ import me.lambdaurora.spruceui.border.EmptyBorder;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_4587;
/*     */ import net.minecraft.class_5348;
/*     */ import net.minecraft.class_5481;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpruceLabelWidget
/*     */   extends AbstractSpruceWidget
/*     */   implements Tooltipable, WithBorder
/*     */ {
/*     */   public static final Consumer<SpruceLabelWidget> DEFAULT_ACTION = label -> {
/*     */     
/*     */     };
/*     */   private final Consumer<SpruceLabelWidget> action;
/*     */   private final int maxWidth;
/*     */   private int baseX;
/*     */   private class_2561 text;
/*     */   private List<class_5481> lines;
/*     */   private class_2561 tooltip;
/*     */   private boolean centered;
/*  48 */   private Border border = (Border)EmptyBorder.EMPTY_BORDER;
/*     */   
/*     */   public SpruceLabelWidget(Position position, @NotNull class_2561 text, int maxWidth, @NotNull Consumer<SpruceLabelWidget> action, boolean centered) {
/*  51 */     super(position);
/*  52 */     this.maxWidth = maxWidth;
/*  53 */     this.baseX = position.getRelativeX();
/*  54 */     this.action = action;
/*  55 */     this.centered = centered;
/*  56 */     setText(text);
/*     */   }
/*     */   
/*     */   public SpruceLabelWidget(Position position, @NotNull class_2561 text, int maxWidth, @NotNull Consumer<SpruceLabelWidget> action) {
/*  60 */     this(position, text, maxWidth, action, false);
/*     */   }
/*     */   
/*     */   public SpruceLabelWidget(Position position, @NotNull class_2561 text, int maxWidth, boolean centered) {
/*  64 */     this(position, text, maxWidth, DEFAULT_ACTION, centered);
/*     */   }
/*     */   
/*     */   public SpruceLabelWidget(Position position, @NotNull class_2561 text, int maxWidth) {
/*  68 */     this(position, text, maxWidth, DEFAULT_ACTION);
/*     */   }
/*     */   
/*     */   private int getInnerX() {
/*  72 */     return getPosition().getAnchor().getX() + this.baseX;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class_2561 getText() {
/*  81 */     return this.text;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setText(@NotNull class_2561 text) {
/*  90 */     this.text = text;
/*  91 */     this.lines = this.client.field_1772.method_1728((class_5348)text, this.maxWidth);
/*     */     
/*  93 */     int width = this.lines.stream().mapToInt(this.client.field_1772::method_30880).max().orElse(this.maxWidth);
/*  94 */     if (width > this.maxWidth) {
/*  95 */       width = this.maxWidth;
/*     */     }
/*     */     
/*  98 */     if (isCentered()) {
/*  99 */       this.position.setRelativeX(this.baseX + this.maxWidth / 2 - width / 2);
/*     */     } else {
/* 101 */       this.position.setRelativeX(this.baseX);
/*     */     } 
/* 103 */     this.width = width;
/* 104 */     this.client.field_1772.getClass(); this.height = this.lines.size() * 9 + 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCentered() {
/* 113 */     return this.centered;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCentered(boolean centered) {
/* 122 */     this.centered = centered;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Optional<class_2561> getTooltip() {
/* 127 */     return Optional.ofNullable(this.tooltip);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTooltip(@Nullable class_2561 tooltip) {
/* 132 */     this.tooltip = tooltip;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Border getBorder() {
/* 137 */     return this.border;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBorder(@NotNull Border border) {
/* 142 */     this.border = border;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onPress() {
/* 149 */     this.action.accept(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean requiresCursor() {
/* 156 */     return (this.action == DEFAULT_ACTION);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean onMouseClick(double mouseX, double mouseY, int button) {
/* 163 */     if (button == 0 && 
/* 164 */       this.hovered) {
/* 165 */       onPress();
/* 166 */       return true;
/*     */     } 
/*     */     
/* 169 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void renderWidget(class_4587 matrices, int mouseX, int mouseY, float delta) {
/* 176 */     int y = getY() + 2;
/* 177 */     for (Iterator<class_5481> it = this.lines.iterator(); it.hasNext(); y += 9) {
/* 178 */       class_5481 line = it.next();
/*     */       
/* 180 */       int x = this.centered ? (getInnerX() + this.maxWidth / 2 - this.client.field_1772.method_30880(line) / 2) : getInnerX();
/* 181 */       this.client.field_1772.method_27528(matrices, line, x, y, 10526880);
/*     */     } 
/*     */     
/* 184 */     getBorder().render(matrices, this, mouseX, mouseY, delta);
/*     */     
/* 186 */     if (this.tooltip != null && 
/* 187 */       !this.tooltip.getString().isEmpty()) {
/* 188 */       List<class_5481> wrappedTooltipText = this.client.field_1772.method_1728((class_5348)this.tooltip, Math.max(this.width / 2, 200));
/* 189 */       if (this.hovered) {
/* 190 */         Tooltip.create(mouseX, mouseY, wrappedTooltipText).queue();
/* 191 */       } else if (this.focused) {
/* 192 */         Tooltip.create(getX() - 12, getY(), wrappedTooltipText).queue();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   protected Optional<class_2561> getNarrationMessage() {
/* 201 */     return Optional.ofNullable(getText());
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\widget\SpruceLabelWidget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */