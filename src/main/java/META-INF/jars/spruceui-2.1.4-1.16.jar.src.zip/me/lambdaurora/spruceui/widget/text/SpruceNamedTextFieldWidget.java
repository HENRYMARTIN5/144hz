/*     */ package me.lambdaurora.spruceui.widget.text;
/*     */ 
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Predicate;
/*     */ import me.lambdaurora.spruceui.SprucePositioned;
/*     */ import me.lambdaurora.spruceui.navigation.NavigationDirection;
/*     */ import me.lambdaurora.spruceui.widget.AbstractSpruceWidget;
/*     */ import net.minecraft.class_332;
/*     */ import net.minecraft.class_4587;
/*     */ import net.minecraft.class_5481;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpruceNamedTextFieldWidget
/*     */   extends AbstractSpruceWidget
/*     */ {
/*     */   private static final int Y_OFFSET = 13;
/*     */   private final SpruceTextFieldWidget textFieldWidget;
/*     */   
/*     */   public SpruceNamedTextFieldWidget(SpruceTextFieldWidget widget) {
/*  35 */     super(widget.getPosition().copy());
/*  36 */     widget.getPosition().setAnchor((SprucePositioned)this);
/*  37 */     widget.getPosition().setRelativeX(0);
/*  38 */     widget.getPosition().setRelativeY(13);
/*     */     
/*  40 */     this.textFieldWidget = widget;
/*     */   }
/*     */   
/*     */   public SpruceTextFieldWidget getTextFieldWidget() {
/*  44 */     return this.textFieldWidget;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getWidth() {
/*  49 */     return getTextFieldWidget().getWidth();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getHeight() {
/*  54 */     return getTextFieldWidget().getHeight() + 13;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isVisible() {
/*  59 */     return getTextFieldWidget().isVisible();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setVisible(boolean visible) {
/*  64 */     getTextFieldWidget().setVisible(visible);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFocused() {
/*  69 */     return getTextFieldWidget().isFocused();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFocused(boolean focused) {
/*  74 */     getTextFieldWidget().setFocused(focused);
/*     */   }
/*     */   
/*     */   public String getText() {
/*  78 */     return getTextFieldWidget().getText();
/*     */   }
/*     */   
/*     */   public void setText(String text) {
/*  82 */     getTextFieldWidget().setText(text);
/*     */   }
/*     */   
/*     */   public Predicate<String> getTextPredicate() {
/*  86 */     return getTextFieldWidget().getTextPredicate();
/*     */   }
/*     */   
/*     */   public void setTextPredicate(Predicate<String> textPredicate) {
/*  90 */     getTextFieldWidget().setTextPredicate(textPredicate);
/*     */   }
/*     */   
/*     */   public BiFunction<String, Integer, class_5481> getRenderTextProvider() {
/*  94 */     return getTextFieldWidget().getRenderTextProvider();
/*     */   }
/*     */   
/*     */   public void setRenderTextProvider(BiFunction<String, Integer, class_5481> renderTextProvider) {
/*  98 */     getTextFieldWidget().setRenderTextProvider(renderTextProvider);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean onNavigation(@NotNull NavigationDirection direction, boolean tab) {
/* 105 */     return getTextFieldWidget().onNavigation(direction, tab);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean onMouseClick(double mouseX, double mouseY, int button) {
/* 112 */     return getTextFieldWidget().method_25402(mouseX, mouseY, button);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onMouseRelease(double mouseX, double mouseY, int button) {
/* 117 */     return getTextFieldWidget().method_25406(mouseX, mouseY, button);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onMouseDrag(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
/* 122 */     return getTextFieldWidget().method_25403(mouseX, mouseY, button, deltaX, deltaY);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onMouseScroll(double mouseX, double mouseY, double amount) {
/* 127 */     return getTextFieldWidget().method_25401(mouseX, mouseY, amount);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onKeyPress(int keyCode, int scanCode, int modifiers) {
/* 132 */     return getTextFieldWidget().method_25404(keyCode, scanCode, modifiers);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onKeyRelease(int keyCode, int scanCode, int modifiers) {
/* 137 */     return getTextFieldWidget().method_16803(keyCode, scanCode, modifiers);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onCharTyped(char chr, int keyCode) {
/* 142 */     return getTextFieldWidget().method_25400(chr, keyCode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void renderWidget(class_4587 matrices, int mouseX, int mouseY, float delta) {
/* 149 */     class_332.method_27535(matrices, this.client.field_1772, getTextFieldWidget().getTitle(), getX() + 2, getY() + 2, -2039584);
/*     */     
/* 151 */     getTextFieldWidget().method_25394(matrices, mouseX, mouseY, delta);
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\widget\text\SpruceNamedTextFieldWidget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */