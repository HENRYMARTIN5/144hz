/*    */ package me.lambdaurora.spruceui.border;
/*    */ 
/*    */ import me.lambdaurora.spruceui.widget.SpruceWidget;
/*    */ import net.minecraft.class_4587;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class EmptyBorder
/*    */   extends Border
/*    */ {
/* 23 */   public static final EmptyBorder EMPTY_BORDER = new EmptyBorder();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void render(class_4587 matrices, SpruceWidget widget, int mouseX, int mouseY, float delta) {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getThickness() {
/* 34 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 39 */     return "EmptyBorder{}";
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\border\EmptyBorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */