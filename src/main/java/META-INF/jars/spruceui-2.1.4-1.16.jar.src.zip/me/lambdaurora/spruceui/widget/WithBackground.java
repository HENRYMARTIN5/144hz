package me.lambdaurora.spruceui.widget;

import me.lambdaurora.spruceui.background.Background;
import org.jetbrains.annotations.NotNull;

public interface WithBackground {
  @NotNull
  Background getBackground();
  
  void setBackground(@NotNull Background paramBackground);
}


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\widget\WithBackground.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */