package me.lambdaurora.spruceui;

import java.util.Optional;
import net.minecraft.class_2561;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public interface Tooltipable {
  @NotNull
  Optional<class_2561> getTooltip();
  
  void setTooltip(@Nullable class_2561 paramclass_2561);
}


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\Tooltipable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */