/*    */ package me.lambdaurora.spruceui.mixin;
/*    */ 
/*    */ import me.lambdaurora.spruceui.event.OpenScreenCallback;
/*    */ import me.lambdaurora.spruceui.event.ResolutionChangeCallback;
/*    */ import net.minecraft.class_310;
/*    */ import net.minecraft.class_437;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_310.class})
/*    */ public class MinecraftClientMixin
/*    */ {
/*    */   @Inject(method = {"openScreen"}, at = {@At("HEAD")})
/*    */   private void spruceui_onScreenPre(class_437 screen, CallbackInfo ci) {
/* 32 */     ((OpenScreenCallback)OpenScreenCallback.PRE.invoker()).apply((class_310)this, screen);
/*    */   }
/*    */   
/*    */   @Inject(method = {"openScreen"}, at = {@At("RETURN")})
/*    */   private void spruceui_onScreenChange(class_437 screen, CallbackInfo ci) {
/* 37 */     ((OpenScreenCallback)OpenScreenCallback.EVENT.invoker()).apply((class_310)this, screen);
/*    */   }
/*    */   
/*    */   @Inject(method = {"onResolutionChanged"}, at = {@At("RETURN")})
/*    */   private void spruceui_onResolutionChanged(CallbackInfo ci) {
/* 42 */     ((ResolutionChangeCallback)ResolutionChangeCallback.EVENT.invoker()).apply((class_310)this);
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\mixin\MinecraftClientMixin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */