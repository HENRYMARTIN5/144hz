/*    */ package me.lambdaurora.spruceui.option;
/*    */ 
/*    */ import java.util.function.Consumer;
/*    */ import java.util.function.Function;
/*    */ import me.lambdaurora.spruceui.Position;
/*    */ import me.lambdaurora.spruceui.widget.SpruceButtonWidget;
/*    */ import me.lambdaurora.spruceui.widget.SpruceWidget;
/*    */ import net.minecraft.class_2561;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpruceCyclingOption
/*    */   extends SpruceOption
/*    */ {
/*    */   private final Consumer<Integer> setter;
/*    */   private final Function<SpruceCyclingOption, class_2561> messageProvider;
/*    */   
/*    */   public SpruceCyclingOption(String key, Consumer<Integer> setter, Function<SpruceCyclingOption, class_2561> messageProvider, @Nullable class_2561 tooltip) {
/* 35 */     super(key);
/* 36 */     this.setter = setter;
/* 37 */     this.messageProvider = messageProvider;
/* 38 */     setTooltip(tooltip);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void cycle(int amount) {
/* 47 */     this.setter.accept(Integer.valueOf(amount));
/*    */   }
/*    */ 
/*    */   
/*    */   public SpruceWidget createWidget(Position position, int width) {
/* 52 */     SpruceButtonWidget button = new SpruceButtonWidget(position, width, 20, getMessage(), btn -> {
/*    */           cycle(1);
/*    */           btn.setMessage(getMessage());
/*    */         });
/* 56 */     getOptionTooltip().ifPresent(button::setTooltip);
/* 57 */     return (SpruceWidget)button;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public class_2561 getMessage() {
/* 66 */     return this.messageProvider.apply(this);
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\option\SpruceCyclingOption.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */