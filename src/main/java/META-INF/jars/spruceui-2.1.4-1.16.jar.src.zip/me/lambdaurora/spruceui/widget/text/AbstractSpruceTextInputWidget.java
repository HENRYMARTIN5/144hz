/*     */ package me.lambdaurora.spruceui.widget.text;
/*     */ 
/*     */ import java.util.Optional;
/*     */ import me.lambdaurora.spruceui.Position;
/*     */ import me.lambdaurora.spruceui.background.Background;
/*     */ import me.lambdaurora.spruceui.background.SimpleColorBackground;
/*     */ import me.lambdaurora.spruceui.border.Border;
/*     */ import me.lambdaurora.spruceui.border.SimpleBorder;
/*     */ import me.lambdaurora.spruceui.widget.AbstractSpruceWidget;
/*     */ import me.lambdaurora.spruceui.widget.SpruceWidget;
/*     */ import me.lambdaurora.spruceui.widget.WithBackground;
/*     */ import me.lambdaurora.spruceui.widget.WithBorder;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_2588;
/*     */ import net.minecraft.class_4587;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractSpruceTextInputWidget
/*     */   extends AbstractSpruceWidget
/*     */   implements WithBackground, WithBorder
/*     */ {
/*     */   private final class_2561 title;
/*  37 */   private Background background = (Background)new SimpleColorBackground(-16777216);
/*  38 */   private Border border = (Border)new SimpleBorder(1, -6250336, -1);
/*     */   
/*  40 */   private int editableColor = -2039584;
/*  41 */   private int uneditableColor = -9408400;
/*     */   
/*     */   public AbstractSpruceTextInputWidget(@NotNull Position position, int width, int height, class_2561 title) {
/*  44 */     super(position);
/*  45 */     this.width = width;
/*  46 */     this.height = height;
/*  47 */     this.title = title;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String getText();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void setText(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class_2561 getTitle() {
/*  65 */     return this.title;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getEditableColor() {
/*  74 */     return this.editableColor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEditableColor(int editableColor) {
/*  83 */     this.editableColor = editableColor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getUneditableColor() {
/*  92 */     return this.uneditableColor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTextColor() {
/* 101 */     return isActive() ? getEditableColor() : getUneditableColor();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUneditableColor(int uneditableColor) {
/* 110 */     this.uneditableColor = uneditableColor;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void setCursorToStart();
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void setCursorToEnd();
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public Background getBackground() {
/* 125 */     return this.background;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBackground(@NotNull Background background) {
/* 130 */     this.background = background;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Border getBorder() {
/* 135 */     return this.border;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBorder(@NotNull Border border) {
/* 140 */     this.border = border;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getInnerWidth() {
/* 149 */     return getWidth() - 6 - getBorder().getThickness() * 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getInnerHeight() {
/* 158 */     return getHeight() - 6 - getBorder().getThickness() * 2;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void sanitize();
/*     */ 
/*     */   
/*     */   public boolean isEditorActive() {
/* 167 */     return (isActive() && isFocused());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void renderWidget(class_4587 matrices, int mouseX, int mouseY, float delta) {
/* 174 */     getBorder().render(matrices, (SpruceWidget)this, mouseX, mouseY, delta);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void renderBackground(class_4587 matrices, int mouseX, int mouseY, float delta) {
/* 179 */     getBackground().render(matrices, (SpruceWidget)this, 0, mouseX, mouseY, delta);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   protected Optional<class_2561> getNarrationMessage() {
/* 186 */     return (Optional)Optional.of(new class_2588("gui.narrate.editBox", new Object[] { this.title, getText() }));
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\widget\text\AbstractSpruceTextInputWidget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */