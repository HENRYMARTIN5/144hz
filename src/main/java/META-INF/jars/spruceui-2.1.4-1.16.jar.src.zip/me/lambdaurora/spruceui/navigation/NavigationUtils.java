/*    */ package me.lambdaurora.spruceui.navigation;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.ListIterator;
/*    */ import java.util.function.BooleanSupplier;
/*    */ import java.util.function.Consumer;
/*    */ import java.util.function.Supplier;
/*    */ import me.lambdaurora.spruceui.widget.SpruceWidget;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class NavigationUtils
/*    */ {
/*    */   private NavigationUtils() {
/* 29 */     throw new UnsupportedOperationException("NavigationUtils only contains static definitions.");
/*    */   }
/*    */   
/*    */   public static <E extends SpruceWidget> boolean tryNavigate(NavigationDirection direction, boolean tab, List<E> children, E focused, Consumer<E> setFocused, boolean alwaysFocus) {
/* 33 */     if (children.isEmpty())
/* 34 */       return false; 
/* 35 */     if (!tab && alwaysFocus && focused != null) {
/* 36 */       int i = children.indexOf(focused);
/* 37 */       if ((!direction.isLookingForward() && i == 0) || (direction.isLookingForward() && i == children.size() - 1)) {
/* 38 */         boolean result = focused.onNavigation(direction, false);
/* 39 */         focused.setFocused(true);
/* 40 */         return result;
/*    */       } 
/*    */     } 
/* 43 */     if (focused == null || !focused.onNavigation(direction, tab)) {
/* 44 */       int next; SpruceWidget spruceWidget; int i = children.indexOf(focused);
/*    */       
/* 46 */       if (focused != null && i >= 0) { next = i + (direction.isLookingForward() ? 1 : 0); }
/* 47 */       else if (direction.isLookingForward()) { next = 0; }
/* 48 */       else { next = children.size(); }
/*    */       
/* 50 */       ListIterator<E> iterator = children.listIterator(next);
/* 51 */       BooleanSupplier hasNext = direction.isLookingForward() ? iterator::hasNext : iterator::hasPrevious;
/* 52 */       Supplier<E> nextGetter = direction.isLookingForward() ? iterator::next : iterator::previous;
/*    */ 
/*    */       
/*    */       do {
/* 56 */         if (!hasNext.getAsBoolean()) {
/* 57 */           setFocused.accept(null);
/* 58 */           return false;
/*    */         } 
/*    */         
/* 61 */         spruceWidget = (SpruceWidget)nextGetter.get();
/* 62 */       } while (!spruceWidget.onNavigation(direction, tab));
/*    */       
/* 64 */       setFocused.accept((E)spruceWidget);
/*    */     } 
/* 66 */     return true;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\navigation\NavigationUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */