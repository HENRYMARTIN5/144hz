/*    */ package me.lambdaurora.spruceui.wrapper;
/*    */ 
/*    */ import me.lambdaurora.spruceui.navigation.NavigationDirection;
/*    */ import me.lambdaurora.spruceui.widget.AbstractSpruceButtonWidget;
/*    */ import me.lambdaurora.spruceui.widget.SpruceElement;
/*    */ import net.fabricmc.api.EnvType;
/*    */ import net.fabricmc.api.Environment;
/*    */ import net.minecraft.class_339;
/*    */ import net.minecraft.class_4587;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Environment(EnvType.CLIENT)
/*    */ public class VanillaButtonWrapper
/*    */   extends class_339
/*    */   implements SpruceElement
/*    */ {
/*    */   private final AbstractSpruceButtonWidget widget;
/*    */   
/*    */   public VanillaButtonWrapper(@NotNull AbstractSpruceButtonWidget widget) {
/* 33 */     super(widget.getX(), widget.getY(), widget.getWidth(), widget.getHeight(), widget.getMessage());
/* 34 */     this.widget = widget;
/*    */   }
/*    */ 
/*    */   
/*    */   public void method_25394(class_4587 matrices, int mouseX, int mouseY, float delta) {
/* 39 */     this.widget.getPosition().setRelativeY(this.field_22761);
/* 40 */     this.widget.method_25394(matrices, mouseX, mouseY, delta);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean method_25402(double mouseX, double mouseY, int button) {
/* 45 */     return this.widget.method_25402(mouseX, mouseY, button);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean method_25406(double mouseX, double mouseY, int button) {
/* 50 */     return this.widget.method_25406(mouseX, mouseY, button);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
/* 55 */     return this.widget.method_25403(mouseX, mouseY, button, deltaX, deltaY);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean onNavigation(@NotNull NavigationDirection direction, boolean tab) {
/* 60 */     return this.widget.onNavigation(direction, tab);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean method_25407(boolean down) {
/* 65 */     boolean value = onNavigation(down ? NavigationDirection.DOWN : NavigationDirection.UP, true);
/* 66 */     return value;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\wrapper\VanillaButtonWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */