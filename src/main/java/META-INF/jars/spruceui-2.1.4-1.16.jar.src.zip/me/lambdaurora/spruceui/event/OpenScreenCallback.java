/*    */ package me.lambdaurora.spruceui.event;
/*    */ 
/*    */ import net.fabricmc.fabric.api.event.Event;
/*    */ import net.minecraft.class_310;
/*    */ import net.minecraft.class_437;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FunctionalInterface
/*    */ public interface OpenScreenCallback
/*    */ {
/* 27 */   public static final Event<OpenScreenCallback> PRE = EventUtil.makeOpenScreenEvent();
/* 28 */   public static final Event<OpenScreenCallback> EVENT = EventUtil.makeOpenScreenEvent();
/*    */   
/*    */   void apply(@NotNull class_310 paramclass_310, @Nullable class_437 paramclass_437);
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\event\OpenScreenCallback.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */