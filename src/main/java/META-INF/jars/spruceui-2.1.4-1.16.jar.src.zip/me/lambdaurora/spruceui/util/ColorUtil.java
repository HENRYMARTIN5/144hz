/*     */ package me.lambdaurora.spruceui.util;
/*     */ 
/*     */ import net.minecraft.class_3532;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ColorUtil
/*     */ {
/*     */   public static final int BLACK = -16777216;
/*     */   public static final int WHITE = -1;
/*     */   public static final int TEXT_COLOR = -2039584;
/*     */   public static final int UNEDITABLE_COLOR = -9408400;
/*     */   
/*     */   private ColorUtil() {
/*  24 */     throw new UnsupportedOperationException("ColorUtil only contains static definitions.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float floatColor(int colorComponent) {
/*  39 */     return colorComponent / 255.0F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int intColor(float colorComponent) {
/*  49 */     return class_3532.method_15340((int)(colorComponent * 255.0F), 0, 255);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int packARGBColor(int red, int green, int blue, int alpha) {
/*  62 */     return ((alpha & 0xFF) << 24) + ((red & 0xFF) << 16) + ((green & 0xFF) << 8) + (blue & 0xFF);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int[] unpackARGBColor(int color) {
/*  72 */     return new int[] {
/*  73 */         argbUnpackRed(color), 
/*  74 */         argbUnpackGreen(color), 
/*  75 */         argbUnpackBlue(color), 
/*  76 */         argbUnpackAlpha(color)
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int argbUnpackRed(int color) {
/*  87 */     return color >> 16 & 0xFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int argbUnpackGreen(int color) {
/*  97 */     return color >> 8 & 0xFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int argbUnpackBlue(int color) {
/* 107 */     return color & 0xFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int argbUnpackAlpha(int color) {
/* 117 */     return color >> 24 & 0xFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int argbDarken(int color) {
/* 127 */     return argbMultiply(color, 0.7F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int argbMultiply(int color, float multiplier) {
/* 138 */     return argbMultiply(color, multiplier, argbUnpackAlpha(color));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int argbMultiply(int color, float multiplier, int alpha) {
/* 150 */     return packARGBColor(
/* 151 */         class_3532.method_15340((int)(argbUnpackRed(color) * multiplier), 0, 255), 
/* 152 */         class_3532.method_15340((int)(argbUnpackGreen(color) * multiplier), 0, 255), 
/* 153 */         class_3532.method_15340((int)(argbUnpackBlue(color) * multiplier), 0, 255), alpha);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int argbMultiply(int a, int b) {
/* 165 */     float aRed = floatColor(argbUnpackRed(a));
/* 166 */     float aGreen = floatColor(argbUnpackGreen(a));
/* 167 */     float aBlue = floatColor(argbUnpackBlue(a));
/* 168 */     float aAlpha = floatColor(argbUnpackAlpha(a));
/*     */     
/* 170 */     float bRed = floatColor(argbUnpackRed(b));
/* 171 */     float bGreen = floatColor(argbUnpackGreen(b));
/* 172 */     float bBlue = floatColor(argbUnpackBlue(b));
/* 173 */     float bAlpha = floatColor(argbUnpackAlpha(b));
/*     */     
/* 175 */     return packARGBColor(
/* 176 */         intColor(aRed * bRed), 
/* 177 */         intColor(aGreen * bGreen), 
/* 178 */         intColor(aBlue * bBlue), 
/* 179 */         intColor(aAlpha * bAlpha));
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceu\\util\ColorUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */