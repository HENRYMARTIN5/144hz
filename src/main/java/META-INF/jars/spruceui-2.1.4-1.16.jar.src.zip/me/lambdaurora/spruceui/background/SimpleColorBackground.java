/*    */ package me.lambdaurora.spruceui.background;
/*    */ 
/*    */ import me.lambdaurora.spruceui.util.ColorUtil;
/*    */ import me.lambdaurora.spruceui.widget.SpruceWidget;
/*    */ import net.minecraft.class_310;
/*    */ import net.minecraft.class_332;
/*    */ import net.minecraft.class_4587;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleColorBackground
/*    */   extends class_332
/*    */   implements Background
/*    */ {
/* 19 */   private final class_310 client = class_310.method_1551();
/*    */   private final int color;
/*    */   
/*    */   public SimpleColorBackground(int color) {
/* 23 */     this.color = color;
/*    */   }
/*    */   
/*    */   public SimpleColorBackground(int red, int green, int blue, int alpha) {
/* 27 */     this(ColorUtil.packARGBColor(red, green, blue, alpha));
/*    */   }
/*    */ 
/*    */   
/*    */   public void render(class_4587 matrices, SpruceWidget widget, int vOffset, int mouseX, int mouseY, float delta) {
/* 32 */     int x = widget.getX();
/* 33 */     int y = widget.getY();
/* 34 */     method_25294(matrices, x, y, x + widget.getWidth(), y + widget.getHeight(), this.color);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 39 */     return "SimpleColorBackground{, color=" + this.color + '}';
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\background\SimpleColorBackground.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */