/*     */ package me.lambdaurora.spruceui.widget.container;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import java.util.AbstractList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import me.lambdaurora.spruceui.Position;
/*     */ import me.lambdaurora.spruceui.SprucePositioned;
/*     */ import me.lambdaurora.spruceui.background.Background;
/*     */ import me.lambdaurora.spruceui.background.DirtTexturedBackground;
/*     */ import me.lambdaurora.spruceui.border.Border;
/*     */ import me.lambdaurora.spruceui.border.EmptyBorder;
/*     */ import me.lambdaurora.spruceui.navigation.NavigationDirection;
/*     */ import me.lambdaurora.spruceui.util.ScissorManager;
/*     */ import me.lambdaurora.spruceui.widget.AbstractSpruceWidget;
/*     */ import me.lambdaurora.spruceui.widget.SpruceWidget;
/*     */ import me.lambdaurora.spruceui.widget.WithBackground;
/*     */ import me.lambdaurora.spruceui.widget.WithBorder;
/*     */ import net.fabricmc.api.EnvType;
/*     */ import net.fabricmc.api.Environment;
/*     */ import net.minecraft.class_287;
/*     */ import net.minecraft.class_289;
/*     */ import net.minecraft.class_290;
/*     */ import net.minecraft.class_3532;
/*     */ import net.minecraft.class_4493;
/*     */ import net.minecraft.class_4587;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SpruceEntryListWidget<E extends SpruceEntryListWidget.Entry>
/*     */   extends AbstractSpruceParentWidget<E>
/*     */   implements WithBackground, WithBorder
/*     */ {
/*  48 */   protected final Position anchor = Position.of((SprucePositioned)this, 0, 0);
/*  49 */   private final List<E> entries = new Entries();
/*     */   private final int anchorYOffset;
/*     */   private double scrollAmount;
/*  52 */   private Background background = DirtTexturedBackground.DARKENED;
/*     */   private boolean renderTransition = true;
/*  54 */   private Border border = (Border)EmptyBorder.EMPTY_BORDER;
/*     */   private boolean scrolling = false;
/*     */   private boolean allowOutsideHorizontalNavigation = false;
/*     */   
/*     */   public SpruceEntryListWidget(@NotNull Position position, int width, int height, int anchorYOffset, Class<E> entryClass) {
/*  59 */     super(position, entryClass);
/*  60 */     this.width = width;
/*  61 */     this.height = height;
/*  62 */     this.anchorYOffset = anchorYOffset;
/*  63 */     this.anchor.setRelativeY(anchorYOffset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getInnerWidth() {
/*  72 */     int width = getWidth();
/*  73 */     if (getMaxScroll() > 0)
/*  74 */       width -= 6; 
/*  75 */     width -= getBorder().getThickness() * 2;
/*  76 */     return width;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Background getBackground() {
/*  81 */     return this.background;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBackground(@NotNull Background background) {
/*  86 */     this.background = background;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean shouldRenderTransition() {
/*  95 */     return this.renderTransition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRenderTransition(boolean render) {
/* 104 */     this.renderTransition = render;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Border getBorder() {
/* 109 */     return this.border;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBorder(@NotNull Border border) {
/* 114 */     this.border = border;
/* 115 */     this.anchor.setRelativeX(border.getThickness());
/* 116 */     if (this.anchor.getRelativeY() == this.anchorYOffset && hasBorder())
/* 117 */       this.anchor.setRelativeY(this.anchorYOffset + border.getThickness()); 
/*     */   }
/*     */   
/*     */   public boolean doesAllowOutsideHorizontalNavigation() {
/* 121 */     return this.allowOutsideHorizontalNavigation;
/*     */   }
/*     */   
/*     */   public void setAllowOutsideHorizontalNavigation(boolean allowOutsideHorizontalNavigation) {
/* 125 */     this.allowOutsideHorizontalNavigation = allowOutsideHorizontalNavigation;
/*     */   }
/*     */   
/*     */   protected int getLengthUntil(int index) {
/* 129 */     int max = 0;
/* 130 */     for (int i = 0; i <= index; i++) {
/* 131 */       max += ((Entry)this.entries.get(i)).getHeight();
/*     */     }
/* 133 */     return max;
/*     */   }
/*     */   
/*     */   public int getMaxPosition() {
/* 137 */     return getLengthUntil(getEntriesCount() - 1);
/*     */   }
/*     */   
/*     */   private void scroll(int amount) {
/* 141 */     setScrollAmount(getScrollAmount() + amount);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getScrollAmount() {
/* 150 */     return this.scrollAmount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setScrollAmount(double amount) {
/* 161 */     this.scrollAmount = class_3532.method_15350(amount, 0.0D, getMaxScroll());
/* 162 */     this.anchor.setRelativeY((int)((this.anchorYOffset + getBorder().getThickness()) - this.scrollAmount));
/*     */     
/* 164 */     for (Entry entry : this.entries) {
/* 165 */       entry.setVisibleInList((entry.getY() + entry.getHeight() >= getY() && entry.getY() <= getY() + getHeight()));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxScroll() {
/* 175 */     return Math.max(0, getMaxPosition() - getHeight() + 8);
/*     */   }
/*     */   
/*     */   protected int getScrollbarPositionX() {
/* 179 */     return getX() + getWidth() - 6 - getBorder().getThickness();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<E> children() {
/* 184 */     return this.entries;
/*     */   }
/*     */   
/*     */   protected final void clearEntries() {
/* 188 */     this.entries.clear();
/*     */   }
/*     */   
/*     */   protected void replaceEntries(Collection<E> newEntries) {
/* 192 */     this.entries.clear();
/* 193 */     this.entries.addAll(newEntries);
/*     */   }
/*     */   
/*     */   protected E getEntry(int index) {
/* 197 */     return children().get(index);
/*     */   }
/*     */   
/*     */   protected int addEntry(E entry) {
/* 201 */     this.entries.add(entry);
/* 202 */     return this.entries.size() - 1;
/*     */   }
/*     */   
/*     */   protected int getEntriesCount() {
/* 206 */     return children().size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void ensureVisible(E entry) {
/* 215 */     int index = children().indexOf(entry);
/* 216 */     int rowTop = getRowTop(index);
/* 217 */     int j = rowTop - getY() - entry.getHeight() - 8;
/* 218 */     if (j < 0) {
/* 219 */       scroll(j);
/*     */     }
/*     */     
/* 222 */     int nextHeight = 0;
/* 223 */     if (index < getEntriesCount() - 1)
/* 224 */       nextHeight = ((Entry)children().get(index + 1)).getHeight(); 
/* 225 */     int k = getY() + getHeight() - rowTop - entry.getHeight() + nextHeight;
/* 226 */     if (k < 0) {
/* 227 */       scroll(-k);
/*     */     }
/*     */   }
/*     */   
/*     */   protected int getRowTop(int index) {
/* 232 */     return getY() + 4 - (int)getScrollAmount() + getLengthUntil(index);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setOwnerShip(E entry) {
/* 237 */     entry.getPosition().setAnchor((SprucePositioned)this.anchor);
/* 238 */     entry.setVisibleInList((entry.getY() + entry.getHeight() >= getY() && entry.getY() <= getY() + getHeight()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean onNavigation(@NotNull NavigationDirection direction, boolean tab) {
/* 245 */     if (requiresCursor()) return false; 
/* 246 */     if (direction.isHorizontal() && getFocused() != null) {
/* 247 */       boolean bool = ((Entry)getFocused()).onNavigation(direction, tab);
/* 248 */       return (!this.allowOutsideHorizontalNavigation || bool);
/*     */     } 
/* 250 */     boolean result = super.onNavigation(direction, tab);
/* 251 */     if (result) ensureVisible(getFocused()); 
/* 252 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean onMouseClick(double mouseX, double mouseY, int button) {
/* 259 */     this.scrolling = (button == 0 && mouseX >= getScrollbarPositionX() && mouseX < (getScrollbarPositionX() + 6));
/* 260 */     return (super.onMouseClick(mouseX, mouseY, button) || this.scrolling);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onMouseDrag(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
/* 265 */     if (super.onMouseDrag(mouseX, mouseY, button, deltaX, deltaY)) return true; 
/* 266 */     if (button == 0 && this.scrolling) {
/* 267 */       if (mouseY < getY()) {
/* 268 */         setScrollAmount(0.0D);
/* 269 */       } else if (mouseY > (getY() + getHeight())) {
/* 270 */         setScrollAmount(getMaxScroll());
/*     */       } else {
/* 272 */         double d = Math.max(1, getMaxScroll());
/* 273 */         int height = this.height;
/* 274 */         int j = class_3532.method_15340((int)((height * height) / getMaxPosition()), 32, height - 8);
/* 275 */         double e = Math.max(1.0D, d / (height - j));
/* 276 */         setScrollAmount(getScrollAmount() + deltaY * e);
/*     */       } 
/* 278 */       return true;
/*     */     } 
/* 280 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onMouseScroll(double mouseX, double mouseY, double amount) {
/* 285 */     setScrollAmount(getScrollAmount() - amount * getMaxPosition() / getEntriesCount() / 2.0D);
/* 286 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void renderBackground(class_4587 matrices, int mouseX, int mouseY, float delta) {
/* 293 */     getBackground().render(matrices, this, 0, mouseX, mouseY, delta);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void renderWidget(class_4587 matrices, int mouseX, int mouseY, float delta) {
/* 298 */     int scrollbarPositionX = getScrollbarPositionX();
/* 299 */     int scrollBarEnd = scrollbarPositionX + 6;
/* 300 */     int left = getX();
/* 301 */     int right = left + getWidth();
/* 302 */     int top = getY();
/* 303 */     int bottom = top + getHeight();
/*     */     
/* 305 */     ScissorManager.push(getX(), getY(), getWidth(), getHeight());
/* 306 */     this.entries.forEach(e -> e.method_25394(matrices, mouseX, mouseY, delta));
/* 307 */     ScissorManager.pop();
/*     */     
/* 309 */     class_289 tessellator = class_289.method_1348();
/* 310 */     class_287 buffer = tessellator.method_1349();
/*     */     
/* 312 */     if (shouldRenderTransition()) {
/* 313 */       RenderSystem.enableBlend();
/* 314 */       RenderSystem.blendFuncSeparate(class_4493.class_4535.field_22541, class_4493.class_4534.field_22523, class_4493.class_4535.field_22544, class_4493.class_4534.field_22518);
/* 315 */       RenderSystem.disableAlphaTest();
/* 316 */       RenderSystem.shadeModel(7425);
/* 317 */       RenderSystem.disableTexture();
/* 318 */       buffer.method_1328(7, class_290.field_1576);
/*     */       
/* 320 */       buffer.method_22912(left, (top + 4), 0.0D).method_22913(0.0F, 1.0F).method_1336(0, 0, 0, 0).method_1344();
/* 321 */       buffer.method_22912(right, (top + 4), 0.0D).method_22913(1.0F, 1.0F).method_1336(0, 0, 0, 0).method_1344();
/* 322 */       buffer.method_22912(right, top, 0.0D).method_22913(1.0F, 0.0F).method_1336(0, 0, 0, 255).method_1344();
/* 323 */       buffer.method_22912(left, top, 0.0D).method_22913(0.0F, 0.0F).method_1336(0, 0, 0, 255).method_1344();
/*     */       
/* 325 */       buffer.method_22912((right - 4), bottom, 0.0D).method_22913(0.0F, 1.0F).method_1336(0, 0, 0, 0).method_1344();
/* 326 */       buffer.method_22912(right, bottom, 0.0D).method_22913(1.0F, 1.0F).method_1336(0, 0, 0, 255).method_1344();
/* 327 */       buffer.method_22912(right, top, 0.0D).method_22913(1.0F, 0.0F).method_1336(0, 0, 0, 255).method_1344();
/* 328 */       buffer.method_22912((right - 4), top, 0.0D).method_22913(0.0F, 0.0F).method_1336(0, 0, 0, 0).method_1344();
/*     */       
/* 330 */       buffer.method_22912(left, bottom, 0.0D).method_22913(0.0F, 1.0F).method_1336(0, 0, 0, 255).method_1344();
/* 331 */       buffer.method_22912(right, bottom, 0.0D).method_22913(1.0F, 1.0F).method_1336(0, 0, 0, 255).method_1344();
/* 332 */       buffer.method_22912(right, (bottom - 4), 0.0D).method_22913(1.0F, 0.0F).method_1336(0, 0, 0, 0).method_1344();
/* 333 */       buffer.method_22912(left, (bottom - 4), 0.0D).method_22913(0.0F, 0.0F).method_1336(0, 0, 0, 0).method_1344();
/*     */       
/* 335 */       buffer.method_22912(left, bottom, 0.0D).method_22913(0.0F, 1.0F).method_1336(0, 0, 0, 255).method_1344();
/* 336 */       buffer.method_22912((left + 4), bottom, 0.0D).method_22913(1.0F, 1.0F).method_1336(0, 0, 0, 0).method_1344();
/* 337 */       buffer.method_22912((left + 4), top, 0.0D).method_22913(1.0F, 0.0F).method_1336(0, 0, 0, 0).method_1344();
/* 338 */       buffer.method_22912(left, top, 0.0D).method_22913(0.0F, 0.0F).method_1336(0, 0, 0, 255).method_1344();
/* 339 */       tessellator.method_1350();
/*     */     } 
/*     */ 
/*     */     
/* 343 */     int maxScroll = getMaxScroll();
/* 344 */     if (maxScroll > 0) {
/* 345 */       RenderSystem.disableTexture();
/* 346 */       int scrollbarHeight = (int)((getHeight() * getHeight()) / getMaxPosition());
/* 347 */       scrollbarHeight = class_3532.method_15340(scrollbarHeight, 32, getHeight() - 8);
/* 348 */       int scrollbarY = (int)getScrollAmount() * (getHeight() - scrollbarHeight) / maxScroll + getY();
/* 349 */       if (scrollbarY < getY()) {
/* 350 */         scrollbarY = getY();
/*     */       }
/*     */       
/* 353 */       renderScrollbar(tessellator, buffer, scrollbarPositionX, scrollBarEnd, scrollbarY, scrollbarHeight);
/*     */     } 
/*     */     
/* 356 */     getBorder().render(matrices, this, mouseX, mouseY, delta);
/*     */     
/* 358 */     RenderSystem.enableTexture();
/* 359 */     RenderSystem.shadeModel(7424);
/* 360 */     RenderSystem.enableAlphaTest();
/* 361 */     RenderSystem.disableBlend();
/*     */   }
/*     */   
/*     */   protected void renderScrollbar(class_289 tessellator, class_287 buffer, int scrollbarX, int scrollbarEndX, int scrollbarY, int scrollbarHeight) {
/* 365 */     buffer.method_1328(7, class_290.field_1575);
/* 366 */     buffer.method_22912(scrollbarX, (getY() + getHeight()), 0.0D).method_22913(0.0F, 1.0F).method_1336(0, 0, 0, 255).method_1344();
/* 367 */     buffer.method_22912(scrollbarEndX, (getY() + getHeight()), 0.0D).method_22913(1.0F, 1.0F).method_1336(0, 0, 0, 255).method_1344();
/* 368 */     buffer.method_22912(scrollbarEndX, getY(), 0.0D).method_22913(1.0F, 0.0F).method_1336(0, 0, 0, 255).method_1344();
/* 369 */     buffer.method_22912(scrollbarX, getY(), 0.0D).method_22913(0.0F, 0.0F).method_1336(0, 0, 0, 255).method_1344();
/* 370 */     buffer.method_22912(scrollbarX, (scrollbarY + scrollbarHeight), 0.0D).method_22913(0.0F, 1.0F).method_1336(128, 128, 128, 255).method_1344();
/* 371 */     buffer.method_22912(scrollbarEndX, (scrollbarY + scrollbarHeight), 0.0D).method_22913(1.0F, 1.0F).method_1336(128, 128, 128, 255).method_1344();
/* 372 */     buffer.method_22912(scrollbarEndX, scrollbarY, 0.0D).method_22913(1.0F, 0.0F).method_1336(128, 128, 128, 255).method_1344();
/* 373 */     buffer.method_22912(scrollbarX, scrollbarY, 0.0D).method_22913(0.0F, 0.0F).method_1336(128, 128, 128, 255).method_1344();
/* 374 */     buffer.method_22912(scrollbarX, (scrollbarY + scrollbarHeight - 1), 0.0D).method_22913(0.0F, 1.0F).method_1336(192, 192, 192, 255).method_1344();
/* 375 */     buffer.method_22912((scrollbarEndX - 1), (scrollbarY + scrollbarHeight - 1), 0.0D).method_22913(1.0F, 1.0F).method_1336(192, 192, 192, 255).method_1344();
/* 376 */     buffer.method_22912((scrollbarEndX - 1), scrollbarY, 0.0D).method_22913(1.0F, 0.0F).method_1336(192, 192, 192, 255).method_1344();
/* 377 */     buffer.method_22912(scrollbarX, scrollbarY, 0.0D).method_22913(0.0F, 0.0F).method_1336(192, 192, 192, 255).method_1344();
/* 378 */     tessellator.method_1350();
/*     */   }
/*     */ 
/*     */   
/*     */   @Environment(EnvType.CLIENT)
/*     */   class Entries
/*     */     extends AbstractList<E>
/*     */   {
/* 386 */     private final List<E> entries = Lists.newArrayList();
/*     */ 
/*     */     
/*     */     public E get(int i) {
/* 390 */       return this.entries.get(i);
/*     */     }
/*     */     
/*     */     public int size() {
/* 394 */       return this.entries.size();
/*     */     }
/*     */     
/*     */     public E set(int i, E entry) {
/* 398 */       SpruceEntryListWidget.Entry entry1 = (SpruceEntryListWidget.Entry)this.entries.set(i, entry);
/* 399 */       recomputePositions();
/* 400 */       SpruceEntryListWidget.this.setOwnerShip(entry);
/* 401 */       return (E)entry1;
/*     */     }
/*     */     
/*     */     public void add(int i, E entry) {
/* 405 */       this.entries.add(i, entry);
/* 406 */       recomputePositions();
/* 407 */       SpruceEntryListWidget.this.setOwnerShip(entry);
/*     */     }
/*     */     
/*     */     public E remove(int i) {
/* 411 */       SpruceEntryListWidget.Entry entry = (SpruceEntryListWidget.Entry)this.entries.remove(i);
/* 412 */       recomputePositions();
/* 413 */       return (E)entry;
/*     */     }
/*     */     
/*     */     private void recomputePositions() {
/* 417 */       int y = 0;
/* 418 */       for (SpruceEntryListWidget.Entry entry : this.entries) {
/* 419 */         entry.getPosition().setRelativeY(y);
/* 420 */         y += entry.getHeight();
/*     */       } 
/*     */     }
/*     */     
/*     */     private Entries() {}
/*     */   }
/*     */   
/*     */   public static abstract class Entry extends AbstractSpruceWidget {
/*     */     public Entry() {
/* 429 */       super(Position.origin());
/*     */     }
/*     */     
/*     */     protected void setVisibleInList(boolean visible) {
/* 433 */       this.visibleInList = visible;
/*     */     }
/*     */     private boolean visibleInList = false;
/*     */     
/*     */     public boolean isVisible() {
/* 438 */       return (super.isVisible() && this.visibleInList);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\widget\container\SpruceEntryListWidget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */