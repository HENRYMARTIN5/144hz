/*    */ package me.lambdaurora.spruceui.option;
/*    */ 
/*    */ import java.util.function.Consumer;
/*    */ import java.util.function.Supplier;
/*    */ import me.lambdaurora.spruceui.Position;
/*    */ import me.lambdaurora.spruceui.widget.AbstractSpruceBooleanButtonWidget;
/*    */ import me.lambdaurora.spruceui.widget.SpruceToggleSwitch;
/*    */ import me.lambdaurora.spruceui.widget.SpruceWidget;
/*    */ import net.minecraft.class_2561;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpruceToggleBooleanOption
/*    */   extends SpruceBooleanOption
/*    */ {
/*    */   public SpruceToggleBooleanOption(String key, Supplier<Boolean> getter, Consumer<Boolean> setter, @Nullable class_2561 tooltip) {
/* 32 */     super(key, getter, setter, tooltip, false);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SpruceWidget createWidget(Position position, int width) {
/* 40 */     SpruceToggleSwitch button = new SpruceToggleSwitch(position, width, 20, getDisplayText(), (btn, newValue) -> { set(); btn.setMessage(getDisplayText()); }get());
/* 41 */     getOptionTooltip().ifPresent(button::setTooltip);
/* 42 */     return (SpruceWidget)button;
/*    */   }
/*    */ 
/*    */   
/*    */   public class_2561 getDisplayText() {
/* 47 */     return getPrefix();
/*    */   }
/*    */ 
/*    */   
/*    */   public class_2561 getDisplayText(class_2561 value) {
/* 52 */     return getPrefix();
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\option\SpruceToggleBooleanOption.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */