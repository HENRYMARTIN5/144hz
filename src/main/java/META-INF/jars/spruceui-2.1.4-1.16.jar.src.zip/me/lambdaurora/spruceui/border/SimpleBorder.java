/*     */ package me.lambdaurora.spruceui.border;
/*     */ 
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import java.util.Arrays;
/*     */ import me.lambdaurora.spruceui.util.ColorUtil;
/*     */ import me.lambdaurora.spruceui.widget.SpruceWidget;
/*     */ import net.minecraft.class_287;
/*     */ import net.minecraft.class_289;
/*     */ import net.minecraft.class_290;
/*     */ import net.minecraft.class_4587;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SimpleBorder
/*     */   extends Border
/*     */ {
/*  30 */   public static final SimpleBorder SIMPLE_BORDER = new SimpleBorder(1, 192, 192, 192, 255);
/*     */   
/*     */   private final int thickness;
/*     */   private final int[] color;
/*     */   private final int[] focusedColor;
/*     */   
/*     */   public SimpleBorder(int thickness, int color) {
/*  37 */     this(thickness, color, color);
/*     */   }
/*     */   
/*     */   public SimpleBorder(int thickness, int color, int focusedColor) {
/*  41 */     this.thickness = thickness;
/*  42 */     this.color = ColorUtil.unpackARGBColor(color);
/*  43 */     this.focusedColor = ColorUtil.unpackARGBColor(focusedColor);
/*     */   }
/*     */   
/*     */   public SimpleBorder(int thickness, int red, int green, int blue, int alpha) {
/*  47 */     this(thickness, red, green, blue, alpha, red, green, blue, alpha);
/*     */   }
/*     */   
/*     */   public SimpleBorder(int thickness, int red, int green, int blue, int alpha, int focusedRed, int focusedGreen, int focusedBlue, int focusedAlpha) {
/*  51 */     this.thickness = thickness;
/*  52 */     this.color = new int[] { red, green, blue, alpha };
/*  53 */     this.focusedColor = new int[] { focusedRed, focusedGreen, focusedBlue, focusedAlpha };
/*     */   }
/*     */ 
/*     */   
/*     */   public void render(class_4587 matrices, SpruceWidget widget, int mouseX, int mouseY, float delta) {
/*  58 */     RenderSystem.disableTexture();
/*     */     
/*  60 */     class_289 tessellator = class_289.method_1348();
/*  61 */     class_287 buffer = tessellator.method_1349();
/*  62 */     buffer.method_1328(7, class_290.field_1576);
/*  63 */     int x = widget.getX();
/*  64 */     int y = widget.getY();
/*  65 */     int right = x + widget.getWidth();
/*  66 */     int bottom = y + widget.getHeight();
/*  67 */     boolean focused = widget.isFocused();
/*     */     
/*  69 */     vertex(buffer, x, y + this.thickness, focused);
/*  70 */     vertex(buffer, right, y + this.thickness, focused);
/*  71 */     vertex(buffer, right, y, focused);
/*  72 */     vertex(buffer, x, y, focused);
/*     */     
/*  74 */     vertex(buffer, right - this.thickness, bottom, focused);
/*  75 */     vertex(buffer, right, bottom, focused);
/*  76 */     vertex(buffer, right, y, focused);
/*  77 */     vertex(buffer, right - this.thickness, y, focused);
/*     */     
/*  79 */     vertex(buffer, x, bottom, focused);
/*  80 */     vertex(buffer, right, bottom, focused);
/*  81 */     vertex(buffer, right, bottom - this.thickness, focused);
/*  82 */     vertex(buffer, x, bottom - this.thickness, focused);
/*     */     
/*  84 */     vertex(buffer, x, bottom, focused);
/*  85 */     vertex(buffer, x + this.thickness, bottom, focused);
/*  86 */     vertex(buffer, x + this.thickness, y, focused);
/*  87 */     vertex(buffer, x, y, focused);
/*  88 */     tessellator.method_1350();
/*     */     
/*  90 */     RenderSystem.enableTexture();
/*     */   }
/*     */   
/*     */   private void vertex(class_287 buffer, int x, int y, boolean focused) {
/*  94 */     int[] color = focused ? this.focusedColor : this.color;
/*  95 */     buffer.method_22912(x, y, 0.0D).method_1336(color[0], color[1], color[2], color[3]).method_1344();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getThickness() {
/* 100 */     return this.thickness;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 105 */     return "SimpleBorder{thickness=" + this.thickness + ", color=" + 
/*     */       
/* 107 */       Arrays.toString(this.color) + ", focusedColor=" + 
/* 108 */       Arrays.toString(this.focusedColor) + '}';
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\border\SimpleBorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */