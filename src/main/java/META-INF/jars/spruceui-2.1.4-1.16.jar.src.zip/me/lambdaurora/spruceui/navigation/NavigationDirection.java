/*    */ package me.lambdaurora.spruceui.navigation;
/*    */ 
/*    */ import java.util.Optional;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum NavigationDirection
/*    */ {
/* 24 */   LEFT,
/* 25 */   RIGHT,
/* 26 */   UP,
/* 27 */   DOWN;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isHorizontal() {
/* 35 */     return (this == LEFT || this == RIGHT);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isVertical() {
/* 44 */     return (this == UP || this == DOWN);
/*    */   }
/*    */   
/*    */   public boolean isLookingForward() {
/* 48 */     return (this == DOWN || this == RIGHT);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Optional<NavigationDirection> fromKey(int keyCode, boolean shift) {
/* 59 */     if (shift && keyCode != 258)
/* 60 */       return Optional.empty(); 
/* 61 */     switch (keyCode) {
/*    */       case 263:
/* 63 */         return Optional.of(LEFT);
/*    */       case 262:
/* 65 */         return Optional.of(RIGHT);
/*    */       case 265:
/* 67 */         return Optional.of(UP);
/*    */       case 258:
/* 69 */         if (shift)
/* 70 */           return Optional.of(UP); 
/*    */       case 264:
/* 72 */         return Optional.of(DOWN);
/*    */     } 
/* 74 */     return Optional.empty();
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\navigation\NavigationDirection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */