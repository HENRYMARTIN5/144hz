/*     */ package me.lambdaurora.spruceui;
/*     */ 
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_2588;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SpruceTexts
/*     */ {
/*  29 */   public static final class_2561 CHAT_LINK_OPEN = (class_2561)new class_2588("chat.link.open");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  37 */   public static final class_2561 CONTROLS_RESET = (class_2561)new class_2588("controls.reset");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  44 */   public static final class_2561 CONTROLS_RESET_ALL = (class_2561)new class_2588("controls.resetAll");
/*     */   
/*  46 */   public static final class_2561 GUI_DONE = (class_2561)new class_2588("gui.done");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   public static final class_2561 GUI_NONE = (class_2561)new class_2588("gui.none");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   public static final class_2561 GUI_UNBIND = (class_2561)new class_2588("spruceui.gui.unbind");
/*     */   
/*  62 */   public static final class_2561 MENU_OPTIONS = (class_2561)new class_2588("menu.options");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   public static final class_2561 NOT_BOUND = (class_2561)new class_2588("key.keyboard.unknown");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   public static final class_2561 OPTIONS_GENERIC_DEFAULT = (class_2561)new class_2588("generator.default");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  79 */   public static final class_2561 OPTIONS_GENERIC_FANCY = (class_2561)new class_2588("spruceui.options.generic.fancy");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   public static final class_2561 OPTIONS_GENERIC_FAST = (class_2561)new class_2588("spruceui.options.generic.fast");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   public static final class_2561 OPTIONS_GENERIC_FASTEST = (class_2561)new class_2588("spruceui.options.generic.fastest");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  94 */   public static final class_2561 OPTIONS_GENERIC_SIMPLE = (class_2561)new class_2588("spruceui.options.generic.simple");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  99 */   public static final class_2561 OPTIONS_ON = (class_2561)new class_2588("options.on");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 104 */   public static final class_2561 OPTIONS_OFF = (class_2561)new class_2588("options.off");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class_2561 getToggleText(boolean value) {
/* 113 */     return value ? OPTIONS_ON : OPTIONS_OFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 119 */   public static final class_2561 OPTIONS_VISIBLE = (class_2561)new class_2588("options.visible");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 124 */   public static final class_2561 OPTIONS_HIDDEN = (class_2561)new class_2588("options.hidden");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 129 */   public static final class_2561 RESET_TEXT = (class_2561)new class_2588("spruceui.reset");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class_2561 getNarratorControlsReset(@NotNull class_2561 bindingName) {
/* 140 */     return (class_2561)new class_2588("narrator.controls.reset", new Object[] { bindingName });
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\SpruceTexts.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */