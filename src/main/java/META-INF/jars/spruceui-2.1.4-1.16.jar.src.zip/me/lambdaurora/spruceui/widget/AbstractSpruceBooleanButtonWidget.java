/*    */ package me.lambdaurora.spruceui.widget;
/*    */ 
/*    */ import me.lambdaurora.spruceui.Position;
/*    */ import net.minecraft.class_2561;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractSpruceBooleanButtonWidget
/*    */   extends AbstractSprucePressableButtonWidget
/*    */ {
/*    */   private static final PressAction DEFAULT_ACTION = (button, newValue) -> {
/*    */     
/*    */     };
/*    */   private final PressAction action;
/*    */   private boolean value;
/*    */   protected boolean showMessage;
/*    */   
/*    */   public AbstractSpruceBooleanButtonWidget(@NotNull Position position, int width, int height, @NotNull class_2561 message, boolean value) {
/* 32 */     this(position, width, height, message, value, true);
/*    */   }
/*    */ 
/*    */   
/*    */   public AbstractSpruceBooleanButtonWidget(@NotNull Position position, int width, int height, @NotNull class_2561 message, boolean value, boolean showMessage) {
/* 37 */     this(position, width, height, message, DEFAULT_ACTION, value, showMessage);
/*    */   }
/*    */   
/*    */   public AbstractSpruceBooleanButtonWidget(@NotNull Position position, int width, int height, @NotNull class_2561 message, @NotNull PressAction action, boolean value) {
/* 41 */     this(position, width, height, message, action, value, true);
/*    */   }
/*    */ 
/*    */   
/*    */   public AbstractSpruceBooleanButtonWidget(@NotNull Position position, int width, int height, @NotNull class_2561 message, @NotNull PressAction action, boolean value, boolean showMessage) {
/* 46 */     super(position, width, height, message);
/* 47 */     this.action = action;
/* 48 */     this.value = value;
/* 49 */     this.showMessage = showMessage;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean getValue() {
/* 58 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onPress() {
/* 63 */     this.value = !this.value;
/* 64 */     this.action.onPress(this, this.value);
/*    */   }
/*    */   
/*    */   public static interface PressAction {
/*    */     void onPress(AbstractSpruceBooleanButtonWidget param1AbstractSpruceBooleanButtonWidget, boolean param1Boolean);
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\widget\AbstractSpruceBooleanButtonWidget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */