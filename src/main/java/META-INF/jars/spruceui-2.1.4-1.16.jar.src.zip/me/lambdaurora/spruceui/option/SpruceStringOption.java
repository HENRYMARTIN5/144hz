/*    */ package me.lambdaurora.spruceui.option;
/*    */ 
/*    */ import java.util.function.Consumer;
/*    */ import java.util.function.Predicate;
/*    */ import java.util.function.Supplier;
/*    */ import me.lambdaurora.spruceui.Position;
/*    */ import me.lambdaurora.spruceui.widget.SpruceWidget;
/*    */ import me.lambdaurora.spruceui.widget.text.SpruceNamedTextFieldWidget;
/*    */ import me.lambdaurora.spruceui.widget.text.SpruceTextFieldWidget;
/*    */ import net.minecraft.class_2561;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpruceStringOption
/*    */   extends SpruceOption
/*    */ {
/*    */   private final Supplier<String> getter;
/*    */   private final Consumer<String> setter;
/*    */   @Nullable
/*    */   private final Predicate<String> predicate;
/*    */   
/*    */   public SpruceStringOption(String key, Supplier<String> getter, Consumer<String> setter, @Nullable Predicate<String> predicate, @Nullable class_2561 tooltip) {
/* 36 */     super(key);
/* 37 */     this.getter = getter;
/* 38 */     this.setter = setter;
/* 39 */     this.predicate = predicate;
/* 40 */     setTooltip(tooltip);
/*    */   }
/*    */ 
/*    */   
/*    */   public SpruceWidget createWidget(Position position, int width) {
/* 45 */     SpruceTextFieldWidget textField = new SpruceTextFieldWidget(position, width, 20, getPrefix());
/* 46 */     textField.setText(get());
/* 47 */     if (this.predicate != null)
/* 48 */       textField.setTextPredicate(this.predicate); 
/* 49 */     textField.setChangedListener(this::set);
/* 50 */     getOptionTooltip().ifPresent(textField::setTooltip);
/* 51 */     return (SpruceWidget)new SpruceNamedTextFieldWidget(textField);
/*    */   }
/*    */   
/*    */   public void set(String value) {
/* 55 */     this.setter.accept(value);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String get() {
/* 64 */     return this.getter.get();
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\option\SpruceStringOption.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */