/*    */ package me.lambdaurora.spruceui.widget.option;
/*    */ 
/*    */ import me.lambdaurora.spruceui.Position;
/*    */ import me.lambdaurora.spruceui.option.SpruceDoubleOption;
/*    */ import me.lambdaurora.spruceui.widget.SpruceSliderWidget;
/*    */ import net.minecraft.class_2585;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpruceOptionSliderWidget
/*    */   extends SpruceSliderWidget
/*    */ {
/*    */   private final SpruceDoubleOption option;
/*    */   
/*    */   public SpruceOptionSliderWidget(Position position, int width, int height, @NotNull SpruceDoubleOption option) {
/* 29 */     super(position, width, height, class_2585.field_24366, option.getRatio(option.get()), slider -> option.set(option.getValue(slider.getValue())));
/* 30 */     this.option = option;
/* 31 */     updateMessage();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void updateMessage() {
/* 36 */     if (this.option != null)
/* 37 */       setMessage(this.option.getDisplayString()); 
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\widget\option\SpruceOptionSliderWidget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */