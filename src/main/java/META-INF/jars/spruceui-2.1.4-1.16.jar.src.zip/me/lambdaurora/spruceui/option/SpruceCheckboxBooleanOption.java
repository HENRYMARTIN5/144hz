/*    */ package me.lambdaurora.spruceui.option;
/*    */ 
/*    */ import java.util.function.Consumer;
/*    */ import java.util.function.Supplier;
/*    */ import me.lambdaurora.spruceui.Position;
/*    */ import me.lambdaurora.spruceui.widget.AbstractSpruceBooleanButtonWidget;
/*    */ import me.lambdaurora.spruceui.widget.SpruceCheckboxWidget;
/*    */ import me.lambdaurora.spruceui.widget.SpruceWidget;
/*    */ import net.minecraft.class_2561;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpruceCheckboxBooleanOption
/*    */   extends SpruceBooleanOption
/*    */ {
/*    */   public SpruceCheckboxBooleanOption(String key, Supplier<Boolean> getter, Consumer<Boolean> setter, @Nullable class_2561 tooltip) {
/* 33 */     super(key, getter, setter, tooltip);
/*    */   }
/*    */   
/*    */   public SpruceCheckboxBooleanOption(String key, Supplier<Boolean> getter, Consumer<Boolean> setter, @Nullable class_2561 tooltip, boolean colored) {
/* 37 */     super(key, getter, setter, tooltip, colored);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SpruceWidget createWidget(Position position, int width) {
/* 45 */     SpruceCheckboxWidget button = new SpruceCheckboxWidget(position, width, 20, getDisplayText(), (btn, newValue) -> { set(); btn.setMessage(getDisplayText()); }get());
/* 46 */     button.setColored(isColored());
/* 47 */     getOptionTooltip().ifPresent(button::setTooltip);
/* 48 */     return (SpruceWidget)button;
/*    */   }
/*    */ 
/*    */   
/*    */   public class_2561 getDisplayText() {
/* 53 */     return getPrefix();
/*    */   }
/*    */ 
/*    */   
/*    */   public class_2561 getDisplayText(@NotNull class_2561 value) {
/* 58 */     return getPrefix();
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\option\SpruceCheckboxBooleanOption.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */