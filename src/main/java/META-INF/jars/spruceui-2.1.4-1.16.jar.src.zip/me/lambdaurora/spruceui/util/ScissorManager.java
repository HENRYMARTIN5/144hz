/*     */ package me.lambdaurora.spruceui.util;
/*     */ 
/*     */ import it.unimi.dsi.fastutil.doubles.DoubleArrayList;
/*     */ import it.unimi.dsi.fastutil.doubles.DoubleList;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Deque;
/*     */ import net.minecraft.class_1041;
/*     */ import net.minecraft.class_310;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ScissorManager
/*     */ {
/*  29 */   private static final Deque<ScissorHandle> SCISSOR_STACK = new ArrayDeque<>();
/*  30 */   private static final DoubleList SCALE_FACTOR_STACK = (DoubleList)new DoubleArrayList();
/*     */   
/*     */   private ScissorManager() {
/*  33 */     throw new UnsupportedOperationException("ScissorManager only contains static definitions.");
/*     */   }
/*     */   
/*     */   public static void pushScaleFactor(double scaleFactor) {
/*  37 */     SCALE_FACTOR_STACK.add(scaleFactor);
/*     */   }
/*     */   
/*     */   public static void pushScaleFactorMultiplier(double scaleFactor) {
/*  41 */     pushScaleFactor(scaleFactor * getCurrentScaleFactor());
/*     */   }
/*     */   
/*     */   public static void popScaleFactor() {
/*  45 */     if (SCALE_FACTOR_STACK.size() == 0)
/*     */       return; 
/*  47 */     SCALE_FACTOR_STACK.removeDouble(SCALE_FACTOR_STACK.size() - 1);
/*     */   }
/*     */   
/*     */   public static double getCurrentScaleFactor() {
/*  51 */     if (SCALE_FACTOR_STACK.size() == 0)
/*  52 */       return 1.0D; 
/*  53 */     return SCALE_FACTOR_STACK.getDouble(SCALE_FACTOR_STACK.size() - 1);
/*     */   }
/*     */   
/*     */   public static void push(int x, int y, int width, int height, double scaleFactor) {
/*  57 */     pushScaleFactor(scaleFactor);
/*  58 */     push(x, y, width, height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void push(int x, int y, int width, int height) {
/*  70 */     if (SCISSOR_STACK.isEmpty())
/*  71 */       GL11.glEnable(3089); 
/*  72 */     double scaleFactor = getCurrentScaleFactor();
/*  73 */     ScissorHandle handle = new ScissorHandle((int)(scaleFactor * x), adaptY(y, height, scaleFactor), (int)(scaleFactor * width), (int)(scaleFactor * height));
/*     */     
/*  75 */     handle.apply();
/*  76 */     SCISSOR_STACK.push(handle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void pop() {
/*  83 */     SCISSOR_STACK.pop();
/*  84 */     if (SCISSOR_STACK.isEmpty()) {
/*  85 */       GL11.glDisable(3089);
/*     */     } else {
/*  87 */       ((ScissorHandle)SCISSOR_STACK.getFirst()).apply();
/*     */     } 
/*     */   }
/*     */   
/*     */   private static int adaptY(int y, int height, double scaleFactor) {
/*  92 */     class_1041 window = class_310.method_1551().method_22683();
/*  93 */     int tmpHeight = (int)(window.method_4506() / scaleFactor);
/*  94 */     int scaledHeight = (window.method_4506() / scaleFactor > tmpHeight) ? (tmpHeight + 1) : tmpHeight;
/*  95 */     return (int)(scaleFactor * (scaledHeight - height - y));
/*     */   }
/*     */   
/*     */   static class ScissorHandle {
/*     */     int x;
/*     */     int y;
/*     */     int width;
/*     */     int height;
/*     */     
/*     */     public ScissorHandle(int x, int y, int width, int height) {
/* 105 */       this.x = x;
/* 106 */       this.y = y;
/* 107 */       this.width = width;
/* 108 */       this.height = height;
/*     */     }
/*     */     
/*     */     void apply() {
/* 112 */       GL11.glScissor(this.x, this.y, this.width, this.height);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceu\\util\ScissorManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */