/*     */ package me.lambdaurora.spruceui;
/*     */ 
/*     */ import com.google.common.collect.Queues;
/*     */ import java.util.List;
/*     */ import java.util.Queue;
/*     */ import java.util.function.Consumer;
/*     */ import me.lambdaurora.spruceui.widget.SpruceWidget;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_332;
/*     */ import net.minecraft.class_437;
/*     */ import net.minecraft.class_4587;
/*     */ import net.minecraft.class_5348;
/*     */ import net.minecraft.class_5481;
/*     */ import org.jetbrains.annotations.ApiStatus.Internal;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Tooltip
/*     */   extends class_332
/*     */   implements SprucePositioned
/*     */ {
/*  35 */   private static final Queue<Tooltip> TOOLTIPS = Queues.newConcurrentLinkedQueue();
/*     */   private static boolean delayed = false;
/*     */   private final int x;
/*     */   private final int y;
/*     */   private final List<class_5481> tooltip;
/*     */   
/*     */   public Tooltip(int x, int y, @NotNull String tooltip, int parentWidth) {
/*  42 */     this(x, y, class_5348.method_29430(tooltip), parentWidth);
/*     */   }
/*     */   
/*     */   public Tooltip(int x, int y, @NotNull class_5348 tooltip, int parentWidth) {
/*  46 */     this(x, y, (class_310.method_1551()).field_1772.method_1728(tooltip, Math.max(parentWidth * 2 / 3, 200)));
/*     */   }
/*     */   
/*     */   public Tooltip(int x, int y, @NotNull List<class_5481> tooltip) {
/*  50 */     this.x = x;
/*  51 */     this.y = y;
/*  52 */     this.tooltip = tooltip;
/*     */   }
/*     */   @NotNull
/*     */   public static Tooltip create(int x, int y, @NotNull String tooltip, int parentWidth) {
/*  56 */     return new Tooltip(x, y, tooltip, parentWidth);
/*     */   }
/*     */   @NotNull
/*     */   public static Tooltip create(int x, int y, @NotNull class_5348 tooltip, int parentWidth) {
/*  60 */     return new Tooltip(x, y, tooltip, parentWidth);
/*     */   }
/*     */   @NotNull
/*     */   public static Tooltip create(int x, int y, @NotNull List<class_5481> tooltip) {
/*  64 */     return new Tooltip(x, y, tooltip);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getX() {
/*  69 */     return this.x;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getY() {
/*  74 */     return this.y;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean shouldRender() {
/*  83 */     return !this.tooltip.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void render(class_437 screen, class_4587 matrices) {
/*  93 */     screen.method_25417(matrices, this.tooltip, this.x, this.y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void queue() {
/* 100 */     TOOLTIPS.add(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Tooltipable & SpruceWidget> void queueFor(@NotNull T widget, int mouseX, int mouseY, int tooltipTicks, @NotNull Consumer<Integer> tooltipTicksSetter, long lastTick, @NotNull Consumer<Long> lastTickSetter) {
/* 113 */     if (((SpruceWidget)widget).isVisible()) {
/* 114 */       widget.getTooltip().ifPresent(tooltip -> {
/*     */             long currentRender = System.currentTimeMillis();
/*     */             if (lastTick != 0L) {
/*     */               if (currentRender - lastTick >= 20L) {
/*     */                 tooltipTicksSetter.accept(Integer.valueOf(tooltipTicks + 1));
/*     */                 lastTickSetter.accept(Long.valueOf(currentRender));
/*     */               } 
/*     */             } else {
/*     */               lastTickSetter.accept(Long.valueOf(currentRender));
/*     */             } 
/*     */             if (!((SpruceWidget)widget).isFocused() && !((SpruceWidget)widget).isMouseHovered()) {
/*     */               tooltipTicksSetter.accept(Integer.valueOf(0));
/*     */             }
/*     */             if (!tooltip.getString().isEmpty() && tooltipTicks >= 45) {
/*     */               List<class_5481> wrappedTooltipText = (class_310.method_1551()).field_1772.method_1728((class_5348)tooltip, Math.max(((SpruceWidget)widget).getWidth() * 2 / 3, 200));
/*     */               if (((SpruceWidget)widget).isMouseHovered()) {
/*     */                 create(mouseX, mouseY, wrappedTooltipText).queue();
/*     */               } else if (((SpruceWidget)widget).isFocused()) {
/*     */                 create(((SpruceWidget)widget).getX() - 12, ((SpruceWidget)widget).getY() + 12 + wrappedTooltipText.size() * 10, wrappedTooltipText).queue();
/*     */               } 
/*     */             } 
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal
/*     */   static void setDelayedRender(boolean delayed) {
/* 144 */     Tooltip.delayed = delayed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static void renderAll(class_4587 matrices) {
/* 155 */     class_437 screen = (class_310.method_1551()).field_1755;
/* 156 */     if (screen != null) {
/* 157 */       renderAll(screen, matrices);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void renderAll(class_437 screen, class_4587 matrices) {
/* 168 */     if (delayed)
/*     */       return; 
/* 170 */     synchronized (TOOLTIPS) {
/*     */       Tooltip tooltip;
/*     */       
/* 173 */       while ((tooltip = TOOLTIPS.poll()) != null)
/* 174 */         tooltip.render(screen, matrices); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\Tooltip.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */