/*    */ package me.lambdaurora.spruceui.widget;
/*    */ 
/*    */ import me.lambdaurora.spruceui.navigation.NavigationDirection;
/*    */ import net.minecraft.class_364;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface SpruceElement
/*    */   extends class_364
/*    */ {
/*    */   default boolean onNavigation(@NotNull NavigationDirection direction, boolean tab) {
/* 32 */     if (requiresCursor()) return false; 
/* 33 */     if (direction.isVertical()) {
/* 34 */       return method_25407((direction == NavigationDirection.DOWN));
/*    */     }
/* 36 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default boolean requiresCursor() {
/* 45 */     return false;
/*    */   }
/*    */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\widget\SpruceElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */