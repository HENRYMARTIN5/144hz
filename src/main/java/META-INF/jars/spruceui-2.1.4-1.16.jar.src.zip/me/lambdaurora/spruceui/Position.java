/*     */ package me.lambdaurora.spruceui;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import me.lambdaurora.spruceui.widget.SpruceWidget;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Position
/*     */   implements SprucePositioned
/*     */ {
/*     */   private SprucePositioned anchor;
/*  25 */   private int x = 0;
/*  26 */   private int y = 0;
/*     */   
/*     */   protected Position(SprucePositioned anchor) {
/*  29 */     this.anchor = anchor;
/*     */   }
/*     */   
/*     */   public static Position of(SprucePositioned anchor, int x, int y) {
/*  33 */     return (new Position(anchor)).move(x, y);
/*     */   }
/*     */   
/*     */   public static Position of(int x, int y) {
/*  37 */     return of(origin(), x, y);
/*     */   }
/*     */   
/*     */   public static Position center(SpruceWidget parent, int y) {
/*  41 */     return center((SprucePositioned)parent, parent.getWidth(), y);
/*     */   }
/*     */   
/*     */   public static Position center(SprucePositioned anchor, int width, int y) {
/*  45 */     return of(anchor, width / 2, y);
/*     */   }
/*     */   
/*     */   public static Position center(int width, int y) {
/*  49 */     return of(width / 2, y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Position origin() {
/*  58 */     return new Position(new SprucePositioned()
/*     */         {
/*     */         
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SprucePositioned getAnchor() {
/*  68 */     return this.anchor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAnchor(SprucePositioned anchor) {
/*  77 */     this.anchor = anchor;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getX() {
/*  82 */     return this.anchor.getX() + this.x;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getY() {
/*  87 */     return this.anchor.getY() + this.y;
/*     */   }
/*     */   
/*     */   public Position move(int x, int y) {
/*  91 */     setRelativeX(x);
/*  92 */     setRelativeY(y);
/*  93 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRelativeX() {
/* 102 */     return this.x;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRelativeX(int x) {
/* 111 */     this.x = x;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRelativeY() {
/* 120 */     return this.y;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRelativeY(int y) {
/* 129 */     this.y = y;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Position copy() {
/* 138 */     return of(this.anchor, this.x, this.y);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 143 */     if (this == o) return true; 
/* 144 */     if (o == null || getClass() != o.getClass()) return false; 
/* 145 */     Position position = (Position)o;
/* 146 */     return (getX() == position.getX() && getY() == position.getY());
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 151 */     return Objects.hash(new Object[] { this.anchor, Integer.valueOf(this.x), Integer.valueOf(this.y) });
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 156 */     return "Position{anchor=" + this.anchor + ", x=" + this.x + ", y=" + this.y + '}';
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\Position.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */