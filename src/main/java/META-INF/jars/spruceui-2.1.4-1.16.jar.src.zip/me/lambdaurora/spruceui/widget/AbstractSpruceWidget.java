/*     */ package me.lambdaurora.spruceui.widget;
/*     */ 
/*     */ import java.util.Optional;
/*     */ import me.lambdaurora.spruceui.Position;
/*     */ import me.lambdaurora.spruceui.navigation.NavigationDirection;
/*     */ import net.minecraft.class_1109;
/*     */ import net.minecraft.class_1113;
/*     */ import net.minecraft.class_156;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_332;
/*     */ import net.minecraft.class_333;
/*     */ import net.minecraft.class_3417;
/*     */ import net.minecraft.class_4587;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractSpruceWidget
/*     */   extends class_332
/*     */   implements SpruceWidget
/*     */ {
/*  34 */   protected final class_310 client = class_310.method_1551();
/*     */   protected final Position position;
/*     */   private boolean visible;
/*     */   protected int width;
/*     */   protected int height;
/*     */   protected boolean active = true;
/*     */   protected boolean focused = false;
/*     */   protected boolean hovered = false;
/*     */   protected boolean wasHovered = false;
/*     */   protected boolean dragging = false;
/*  44 */   protected long lastDrag = 0L;
/*  45 */   private long nextNarration = 0L;
/*     */   
/*     */   public AbstractSpruceWidget(@NotNull Position position) {
/*  48 */     this.position = position;
/*  49 */     this.visible = true;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Position getPosition() {
/*  54 */     return this.position;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isVisible() {
/*  59 */     return this.visible;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setVisible(boolean visible) {
/*  64 */     this.visible = visible;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getWidth() {
/*  69 */     return this.width;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getHeight() {
/*  74 */     return this.height;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isActive() {
/*  79 */     return this.active;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setActive(boolean active) {
/*  84 */     this.active = active;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isMouseHovered() {
/*  89 */     return this.hovered;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFocused() {
/*  94 */     return this.focused;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFocused(boolean focused) {
/*  99 */     this.focused = focused;
/* 100 */     this.dragging = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDragging() {
/* 105 */     return this.dragging;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDragging(boolean dragging) {
/* 110 */     this.dragging = dragging;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean method_25407(boolean lookForwards) {
/* 117 */     return onNavigation(lookForwards ? NavigationDirection.DOWN : NavigationDirection.UP, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean onNavigation(@NotNull NavigationDirection direction, boolean tab) {
/* 122 */     if (requiresCursor()) return false; 
/* 123 */     if (isVisible() && isActive()) {
/* 124 */       setFocused(!isFocused());
/* 125 */       if (isFocused()) {
/* 126 */         queueNarration(200);
/*     */       }
/* 128 */       return isFocused();
/*     */     } 
/* 130 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean method_25402(double mouseX, double mouseY, int button) {
/* 137 */     if (!isActive() || !isVisible() || !method_25405(mouseX, mouseY)) {
/* 138 */       return false;
/*     */     }
/* 140 */     return onMouseClick(mouseX, mouseY, button);
/*     */   }
/*     */   
/*     */   protected boolean onMouseClick(double mouseX, double mouseY, int button) {
/* 144 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean method_25406(double mouseX, double mouseY, int button) {
/* 149 */     boolean result = onMouseRelease(mouseX, mouseY, button);
/* 150 */     if (result) this.dragging = false; 
/* 151 */     return result;
/*     */   }
/*     */   
/*     */   protected boolean onMouseRelease(double mouseX, double mouseY, int button) {
/* 155 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
/* 160 */     if (!isActive() || !isVisible()) {
/* 161 */       return false;
/*     */     }
/* 163 */     boolean result = onMouseDrag(mouseX, mouseY, button, deltaX, deltaY);
/* 164 */     if (result) {
/* 165 */       this.dragging = true;
/* 166 */       this.lastDrag = class_156.method_658();
/*     */     } 
/* 168 */     return result;
/*     */   }
/*     */   
/*     */   protected boolean onMouseDrag(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
/* 172 */     return false;
/*     */   }
/*     */   
/*     */   public boolean method_25401(double mouseX, double mouseY, double amount) {
/* 176 */     if (isActive() && isVisible() && method_25405(mouseX, mouseY)) {
/* 177 */       return onMouseScroll(mouseX, mouseY, amount);
/*     */     }
/* 179 */     return false;
/*     */   }
/*     */   
/*     */   protected boolean onMouseScroll(double mouseX, double mouseY, double amount) {
/* 183 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean method_25404(int keyCode, int scanCode, int modifiers) {
/* 188 */     if (isActive() && isVisible()) {
/* 189 */       return onKeyPress(keyCode, scanCode, modifiers);
/*     */     }
/* 191 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean onKeyPress(int keyCode, int scanCode, int modifiers) {
/* 203 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean method_16803(int keyCode, int scanCode, int modifiers) {
/* 208 */     if (isActive() && isVisible()) {
/* 209 */       return onKeyRelease(keyCode, scanCode, modifiers);
/*     */     }
/* 211 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean onKeyRelease(int keyCode, int scanCode, int modifiers) {
/* 227 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean method_25400(char chr, int keyCode) {
/* 232 */     if (isActive() && isVisible()) {
/* 233 */       return onCharTyped(chr, keyCode);
/*     */     }
/* 235 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean onCharTyped(char chr, int keyCode) {
/* 248 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void method_25394(class_4587 matrices, int mouseX, int mouseY, float delta) {
/* 255 */     if (isVisible()) {
/* 256 */       this.hovered = (mouseX >= getX() && mouseY >= getY() && mouseX < getX() + getWidth() && mouseY < getY() + getHeight());
/*     */       
/* 258 */       if (this.wasHovered != isMouseHovered()) {
/* 259 */         if (isMouseHovered())
/* 260 */         { if (isFocused()) {
/* 261 */             queueNarration(200);
/*     */           } else {
/* 263 */             queueNarration(750);
/*     */           }  }
/* 265 */         else { this.nextNarration = Long.MAX_VALUE; }
/*     */       
/*     */       }
/* 268 */       if (this.dragging && !isMouseHovered() && 
/* 269 */         class_156.method_658() - this.lastDrag > 60L) {
/* 270 */         this.dragging = false;
/*     */       }
/*     */ 
/*     */       
/* 274 */       renderBackground(matrices, mouseX, mouseY, delta);
/* 275 */       renderWidget(matrices, mouseX, mouseY, delta);
/*     */       
/* 277 */       narrate();
/* 278 */       this.wasHovered = isMouseHovered();
/*     */     } else {
/* 280 */       this.hovered = this.wasHovered = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void renderBackground(class_4587 matrices, int mouseX, int mouseY, float delta) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void playDownSound() {
/* 308 */     this.client.method_1483().method_4873((class_1113)class_1109.method_4758(class_3417.field_15015, 1.0F));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void narrate() {
/* 317 */     if (isActive() && isFocusedOrHovered() && class_156.method_658() > this.nextNarration && this.nextNarration != 0L) {
/* 318 */       getNarrationMessage().map(class_2561::getString).ifPresent(message -> {
/*     */             if (!message.isEmpty()) {
/*     */               class_333.field_2054.method_19788(message);
/*     */               this.nextNarration = Long.MAX_VALUE;
/*     */             } 
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   protected Optional<class_2561> getNarrationMessage() {
/* 333 */     return Optional.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void queueNarration(int delay) {
/* 342 */     this.nextNarration = class_156.method_658() + delay;
/*     */   }
/*     */   
/*     */   protected abstract void renderWidget(class_4587 paramclass_4587, int paramInt1, int paramInt2, float paramFloat);
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\widget\AbstractSpruceWidget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */