/*     */ package me.lambdaurora.spruceui.widget;
/*     */ 
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import me.lambdaurora.spruceui.Position;
/*     */ import net.minecraft.class_2477;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_2960;
/*     */ import net.minecraft.class_3532;
/*     */ import net.minecraft.class_4493;
/*     */ import net.minecraft.class_4587;
/*     */ import net.minecraft.class_5348;
/*     */ import net.minecraft.class_5481;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpruceCheckboxWidget
/*     */   extends AbstractSpruceBooleanButtonWidget
/*     */ {
/*  31 */   private static final class_2960 TEXTURE = new class_2960("spruceui", "textures/gui/checkbox.png");
/*     */   private boolean showCross = false;
/*     */   private boolean colored = false;
/*     */   
/*     */   public SpruceCheckboxWidget(@NotNull Position position, int width, int height, @NotNull class_2561 message, boolean value) {
/*  36 */     super(position, width, height, message, value);
/*     */   }
/*     */   
/*     */   public SpruceCheckboxWidget(@NotNull Position position, int width, int height, @NotNull class_2561 message, boolean value, boolean showMessage) {
/*  40 */     super(position, width, height, message, value, showMessage);
/*     */   }
/*     */   
/*     */   public SpruceCheckboxWidget(@NotNull Position position, int width, int height, @NotNull class_2561 message, @NotNull AbstractSpruceBooleanButtonWidget.PressAction action, boolean value) {
/*  44 */     super(position, width, height, message, action, value);
/*     */   }
/*     */   
/*     */   public SpruceCheckboxWidget(@NotNull Position position, int width, int height, @NotNull class_2561 message, @NotNull AbstractSpruceBooleanButtonWidget.PressAction action, boolean value, boolean showMessage) {
/*  48 */     super(position, width, height, message, action, value, showMessage);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean showCross() {
/*  57 */     return this.showCross;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setShowCross(boolean showCross) {
/*  66 */     this.showCross = showCross;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isColored() {
/*  75 */     return this.colored;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setColored(boolean colored) {
/*  84 */     this.colored = colored;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void renderButton(class_4587 matrices, int mouseX, int mouseY, float delta) {
/*  89 */     RenderSystem.enableDepthTest();
/*  90 */     RenderSystem.enableBlend();
/*  91 */     RenderSystem.defaultBlendFunc();
/*  92 */     RenderSystem.blendFunc(class_4493.class_4535.field_22541, class_4493.class_4534.field_22523);
/*  93 */     if (getValue()) {
/*  94 */       if (this.colored)
/*  95 */         RenderSystem.color4f(0.0F, 1.0F, 0.0F, this.alpha); 
/*  96 */       method_25290(matrices, getX(), getY(), 0.0F, 40.0F, getHeight(), getHeight(), 64, 64);
/*  97 */     } else if (this.showCross) {
/*  98 */       if (this.colored)
/*  99 */         RenderSystem.color4f(1.0F, 0.0F, 0.0F, this.alpha); 
/* 100 */       method_25290(matrices, getX(), getY(), 0.0F, 20.0F, getHeight(), getHeight(), 64, 64);
/*     */     } 
/*     */     
/* 103 */     if (this.showMessage) {
/* 104 */       class_5481 message = class_2477.method_10517().method_30934(this.client.field_1772.method_1714((class_5348)getMessage(), getWidth() - getHeight() - 4));
/* 105 */       this.client.field_1772.method_27517(matrices, message, (getX() + getHeight() + 4), getY() + (getHeight() - 8) / 2.0F, 0xE0E0E0 | 
/* 106 */           class_3532.method_15386(this.alpha * 255.0F) << 24);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void renderBackground(class_4587 matrices, int mouseX, int mouseY, float delta) {
/* 112 */     this.client.method_1531().method_22813(TEXTURE);
/* 113 */     RenderSystem.enableDepthTest();
/* 114 */     RenderSystem.color4f(1.0F, 1.0F, 1.0F, this.alpha);
/* 115 */     RenderSystem.enableBlend();
/* 116 */     RenderSystem.defaultBlendFunc();
/* 117 */     RenderSystem.blendFunc(class_4493.class_4535.field_22541, class_4493.class_4534.field_22523);
/* 118 */     method_25290(matrices, getX(), getY(), isFocusedOrHovered() ? 20.0F : 0.0F, 0.0F, getHeight(), getHeight(), 64, 64);
/*     */   }
/*     */ }


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\spruceui-2.1.4-1.16.jar!\me\lambdaurora\spruceui\widget\SpruceCheckboxWidget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */