package com.sun.jna.win32;

import com.sun.jna.Callback;

public interface DLLCallback extends Callback {
  public static final int DLL_FPTRS = 16;
}


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\discord-rpc-1.6.2.jar!\com\sun\jna\win32\DLLCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */