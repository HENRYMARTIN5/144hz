package net.arikia.dev.drpc.callbacks;

import com.sun.jna.Callback;

public interface ErroredCallback extends Callback {
  void apply(int paramInt, String paramString);
}


/* Location:              D:\reversingPhobos\144hz_build28.jar!\META-INF\jars\discord-rpc-1.6.2.jar!\net\arikia\dev\drpc\callbacks\ErroredCallback.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */